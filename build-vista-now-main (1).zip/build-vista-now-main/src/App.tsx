import { Suspense, lazy, ReactNode } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import { AdminAuthProvider } from "@/hooks/useAdminAuth";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { AdminProtectedRoute } from "@/components/AdminProtectedRoute";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { LanguageProvider } from "@/contexts/LanguageContext";
const ChatAssistant = lazy(() => import("./pages/ChatAssistant"));

import { HelmetProvider } from "react-helmet-async";
import { Helmet } from "react-helmet-async";



// Lazy load components
const Index = lazy(() => import("./pages/Index"));
const About = lazy(() => import("./pages/About"));
const Contact = lazy(() => import("./pages/Contact"));
const Auth = lazy(() => import("./pages/Auth"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));
const UserProfile = lazy(() => import("./pages/UserProfile"));
const UserDashboard = lazy(() => import("./pages/UserDashboard"));
const PostRequirement = lazy(() => import("./pages/PostRequirement"));
const MyRequirements = lazy(() => import("./pages/MyRequirements"));
const Notifications = lazy(() => import("./pages/Notifications"));
const ProfessionalsPage = lazy(() => import("./pages/ProfessionalsPage"));
const SearchResults = lazy(() => import("./pages/SearchResults"));
const BusinessRegistration = lazy(() => import("./pages/BusinessRegistration"));
const ProviderDashboard = lazy(() => import("./pages/ProviderDashboard"));
const ShopPortfolioSetup = lazy(() => import("./pages/ShopPortfolioSetup"));
const VendorShop = lazy(() => import("./pages/VendorShop"));
const ProfessionalPortfolio = lazy(() => import("./pages/ProfessionalPortfolio"));
const VendorShopManagement = lazy(() => import("./pages/VendorShopManagement"));
const NewProviderDashboard = lazy(() => import("./pages/NewProviderDashboard"));
const PortfolioManagementPage = lazy(() => import("./pages/PortfolioManagementPage"));
const SocialFeed = lazy(() => import("./pages/SocialFeed"));
const AdminLogin = lazy(() => import("./pages/AdminLogin"));
const AdminDashboard = lazy(() => import("./pages/AdminDashboard"));
const ProviderRequirements = lazy(() => import("./pages/ProviderRequirements"));
const ReferralPage = lazy(() => import("./pages/ReferralPage"));
const Subscription = lazy(() => import("./pages/Subscription"));
const PrivacyPolicy = lazy(() => import("./pages/PrivacyPolicy"));
const TermsAndConditions = lazy(() => import("./pages/TermsAndConditions"));
const NotFound = lazy(() => import("./pages/NotFound"));
// Add CustomerTracking component

const CustomerTracking = lazy(() => import("@/pages/CustomerTracking"));

const queryClient = new QueryClient();

// TypeScript interfaces
interface SEOProps {
  title: string;
  description: string;
  keywords?: string;
  canonical?: string;
  route?: string;
}

interface RouteConfig {
  title: string;
  description: string;
  keywords: string;
}

interface PublicRouteWrapperProps {
  children: ReactNode;
  routeProps: RouteConfig & { route?: string };
}

// JSON-LD Structured Data for Website and Organization
const StructuredData = () => (
  <script type="application/ld+json">
    {JSON.stringify({
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "WebSite",
          "@id": "https://www.buildonclicks.com/#website",
          "url": "https://www.buildonclicks.com/",
          "name": "BuildOnClicks",
          "description": "Connect with architects, civil engineers, contractors, and interior designers in Bhopal, India for construction projects and professional services.",
          "publisher": {
            "@id": "https://www.buildonclicks.com/#organization"
          },
          "potentialAction": [
            {
              "@type": "SearchAction",
              "target": {
                "@type": "EntryPoint",
                "urlTemplate": "https://www.buildonclicks.com/search?q={search_term_string}"
              },
              "query-input": "required name=search_term_string"
            }
          ]
        },
        {
          "@type": "Organization",
          "@id": "https://www.buildonclicks.com/#organization",
          "name": "BuildOnClicks",
          "url": "https://www.buildonclicks.com/",
          "logo": "https://www.buildonclicks.com/logo.png",
          "description": "BuildOnClicks connects construction professionals including architects, civil engineers, contractors, and interior designers in Bhopal, India.",
          "address": {
            "@type": "PostalAddress",
            "addressLocality": "Bhopal",
            "addressRegion": "Madhya Pradesh",
            "addressCountry": "India"
          },
          "sameAs": [
            "https://www.facebook.com/buildonclicks",
            "https://twitter.com/buildonclicks",
            "https://www.linkedin.com/company/buildonclicks"
          ]
        },
        {
          "@type": "LocalBusiness",
          "@id": "https://www.buildonclicks.com/#local-business",
          "name": "BuildOnClicks Bhopal",
          "image": "https://www.buildonclicks.com/logo.png",
          "url": "https://www.buildonclicks.com/",
          "telephone": "+91-XXXXXXXXXX",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Construction Professionals Hub",
            "addressLocality": "Bhopal",
            "addressRegion": "Madhya Pradesh",
            "postalCode": "462001",
            "addressCountry": "India"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": "23.2599",
            "longitude": "77.4126"
          },
          "openingHoursSpecification": [
            {
              "@type": "OpeningHoursSpecification",
              "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
              "opens": "09:00",
              "closes": "18:00"
            }
          ],
          "priceRange": "$$",
          "description": "BuildOnClicks connects architects, civil engineers, contractors, and interior designers in Bhopal, India for construction projects, professional services, and business collaboration."
        }
      ]
    })}
  </script>
);

// SEO Component for Public Pages with Local SEO Targeting
const SEO: React.FC<SEOProps> = ({ 
  title, 
  description, 
  keywords = "architects, civil engineers, contractors, interior designers, construction professionals, Bhopal, India, BuildOnClicks",
  canonical,
  route = ""
}) => {
  const baseUrl = "https://www.buildonclicks.com";
  const fullCanonical = canonical || `${baseUrl}${route}`;
  
  return (
    <Helmet prioritizeSeoTags>
      <title>{title} | BuildOnClicks</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      <link rel="canonical" href={fullCanonical} />
      
      {/* Open Graph Tags for Social Sharing */}
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={fullCanonical} />
      <meta property="og:type" content="website" />
      <meta property="og:locale" content="en_IN" />
      
      {/* Twitter Card Tags */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
    </Helmet>
  );
};

// Floating AI Button Component
const FloatingAIButton: React.FC = () => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate("/chat");
  };

  return (
    <button
      onClick={handleClick}
      className="floating-ai-button"
      aria-label="Open AI Chat Assistant"
      title="AI Chat Assistant"
    >
      <div className="ai-button-inner">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="ai-button-icon"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
          />
        </svg>
        {/* Animated pulsing dot */}
        <span className="ai-button-pulse">
          <span className="ai-button-pulse-outer"></span>
          <span className="ai-button-pulse-inner"></span>
        </span>
      </div>
      {/* Optional: Text label that appears on hover */}
      <span className="ai-button-label">AI Assistant</span>
    </button>
  );
};

// Public Route Wrapper with SEO Fallback Content
const PublicRouteWrapper: React.FC<PublicRouteWrapperProps> = ({ children, routeProps }) => {
  const { route, title, description, keywords } = routeProps;
  
  return (
    <>
      <SEO 
        title={title}
        description={description}
        keywords={keywords}
        route={route}
      />
      {children}
    </>
  );
};

// Fallback SEO content for Suspense loading state
interface SEOFallbackContentProps {
  routeName: string;
}

const SEOFallbackContent: React.FC<SEOFallbackContentProps> = ({ routeName }) => (
  <div style={{ display: 'none' }} aria-hidden="true">
    <h1>{routeName} | BuildOnClicks Bhopal</h1>
    <p>Connect with architects, civil engineers, contractors, and interior designers in Bhopal, India through BuildOnClicks - your construction professionals network.</p>
    <p>Find construction services, portfolio showcases, and professional connections in Bhopal's building industry.</p>
    <ul>
      <li>Architects in Bhopal</li>
      <li>Civil Engineers in Bhopal</li>
      <li>Construction Contractors in Bhopal</li>
      <li>Interior Designers in Bhopal</li>
      <li>Building Professionals Network</li>
    </ul>
  </div>
);

// Public Route Configuration with Local SEO Targeting
const publicRoutesConfig: Record<string, RouteConfig & { route?: string }> = {
  "/": {
    route: "/",
    title: "Construction Professionals Network",
    description: "Connect with architects, civil engineers, contractors, and interior designers in Bhopal, India. BuildOnClinks is your premier construction professionals network.",
    keywords: "construction professionals, architects Bhopal, civil engineers India, contractors, interior designers, building services, construction network"
  },
  "/about": {
    route: "/about",
    title: "About BuildOnClicks Construction Network",
    description: "Learn about BuildOnClicks - connecting architects, civil engineers, contractors, and interior designers in Bhopal, India for construction projects and professional growth.",
    keywords: "about construction network, architects platform, civil engineers community, contractors directory, interior designers Bhopal"
  },
  "/contact": {
    route: "/contact",
    title: "Contact Construction Professionals",
    description: "Get in touch with BuildOnClicks to connect with architects, civil engineers, contractors, and interior designers in Bhopal, India for your construction projects.",
    keywords: "contact construction professionals, architects contact, civil engineers support, contractors inquiry, interior designers Bhopal"
  },
  "/professionals": {
    route: "/professionals",
    title: "Find Construction Professionals in Bhopal",
    description: "Browse and connect with verified architects, civil engineers, contractors, and interior designers in Bhopal, India. Find the right professional for your construction project.",
    keywords: "find architects, civil engineers directory, contractors Bhopal, interior designers India, construction professionals search"
  },
  "/search": {
    route: "/search",
    title: "Search Construction Services",
    description: "Search for architects, civil engineers, contractors, and interior designers in Bhopal, India. Find construction services, portfolios, and professional expertise.",
    keywords: "search construction services, find architects Bhopal, locate civil engineers, contractor search, interior designers directory"
  },
  "/shop/:shopId": {
    title: "Vendor Shop Portfolio",
    description: "View construction material supplier shop portfolio. Connect with building material vendors, contractors, and suppliers in Bhopal, India.",
    keywords: "construction materials, building suppliers, vendor shop, contractors suppliers, building materials Bhopal"
  },
  "/portfolio/:professionalId": {
    title: "Professional Construction Portfolio",
    description: "View architect, civil engineer, contractor, or interior designer portfolio in Bhopal, India. See construction projects, expertise, and professional credentials.",
    keywords: "architect portfolio, civil engineer projects, contractor portfolio, interior designer work, construction showcase"
  },
  "/terms": {
    route: "/terms",
    title: "Terms of Service for Construction Professionals",
    description: "Terms and conditions for architects, civil engineers, contractors, and interior designers using BuildOnClicks construction network in Bhopal, India.",
    keywords: "terms for architects, civil engineers terms, contractors agreement, interior designers terms, construction platform terms"
  },
  "/privacy": {
    route: "/privacy",
    title: "Privacy Policy for Construction Network",
    description: "Privacy policy for architects, civil engineers, contractors, and interior designers using BuildOnClicks construction professionals network in Bhopal, India.",
    keywords: "privacy for architects, civil engineers privacy, contractors data, interior designers policy, construction network privacy"
  },
  "/customer": {
    route: "/customer",
    title: "Customer Tracking & Registration Management",
    description: "Track customer registration progress, follow-ups, and manage customer interactions. Monitor registration status, business categories, and daily call tracking.",
    keywords: "customer tracking, registration management, follow-up system, customer database, CRM, business tracking, client management"
  }
};

// Main App Component
const App: React.FC = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <HelmetProvider>
          <LanguageProvider>
            <AuthProvider>
              <AdminAuthProvider>
                <ErrorBoundary>
                  <Suspense fallback={
                    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <div className="loading-indicator">
                        <SEOFallbackContent routeName="BuildOnClicks Construction Network" />
                        <p>Loading BuildOnClicks Construction Professionals Network...</p>
                      </div>
                    </div>
                  }>
                    {/* Add Structured Data to all pages */}
                    <StructuredData />
                    
                    {/* Add CSS styles for the floating button */}
                    <style>{`
  .floating-ai-button {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 9999;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, #000000 0%, #333333 100%);
    border: none;
    cursor: pointer;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3),
                0 10px 40px rgba(0, 0, 0, 0.2);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    overflow: visible;
  }
  
  .floating-ai-button:hover {
    transform: scale(1.1);
    box-shadow: 0 6px 30px rgba(0, 0, 0, 0.4),
                0 15px 50px rgba(0, 0, 0, 0.3);
    background: linear-gradient(135deg, #111111 0%, #444444 100%);
    width: 140px;
    border-radius: 30px;
  }
  
  .floating-ai-button:active {
    transform: scale(0.95);
  }
  
  .floating-ai-button:focus {
    outline: none;
    ring: 2px solid rgba(255, 255, 255, 0.3);
    ring-offset: 2px;
  }
  
  .ai-button-inner {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
  }
  
  .ai-button-icon {
    width: 28px;
    height: 28px;
    color: white;
    transition: transform 0.3s ease;
  }
  
  .floating-ai-button:hover .ai-button-icon {
    transform: scale(1.1);
  }
  
  .ai-button-pulse {
    position: absolute;
    top: -2px;
    right: -2px;
    display: flex;
    width: 20px;
    height: 20px;
  }
  
  .ai-button-pulse-outer {
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-color: #10b981;
    animation: ai-pulse 2s infinite;
    opacity: 0.75;
  }
  
  .ai-button-pulse-inner {
    position: relative;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background-color: #10b981;
    top: 4px;
    left: 4px;
  }
  
  .ai-button-label {
    position: absolute;
    right: 70px;
    background: rgba(0, 0, 0, 0.9);
    color: white;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 500;
    white-space: nowrap;
    opacity: 0;
    transform: translateX(10px);
    transition: all 0.3s ease;
    pointer-events: none;
    border: 1px solid rgba(255, 255, 255, 0.1);
  }
  
  .floating-ai-button:hover .ai-button-label {
    opacity: 1;
    transform: translateX(0);
  }
  
  @keyframes ai-pulse {
    0% {
      transform: scale(0.95);
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);
    }
    70% {
      transform: scale(1.1);
      box-shadow: 0 0 0 10px rgba(16, 185, 129, 0);
    }
    100% {
      transform: scale(0.95);
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);
    }
  }
  
  /* Media query for mobile responsiveness */
  @media (max-width: 768px) {
    .floating-ai-button {
      bottom: 80px;
      right: 20px;
      width: 56px;
      height: 56px;
    }
    
    .ai-button-icon {
      width: 24px;
      height: 24px;
    }
    
    .floating-ai-button:hover {
      width: 56px;
      border-radius: 50%;
    }
    
    .floating-ai-button:hover .ai-button-label {
      display: none;
    }
  }
  
  /* Ensure button is above all other elements */
  .floating-ai-button {
    z-index: 99999 !important;
  }
  
  /* Loading indicator styles */
  .loading-indicator {
    text-align: center;
    padding: 2rem;
  }
  
  .loading-indicator p {
    margin-top: 1rem;
    color: #666;
    font-size: 1.1rem;
  }
`}</style>
                    {/* Floating AI Button - Placed here so it appears on all routes */}
                    <FloatingAIButton />
                    
                    <Routes>
                      {/* Public Routes with SEO Optimization */}
                      <Route path="/" element={
                        <PublicRouteWrapper routeProps={publicRoutesConfig["/"]}>
                          <Index />
                        </PublicRouteWrapper>
                      } />
                      <Route path="/about" element={
                        <PublicRouteWrapper routeProps={publicRoutesConfig["/about"]}>
                          <About />
                        </PublicRouteWrapper>
                      } />
                      <Route path="/contact" element={
                        <PublicRouteWrapper routeProps={publicRoutesConfig["/contact"]}>
                          <Contact />
                        </PublicRouteWrapper>
                      } />
                      <Route path="/auth" element={<Auth />} />
                      <Route path="/reset-password" element={<ResetPassword />} />
                      <Route path="/professionals" element={
                        <PublicRouteWrapper routeProps={publicRoutesConfig["/professionals"]}>
                          <ProfessionalsPage />
                        </PublicRouteWrapper>
                      } />
                      <Route path="/search" element={
                        <PublicRouteWrapper routeProps={publicRoutesConfig["/search"]}>
                          <SearchResults />
                        </PublicRouteWrapper>
                      } />
                      <Route path="/social" element={<SocialFeed />} />
                      
                      {/* Customer Tracking Route - Protected for Admin Only */}
                      <Route 
                        path="/customer" 
                        element={
                          <AdminProtectedRoute>
                            <PublicRouteWrapper routeProps={publicRoutesConfig["/customer"]}>
                              <CustomerTracking />
                            </PublicRouteWrapper>
                          </AdminProtectedRoute>
                        } 
                      />
                      
                      {/* Dynamic Routes with SEO Handling */}
                      <Route path="/shop/:shopId" element={
                        <>
                          <Helmet>
                            <title>Vendor Shop | Bhopal | BuildOnClicks</title>
                            <meta name="description" content="Construction material supplier shop in Bhopal, India. View building materials, vendor portfolio, and connect with contractors." />
                            <meta name="keywords" content="construction materials shop, building suppliers Bhopal, vendor portfolio, contractors materials, shop showcase" />
                            <link rel="canonical" href="https://www.buildonclicks.com/shop/:shopId" />
                          </Helmet>
                          <VendorShop />
                        </>
                      } />
                      <Route path="/vendor-shop/:shopId" element={
                        <>
                          <Helmet>
                            <title>Vendor Shop | Bhopal | BuildOnClicks</title>
                            <meta name="description" content="Construction material supplier shop in Bhopal, India. View building materials, vendor portfolio, and connect with contractors." />
                            <meta name="keywords" content="construction materials shop, building suppliers Bhopal, vendor portfolio, contractors materials, shop showcase" />
                            <link rel="canonical" href="https://www.buildonclicks.com/vendor-shop/:shopId" />
                          </Helmet>
                          <VendorShop />
                        </>
                      } />
                      <Route path="/portfolio/:professionalId" element={
                        <>
                          <Helmet>
                            <title>Professional Portfolio | Bhopal | BuildOnClicks</title>
                            <meta name="description" content="Architect, civil engineer, contractor, or interior designer portfolio in Bhopal, India. View construction projects and professional expertise." />
                            <meta name="keywords" content="architect portfolio Bhopal, civil engineer projects, contractor showcase, interior designer work, professional construction portfolio" />
                            <link rel="canonical" href="https://www.buildonclicks.com/portfolio/:professionalId" />
                          </Helmet>
                          <ProfessionalPortfolio />
                        </>
                      } />
                      <Route path="/admin-login" element={<AdminLogin />} />
                      <Route path="/chat" element={<ChatAssistant />} />

                      {/* Protected Routes - No SEO modifications as per requirements */}
                      <Route 
                        path="/profile" 
                        element={
                          <ProtectedRoute>
                            <UserProfile />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/dashboard" 
                        element={
                          <ProtectedRoute>
                            <UserDashboard />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/business-registration" 
                        element={
                          <ProtectedRoute>
                            <BusinessRegistration />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/provider-dashboard" 
                        element={
                          <ProtectedRoute>
                            <ProviderDashboard />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/shop-portfolio-setup" 
                        element={
                          <ProtectedRoute>
                            <ShopPortfolioSetup />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/vendor-shop-management" 
                        element={
                          <ProtectedRoute>
                            <VendorShopManagement />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/new-provider-dashboard" 
                        element={
                          <ProtectedRoute>
                            <NewProviderDashboard />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/portfolio-management" 
                        element={
                          <ProtectedRoute>
                            <PortfolioManagementPage />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/post-requirement" 
                        element={
                          <ProtectedRoute>
                            <PostRequirement />
                          </ProtectedRoute>
                        } 
                      />
                                   <Route 
                        path="/my-requirements" 
                        element={
                          <ProtectedRoute>
                            <MyRequirements />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/notifications" 
                        element={
                          <ProtectedRoute>
                            <Notifications />
                          </ProtectedRoute>
                        } 
                      />
                      <Route
                        path="/provider-requirements" 
                        element={
                          <ProtectedRoute requireProvider={true}>
                            <ProviderRequirements />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/referral" 
                        element={
                          <ProtectedRoute>
                            <ReferralPage />
                          </ProtectedRoute>
                        } 
                      />
                      <Route 
                        path="/subscription" 
                        element={
                          <ProtectedRoute>
                            <Subscription />
                          </ProtectedRoute>
                        } 
                      />
                      
                      {/* Additional Public Routes with SEO */}
                      <Route path="/privacy" element={
                        <PublicRouteWrapper routeProps={publicRoutesConfig["/privacy"]}>
                          <PrivacyPolicy />
                        </PublicRouteWrapper>
                      } />
                      <Route path="/terms" element={
                        <PublicRouteWrapper routeProps={publicRoutesConfig["/terms"]}>
                          <TermsAndConditions />
                        </PublicRouteWrapper>
                      } />
                      <Route 
                        path="/admin-dashboard"
                        element={
                          <AdminProtectedRoute>
                            <AdminDashboard />
                          </AdminProtectedRoute>
                        } 
                      />
                      <Route path="*" element={<NotFound />} />
                    </Routes>
                  </Suspense>
                </ErrorBoundary>
              </AdminAuthProvider>
            </AuthProvider>
          </LanguageProvider>
        </HelmetProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
