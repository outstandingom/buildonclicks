import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Star, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import { LazyImage } from "@/components/LazyImage";

// Note: Local image paths like '/src/assets/...' are not accessible in this environment.
// To display these images, they would need to be hosted online with public URLs.
import BhopalContractors1 from '/src/assets/Bhopal_Contractors1.jpg';
import steel1 from '/src/assets/steel.jpg';

const BusinessFeedSection = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const posts = [
    {
      id: 1,
      profile: "Arera Colony Contractors",
      title: "Residential Township - Phase 2 Complete",
      description: "Successfully completed the structural work for a 25-unit residential township near E-7, Arera Colony.",
      image: BhopalContractors1,
      likes: 24,
      comments: 8,
      rating: 4.8
    },
    {
      id: 2,
      profile: "MP Nagar Architects",
      title: "Eco-Friendly Office Design",
      description: "Designed a modern eco-friendly office space for a finance firm in MP Nagar Zone-II.",
      image: "https://images.unsplash.com/photo-1460574283810-2aab119d8511?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      likes: 42,
      comments: 12,
      rating: 4.9
    },
    {
      id: 3,
      profile: "Hoshangabad Road Steel Suppliers",
      title: "Premium Steel Delivery",
      description: "Supplied 60 tons of high-grade steel for a high-rise project near Aashima Mall, Hoshangabad Road.",
      image: "https://images.unsplash.com/photo-1493397212122-2b85dda8106b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      likes: 18,
      comments: 5,
      rating: 4.7
    },
    {
      id: 4,
      profile: "Kolar Road Green Building Solutions",
      title: "Sustainable Villa Project",
      description: "Implemented eco-friendly construction methods for a premium villa project near Danish Kunj, Kolar Road.",
      image: "https://images.unsplash.com/photo-1433086966358-54859d0ed716?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      likes: 35,
      comments: 15,
      rating: 4.9
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
      },
    },
  };

  return (
    <section className="py-8 sm:py-10 lg:py-12 bg-gray-150" ref={ref}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-6 sm:mb-8 lg:mb-10"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          {/* Main heading color changed to orange-500 */}
          {/* {t('businessFeed.title')} */}
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-black mb-2 sm:mb-3 lg:mb-4">
             What Professionals Are<span className="text-orange-500"> Building</span>
          </h2>
          <p className="text-sm sm:text-base lg:text-lg text-gray-600 max-w-2xl mx-auto">
            {t('businessFeed.description')}
          </p>
        </motion.div>

        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8 mb-8 sm:mb-10 lg:mb-12"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {posts.map((post) => (
            <motion.div
              key={post.id}
              variants={itemVariants}
              whileHover={{ 
                scale: 1.03,
                y: -5,
                transition: { duration: 0.2 }
              }}
              className="group"
            >
              <Card className="h-full hover:shadow-lg transition-all duration-300 overflow-hidden">
                <div className="relative overflow-hidden aspect-video">
                  <LazyImage 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full flex items-center shadow-md">
                    <Star className="h-4 w-4 text-yellow-500 mr-1" />
                    <span className="text-sm font-medium">{post.rating}</span>
                  </div>
                </div>
                
                <CardContent className="p-4 sm:p-5 lg:p-6">
                  <h3 className="font-semibold text-gray-900 mb-1 group-hover:text-blue-600 transition-colors">
                    {post.profile}
                  </h3>
                  <h4 className="text-sm font-medium text-gray-800 mb-2">
                    {post.title}
                  </h4>
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                    {post.description}
                  </p>
                  
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <div className="flex items-center space-x-4">
                      <motion.button 
                        className="flex items-center space-x-1 hover:text-red-500 transition-colors"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <Heart className="h-4 w-4" />
                        <span>{post.likes}</span>
                      </motion.button>
                      <motion.button 
                        className="flex items-center space-x-1 hover:text-blue-600 transition-colors"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                      >
                        <MessageCircle className="h-4 w-4" />
                        <span>{post.comments}</span>
                      </motion.button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
           <Button 
  size="default"
  className="bg-black hover:bg-neutral-800 text-white shadow-lg hover:shadow-xl transition-all duration-300 sm:h-10 sm:px-6 sm:text-base"
  onClick={() => navigate('/social')}
>
  {t('businessFeed.button')}
  <motion.div
    animate={{ x: [0, 5, 0] }}
    transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
  >
    <ArrowRight className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
  </motion.div>
</Button>

          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default BusinessFeedSection;
