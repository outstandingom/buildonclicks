
import React, { useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form } from '@/components/ui/form';
import { CheckCircle, Circle, ArrowLeft, ArrowRight, Building, Users, Share2, Shield, CreditCard, Clock, X, Loader2 } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { EnhancedBusinessInfoStep } from './form-steps/EnhancedBusinessInfoStep';
import { ContactInfoStep } from './form-steps/ContactInfoStep';
import { SocialMediaStep } from './form-steps/SocialMediaStep';
import { EnhancedDocumentsStep } from './form-steps/EnhancedDocumentsStep';
import { BankingStep } from './form-steps/BankingStep';
import { useBusinessRegistration, BusinessRegistrationData } from '@/hooks/useBusinessRegistration';
import { useProviderDashboard } from '@/hooks/useProviderDashboard';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

const businessRegistrationSchema = z.object({
  businessName: z.string().min(2, 'Business name is required'),
  businessType: z.string().min(1, 'Business type is required'),
  subBusinessType: z.array(z.string()).optional(),
  registrationNumber: z.string().refine(
    (val) => !val || val.length === 0 || val.length >= 5,
    { message: 'Registration number must be at least 5 characters' }
  ).optional(),
  vatGstNumber: z.string().optional(),
  website: z.string().url('Invalid URL').optional().or(z.literal('')),
  businessLicense: z.any().optional(),
  businessAddress: z.string().min(10, 'Business address is required'),
  citiesServed: z.array(z.string()).min(1, 'At least one city must be selected'),
  yearsInBusiness: z.number().min(0, 'Years in business is required'),
  aboutServices: z.string().min(20, 'Please provide detailed information about your services'),
  contactName: z.string().min(2, 'Contact name is required'),
  phoneNumber: z.string().min(10, 'Valid phone number is required'),
  emailAddress: z.string().email('Valid email is required'),
  alternateContact: z.string().optional(),
  preferredCommunication: z.array(z.string()).min(1, 'At least one communication method is required'),
  linkedinProfile: z.string().optional(),
  facebookPage: z.string().optional(),
  instagramHandle: z.string().optional(),
  otherLinks: z.array(z.string()).optional(),
  governmentId: z.any().refine(files => files?.length > 0, 'Government ID is required'),
  businessCertificate: z.any().optional(),
  insuranceCertificate: z.any().optional(),
  bankName: z.string().optional(),
  accountNumber: z.string().optional(),
  accountType: z.string().optional(),
  ifscCode: z.string().optional(),
});

const businessRegistrationSchemaAdmin = businessRegistrationSchema.extend({
  governmentId: z.any().optional(),
});

type BusinessRegistrationForm = z.infer<typeof businessRegistrationSchema>;

interface BusinessRegistrationFormProps {
  adminMode?: boolean;
  targetUserId?: string;
  onAdminSubmit?: (data: BusinessRegistrationForm) => Promise<boolean>;
}

const steps = [
  { id: 1, title: 'Business Information', icon: Building, description: 'Basic business details' },
  { id: 2, title: 'Contact Information', icon: Users, description: 'How to reach you' },
  { id: 3, title: 'Social Media', icon: Share2, description: 'Online presence (optional)' },
  { id: 4, title: 'Documents', icon: Shield, description: 'Verification documents' },
  { id: 5, title: 'Banking', icon: CreditCard, description: 'Payment information (optional)' },
];

export const BusinessRegistrationForm: React.FC<BusinessRegistrationFormProps> = ({
  adminMode = false,
  targetUserId,
  onAdminSubmit,
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isReapplying, setIsReapplying] = useState(false);
  const [showRegistrationForm, setShowRegistrationForm] = useState(false);
  const draftLoadedRef = useRef(false);
  const { submitRegistration, isSubmitting, loadDraft, saveDraft, clearDraft } = useBusinessRegistration();
  const { user } = useAuth();
  const { businessRegistration, hasRegistration, loading } = useProviderDashboard(user?.id);
  const { toast } = useToast();
  const navigate = useNavigate();

  const activeSchema = useMemo(
    () => (adminMode ? businessRegistrationSchemaAdmin : businessRegistrationSchema),
    [adminMode]
  );

  const form = useForm<BusinessRegistrationForm>({
    resolver: zodResolver(activeSchema),
    mode: 'onChange',
    defaultValues: {
      businessName: '',
      businessType: '',
      subBusinessType: [],
      registrationNumber: '',
      vatGstNumber: '',
      website: '',
      businessAddress: '',
      citiesServed: [],
      yearsInBusiness: 0,
      aboutServices: '',
      contactName: '',
      phoneNumber: '',
      emailAddress: '',
      alternateContact: '',
      preferredCommunication: [],
      linkedinProfile: '',
      facebookPage: '',
      instagramHandle: '',
      otherLinks: [],
      bankName: '',
      accountNumber: '',
      accountType: '',
      ifscCode: '',
    },
  });

  const { handleSubmit, trigger, formState: { errors, isValid } } = form;

  // Prepare data that can be stored in DB (strip files)
  const getSerializableDraft = (stepToStore: number) => {
    const values = form.getValues();
    const { businessLicense, governmentId, businessCertificate, insuranceCertificate, ...rest } = values;
    return {
      ...rest,
      currentStep: stepToStore,
    };
  };

  // Restore draft from database (provider only)
  React.useEffect(() => {
    if (adminMode) return;
    const fetchDraft = async () => {
      if (draftLoadedRef.current) return;
      // prevent multiple concurrent fetches/toasts
      draftLoadedRef.current = true;

      const draft = await loadDraft();
      if (draft?.data) {
        const { current_step, data } = draft;
        form.reset(data);
        if (current_step && current_step >= 1 && current_step <= steps.length) {
          setCurrentStep(current_step);
        }
        toast({
          title: "Draft Loaded",
          description: "We restored your previous registration progress.",
        });
      }
    };

    if (user) {
      fetchDraft();
    }
  }, [form, loadDraft, toast, user, adminMode]);

  const nextStep = async () => {
    if (!adminMode) {
      const draft = getSerializableDraft(currentStep);
      await saveDraft(draft, currentStep);
    }

    const fieldsToValidate = getFieldsForStep(currentStep);
    const isStepValid = await trigger(fieldsToValidate);
    
    if (isStepValid) {
      setCurrentStep(prev => Math.min(prev + 1, steps.length));
    } else {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields correctly.",
        variant: "destructive",
      });
    }
  };

  const prevStep = async () => {
    if (!adminMode) {
      const draft = getSerializableDraft(currentStep);
      await saveDraft(draft, currentStep);
    }
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const getFieldsForStep = (step: number) => {
    switch (step) {
      case 1:
        return ['businessName', 'businessType', 'registrationNumber', 'businessAddress', 'citiesServed', 'yearsInBusiness', 'aboutServices'] as const;
      case 2:
        return ['contactName', 'phoneNumber', 'emailAddress', 'preferredCommunication'] as const;
      case 3:
        return [] as const; // Optional step
      case 4:
        return ['businessLicense', 'governmentId', 'businessCertificate'] as const;
      case 5:
        return [] as const; // Optional step
      default:
        return [] as const;
    }
  };

  const handleReapply = async () => {
    if (!businessRegistration?.id || !user?.id) return;
    
    setIsReapplying(true);
    try {
      // Delete the existing registration
      const { error: deleteError } = await supabase
        .from('business_registrations')
        .delete()
        .eq('id', businessRegistration.id)
        .eq('user_id', user.id); // Ensure user can only delete their own registration

      if (deleteError) {
        console.error('Error deleting registration:', deleteError);
        toast({
          title: "Error",
          description: "Failed to delete existing registration. Please try again.",
          variant: "destructive",
        });
        return;
      }

      // Create a notification for the reapplication
      const { error: notificationError } = await supabase.rpc('create_notification', {
        p_user_id: user.id,
        p_title: 'Business Registration Reapplication Started',
        p_message: 'You have started a new business registration application. Please complete all steps to resubmit.',
        p_type: 'info'
      });

      if (notificationError) {
        console.error('Error creating notification:', notificationError);
      }

      toast({
        title: "Success",
        description: "Previous registration deleted. You can now submit a new application.",
      });

      // Show the registration form immediately
      setShowRegistrationForm(true);
    } catch (error) {
      console.error('Error during reapplication:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsReapplying(false);
    }
  };

  const onSubmit = async (data: BusinessRegistrationForm) => {
    try {
      if (adminMode && onAdminSubmit) {
        const success = await onAdminSubmit(data);
        if (success) {
          toast({
            title: "Success",
            description: "Registration submitted successfully!",
          });
          form.reset();
        }
        return;
      }

      const success = await submitRegistration(data as BusinessRegistrationData);
      if (success) {
        await clearDraft();
        toast({
          title: "Success",
          description: "Registration submitted successfully!",
        });
        // Redirect to dashboard or home page after successful submission
        navigate('/');
      }
    } catch (error) {
      console.error('Form submission error:', error);
      toast({
        title: "Error",
        description: "Failed to submit registration. Please try again.",
        variant: "destructive",
      });
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <EnhancedBusinessInfoStep form={form} />;
      case 2:
        return <ContactInfoStep form={form} />;
      case 3:
        return <SocialMediaStep form={form} />;
      case 4:
        return <EnhancedDocumentsStep form={form} />;
      case 5:
        return <BankingStep form={form} />;
      default:
        return null;
    }
  };

  const progress = (currentStep / steps.length) * 100;

  // Show loading state
  if (!adminMode && loading) {
    return (
      <div className="min-h-screen bg-gradient-section flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
          <p className="text-construction-neutral">Loading registration status...</p>
        </div>
      </div>
    );
  }

  // If user already has an approved registration, redirect to dashboard
  if (!adminMode && !loading && hasRegistration && businessRegistration?.status === 'approved') {
    return (
      <div className="min-h-screen bg-gradient-section py-8 px-4">
        <div className="max-w-2xl mx-auto">
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-600">
                <CheckCircle className="w-6 h-6" />
                Registration Already Complete
              </CardTitle>
              <CardDescription>
                Your business registration has already been approved. You can access all provider features.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-green-50 rounded-lg">
                  <h3 className="font-medium text-green-800 mb-2">Registration Details:</h3>
                  <p><strong>Business:</strong> {businessRegistration.business_name}</p>
                  <p><strong>Status:</strong> <span className="text-green-600">Approved</span></p>
                  <p><strong>Cities Served:</strong> {businessRegistration.cities_served.join(', ')}</p>
                </div>
                <div className="flex gap-3">
                  <Button onClick={() => navigate('/provider-dashboard')} className="flex-1">
                    Go to Dashboard
                  </Button>
                  <Button variant="outline" onClick={() => navigate('/provider-requirements')} className="flex-1">
                    View Requirements
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // If user has a rejected registration and hasn't clicked reapply, show reapply option
  if (!adminMode && !loading && hasRegistration && businessRegistration?.status === 'rejected' && !showRegistrationForm) {
    return (
      <div className="min-h-screen bg-gradient-section py-8 px-4">
        <div className="max-w-2xl mx-auto">
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <X className="w-6 h-6" />
                Registration Rejected
              </CardTitle>
              <CardDescription>
                Your business registration was rejected. You can reapply after addressing the issues.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-red-50 rounded-lg">
                  <h3 className="font-medium text-red-800 mb-2">Registration Details:</h3>
                  <p><strong>Business:</strong> {businessRegistration.business_name}</p>
                  <p><strong>Status:</strong> <span className="text-red-600">Rejected</span></p>
                  <p><strong>Submitted:</strong> {new Date(businessRegistration.created_at).toLocaleDateString()}</p>
                  {businessRegistration.rejection_reason && (
                    <p><strong>Reason:</strong> <span className="text-red-600">{businessRegistration.rejection_reason}</span></p>
                  )}
                </div>
                <p className="text-sm text-gray-600">
                  Please review the rejection reason above and make necessary corrections before reapplying.
                </p>
                <div className="flex gap-3">
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        disabled={isReapplying}
                        className="flex-1"
                      >
                        {isReapplying ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          'Reapply Now'
                        )}
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Confirm Reapplication</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will delete your current registration and allow you to submit a new application. 
                          Make sure you have addressed the rejection reasons before reapplying.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleReapply}>
                          Yes, Reapply
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                  <Button variant="outline" onClick={() => navigate('/notifications')} className="flex-1">
                    View Notifications
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // If user has a pending registration, show status
  if (!adminMode && !loading && hasRegistration && businessRegistration?.status === 'pending') {
    return (
      <div className="min-h-screen bg-gradient-section py-8 px-4">
        <div className="max-w-2xl mx-auto">
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-yellow-600">
                <Clock className="w-6 h-6" />
                Registration Under Review
              </CardTitle>
              <CardDescription>
                Your business registration is currently being reviewed by our team.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-yellow-50 rounded-lg">
                  <h3 className="font-medium text-yellow-800 mb-2">Registration Details:</h3>
                  <p><strong>Business:</strong> {businessRegistration.business_name}</p>
                  <p><strong>Status:</strong> <span className="text-yellow-600">Under Review</span></p>
                  <p><strong>Submitted:</strong> {new Date(businessRegistration.created_at).toLocaleDateString()}</p>
                </div>
                <p className="text-sm text-gray-600">
                  We'll contact you within 48 hours with an update on your registration status.
                </p>
                <Button onClick={() => navigate('/provider-dashboard')} className="w-full">
                  Go to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-section py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-construction-secondary mb-2">
            Business Registration
          </h1>
          <p className="text-construction-neutral">
            Join BuildOnClicks's network of verified professionals
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm text-construction-neutral">
              Step {currentStep} of {steps.length}
            </span>
            <span className="text-sm text-construction-neutral">
              {Math.round(progress)}% Complete
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step Indicator */}
        <div className="flex justify-center mb-8">
          <div className="flex space-x-4 overflow-x-auto pb-4">
            {steps.map((step) => {
              const StepIcon = step.icon;
              const isCompleted = currentStep > step.id;
              const isCurrent = currentStep === step.id;
              
              return (
                <div
                  key={step.id}
                  className={`flex flex-col items-center min-w-[120px] ${
                    isCurrent ? 'text-construction-primary' : 
                    isCompleted ? 'text-green-600' : 'text-construction-neutral'
                  }`}
                >
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-all ${
                    isCurrent ? 'bg-construction-primary text-white' :
                    isCompleted ? 'bg-green-600 text-white' : 'bg-gray-200'
                  }`}>
                    {isCompleted ? <CheckCircle className="w-6 h-6" /> : <StepIcon className="w-6 h-6" />}
                  </div>
                  <span className="text-xs font-medium text-center">{step.title}</span>
                  <span className="text-xs text-construction-neutral text-center">{step.description}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Form Content */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {React.createElement(steps[currentStep - 1].icon, { className: "w-5 h-5" })}
              {steps[currentStep - 1].title}
            </CardTitle>
            <CardDescription>
              {steps[currentStep - 1].description}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={handleSubmit(onSubmit)}>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentStep}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    {renderStep()}
                  </motion.div>
                </AnimatePresence>

                {/* Navigation Buttons */}
                <div className="flex justify-between mt-8 pt-6 border-t">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={prevStep}
                    disabled={currentStep === 1}
                    className="flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Previous
                  </Button>

                  {currentStep === steps.length ? (
                    <Button
                      type="submit"
                      className="flex items-center gap-2 bg-construction-primary hover:bg-construction-primary/90"
                      disabled={!isValid || isSubmitting}
                    >
                      {isSubmitting ? 'Submitting...' : 'Submit Registration'}
                      <CheckCircle className="w-4 h-4" />
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      onClick={nextStep}
                      className="flex items-center gap-2 bg-construction-primary hover:bg-construction-primary/90"
                    >
                      Save & Next
                      <ArrowRight className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
