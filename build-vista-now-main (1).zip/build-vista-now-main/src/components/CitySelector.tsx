import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { MapPin, Search, Locate, Navigation } from 'lucide-react';
import { useGoogleLocation, LocationData } from '@/hooks/useGoogleLocation';

const GOOGLE_MAPS_API_KEY = 'AIzaSyBz8TJrPNKb7lzxwLC4P6C6vWl7Ut3akOY';

declare global {
  interface Window {
    google: any;
  }
}

const CitySelector = () => {
  const { 
    location, 
    loading, 
    isGoogleMapsLoaded,
    getCurrentLocation, 
    setLocation,
    searchLocations 
  } = useGoogleLocation();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [locationSuggestions, setLocationSuggestions] = useState<LocationData[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const autocompleteServiceRef = useRef<any>(null);
  const placesServiceRef = useRef<any>(null);

  // Initialize Google Places services
  useEffect(() => {
    if (isGoogleMapsLoaded && window.google?.maps?.places) {
      autocompleteServiceRef.current = new window.google.maps.places.AutocompleteService();
      placesServiceRef.current = new window.google.maps.places.PlacesService(
        document.createElement('div')
      );
    }
  }, [isGoogleMapsLoaded]);

  // Handle search with debounce
  useEffect(() => {
    if (!isGoogleMapsLoaded || !searchTerm || searchTerm.trim().length < 2) {
      setLocationSuggestions([]);
      return;
    }

    const delaySearch = setTimeout(async () => {
      await handlePlacesSearch(searchTerm.trim());
    }, 300);

    return () => clearTimeout(delaySearch);
  }, [searchTerm, isGoogleMapsLoaded]);

  const handlePlacesSearch = async (query: string) => {
    if (!autocompleteServiceRef.current) {
      // Fallback to geocoding if Places API not available
      setIsSearching(true);
      try {
        const results = await searchLocations(query);
        setLocationSuggestions(results);
      } catch (error) {
        console.error('Search error:', error);
        setLocationSuggestions([]);
      } finally {
        setIsSearching(false);
      }
      return;
    }

    setIsSearching(true);
    try {
      autocompleteServiceRef.current.getPlacePredictions(
        {
          input: query,
          types: ['(cities)'],
          componentRestrictions: { country: 'in' },
        },
        (predictions: any[], status: any) => {
          if (status === window.google.maps.places.PlacesServiceStatus.OK && predictions) {
            const placeIds = predictions.slice(0, 5).map(p => p.place_id);
            const suggestions: LocationData[] = [];
            let processed = 0;

            placeIds.forEach((placeId) => {
              placesServiceRef.current.getDetails(
                { placeId, fields: ['formatted_address', 'address_components', 'geometry'] },
                (place: any, placeStatus: any) => {
                  processed++;
                  if (placeStatus === window.google.maps.places.PlacesServiceStatus.OK && place) {
                    const addressComponents = place.address_components || [];
                    const location = place.geometry?.location;

                    const cityComponent = addressComponents.find((c: any) => 
                      c.types.includes('locality') || c.types.includes('administrative_area_level_2')
                    );
                    const city = cityComponent?.long_name || place.formatted_address?.split(',')[0] || '';

                    const stateComponent = addressComponents.find((c: any) => 
                      c.types.includes('administrative_area_level_1')
                    );
                    const state = stateComponent?.long_name || '';

                    const countryComponent = addressComponents.find((c: any) => 
                      c.types.includes('country')
                    );
                    const country = countryComponent?.long_name || '';

                    let displayCity = city;
                    if (state && !city.includes(state)) {
                      displayCity = `${city}, ${state}`;
                    }

                    suggestions.push({
                      city: displayCity,
                      fullAddress: place.formatted_address || '',
                      state,
                      country,
                      latitude: location ? (typeof location.lat === 'function' ? location.lat() : location.lat) : 0,
                      longitude: location ? (typeof location.lng === 'function' ? location.lng() : location.lng) : 0,
                    });

                    if (processed === placeIds.length) {
                      setLocationSuggestions(suggestions);
                      setIsSearching(false);
                    }
                  } else {
                    if (processed === placeIds.length) {
                      setLocationSuggestions(suggestions);
                      setIsSearching(false);
                    }
                  }
                }
              );
            });
          } else {
            // Fallback to geocoding
            searchLocations(query).then(results => {
              setLocationSuggestions(results);
              setIsSearching(false);
            }).catch(() => {
              setLocationSuggestions([]);
              setIsSearching(false);
            });
          }
        }
      );
    } catch (error) {
      console.error('Places search error:', error);
      setIsSearching(false);
    }
  };

  const handleLocationSelect = async (suggestion: LocationData) => {
    try {
      await setLocation(suggestion);
      setSearchTerm('');
      setLocationSuggestions([]);
    } catch (error) {
      console.error('Error selecting location:', error);
    }
  };

  const handleDetectLocation = async () => {
    if (!isGoogleMapsLoaded) {
      console.warn('Google Maps not loaded yet, waiting...');
      // Wait for Google Maps to load
      let attempts = 0;
      while (!window.google?.maps?.places && attempts < 50) {
        await new Promise(resolve => setTimeout(resolve, 200));
        attempts++;
      }
      
      if (!window.google?.maps?.places) {
        console.error('Google Maps failed to load');
        return;
      }
    }

    try {
      await getCurrentLocation();
    } catch (error) {
      console.error('Location detection failed:', error);
    }
  };

  const currentCity = location?.city || 'Select City';
  const currentFullAddress = location?.fullAddress || location?.city || '';

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="flex items-center space-x-2 max-w-[200px] justify-start group hover:bg-accent"
          title={currentFullAddress}
        >
          <MapPin className="h-4 w-4 text-primary" />
          <div className="flex flex-col items-start overflow-hidden">
            <span className="truncate text-sm font-medium">
              {loading ? 'Detecting...' : currentCity}
            </span>
            {location?.state && (
              <span className="text-xs text-muted-foreground truncate">
                {location.state}
              </span>
            )}
          </div>
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent className="w-80 p-0" align="start" sideOffset={5}>
        {/* Search + GPS Section */}
        <div className="p-3 border-b space-y-3">
          <div className="flex items-center space-x-2">
            <Search className="h-4 w-4 text-muted-foreground flex-shrink-0" />
            <div className="flex-1 relative">
              <Input
                placeholder="Type city or address..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="h-8 border-0 p-0 focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                disabled={!isGoogleMapsLoaded}
              />
              {isSearching && (
                <div className="absolute right-0 top-1/2 transform -translate-y-1/2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                </div>
              )}
            </div>
          </div>

          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start"
            onClick={handleDetectLocation}
            disabled={loading || !isGoogleMapsLoaded}
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2"></div>
                Detecting...
              </>
            ) : (
              <>
                <Locate className="h-4 w-4 mr-2" />
                Detect My Location
              </>
            )}
          </Button>
        </div>

        {/* Results Section */}
        <div className="max-h-80 overflow-y-auto">
          {/* Google Places Search Results */}
          {locationSuggestions.length > 0 && (
            <>
              <div className="p-2 text-xs font-medium text-muted-foreground bg-accent/50">
                Search Results
              </div>
              {locationSuggestions.map((suggestion, index) => (
                <DropdownMenuItem
                  key={`place-${index}`}
                  onClick={() => handleLocationSelect(suggestion)}
                  className="cursor-pointer py-2 hover:bg-accent"
                >
                  <div className="flex flex-col w-full">
                    <div className="flex items-center">
                      <Navigation className="h-3 w-3 text-primary mr-2 flex-shrink-0" />
                      <span className="font-medium truncate">{suggestion.city}</span>
                    </div>
                    {suggestion.fullAddress && suggestion.fullAddress !== suggestion.city && (
                      <span className="text-xs text-muted-foreground truncate mt-1">
                        {suggestion.fullAddress}
                      </span>
                    )}
                  </div>
                </DropdownMenuItem>
              ))}
            </>
          )}

          {/* No Results Found */}
          {searchTerm && !locationSuggestions.length && !isSearching && isGoogleMapsLoaded && (
            <div className="p-4 text-center text-muted-foreground">
              <MapPin className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No locations found</p>
              <p className="text-xs mt-1">Try searching for a different location</p>
            </div>
          )}

          {/* Empty State - No Search */}
          {!searchTerm && !locationSuggestions.length && (
            <div className="p-4 text-center text-muted-foreground">
              <MapPin className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Type to search for a location</p>
              <p className="text-xs mt-1">Or use "Detect My Location" button</p>
            </div>
          )}

          {/* Loading Google Maps */}
          {!isGoogleMapsLoaded && (
            <div className="p-4 text-center text-muted-foreground">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto mb-2"></div>
              <p className="text-sm">Loading Google Maps...</p>
            </div>
          )}
        </div>

        {/* Current Location Display (if available) */}
        {location && (
          <div className="p-3 border-t bg-accent/30">
            <div className="text-xs font-medium text-muted-foreground mb-1">
              Current Location
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="h-3 w-3 text-primary flex-shrink-0" />
              <div className="text-sm truncate" title={currentFullAddress}>
                {currentFullAddress}
              </div>
            </div>
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default CitySelector;
