import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { showErrorToast, showSuccessToast } from '@/lib/loading-toast';
import { useLeadCredits } from '@/hooks/useLeadCredits';
import { Loader2, Phone, Mail, ExternalLink } from 'lucide-react';

interface ContactInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  professionalId: string;
  professionalName: string;
}

export const ContactInfoModal = ({ 
  isOpen, 
  onClose, 
  professionalId, 
  professionalName 
}: ContactInfoModalProps) => {
  const [loading, setLoading] = useState(false);
  const [contactInfo, setContactInfo] = useState<{ email?: string; phone?: string } | null>(null);
  const [showUnlock, setShowUnlock] = useState(false);
  const { user } = useAuth();
  const { hasAccessedLead, consumeCredits } = useLeadCredits();

  // Reset state when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      setContactInfo(null);
      setShowUnlock(false);
      checkAccess();
    }
  }, [isOpen, professionalId]);

  const checkAccess = async () => {
    if (!user) return;
    
    try {
      const accessed = await hasAccessedLead(professionalId, 'contact', 'professional');
      if (accessed) {
        // User already has access, fetch contact info
        fetchContactInfo();
      } else {
        // User needs to unlock
        setShowUnlock(true);
      }
    } catch (error) {
      console.error('Error checking access:', error);
      showErrorToast({
        title: 'Error',
        description: 'Failed to check access. Please try again.'
      });
    }
  };

  const fetchContactInfo = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('get_professional_contact', {
        professional_id: professionalId
      });

      if (error) {
        console.error('Error fetching contact:', error);
        showErrorToast({
          title: 'Error',
          description: 'Failed to fetch contact information.'
        });
        return;
      }

      if (data) {
        setContactInfo({
          email: data.email,
          phone: data.phone
        });
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      showErrorToast({
        title: 'Error',
        description: 'Something went wrong. Please try again.'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUnlock = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const success = await consumeCredits(professionalId, 1, 'contact', 'professional');
      
      if (success) {
        showSuccessToast({
          title: 'Contact Unlocked',
          description: 'You can now view the contact information.'
        });
        setShowUnlock(false);
        fetchContactInfo();
      } else {
        showErrorToast({
          title: 'Insufficient Credits',
          description: 'You need 1 credit to unlock contact information.'
        });
      }
    } catch (error) {
      console.error('Error unlocking:', error);
      showErrorToast({
        title: 'Error',
        description: 'Failed to unlock contact information.'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">
            Contact {professionalName}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
              <p className="text-sm text-gray-600">Loading contact information...</p>
            </div>
          ) : showUnlock ? (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-medium text-blue-800 mb-2">Unlock Contact Information</h3>
                <p className="text-sm text-blue-700">
                  Use 1 credit to unlock contact details for <strong>{professionalName}</strong>.
                  Once unlocked, you can access this information anytime.
                </p>
              </div>
              
              <div className="flex gap-2">
                <Button 
                  onClick={handleUnlock}
                  disabled={loading}
                  className="flex-1 bg-[#C45A2A] hover:bg-[#C45A2A]/90"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Unlocking...
                    </>
                  ) : (
                    'Unlock for 1 Credit'
                  )}
                </Button>
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : contactInfo ? (
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                <h4 className="font-medium text-gray-900">Contact Details:</h4>
                
                {contactInfo.phone && (
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                      <Phone className="h-4 w-4 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-600">Phone Number</p>
                      <a 
                        href={`tel:${contactInfo.phone}`}
                        className="text-base font-medium text-gray-900 hover:text-primary transition-colors"
                      >
                        {contactInfo.phone}
                      </a>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      asChild
                    >
                      <a href={`tel:${contactInfo.phone}`}>
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </Button>
                  </div>
                )}
                
                {contactInfo.email && (
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                      <Mail className="h-4 w-4 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-600">Email Address</p>
                      <a 
                        href={`mailto:${contactInfo.email}`}
                        className="text-base font-medium text-gray-900 hover:text-primary transition-colors break-all"
                      >
                        {contactInfo.email}
                      </a>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      asChild
                    >
                      <a href={`mailto:${contactInfo.email}`}>
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="text-xs text-gray-500">
                <p>✓ You have already unlocked this contact information.</p>
                <p>You can access it anytime from your leads dashboard.</p>
              </div>
              
              <Button onClick={onClose} className="w-full">
                Close
              </Button>
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-600">Unable to load contact information.</p>
              <Button onClick={onClose} className="mt-4">
                Close
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
