// src/components/ContactRequestModal.tsx

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { showErrorToast, showLoadingToast } from '@/lib/loading-toast';
import { LeadPaywall } from './LeadPaywall';
import { useLeadCredits } from '@/hooks/useLeadCredits';

interface ContactRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  professionalId: string;
  professionalName: string;
}

export const ContactRequestModal = ({ 
  isOpen, 
  onClose, 
  professionalId, 
  professionalName 
}: ContactRequestModalProps) => {
  const [message, setMessage] = useState('I would like to discuss a project with you.');
  const [loading, setLoading] = useState(false);
  const [contactInfo, setContactInfo] = useState<{ email?: string; phone?: string } | null>(null);
  const [showPaywall, setShowPaywall] = useState(false);
  const [hasAccess, setHasAccess] = useState(false);
  const { user } = useAuth();
  const { hasAccessedLead, consumeCredits } = useLeadCredits();

  // Check if user already has access when modal opens
  useEffect(() => {
    const checkAccess = async () => {
      if (!isOpen || !user) return;
      
      // Validate professionalId before making any calls
      if (!professionalId || professionalId === 'undefined') {
        console.error('Invalid professionalId:', professionalId);
        return;
      }
      
      try {
        const accessed = await hasAccessedLead(professionalId, 'contact', 'professional');
        setHasAccess(accessed);
        
        // If already accessed, fetch contact info directly
        if (accessed) {
          handleRequestContact();
        }
      } catch (error) {
        console.error('Error checking access:', error);
      }
    };
    
    checkAccess();
  }, [isOpen, user, professionalId]);

const handleRequestContact = async () => {
  if (!user) {
    showErrorToast({
      title: 'Authentication Required',
      description: 'Please log in to request contact information.'
    });
    return;
  }

  setLoading(true);

  try {
    const { data, error } = await supabase.rpc('request_professional_contact', {
      professional_id: professionalId,
      requester_message: message
    });

    if (error) {
      console.error('Error requesting contact:', error);
      showErrorToast({
        title: 'Request Failed',
        description: 'Failed to send contact request. Please try again.'
      });
      return;
    }

    const result = data as any;

    if (result?.success) {
      setContactInfo({
        email: result.email,
        phone: result.phone
      });

      // No toast here — no popup duplicate modal
      console.log('Contact info retrieved:', result.message || '');
    } else {
      if (result?.error?.includes('Insufficient credits')) {
        showErrorToast({
          title: 'Insufficient Credits',
          description: `You need ${result.credits_required || 1} credit to access contact information. You have ${result.available_credits || 0} credits remaining.`
        });
      } else {
        showErrorToast({
          title: 'Request Failed',
          description: result?.error || 'Failed to access contact information.'
        });
      }
    }
  } catch (error) {
    console.error('Unexpected error:', error);
    showErrorToast({
      title: 'Unexpected Error',
      description: 'Something went wrong. Please try again.'
    });
  } finally {
    setLoading(false);
  }
};


  const handleUnlockAndRequest = async () => {
    // Validate professionalId before consuming credits
    if (!professionalId || professionalId === 'undefined') {
      console.error('Invalid professionalId for credit consumption:', professionalId);
      showErrorToast({
        title: 'Error',
        description: 'Unable to process request. Please try again.',
      });
      return;
    }
    
    try {
      const success = await consumeCredits(professionalId, 1, 'contact', 'professional');
      
      if (success) {
        setHasAccess(true);
        setShowPaywall(false);
        await handleRequestContact();
      }
    } catch (error) {
      console.error('Error unlocking contact:', error);
    }
  };

  const handleClose = () => {
    setMessage('I would like to discuss a project with you.');
    setContactInfo(null);
    setShowPaywall(false);
    setHasAccess(false);
    onClose();
  };

  // Show paywall if user doesn't have access
  if (showPaywall || (!hasAccess && !contactInfo && !loading)) {
    return (
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-md">
          <LeadPaywall
            title="Unlock Contact Information"
            description={`Access contact details for ${professionalName}. Once unlocked, you can contact them anytime.`}
            requirementId={professionalId}
            accessType="contact"
            entityType="professional"
            onUnlock={handleUnlockAndRequest}
            creditsRequired={1}
          />
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Contact Information</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <p className="text-sm text-muted-foreground mb-3">
              Contact information for <strong>{professionalName}</strong>
            </p>
            
            {!contactInfo ? (
              <>
                <Label htmlFor="message" className="text-sm font-medium">
                  Your Message
                </Label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell them about your project..."
                  className="min-h-[80px] mt-2"
                />
                
                <div className="flex gap-2 mt-4">
                  <Button 
                    onClick={handleRequestContact}
                    disabled={loading || !message.trim()}
                    className="flex-1"
                  >
                    {loading ? 'Accessing...' : 'Get Contact Info (1 Credit)'}
                  </Button>
                  <Button variant="outline" onClick={handleClose}>
                    Cancel
                  </Button>
                </div>
              </>
            ) : (
              <div className="space-y-3">
                <div className="p-4 bg-secondary/50 rounded-lg">
                  <h4 className="font-medium text-sm mb-2">Contact Information:</h4>
                  {contactInfo.email && (
                    <p className="text-sm">
                      <strong>Email:</strong> 
                      <a href={`mailto:${contactInfo.email}`} className="ml-2 text-primary hover:underline">
                        {contactInfo.email}
                      </a>
                    </p>
                  )}
                  {contactInfo.phone && (
                    <p className="text-sm">
                      <strong>Phone:</strong> 
                      <a href={`tel:${contactInfo.phone}`} className="ml-2 text-primary hover:underline">
                        {contactInfo.phone}
                      </a>
                    </p>
                  )}
                </div>
                
                <Button onClick={handleClose} className="w-full">
                  Close
                </Button>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
