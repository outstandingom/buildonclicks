import { useLeadCredits } from '@/hooks/useLeadCredits';
import { Badge } from '@/components/ui/badge';
import { Coins, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { SubscriptionModal } from './SubscriptionModal';

export const CreditBalance = () => {
  const { credits, loading } = useLeadCredits();
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  if (loading) {
    return (
      <div className="flex items-center gap-2">
        <Coins className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm text-muted-foreground">Loading...</span>
      </div>
    );
  }

  if (!credits) {
    return null;
  }

  const isLowCredits = credits.available_credits <= 3;

  return (
    <>
      <div className="flex items-center gap-2">
        <Badge 
          variant={isLowCredits ? "destructive" : "secondary"}
          className="flex items-center gap-1"
        >
          <Coins className="h-3 w-3" />
          {credits.available_credits} leads
        </Badge>
        {isLowCredits && (
          <Button 
            size="sm" 
            onClick={() => setShowSubscriptionModal(true)}
            className="flex items-center gap-1"
          >
            <Plus className="h-3 w-3" />
            Buy Credits
          </Button>
        )}
      </div>

      <SubscriptionModal 
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
      />
    </>
  );
};