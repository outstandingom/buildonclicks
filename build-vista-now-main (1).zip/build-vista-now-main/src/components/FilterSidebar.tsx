import React from 'react';
import { Search, MapPin, Award, TrendingUp, Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface FilterSidebarProps {
  filters: {
    city: string;
    experience: string;
    sortBy: string;
    type: string;
    subType: string;
  };
  onFiltersChange: (filters: any) => void;
  resultCount: number;
  businessTypes?: Array<{ id: string; name: string }>;
}

// Define subcategories for each professional type
const subBusinessTypes = {
  'architects': [
    'Architect',
    'Landscape Architect'
  ],
  'designers': [],
  'engineers': [
    'Civil Engineer / Structural',
    'Geotechnical Engineer',
    'Site Engineer / Supervisor',
    'Land Surveyor'
  ],
  'contractors': [
    'General contractor / Builders',
    'Government contractors',
    'Excavation contractor',
    'Shuttering / framework contractor',
    'Fall Ceiling / POP contractor',
    'Modular furniture contractor/installer',
    'flooring contractor',
    'Waterproofing Specialist',
    'Fabricators',
    'Masons',
    'Tile Mason',
    'Steel fixer / Bar Benders',
    'Plumbing (Plumber)',
    'Electrician',
    'HVAC Technician',
    'Carpenter',
    'Painter',
    'Cleaning crew',
    'Municipal / Legal consultant',
    'Advocates',
    'Notary',
    'Quality inspectors / Auditors',
    'GOVT inspectors'
  ],
  'vendors': [
    'sand & Minerals',
    'Steel and cement',
    'Hardware',
    'Tiles and Sanitaryware',
    'plumbing Material',
    'Plywood & Decor',
    'furniture',
    'Stones'
  ],
  'manufacturers': [
    'Steel Manufacturers',
    'Cement Manufacturers',
    'Building Materials Manufacturers',
    'Hardware Manufacturers',
    'Tiles Manufacturers',
    'Sanitaryware Manufacturers',
    'Plumbing Materials Manufacturers',
    'Electrical Equipment Manufacturers',
    'HVAC Equipment Manufacturers',
    'Prefab Manufacturers',
    'Door & Window Manufacturers',
    'Roofing Materials Manufacturers'
  ]
};

const FilterSidebar: React.FC<FilterSidebarProps> = ({
  filters,
  onFiltersChange,
  resultCount,
  businessTypes = []
}) => {
  // Get available subcategories based on selected professional type
  const availableSubTypes = filters.type && filters.type !== 'all' 
    ? subBusinessTypes[filters.type as keyof typeof subBusinessTypes] || []
    : [];

  const [filteredSubTypes, setFilteredSubTypes] = React.useState(availableSubTypes);

  React.useEffect(() => {
    const newSubTypes = filters.type && filters.type !== 'all' 
      ? subBusinessTypes[filters.type as keyof typeof subBusinessTypes] || []
      : [];
    setFilteredSubTypes(newSubTypes);
    // Reset subType when professional type changes
    if (filters.subType && filters.subType !== 'all' && !newSubTypes.includes(filters.subType)) {
      onFiltersChange({
        ...filters,
        subType: 'all'
      });
    }
  }, [filters.type]);

  const handleFilterChange = (key: string, value: string) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const clearFilters = () => {
    onFiltersChange({
      city: '',
      experience: 'any',
      sortBy: 'rating',
      type: 'all',
      subType: 'all'
    });
  };

const cities = [
  'Bhopal, Madhya Pradesh',
  'Kolar, Bhopal',
  'Arera Colony, Bhopal',
  'MP Nagar, Bhopal',
  'New Market, Bhopal',
  'Shahpura, Bhopal',
  'Bairagarh, Bhopal',
  'Ashoka Garden, Bhopal',
  'Habibganj, Bhopal',
  'Hoshangabad Road, Bhopal'
];


  return (
    <div className="space-y-6 sticky top-4">
      {/* Filter Header */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Filters</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="text-primary hover:text-primary/80"
            >
              Clear All
            </Button>
          </div>
          <p className="text-sm text-gray-600">{resultCount} professionals found</p>
        </CardHeader>
      </Card>

      {/* Professional Type Filter */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center">
            <Users className="h-4 w-4 mr-2" />
            Professional Type
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <Select
            value={filters.type}
            onValueChange={(value) => handleFilterChange('type', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="All professionals" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Professionals</SelectItem>
              <SelectItem value="architects">Architects</SelectItem>
              <SelectItem value="designers">Designers</SelectItem>
              <SelectItem value="engineers">Engineers</SelectItem>
              <SelectItem value="contractors">Contractors</SelectItem>
              <SelectItem value="vendors">Vendors</SelectItem>
              <SelectItem value="manufacturers">Manufacturers</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Sub Business Type Filter with Search */}
      {filters.type && filters.type !== 'all' && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center">
              <Users className="h-4 w-4 mr-2" />
              Sub Business Type
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <Select
              value={filters.subType}
              onValueChange={(value) => handleFilterChange('subType', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="All sub types" />
              </SelectTrigger>
              <SelectContent className="max-h-60 overflow-y-auto">
                {/* Search Field Inside Dropdown */}
                <div className="p-2 sticky top-0 bg-background">
                  <Input
                    placeholder="Search sub type..."
                    onChange={(e) => {
                      const searchTerm = e.target.value.toLowerCase();
                      setFilteredSubTypes(
                        availableSubTypes.filter((subType) =>
                          subType.toLowerCase().includes(searchTerm)
                        )
                      );
                    }}
                  />
                </div>

                <SelectItem value="all">All Sub Types</SelectItem>
                {/* Show Filtered Items */}
                {(filteredSubTypes.length > 0 ? filteredSubTypes : availableSubTypes).map((subType) => (
                  <SelectItem key={subType} value={subType}>
                    {subType}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
      )}

      {/* City Filter */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center">
            <MapPin className="h-4 w-4 mr-2" />
            Location
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3">
            <div>
              <Label htmlFor="city-search" className="text-sm font-medium">
                Search City
              </Label>
              <div className="relative mt-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="city-search"
                  type="text"
                  placeholder="Enter city name..."
                  value={filters.city}
                  onChange={(e) => handleFilterChange('city', e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium">Popular Cities</Label>
              <div className="mt-2 space-y-2">
                {cities.slice(0, 5).map((city) => (
                  <Button
                    key={city}
                    variant="ghost"
                    size="sm"
                    onClick={() => handleFilterChange('city', city.split(',')[0])}
                    className="w-full justify-start text-left h-auto py-2 px-3 text-sm font-normal hover:bg-gray-50"
                  >
                    {city}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Experience Filter */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center">
            <Award className="h-4 w-4 mr-2" />
            Experience Level
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <Select
            value={filters.experience}
            onValueChange={(value) => handleFilterChange('experience', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Any experience" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="any">Any experience</SelectItem>
              <SelectItem value="1">1+ years</SelectItem>
              <SelectItem value="3">3+ years</SelectItem>
              <SelectItem value="5">5+ years</SelectItem>
              <SelectItem value="10">10+ years</SelectItem>
              <SelectItem value="15">15+ years</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Sort By */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center">
            <TrendingUp className="h-4 w-4 mr-2" />
            Sort By
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <Select
            value={filters.sortBy}
            onValueChange={(value) => handleFilterChange('sortBy', value)}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="rating">Highest Rated</SelectItem>
              <SelectItem value="reviews">Most Reviews</SelectItem>
              <SelectItem value="experience">Most Experienced</SelectItem>
              <SelectItem value="newest">Newest First</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>
    </div>
  );
};

export default FilterSidebar;
