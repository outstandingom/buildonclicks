import {
  Home,
  Users,
  MessageCircle,
  Mail,
  Phone,
  MapPin,
  Facebook,
  Instagram,
  Linkedin,  // ADD THIS
  Twitter,   // ADD THIS
  Youtube    // ADD THIS (optional)
} from "lucide-react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { useLanguage } from "@/contexts/LanguageContext";
import { Link } from "react-router-dom";

const Footer = () => {
  const { t } = useLanguage();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  // ✅ UPDATED: Social icons with actual URLs
  const socialIcons = [
    { 
      icon: Facebook, 
      label: "Facebook",
      url: "https://facebook.com/buildonclicks",
      color: "hover:text-[#1877F2]"
    },
    { 
      icon: Instagram, 
      label: "Instagram", 
      url: "https://instagram.com/buildonclicks",
      color: "hover:text-[#E4405F]"
    },
    { 
      icon: Linkedin, 
      label: "LinkedIn", 
      url: "https://linkedin.com/company/buildonclicks",
      color: "hover:text-[#0A66C2]"
    },
    { 
      icon: Twitter, 
      label: "Twitter", 
      url: "https://twitter.com/buildonclicks",
      color: "hover:text-[#1DA1F2]"
    },
    // Optional: Add YouTube if you have it
    // { 
    //   icon: Youtube, 
    //   label: "YouTube", 
    //   url: "https://youtube.com/@buildonclicks",
    //   color: "hover:text-[#FF0000]"
    // }
  ];

  const quickLinks = [
    { name: t("footer.quickLinks.home"), href: "/" },
    { name: t("footer.quickLinks.professionals"), href: "/professionals" },
    { name: t("footer.quickLinks.social"), href: "/social" },
    { name: t("footer.quickLinks.about"), href: "/about" },
    { name: t("footer.quickLinks.contact"), href: "/contact" },
    { name: t("footer.quickLinks.referrals"), href: "/referrals" },
  ];

  const legalLinks = [
    { name: t("footer.legal.terms"), href: "/terms" },
    { name: t("footer.legal.privacy"), href: "/privacy" },
    { name: t("footer.legal.support"), href: "/support" },
  ];

  return (
    <>
      {/* ✅ Desktop / Tablet Footer */}
      <footer
        className="hidden sm:block bg-construction-secondary text-white"
        ref={ref}
      >
        <motion.div
          className="container mx-auto px-4 sm:px-6 lg:px-8 py-16"
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <div className="flex items-center space-x-2 mb-4">
                <img
                  src="/lovable-uploads/672c8b35-7c22-4402-bd29-4160240af405.png"
                  alt="BuildOnClicks Logo"
                  className="h-8 w-8 rounded-full"
                />
                <span className="text-xl font-bold">{t("header.logo")}</span>
              </div>
              <p className="text-gray-300 mb-4 leading-relaxed">
                {t("footer.company.description")}
              </p>
              
              {/* ✅ UPDATED: Working Social Links */}
              <div className="flex space-x-4">
                {socialIcons.map((social, index) => (
                  <motion.a
                    key={social.label}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`Visit our ${social.label} page`}
                    whileHover={{ scale: 1.2, rotate: 5 }}
                    whileTap={{ scale: 0.9 }}
                    initial={{ opacity: 0, y: 20 }}
                    animate={inView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.3, delay: 0.2 + index * 0.1 }}
                    className={`${social.color} transition-colors duration-300`}
                  >
                    <social.icon className="h-6 w-6 text-gray-300 cursor-pointer" />
                  </motion.a>
                ))}
              </div>
              
              {/* ✅ ADD: Social Media Call-to-Action */}
              <motion.div 
                className="mt-6 p-3 bg-gray-800/50 rounded-lg border-l-4 border-primary"
                initial={{ opacity: 0 }}
                animate={inView ? { opacity: 1 } : {}}
                transition={{ delay: 0.5 }}
              >
                <p className="text-sm font-medium">
                  {t("footer.social.cta") || "Follow for construction insights!"}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {t("footer.social.hashtag") || "#BuildOnClicksBhopal #BhopalConstruction"}
                </p>
              </motion.div>
            </motion.div>

            {/* Quick Links */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <h3 className="text-lg font-semibold mb-4">
                {t("footer.quickLinks.title")}
              </h3>
              <ul className="space-y-2 text-gray-300">
                {quickLinks.map((link, index) => (
                  <motion.li
                    key={link.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                  >
                    <Link to={link.href}>
                      <motion.span
                        className="hover:text-primary hover:underline transition-colors text-sm cursor-pointer inline-block"
                        whileHover={{ x: 5 }}
                      >
                        {link.name}
                      </motion.span>
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </motion.div>

            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <h3 className="text-lg font-semibold mb-4">
                {t("footer.contact.title")}
              </h3>
              <div className="space-y-3 text-gray-300">
                {[
                  { icon: Phone, text: t("footer.contact.phone") },
                  { icon: Mail, text: t("footer.contact.email") },
                  { icon: MapPin, text: t("footer.contact.address") },
                ].map((contact, index) => (
                  <motion.div
                    key={contact.text}
                    className="flex items-center space-x-2"
                    initial={{ opacity: 0, x: -20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.4 + index * 0.1 }}
                    whileHover={{ x: 5 }}
                  >
                    <contact.icon className="h-4 w-4 text-primary" />
                    <span>{contact.text}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Legal */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <h3 className="text-lg font-semibold mb-4">
                {t("footer.legal.title")}
              </h3>
              <ul className="space-y-2 text-gray-300">
                {legalLinks.map((link, index) => (
                  <motion.li
                    key={link.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.4, delay: 0.5 + index * 0.1 }}
                  >
                    <Link to={link.href}>
                      <motion.span
                        className="hover:text-primary hover:underline transition-colors text-sm cursor-pointer inline-block"
                        whileHover={{ x: 5 }}
                      >
                        {link.name}
                      </motion.span>
                    </Link>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          </div>

          <motion.div
            className="border-t border-gray-600 mt-12 pt-8 text-center text-gray-300"
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <p>{t("footer.copyright")}</p>
          </motion.div>
        </motion.div>
      </footer>

      {/* ✅ Mobile Bottom Navigation */}
      <nav className="sm:hidden fixed bottom-0 left-0 w-full bg-construction-secondary text-white border-t border-gray-700 flex justify-around items-center py-2 z-50">
        <Link
          to="/"
          className="flex flex-col items-center text-xs hover:text-primary"
        >
          <Home className="h-6 w-6 mb-1" />
          {t("footer.quickLinks.home")}
        </Link>
        <Link
          to="/professionals"
          className="flex flex-col items-center text-xs hover:text-primary"
        >
          <Users className="h-6 w-6 mb-1" />
          {t("footer.quickLinks.professionals")}
        </Link>
        <Link
          to="/social"
          className="flex flex-col items-center text-xs hover:text-primary"
        >
          <MessageCircle className="h-6 w-6 mb-1" />
          {t("footer.quickLinks.social")}
        </Link>
      </nav>
    </>
  );
};

export default Footer;
