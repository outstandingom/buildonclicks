import React from 'react';
import { Link, useNavigate, NavLink } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useProfile } from "@/hooks/useProfile";
import SearchBar from './SearchBar';
import CitySelector from './CitySelector';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { User, Settings, LogOut, Building2, Home, Menu, Gift, CreditCard, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import NotificationDropdown from './NotificationDropdown';
import LanguageSelector from './LanguageSelector';
import { useLanguage } from '@/contexts/LanguageContext';
import { CreditBalance } from './CreditBalance';

const Header = () => {
  const { user, signOut, loading } = useAuth();
  const { profile } = useProfile(user?.id);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { t } = useLanguage();
  const [isSearchOpen, setIsSearchOpen] = React.useState(false);

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: "Signed Out",
        description: "You have been signed out successfully.",
      });
      navigate('/');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to sign out. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getUserInitials = () => {
    if (user?.user_metadata?.full_name) {
      return user.user_metadata.full_name
        .split(' ')
        .map((name: string) => name[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);
    }
    return user?.email?.[0]?.toUpperCase() || 'U';
  };

  const getUserType = () => {
    return user?.user_metadata?.user_type || 'user';
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
        <div className="flex h-16 items-center justify-between gap-1 sm:gap-2 md:gap-4 min-w-0 w-full">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-1 sm:space-x-2 flex-shrink-0 min-w-0">
            <img 
              src="/lovable-uploads/buildonclicklogo-removebg-preview.png" 
              alt="BuildOnClicks Logo" 
              width="48"
              height="48"
              className="h-12 w-12 sm:h-12 sm:w-12 rounded-full flex-shrink-0 object-cover"
            />
            <span className="text-base sm:text-2xl font-bold text-primary truncate">{t('header.logo')}</span>
          </Link>

          {/* City Selector */}
          <div className="hidden md:block flex-shrink-0">
            <CitySelector />
          </div>

          {/* Search Bar - Desktop only */}
          <div className="hidden md:flex flex-1 min-w-0 max-w-md mx-2 lg:max-w-xl xl:max-w-xs 2xl:max-w-sm">
            <SearchBar />
          </div>
          
          {/* Spacer for mobile */}
          <div className="flex-1 md:hidden"></div>

          {/* Mobile Search Dialog */}
          <Sheet open={isSearchOpen} onOpenChange={setIsSearchOpen}>
            <SheetContent side="top" className="h-auto">
              <SheetHeader>
                <SheetTitle>Search</SheetTitle>
              </SheetHeader>
              <div className="mt-4">
                <SearchBar />
              </div>
            </SheetContent>
          </Sheet>

          {/* Navigation Links - Responsive */}
          <nav className="hidden xl:flex items-center gap-2 xl:gap-3 2xl:gap-4 flex-shrink-0 text-sm whitespace-nowrap xl:ml-4">
            
            {/* <NavLink
              to="/"
              className={({ isActive }) =>
                `text-foreground hover:text-primary transition-colors px-2 py-1 ${
                  isActive ? 'font-bold text-primary' : ''
                }`
              }
              end
            >
              {t('header.nav.home')}
            </NavLink> */}
            {user && (
              <NavLink 
                to="/my-requirements" 
                className={({ isActive }) => 
                  `text-sm font-medium transition-colors hover:text-primary px-2 py-1 ${
                    isActive ? 'text-primary' : 'text-muted-foreground'
                  }`
                }
              >
                My Requirements
              </NavLink>
            )}
            <NavLink
              to="/professionals"
              className={({ isActive }) =>
                `text-foreground hover:text-primary transition-colors px-2 py-1 ${
                  isActive ? 'font-bold text-primary' : ''
                }`
              }
            >
              {t('header.nav.professionals')}
            </NavLink>
            <NavLink
              to="/social"
              className={({ isActive }) =>
                `text-foreground hover:text-primary transition-colors px-2 py-1 ${
                  isActive ? 'font-bold text-primary' : ''
                }`
              }
            >
              {t('header.nav.social')}
            </NavLink>
            <NavLink
              to="/about"
              className={({ isActive }) =>
                `text-foreground hover:text-primary transition-colors px-2 py-1 ${
                  isActive ? 'font-bold text-primary' : ''
                }`
              }
            >
              {t('header.nav.about')}
            </NavLink>
            <NavLink
              to="/contact"
              className={({ isActive }) =>
                `text-foreground hover:text-primary transition-colors px-2 py-1 ${
                  isActive ? 'font-bold text-primary' : ''
                }`
              }
            >
              {t('header.nav.contact')}
            </NavLink>
          </nav>

          {/* Mobile Search Icon and Menu - Shows on mobile and tablet */}
          <div className="flex items-center gap-2 xl:hidden">
            <Button 
              variant="ghost" 
              size="icon"
              className="md:hidden"
              onClick={() => setIsSearchOpen(true)}
            >
              <Search className="h-5 w-5" />
            </Button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80 flex flex-col">
                <SheetHeader className="flex-shrink-0">
                  <SheetTitle>{t('header.menu')}</SheetTitle>
                </SheetHeader>
                <div className="flex-1 overflow-y-auto">
                  <div className="flex flex-col space-y-4 mt-6 pb-6">
                    {/* Get Started Button for non-logged in users */}
                    {!user && (
                      <div className="border-b pb-4">
                        <Button
                          onClick={() => navigate('/auth')}
                          className="w-full rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90 transition-all"
                        >
                          {t('header.getStarted')}
                        </Button>
                      </div>
                    )}

                    {/* User Profile Section for logged in users - MOVED BEFORE NAVIGATION */}
                    {user ? (
                      <div className="border-b pb-4">
                        {/* Clickable User Info Section */}
                        <div 
                          className="flex items-center space-x-3 mb-4 p-2 rounded-lg hover:bg-accent cursor-pointer transition-colors"
                          onClick={() => navigate('/profile')}
                        >
                          <Avatar className="h-10 w-10">
                            {profile?.profile_image_url && (
                              <AvatarImage src={profile.profile_image_url} alt={user.user_metadata?.full_name || 'User'} />
                            )}
                            <AvatarFallback className="bg-primary text-primary-foreground">
                              {getUserInitials()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">
                              {user.user_metadata?.full_name || user.email}
                            </p>
                            <p className="text-xs text-muted-foreground truncate">
                              {user.email}
                            </p>
                            <p className="text-xs text-muted-foreground capitalize">
                              {getUserType()}
                            </p>
                          </div>
                        </div>

                        {/* Provider-specific navigation */}
                        {getUserType() !== 'user' && (
                          <>
                            <Button
                              variant="ghost"
                              className="w-full justify-start mb-2"
                              onClick={() => navigate('/provider-dashboard')}
                            >
                              <Building2 className="mr-2 h-4 w-4" />
                              {t('header.providerDashboard')}
                            </Button>
                            <Button
                              variant="ghost"
                              className="w-full justify-start mb-2"
                              onClick={() => navigate('/provider-requirements')}
                            >
                              <Building2 className="mr-2 h-4 w-4" />
                              {t('header.clientRequirements')}
                            </Button>
                          </>
                        )}

                        {/* Common user navigation */}
                        <Button
                          variant="ghost"
                          className="w-full justify-start mb-2"
                          onClick={() => navigate('/my-requirements')}
                        >
                          <Building2 className="mr-2 h-4 w-4" />
                          My Requirements
                        </Button>
                        <Button
                          variant="ghost"
                          className="w-full justify-start mb-2"
                          onClick={() => navigate('/post-requirement')}
                        >
                          <Building2 className="mr-2 h-4 w-4" />
                          {t('header.nav.postRequirement')}
                        </Button>
                        <Button
                          variant="ghost"
                          className="w-full justify-start mb-2"
                          onClick={() => navigate('/subscription')}
                        >
                          <CreditCard className="mr-2 h-4 w-4" />
                          Subscription
                        </Button>
                        <Button
                          variant="ghost"
                          className="w-full justify-start mb-2"
                          onClick={() => navigate('/referral')}
                        >
                          <Gift className="mr-2 h-4 w-4" />
                          Referrals
                        </Button>

                        <Button
                          variant="ghost"
                          className="w-full justify-start text-red-600 hover:text-red-700"
                          onClick={handleSignOut}
                        >
                          <LogOut className="mr-2 h-4 w-4" />
                          {t('header.signOut')}
                        </Button>
                      </div>
                    ) : null}

                    {/* Navigation Links - Now comes after user section */}
                    <div className="border-b pb-4">
                      <NavLink
                        to="/"
                        className={({ isActive }) =>
                          `text-foreground hover:text-primary transition-colors text-lg py-2 block ${
                            isActive ? 'font-bold text-primary' : ''
                          }`
                        }
                        end
                      >
                        {t('header.nav.home')}
                      </NavLink>
                      <NavLink
                        to="/professionals"
                        className={({ isActive }) =>
                          `text-foreground hover:text-primary transition-colors text-lg py-2 block ${
                            isActive ? 'font-bold text-primary' : ''
                          }`
                        }
                      >
                        {t('header.nav.professionals')}
                      </NavLink>
                      <NavLink
                        to="/social"
                        className={({ isActive }) =>
                          `text-foreground hover:text-primary transition-colors text-lg py-2 block ${
                            isActive ? 'font-bold text-primary' : ''
                          }`
                        }
                      >
                        {t('header.nav.social')}
                      </NavLink>
                      <NavLink
                        to="/about"
                        className={({ isActive }) =>
                          `text-foreground hover:text-primary transition-colors text-lg py-2 block ${
                            isActive ? 'font-bold text-primary' : ''
                          }`
                        }
                      >
                        {t('header.nav.about')}
                      </NavLink>
                      <NavLink
                        to="/contact"
                        className={({ isActive }) =>
                          `text-foreground hover:text-primary transition-colors text-lg py-2 block ${
                            isActive ? 'font-bold text-primary' : ''
                          }`
                        }
                      >
                        {t('header.nav.contact')}
                      </NavLink>
                    </div>

                    {/* Location and Language Selectors */}
                    <div className="border-b pb-4">
                      <CitySelector />
                    </div>

                    <div className="border-b pb-4">
                      <LanguageSelector />
                    </div>

                    {/* Legal Links Section */}
                    <div className="border-t pt-4">
                      <h4 className="text-sm font-semibold mb-3 text-muted-foreground">
                        {t('footer.legal.title')}
                      </h4>
                      <div className="space-y-2">
                        <NavLink
                          to="/privacy"
                          className={({ isActive }) =>
                            `text-foreground hover:text-primary transition-colors text-sm py-2 block ${
                              isActive ? 'font-bold text-primary' : ''
                            }`
                          }
                        >
                          {t('footer.legal.privacy')}
                        </NavLink>
                        <NavLink
                          to="/terms"
                          className={({ isActive }) =>
                            `text-foreground hover:text-primary transition-colors text-sm py-2 block ${
                              isActive ? 'font-bold text-primary' : ''
                            }`
                          }
                        >
                          {t('footer.legal.terms')}
                        </NavLink>
                        {/* <NavLink
                          to="/support"
                          className={({ isActive }) =>
                            `text-foreground hover:text-primary transition-colors text-sm py-2 block ${
                              isActive ? 'font-bold text-primary' : ''
                            }`
                          }
                        >
                          {t('footer.legal.support')}
                        </NavLink> */}
                      </div>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Desktop User Actions - Hidden on mobile */}
          <div className="hidden lg:flex items-center space-x-1 xl:space-x-2 2xl:space-x-4 flex-shrink-0 min-w-0">
            {loading ? (
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            ) : user ? (
              <>
                {getUserType() !== 'user' && <CreditBalance />}
                <NotificationDropdown />
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 sm:h-10 sm:w-10 rounded-full">
                    <Avatar className="h-8 w-8 sm:h-10 sm:w-10">
                      {profile?.profile_image_url && (
                        <AvatarImage src={profile.profile_image_url} alt={user.user_metadata?.full_name || 'User'} />
                      )}
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getUserInitials()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end">
                  <div className="flex items-center justify-start gap-2 p-2">
                    <div className="flex flex-col space-y-1 leading-none">
                      <p className="font-medium">
                        {user.user_metadata?.full_name || user.email}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {user.email}
                      </p>
                      <p className="text-xs text-muted-foreground capitalize">
                        {getUserType()}
                      </p>
                    </div>
                  </div>
                  <DropdownMenuSeparator />
                  
                  {/* Language Selector in Profile Menu */}
                  <div className="px-2 py-1">
                    <LanguageSelector />
                  </div>
                  <DropdownMenuSeparator />

                  {getUserType() !== 'user' && (
                    <>
                      <DropdownMenuItem onClick={() => navigate('/provider-dashboard')}>
                        <Building2 className="mr-2 h-4 w-4" />
                        {t('header.providerDashboard')}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigate('/provider-requirements')}>
                        <Building2 className="mr-2 h-4 w-4" />
                        {t('header.clientRequirements')}
                      </DropdownMenuItem>
                    </>
                  )}

                  <DropdownMenuItem onClick={() => navigate('/profile')}>
                    <User className="mr-2 h-4 w-4" />
                    {t('header.profile')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/my-requirements')}>
                    <Building2 className="mr-2 h-4 w-4" />
                    My Requirements
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/post-requirement')}>
                    <Building2 className="mr-2 h-4 w-4" />
                    {t('header.nav.postRequirement')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/referral')}>
                    <Gift className="mr-2 h-4 w-4" />
                    Referrals
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/subscription')}>
                    <CreditCard className="mr-2 h-4 w-4" />
                    Subscription
                  </DropdownMenuItem>

                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    {t('header.signOut')}
                  </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex items-center space-x-2">
                <Button
                  onClick={() => navigate('/auth')}
                  className="rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90 transition-all"
                >
                  {t('header.getStarted')}
                </Button>
              </div>
            )}
        </div>
      </div>
      </div>
    </header>
  );
};

export default Header;
