import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/contexts/LanguageContext";

const HeroSection = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { t } = useLanguage();

  const handleStartProject = () => {
    if (user) {
      navigate('/post-requirement');
    } else {
      navigate('/auth');
    }
  };

  const handleBrowseProfessionals = () => {
    navigate('/professionals');
  };

  return (
    <section className="relative mt-1 flex flex-col items-center text-black bg-[#f0f0f0]">
      
      {/* Top Content */}
      {/* Updated the vertical padding to 0 as requested */}
      {/*  
      <div className="relative z-20 w-full py- text-center bg-[#f0f0f0]">
        <motion.h1 
          className="text-4xl md:text-6xl font-bold mb-1 leading-tight text-black"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {t('hero.title')}
          <motion.span 
            className="text-black block"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            {t('hero.subtitle')}
          </motion.span>
        </motion.h1>
        
        <motion.p 
          className="text-xl md:text-2xl mb-2 text-gray-700 leading-relaxed max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
        >
          {t('hero.description')}
        </motion.p>

        {/* CTA Buttons */}
      {/*  
        <motion.div 
          className="flex flex-col sm:flex-row gap-4 justify-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.2 }}
        >
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="group"
          >
            <Button 
              size="lg" 
              className="text-lg px-8 py-4 bg-black hover:bg-gray-900 text-white shadow-md transition-all duration-300 rounded-md"
              onClick={handleStartProject}
            >
              {t('hero.buttons.postRequirement')}
              <motion.div
                className="ml-2"
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
              >
                <ArrowRight className="h-5 w-5" />
              </motion.div>
            </Button>
          </motion.div>
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button 
              variant="outline" 
              size="lg" 
              className="text-lg px-8 py-4 border-2 border-black text-black bg-white hover:bg-black hover:text-white transition-all duration-300 shadow-md rounded-md"
              onClick={handleBrowseProfessionals}
            >
              {t('hero.buttons.connectProfessionals')}
            </Button>
          </motion.div>
        </motion.div>
      </div>
    */}
    </section>
  );
};

export default HeroSection;
