import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { SubscriptionModal } from './SubscriptionModal';
import { Lock, Coins, Star } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useLeadCredits } from '@/hooks/useLeadCredits';

interface LeadPaywallProps {
  title: string;
  description: string;
  requirementId: string;
  accessType: 'view' | 'contact';
  entityType?: 'requirement' | 'professional';
  onUnlock?: () => void;
  creditsRequired?: number;
  children?: React.ReactNode;
  hasAccess?: boolean; // Optional: if provided, skips internal access check
}

export const LeadPaywall = ({ 
  title, 
  description, 
  requirementId,
  accessType,
  entityType = 'requirement',
  onUnlock, 
  creditsRequired = 1,
  children,
  hasAccess: externalHasAccess
}: LeadPaywallProps) => {
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [internalHasAccess, setInternalHasAccess] = useState(false);
  const [loading, setLoading] = useState(externalHasAccess === undefined);
  const { hasAccessedLead } = useLeadCredits();

  // Use external hasAccess if provided, otherwise check internally
  const hasAccess = externalHasAccess !== undefined ? externalHasAccess : internalHasAccess;

  useEffect(() => {
    // Skip check if external hasAccess is provided
    if (externalHasAccess !== undefined) {
      setLoading(false);
      return;
    }

    const checkAccess = async () => {
      try {
        setLoading(true);
        if (hasAccessedLead) {
          const accessed = await hasAccessedLead(requirementId, accessType, entityType);
          setInternalHasAccess(accessed);
        } else {
          setInternalHasAccess(false);
        }
      } catch (error) {
        console.error('Error checking lead access:', error);
        setInternalHasAccess(false);
      } finally {
        setLoading(false);
      }
    };

    checkAccess();
  }, [requirementId, accessType, entityType, hasAccessedLead, externalHasAccess]);

  // Show loading skeleton only when actually loading
  if (loading) {
    return (
      <div className="space-y-2 animate-pulse">
        <div className="h-10 bg-muted rounded" />
      </div>
    );
  }

  // If user has access, render children directly
  if (hasAccess) {
    return <>{children}</>;
  }

  return (
    <>
      <Card className="relative overflow-hidden border-2 border-dashed border-muted">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5" />
        <CardHeader className="relative text-center p-4 sm:p-6">
          <div className="mx-auto mb-3 sm:mb-4 flex h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 items-center justify-center rounded-full bg-primary/10">
            <Lock className="h-5 w-5 sm:h-6 sm:w-6 md:h-7 md:w-7 text-primary" />
          </div>
          <CardTitle className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 text-sm sm:text-base md:text-lg">
            {title}
            <Badge variant="secondary" className="flex items-center gap-0.5 sm:gap-1 text-[10px] sm:text-xs">
              <Coins className="h-2.5 w-2.5 sm:h-3 sm:w-3" />
              {creditsRequired} credit{creditsRequired > 1 ? 's' : ''}
            </Badge>
          </CardTitle>
          <CardDescription className="max-w-md mx-auto text-xs sm:text-sm mt-2">
            {description}
          </CardDescription>
        </CardHeader>
        
        <CardContent className="relative space-y-3 sm:space-y-4 p-4 sm:p-6 pt-0">
          {children && (
            <div className="p-3 sm:p-4 bg-muted/50 rounded-lg blur-sm pointer-events-none">
              {children}
            </div>
          )}
          
          <div className="flex flex-col gap-2 sm:gap-3">
            {onUnlock && (
              <Button 
                onClick={onUnlock} 
                className="w-full flex items-center justify-center gap-1.5 sm:gap-2 text-xs sm:text-sm h-9 sm:h-10"
              >
                <Coins className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                Use {creditsRequired} Credit{creditsRequired > 1 ? 's' : ''}
              </Button>
            )}
            <Button 
              variant="outline" 
              onClick={() => setShowSubscriptionModal(true)}
              className="w-full flex items-center justify-center gap-1.5 sm:gap-2 text-xs sm:text-sm h-9 sm:h-10"
            >
              <Star className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
              Buy More Credits
            </Button>
          </div>

          <div className="text-center text-[10px] sm:text-xs text-muted-foreground px-1 sm:px-2 space-y-0.5 sm:space-y-1">
            <p>💡 Credits are used to access lead contact details</p>
            <p className="hidden sm:block">Once unlocked, you can access this lead anytime</p>
            <p className="sm:hidden">Unlock once, access anytime</p>
          </div>
        </CardContent>
      </Card>

      <SubscriptionModal 
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
      />
    </>
  );
};
