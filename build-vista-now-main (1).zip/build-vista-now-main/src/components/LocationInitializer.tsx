import React, { useEffect, useState } from 'react';
import LocationPermissionModal from './LocationPermissionModal';
import { useGoogleLocation } from '@/hooks/useGoogleLocation';

const LocationInitializer: React.FC = () => {
  const [showModal, setShowModal] = useState(false);
  const { location, getCurrentLocation, isGoogleMapsLoaded, loading } = useGoogleLocation();

  useEffect(() => {
    const hasSetLocation = localStorage.getItem('userCity') || location?.city;
    const hasSeenLocationPrompt = localStorage.getItem('hasSeenLocationPrompt');

    if (!hasSetLocation && !hasSeenLocationPrompt) {
      // Wait for Google Maps to load before showing modal
      if (isGoogleMapsLoaded) {
        const timer = setTimeout(() => {
          console.log('Showing location permission modal');
          setShowModal(true);
        }, 2000);
        return () => clearTimeout(timer);
      } else {
        // Wait for Google Maps to load, then show modal
        const checkTimer = setInterval(() => {
          if (isGoogleMapsLoaded || window.google?.maps?.places) {
            clearInterval(checkTimer);
            const timer = setTimeout(() => {
              console.log('Showing location permission modal after Google Maps loaded');
              setShowModal(true);
            }, 2000);
            return () => clearTimeout(timer);
          }
        }, 500);
        
        // Cleanup after 10 seconds
        setTimeout(() => clearInterval(checkTimer), 10000);
        
        return () => clearInterval(checkTimer);
      }
    }
  }, [location, isGoogleMapsLoaded]);

  const handleAllow = async () => {
    // Check if Google Maps is loaded
    if (!isGoogleMapsLoaded) {
      console.warn('Google Maps not loaded yet, waiting...');
      // Wait a bit more for Google Maps to load
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check again
      if (!window.google?.maps?.places) {
        console.error('Google Maps still not loaded');
        localStorage.setItem('hasSeenLocationPrompt', 'true');
        setShowModal(false);
        return;
      }
    }

    try {
      await getCurrentLocation();
      localStorage.setItem('hasSeenLocationPrompt', 'true');
      setShowModal(false);
    } catch (error) {
      // Error is handled by the hook
      console.error('Location fetch error:', error);
      localStorage.setItem('hasSeenLocationPrompt', 'true');
      setShowModal(false);
    }
  };

  const handleSkip = () => {
    localStorage.setItem('hasSeenLocationPrompt', 'true');
    setShowModal(false);
  };

  return (
    <LocationPermissionModal
      isOpen={showModal}
      onClose={() => setShowModal(false)}
      onAllow={handleAllow}
      onSkip={handleSkip}
    />
  );
};

export default LocationInitializer;
