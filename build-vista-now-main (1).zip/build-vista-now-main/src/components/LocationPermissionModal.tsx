import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { MapPin, Shield, Target } from 'lucide-react';

interface LocationPermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAllow: () => void;
  onSkip: () => void;
}

const LocationPermissionModal: React.FC<LocationPermissionModalProps> = ({
  isOpen,
  onClose,
  onAllow,
  onSkip,
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full">
            <MapPin className="w-8 h-8 text-primary" />
          </div>
          <DialogTitle className="text-center">
            Help Us Find Local Professionals
          </DialogTitle>
          <DialogDescription className="text-center">
            Allow location access to discover the best construction professionals and services in your area.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="flex items-start space-x-3">
            <Target className="w-5 h-5 text-primary mt-0.5" />
            <div className="text-sm">
              <p className="font-medium">Better Search Results</p>
              <p className="text-muted-foreground">Find professionals near you</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3">
            <Shield className="w-5 h-5 text-primary mt-0.5" />
            <div className="text-sm">
              <p className="font-medium">Privacy Protected</p>
              <p className="text-muted-foreground">Your location is only used for search</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col space-y-2">
          <Button onClick={onAllow} className="w-full">
            Allow Location Access
          </Button>
          <Button variant="outline" onClick={onSkip} className="w-full">
            Skip for Now
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default LocationPermissionModal;