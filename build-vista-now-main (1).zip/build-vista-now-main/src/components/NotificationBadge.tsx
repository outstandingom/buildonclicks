import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Bell } from 'lucide-react';
import { useNotifications } from '@/hooks/useNotifications';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';

interface NotificationBadgeProps {
  showIcon?: boolean;
  className?: string;
}

const NotificationBadge: React.FC<NotificationBadgeProps> = ({ 
  showIcon = true, 
  className = '' 
}) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { unreadCount } = useNotifications(user?.id);

  if (!user || unreadCount === 0) return null;

  return (
    <div 
      className={`cursor-pointer ${className}`}
      onClick={() => navigate('/notifications')}
    >
      {showIcon && <Bell className="h-4 w-4 mr-1" />}
      <Badge variant="destructive" className="ml-1">
        {unreadCount > 99 ? '99+' : unreadCount}
      </Badge>
    </div>
  );
};

export default NotificationBadge;