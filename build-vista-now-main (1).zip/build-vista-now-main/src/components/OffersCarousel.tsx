import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { useBanners } from "@/hooks/useBanners";
import Autoplay from "embla-carousel-autoplay";
import { LazyImage } from "@/components/LazyImage";
import offerBanner1 from "@/assets/offer-banner-1.jpg";
import offerBanner2 from "@/assets/offer-banner-2.jpg";
import offerBanner3 from "@/assets/offer-banner-3.jpg";
import offerBanner4 from "@/assets/offer-banner-4.jpg";
import offerBanner5 from "@/assets/offer-banner-5.jpg";

const OffersCarousel = () => {
  const { banners, loading } = useBanners();
  
  // Fallback to static images if no dynamic banners are available
  const staticImages = [
    { src: offerBanner1, alt: "Special Construction Offer" },
    { src: offerBanner2, alt: "Building Materials Discount" },
    { src: offerBanner3, alt: "Professional Services" },
    { src: offerBanner4, alt: "Quality Assurance" },
    { src: offerBanner5, alt: "Expert Consultation" }
  ];

  const carouselImages = banners.length > 0 
    ? banners.map(banner => ({ 
        src: banner.image_url, 
        alt: banner.alt_text || banner.title 
      }))
    : staticImages;

  return (
    <section className="w-full bg-gray-150 dark:bg-gray-900 py-4">
      {/* Added container padding for left-right spacing */}
      <div className="relative z-10 w-full px-4 sm:px-6 lg:px-8">
        <Carousel 
          className="w-full"
          plugins={[
            Autoplay({
              delay: 3000,
            }) as any,
          ]}
        >
          <CarouselContent>
            {carouselImages.map((image, index) => (
              <CarouselItem key={index}>
                <div className="relative w-full aspect-[16/9] md:aspect-[5/1] rounded-xl overflow-hidden shadow-lg">
                  <LazyImage 
                    src={image.src}
                    alt={image.alt}
                    className="object-cover w-full h-full"
                    priority={index === 0}
                  />
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="hidden md:flex absolute left-4 top-1/2 -translate-y-1/2 bg-black/20 border-black/30 text-white hover:bg-black/30 transition-colors rounded-full" />
          <CarouselNext className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 bg-black/20 border-black/30 text-white hover:bg-black/30 transition-colors rounded-full" />
        </Carousel>
      </div>
    </section>
  );
};

export default OffersCarousel;
