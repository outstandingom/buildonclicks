import { Truck, Hammer, PenTool, Plus, Palette, Settings, Factory } from "lucide-react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/hooks/useAuth";

const PopularCategoriesSection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const navigate = useNavigate();
  const { t } = useLanguage();
  const { user } = useAuth();

  const categories = [
    {
      title: t('categories.items.materials.title'),
      description: t('categories.items.materials.description'),
      icon: Truck,
      link: "/professionals?type=vendors",
      color: "bg-gray-700"
    },
    {
      title: t('categories.items.contractors.title'),
      description: t('categories.items.contractors.description'),
      icon: Hammer,
      link: "/professionals?type=contractors",
    color: "bg-gray-700"
    },
    {
      title: t('categories.items.architects.title'),
      description: t('categories.items.architects.description'),
      icon: PenTool,
      link: "/professionals?type=architects",
      color: "bg-gray-700"
    },
    {
      title: t('categories.items.designers.title'),
      description: t('categories.items.designers.description'),
      icon: Palette,
      link: "/professionals?type=designers",
      color: "bg-gray-700"
    },
    {
      title: t('categories.items.engineers.title'),
      description: t('categories.items.engineers.description'),
      icon: Settings,
      link: "/professionals?type=engineers",
      color: "bg-gray-700"
    },
    {
      title: t('categories.items.manufacturers.title'),
      description: t('categories.items.manufacturers.description'),
      icon: Factory,
      link: "/professionals?type=manufacturers",
      color: "bg-gray-700"
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
      },
    },
  };

  const handleJoinAsProvider = () => {
    if (user) {
      // User is logged in, redirect to provider dashboard
      navigate("/provider-dashboard");
    } else {
      // User is not logged in, redirect to auth page
      navigate("/auth");
    }
  };

  return (
    <section className="bg-gray-150 py-8 sm:py-10 lg:py-16" ref={ref}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main section title and description */}
        <motion.div
          className="text-center mb-6 sm:mb-8 lg:mb-12"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-orange-500 mb-2 sm:mb-3 lg:mb-4">
            {t('categories.title')}
          </h2>
          <p className="text-sm sm:text-base lg:text-lg text-gray-600 max-w-2xl mx-auto">
            {t('categories.description')}
          </p>
        </motion.div>

        {/* Categories grid */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 mb-12 sm:mb-14 lg:mb-16"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {categories.map((category, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{
                scale: 1.05,
                transition: { duration: 0.2 }
              }}
              whileTap={{ scale: 0.98 }}
              className="group"
            >
              {/* Entire card is clickable */}
              <div
                onClick={() => navigate(category.link)} // ✅ direct navigate
                className="h-full cursor-pointer bg-card rounded-xl shadow-md hover:shadow-lg hover:shadow-gray-400 transition-all duration-300 border-2 border-transparent hover:border-gray-300"
              >
                <div className="p-4 sm:p-6 lg:p-8 h-full">
                  <div className="flex items-start mb-3 sm:mb-4">
                    <motion.div
                      className={`p-2 sm:p-3 lg:p-4 ${category.color} rounded-full mr-3 sm:mr-4 group-hover:scale-110 transition-transform duration-300`}
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.5 }}
                    >
                      <category.icon className="h-5 w-5 sm:h-6 sm:w-6 lg:h-8 lg:w-8 text-white" />
                    </motion.div>
                    <div className="flex-1">
                      <h3 className="text-base sm:text-lg lg:text-xl font-semibold text-gray-900 group-hover:text-gray-800 transition-colors duration-300">
                        {category.title}
                      </h3>
                      <p className="text-sm sm:text-base text-gray-600 mt-1 sm:mt-2">
                        {category.description}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Provider CTA */}
        <motion.div
          className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-3xl p-6 sm:p-8 lg:p-12 text-center shadow-lg"
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <h3 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-orange-500 mb-3 sm:mb-4">
            {t('categories.provider.title')}
          </h3>
          <p className="text-sm sm:text-base lg:text-lg text-gray-600 mb-6 sm:mb-8 max-w-2xl mx-auto">
            {t('categories.provider.description')}
          </p>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <button
              onClick={handleJoinAsProvider}
              className="bg-gray-700 hover:bg-gray-800 text-white px-6 sm:px-8 py-3 sm:py-4 text-sm sm:text-base md:text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center mx-auto"
            >
              <motion.div
                animate={{ rotate: [0, 90, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                <Plus className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
              </motion.div>
              {t('categories.provider.button')}
            </button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default PopularCategoriesSection;
