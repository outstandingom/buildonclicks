
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { X, Plus, Briefcase, Award, User } from 'lucide-react';

interface PortfolioCreationFormProps {
  onSubmit: (data: PortfolioData) => Promise<boolean>;
  isSubmitting: boolean;
}

interface ProjectData {
  title: string;
  description: string;
  duration: string;
  clientType: string;
  images: string[];
}

interface PortfolioData {
  title: string;
  description: string;
  services: string[];
  skills: string[];
  experience: string;
  projects: ProjectData[];
  certifications: string[];
  images: string[];
}

const PortfolioCreationForm: React.FC<PortfolioCreationFormProps> = ({ onSubmit, isSubmitting }) => {
  const [formData, setFormData] = useState<PortfolioData>({
    title: '',
    description: '',
    services: [],
    skills: [],
    experience: '',
    projects: [],
    certifications: [],
    images: [],
  });

  const [newService, setNewService] = useState('');
  const [newSkill, setNewSkill] = useState('');
  const [newCertification, setNewCertification] = useState('');
  const [newProject, setNewProject] = useState<ProjectData>({
    title: '',
    description: '',
    duration: '',
    clientType: '',
    images: [],
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await onSubmit(formData);
    if (success) {
      setFormData({
        title: '',
        description: '',
        services: [],
        skills: [],
        experience: '',
        projects: [],
        certifications: [],
        images: [],
      });
    }
  };

  const addService = () => {
    if (newService.trim() && !formData.services.includes(newService.trim())) {
      setFormData(prev => ({
        ...prev,
        services: [...prev.services, newService.trim()]
      }));
      setNewService('');
    }
  };

  const removeService = (service: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.filter(s => s !== service)
    }));
  };

  const addSkill = () => {
    if (newSkill.trim() && !formData.skills.includes(newSkill.trim())) {
      setFormData(prev => ({
        ...prev,
        skills: [...prev.skills, newSkill.trim()]
      }));
      setNewSkill('');
    }
  };

  const removeSkill = (skill: string) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== skill)
    }));
  };

  const addCertification = () => {
    if (newCertification.trim() && !formData.certifications.includes(newCertification.trim())) {
      setFormData(prev => ({
        ...prev,
        certifications: [...prev.certifications, newCertification.trim()]
      }));
      setNewCertification('');
    }
  };

  const removeCertification = (certification: string) => {
    setFormData(prev => ({
      ...prev,
      certifications: prev.certifications.filter(c => c !== certification)
    }));
  };

  const addProject = () => {
    if (newProject.title.trim() && newProject.description.trim()) {
      setFormData(prev => ({
        ...prev,
        projects: [...prev.projects, newProject]
      }));
      setNewProject({
        title: '',
        description: '',
        duration: '',
        clientType: '',
        images: [],
      });
    }
  };

  const removeProject = (index: number) => {
    setFormData(prev => ({
      ...prev,
      projects: prev.projects.filter((_, i) => i !== index)
    }));
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="w-5 h-5 text-construction-primary" />
          Create Your Portfolio
        </CardTitle>
        <CardDescription>
          Showcase your skills, experience, and past work to attract potential clients.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Portfolio Title */}
          <div>
            <Label htmlFor="title">Portfolio Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="e.g., Professional Interior Designer"
              required
            />
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Professional Summary *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Describe your background, expertise, and what sets you apart"
              className="min-h-[100px]"
              required
            />
          </div>

          {/* Services */}
          <div>
            <Label className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Services Offered
            </Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newService}
                onChange={(e) => setNewService(e.target.value)}
                placeholder="Add a service"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addService())}
              />
              <Button type="button" onClick={addService} variant="outline">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.services.map((service) => (
                <Badge key={service} variant="secondary" className="flex items-center gap-1">
                  {service}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeService(service)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Skills */}
          <div>
            <Label>Skills & Expertise</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="Add a skill"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
              />
              <Button type="button" onClick={addSkill} variant="outline">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.skills.map((skill) => (
                <Badge key={skill} variant="secondary" className="flex items-center gap-1">
                  {skill}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeSkill(skill)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Experience */}
          <div>
            <Label htmlFor="experience">Years of Experience *</Label>
            <Input
              id="experience"
              value={formData.experience}
              onChange={(e) => setFormData(prev => ({ ...prev, experience: e.target.value }))}
              placeholder="e.g., 5+ years in residential construction"
              required
            />
          </div>

          {/* Certifications */}
          <div>
            <Label className="flex items-center gap-2">
              <Award className="w-4 h-4" />
              Certifications
            </Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newCertification}
                onChange={(e) => setNewCertification(e.target.value)}
                placeholder="Add certification"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCertification())}
              />
              <Button type="button" onClick={addCertification} variant="outline">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.certifications.map((cert) => (
                <Badge key={cert} variant="secondary" className="flex items-center gap-1">
                  {cert}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeCertification(cert)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Projects */}
          <div>
            <Label>Past Projects</Label>
            <Card className="mb-4">
              <CardHeader>
                <CardTitle className="text-lg">Add New Project</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="projectTitle">Project Title</Label>
                    <Input
                      id="projectTitle"
                      value={newProject.title}
                      onChange={(e) => setNewProject(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Project name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="projectDuration">Duration</Label>
                    <Input
                      id="projectDuration"
                      value={newProject.duration}
                      onChange={(e) => setNewProject(prev => ({ ...prev, duration: e.target.value }))}
                      placeholder="e.g., 3 months"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="projectDescription">Project Description</Label>
                  <Textarea
                    id="projectDescription"
                    value={newProject.description}
                    onChange={(e) => setNewProject(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe the project and your role"
                  />
                </div>
                <div>
                  <Label htmlFor="clientType">Client Type</Label>
                  <Input
                    id="clientType"
                    value={newProject.clientType}
                    onChange={(e) => setNewProject(prev => ({ ...prev, clientType: e.target.value }))}
                    placeholder="e.g., Residential, Commercial, Government"
                  />
                </div>
                <Button type="button" onClick={addProject} variant="outline">
                  Add Project
                </Button>
              </CardContent>
            </Card>

            {/* Display added projects */}
            {formData.projects.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-medium">Added Projects:</h4>
                {formData.projects.map((project, index) => (
                  <Card key={index} className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h5 className="font-medium">{project.title}</h5>
                        <p className="text-sm text-muted-foreground">{project.description}</p>
                        <p className="text-sm">Duration: {project.duration} | Client: {project.clientType}</p>
                      </div>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="sm"
                        onClick={() => removeProject(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>

          <Button 
            type="submit" 
            disabled={isSubmitting}
            className="w-full bg-construction-primary hover:bg-construction-primary/90"
          >
            {isSubmitting ? 'Creating Portfolio...' : 'Create Portfolio'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default PortfolioCreationForm;
