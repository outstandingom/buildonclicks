import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Briefcase, Calendar, User, Award, Star, ExternalLink, 
  Camera, MapPin, Phone, Mail, Globe, Clock, Plus
} from 'lucide-react';

interface Project {
  title: string;
  description: string;
  duration: string;
  clientType: string;
  images: string[];
  completedAt?: string;
  technologies?: string[];
  projectValue?: string;
}

interface Portfolio {
  id: string;
  title: string;
  description: string;
  services: string[];
  skills: string[];
  experience: string;
  projects: any; // JSON field from Supabase  
  certifications: string[];
  images: string[];
  banner_url?: string;
  logo_url?: string;
}

interface PortfolioDisplayProps {
  portfolio: Portfolio;
  isPublicView?: boolean;
  contactInfo?: {
    name?: string;
    phone?: string;
    email?: string;
    website?: string;
    address?: string;
  };
}

const PortfolioDisplay: React.FC<PortfolioDisplayProps> = ({ 
  portfolio, 
  isPublicView = false,
  contactInfo 
}) => {
  return (
    <div className="max-w-7xl mx-auto space-y-6 bg-gray-50 min-h-screen">
      {/* Portfolio Banner */}
      {portfolio.banner_url && (
        <div className="relative h-48 md:h-64 overflow-hidden">
          <img
            src={portfolio.banner_url}
            alt="Portfolio banner"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/30" />
        </div>
      )}

      {/* Profile Header Section */}
      <div className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-8">
          <div className="flex flex-col md:flex-row items-start gap-6">
            {/* Profile Image/Logo */}
            <div className="flex-shrink-0">
              {portfolio.logo_url ? (
                <img
                  src={portfolio.logo_url}
                  alt="Profile"
                  className="w-24 h-24 rounded-full object-cover border-4 border-gray-200"
                />
              ) : (
                <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center text-2xl font-bold text-gray-600">
                  {portfolio.title.split(' ').map(word => word[0]).join('').slice(0, 2)}
                </div>
              )}
            </div>

            {/* Profile Info */}
            <div className="flex-grow">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-1">{portfolio.title}</h1>
                  <div className="flex items-center gap-4 text-gray-600 mb-2">
                    <span className="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium">
                      {portfolio.services[0] || 'Professional'}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span>{contactInfo?.address || 'Location not specified'}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{portfolio.experience} experience</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span>4.5 (0 reviews)</span>
                    </div>
                  </div>
                  <p className="text-gray-700 max-w-2xl">
                    {portfolio.description}
                  </p>
                </div>

                {/* Action Buttons */}
                {isPublicView && contactInfo && (
                  <div className="flex flex-col sm:flex-row gap-3 mt-4 md:mt-0">
                    {contactInfo.phone && (
                      <Button className="bg-black hover:bg-gray-800 text-white px-6">
                        <Phone className="w-4 h-4 mr-2" />
                        Call Now
                      </Button>
                    )}
                    {contactInfo.phone && (
                      <Button variant="outline" className="px-6">
                        <Phone className="w-4 h-4 mr-2" />
                        WhatsApp
                      </Button>
                    )}
                    <Button variant="outline" className="px-6">
                      Request Consultation
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar - Skills & Specializations */}
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Award className="w-5 h-5" />
                  Skills & Specializations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {portfolio.skills.map((skill, index) => (
                    <Badge key={index} variant="secondary" className="mr-2 mb-2">
                      {skill}
                    </Badge>
                  ))}
                </div>
                {portfolio.services.length > 0 && (
                  <div className="mt-4">
                    <h4 className="font-medium text-sm text-gray-700 mb-2">Services</h4>
                    <div className="space-y-1">
                      {portfolio.services.map((service, index) => (
                        <div key={index} className="text-sm text-gray-600">• {service}</div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Main Content - Portfolio Projects */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">Portfolio Projects</CardTitle>
                  {!isPublicView && (
                    <Button size="sm" className="bg-black hover:bg-gray-800">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Project
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {!Array.isArray(portfolio.projects) || portfolio.projects.length === 0 ? (
                  <div className="text-center py-12">
                    <Briefcase className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-600 mb-2">No projects added yet.</h3>
                    <p className="text-gray-500">Add your first project to showcase your work.</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {Array.isArray(portfolio.projects) && portfolio.projects.map((project, index) => (
                      <div key={index} className="border-b border-gray-200 last:border-b-0 pb-6 last:pb-0">
                        <div className="flex gap-4">
                          {project.images.length > 0 && (
                            <div className="flex-shrink-0">
                              <img
                                src={project.images[0]}
                                alt={project.title}
                                className="w-20 h-20 object-cover rounded-lg"
                              />
                            </div>
                          )}
                          <div className="flex-grow">
                            <h4 className="font-semibold text-lg mb-1">{project.title}</h4>
                            <p className="text-gray-600 text-sm mb-2">{project.description}</p>
                            <div className="flex items-center gap-4 text-xs text-gray-500">
                              <span>{project.duration}</span>
                              <span>Client: {project.clientType}</span>
                              {project.completedAt && (
                                <span>Completed: {new Date(project.completedAt).toLocaleDateString()}</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Sidebar - Contact & Stats */}
          <div className="lg:col-span-1 space-y-6">
            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {isPublicView && contactInfo && (
                  <>
                    {contactInfo.phone && (
                      <Button className="w-full bg-black hover:bg-gray-800 text-white">
                        <Phone className="w-4 h-4 mr-2" />
                        Call Now
                      </Button>
                    )}
                    {contactInfo.phone && (
                      <Button variant="outline" className="w-full">
                        <Phone className="w-4 h-4 mr-2" />
                        WhatsApp Chat
                      </Button>
                    )}
                    {contactInfo.email && (
                      <div className="flex items-center gap-2 text-sm">
                        <Mail className="w-4 h-4 text-blue-600" />
                        <span>{contactInfo.email}</span>
                      </div>
                    )}
                    {contactInfo.phone && (
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="w-4 h-4 text-green-600" />
                        <span>{contactInfo.phone}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2 text-sm text-blue-600">
                      <Globe className="w-4 h-4" />
                      <span>Professional Profile</span>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Certifications */}
            {portfolio.certifications.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Certifications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {portfolio.certifications.map((cert, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Award className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm">{cert}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Projects Completed</span>
                  <span className="font-bold">{Array.isArray(portfolio.projects) ? portfolio.projects.length : 0}+</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Years Experience</span>
                  <span className="font-bold">{portfolio.experience}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Client Rating</span>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span className="font-bold">4.5</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PortfolioDisplay;