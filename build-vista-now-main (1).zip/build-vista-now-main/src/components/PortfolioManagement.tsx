import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Plus, Edit, Trash2, Eye, Upload, Camera, FileText, Award, 
  Briefcase, Calendar, User, ExternalLink
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface Project {
  id?: string;
  title: string;
  description: string;
  duration: string;
  clientType: string;
  images: string[];
  completedAt?: string;
  technologies?: string[];
  projectValue?: string;
}

interface Portfolio {
  id: string;
  title: string;
  description: string;
  services: string[];
  skills: string[];
  experience: string;
  projects: any; // JSON field from Supabase
  certifications: string[];
  images: string[];
  banner_url?: string;
  logo_url?: string;
}

interface PortfolioManagementProps {
  portfolio: Portfolio | null;
  onUpdate: (data: Partial<Portfolio>) => Promise<boolean>;
  isSubmitting: boolean;
}

const PortfolioManagement: React.FC<PortfolioManagementProps> = ({ 
  portfolio, 
  onUpdate, 
  isSubmitting 
}) => {
  const navigate = useNavigate();
  const [isProjectDialogOpen, setIsProjectDialogOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [projectData, setProjectData] = useState<Project>({
    title: '',
    description: '',
    duration: '',
    clientType: '',
    images: [],
    completedAt: '',
    technologies: [],
    projectValue: '',
  });
  const [uploadingImages, setUploadingImages] = useState(false);
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleAddProject = () => {
    setEditingProject(null);
    setProjectData({
      title: '',
      description: '',
      duration: '',
      clientType: '',
      images: [],
      completedAt: '',
      technologies: [],
      projectValue: '',
    });
    setIsProjectDialogOpen(true);
  };

  const handleEditProject = (project: Project, index: number) => {
    setEditingProject({ ...project, id: index.toString() });
    setProjectData(project);
    setIsProjectDialogOpen(true);
  };

  const handleSaveProject = async () => {
    if (!projectData.title.trim() || !projectData.description.trim()) {
      toast({
        title: "Validation Error",
        description: "Project title and description are required.",
        variant: "destructive",
      });
      return;
    }

    if (!portfolio) return;

    const updatedProjects = Array.isArray(portfolio.projects) ? [...portfolio.projects] : [];
    
    if (editingProject && editingProject.id) {
      // Update existing project
      const index = parseInt(editingProject.id);
      updatedProjects[index] = projectData;
    } else {
      // Add new project
      updatedProjects.push(projectData);
    }

    const success = await onUpdate({ projects: updatedProjects });
    if (success) {
      setIsProjectDialogOpen(false);
      toast({
        title: "Project Saved",
        description: `Project ${editingProject ? 'updated' : 'added'} successfully.`,
      });
    }
  };

  const handleDeleteProject = async (index: number) => {
    if (!portfolio) return;

    const updatedProjects = Array.isArray(portfolio.projects) ? portfolio.projects.filter((_, i) => i !== index) : [];
    const success = await onUpdate({ projects: updatedProjects });
    if (success) {
      toast({
        title: "Project Deleted",
        description: "Project has been removed from your portfolio.",
      });
    }
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setUploadingImages(true);
    try {
      const uploadPromises = Array.from(files).map(async (file) => {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `portfolio-projects/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('business-documents')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('business-documents')
          .getPublicUrl(filePath);

        return publicUrl;
      });

      const uploadedUrls = await Promise.all(uploadPromises);
      
      setProjectData(prev => ({
        ...prev,
        images: [...prev.images, ...uploadedUrls]
      }));

      toast({
        title: "Images Uploaded",
        description: `${uploadedUrls.length} image(s) uploaded successfully.`,
      });
    } catch (error) {
      console.error('Error uploading images:', error);
      toast({
        title: "Upload Failed",
        description: "Failed to upload images. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingImages(false);
    }
  };

  const handleBannerUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid File Type",
        description: "Please select an image file.",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select an image smaller than 10MB.",
        variant: "destructive",
      });
      return;
    }

    setUploadingBanner(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `banner_${Date.now()}.${fileExt}`;
      const filePath = `portfolio-banners/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('business-documents')
        .upload(filePath, file);

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw uploadError;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('business-documents')
        .getPublicUrl(filePath);

      const success = await onUpdate({ banner_url: publicUrl });
      if (success) {
        toast({
          title: "Banner Updated",
          description: "Portfolio banner uploaded successfully.",
        });
      }
    } catch (error) {
      console.error('Error uploading banner:', error);
      toast({
        title: "Upload Failed",
        description: "Failed to upload banner. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingBanner(false);
      // Reset the input value so the same file can be selected again
      if (event.target) {
        event.target.value = '';
      }
    }
  };

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid File Type",
        description: "Please select an image file.",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 5MB for logos)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select an image smaller than 5MB.",
        variant: "destructive",
      });
      return;
    }

    setUploadingLogo(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `logo_${Date.now()}.${fileExt}`;
      const filePath = `portfolio-logos/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('business-documents')
        .upload(filePath, file);

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw uploadError;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('business-documents')
        .getPublicUrl(filePath);

      const success = await onUpdate({ logo_url: publicUrl });
      if (success) {
        toast({
          title: "Logo Updated",
          description: "Portfolio logo uploaded successfully.",
        });
      }
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast({
        title: "Upload Failed",
        description: "Failed to upload logo. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingLogo(false);
      // Reset the input value so the same file can be selected again
      if (event.target) {
        event.target.value = '';
      }
    }
  };

  const removeImage = (imageUrl: string) => {
    setProjectData(prev => ({
      ...prev,
      images: prev.images.filter(url => url !== imageUrl)
    }));
  };

  if (!portfolio) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>No Portfolio Found</CardTitle>
          <CardDescription>Create a portfolio first to manage projects.</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Portfolio Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <span className="flex items-center gap-2 text-lg sm:text-xl">
              <Briefcase className="w-5 h-5" />
              {portfolio.title}
            </span>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate(`/portfolio/${portfolio.id}`)}
              className="w-full sm:w-auto"
            >
              <Eye className="w-4 h-4 mr-2" />
              Preview Portfolio
            </Button>
          </CardTitle>
          <CardDescription className="text-sm">{portfolio.description}</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Banner and Logo Preview */}
          {(portfolio.banner_url || portfolio.logo_url) && (
            <div className="mb-4 sm:mb-6 p-3 sm:p-4 bg-muted/50 rounded-lg">
              <h4 className="text-xs sm:text-sm font-medium mb-3">Current Branding</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {portfolio.banner_url && (
                  <div>
                    <label className="text-xs text-muted-foreground mb-2 block">Banner</label>
                    <img
                      src={portfolio.banner_url}
                      alt="Portfolio banner"
                      className="w-full h-12 sm:h-16 object-cover rounded border"
                    />
                  </div>
                )}
                {portfolio.logo_url && (
                  <div>
                    <label className="text-xs text-muted-foreground mb-2 block">Logo</label>
                    <img
                      src={portfolio.logo_url}
                      alt="Portfolio logo"
                      className="w-12 h-12 sm:w-16 sm:h-16 object-cover rounded border"
                    />
                  </div>
                )}
              </div>
            </div>
          )}
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <Label className="text-sm font-medium">Projects</Label>
              <p className="text-xl sm:text-2xl font-bold text-primary">{Array.isArray(portfolio.projects) ? portfolio.projects.length : 0}</p>
            </div>
            <div>
              <Label className="text-sm font-medium">Services</Label>
              <p className="text-xl sm:text-2xl font-bold text-primary">{portfolio.services.length}</p>
            </div>
            <div>
              <Label className="text-sm font-medium">Experience</Label>
              <p className="text-xl sm:text-2xl font-bold text-primary">{portfolio.experience}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Portfolio Branding Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="w-5 h-5" />
            Portfolio Branding
          </CardTitle>
          <CardDescription>
            Upload a banner and logo to make your portfolio stand out
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            {/* Banner Upload */}
            <div>
              <Label className="text-sm font-medium mb-3 block">Portfolio Banner</Label>
              {portfolio.banner_url ? (
                <div className="relative group">
                  <img
                    src={portfolio.banner_url}
                    alt="Portfolio banner"
                    className="w-full h-24 sm:h-32 object-cover rounded-lg border"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => bannerInputRef.current?.click()}
                      disabled={uploadingBanner}
                      className="text-xs sm:text-sm"
                    >
                      <Upload className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                      {uploadingBanner ? 'Uploading...' : 'Change Banner'}
                    </Button>
                  </div>
                </div>
              ) : (
                <div 
                  className="w-full h-24 sm:h-32 border-2 border-dashed border-muted-foreground/25 rounded-lg flex items-center justify-center cursor-pointer hover:border-muted-foreground/50 transition-colors"
                  onClick={() => bannerInputRef.current?.click()}
                >
                  <div className="text-center px-2">
                    <Upload className="w-6 h-6 sm:w-8 sm:h-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-xs sm:text-sm text-muted-foreground">
                      {uploadingBanner ? 'Uploading...' : 'Click to upload banner'}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Recommended: 1200x300px
                    </p>
                  </div>
                </div>
              )}
              <input
                ref={bannerInputRef}
                type="file"
                accept="image/*"
                onChange={handleBannerUpload}
                className="hidden"
              />
            </div>

            {/* Logo Upload */}
            <div>
              <Label className="text-sm font-medium mb-3 block">Portfolio Logo</Label>
              {portfolio.logo_url ? (
                <div className="relative group flex justify-center sm:block">
                  <img
                    src={portfolio.logo_url}
                    alt="Portfolio logo"
                    className="w-24 h-24 sm:w-32 sm:h-32 object-cover rounded-lg border"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center max-w-[96px] sm:max-w-[128px] mx-auto">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => logoInputRef.current?.click()}
                      disabled={uploadingLogo}
                      className="text-xs sm:text-sm"
                    >
                      <Upload className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                      {uploadingLogo ? 'Uploading...' : 'Change Logo'}
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex justify-center sm:block">
                  <div 
                    className="w-24 h-24 sm:w-32 sm:h-32 border-2 border-dashed border-muted-foreground/25 rounded-lg flex items-center justify-center cursor-pointer hover:border-muted-foreground/50 transition-colors"
                    onClick={() => logoInputRef.current?.click()}
                  >
                    <div className="text-center px-2">
                      <Upload className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-1 text-muted-foreground" />
                      <p className="text-xs text-muted-foreground">
                        {uploadingLogo ? 'Uploading...' : 'Upload logo'}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Square format
                      </p>
                    </div>
                  </div>
                </div>
              )}
              <input
                ref={logoInputRef}
                type="file"
                accept="image/*"
                onChange={handleLogoUpload}
                className="hidden"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Projects Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <span className="text-lg sm:text-xl">Portfolio Projects</span>
            <Button 
              onClick={handleAddProject}
              className="w-full sm:w-auto"
              size="sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Project
            </Button>
          </CardTitle>
          <CardDescription className="text-sm">
            Manage your portfolio projects to showcase your work and expertise.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!Array.isArray(portfolio.projects) || portfolio.projects.length === 0 ? (
            <div className="text-center py-8">
              <Briefcase className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Projects Yet</h3>
              <p className="text-muted-foreground mb-4">
                Add your first project to start showcasing your work.
              </p>
              <Button onClick={handleAddProject}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Project
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {Array.isArray(portfolio.projects) && portfolio.projects.map((project, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base sm:text-lg flex items-start justify-between gap-2">
                        <span className="line-clamp-2 flex-1">{project.title}</span>
                        <div className="flex gap-1 flex-shrink-0">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditProject(project, index)}
                            className="h-8 w-8 p-0"
                          >
                            <Edit className="w-3 h-3 sm:w-4 sm:h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteProject(index)}
                            className="h-8 w-8 p-0"
                          >
                            <Trash2 className="w-3 h-3 sm:w-4 sm:h-4" />
                          </Button>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-3">
                        {project.description}
                      </p>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm">
                          <Calendar className="w-4 h-4" />
                          <span>Duration: {project.duration}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <User className="w-4 h-4" />
                          <span>Client: {project.clientType}</span>
                        </div>
                        {project.images.length > 0 && (
                          <div className="flex items-center gap-2 text-sm">
                            <Camera className="w-4 h-4" />
                            <span>{project.images.length} image(s)</span>
                          </div>
                        )}
                      </div>
                      {project.technologies && project.technologies.length > 0 && (
                        <div className="mt-3">
                          <div className="flex flex-wrap gap-1">
                            {project.technologies.slice(0, 3).map((tech, techIndex) => (
                              <Badge key={techIndex} variant="secondary" className="text-xs">
                                {tech}
                              </Badge>
                            ))}
                            {project.technologies.length > 3 && (
                              <Badge variant="secondary" className="text-xs">
                                +{project.technologies.length - 3} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Project Dialog */}
      <Dialog open={isProjectDialogOpen} onOpenChange={setIsProjectDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto w-[95vw] sm:w-full">
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl">
              {editingProject ? 'Edit Project' : 'Add New Project'}
            </DialogTitle>
            <DialogDescription className="text-sm">
              {editingProject ? 'Update project details' : 'Add a new project to your portfolio'}
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-3 h-auto">
              <TabsTrigger value="basic" className="text-xs sm:text-sm py-2">Basic Info</TabsTrigger>
              <TabsTrigger value="details" className="text-xs sm:text-sm py-2">Project Details</TabsTrigger>
              <TabsTrigger value="media" className="text-xs sm:text-sm py-2">Images & Media</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title" className="text-sm">Project Title *</Label>
                  <Input
                    id="title"
                    value={projectData.title}
                    onChange={(e) => setProjectData(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g., Modern Villa Construction"
                    className="text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="clientType" className="text-sm">Client Type</Label>
                  <Input
                    id="clientType"
                    value={projectData.clientType}
                    onChange={(e) => setProjectData(prev => ({ ...prev, clientType: e.target.value }))}
                    placeholder="e.g., Residential, Commercial"
                    className="text-sm"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description" className="text-sm">Project Description *</Label>
                <Textarea
                  id="description"
                  value={projectData.description}
                  onChange={(e) => setProjectData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe the project, your role, challenges faced, and outcomes achieved"
                  className="min-h-[100px] sm:min-h-[120px] text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="duration" className="text-sm">Project Duration</Label>
                  <Input
                    id="duration"
                    value={projectData.duration}
                    onChange={(e) => setProjectData(prev => ({ ...prev, duration: e.target.value }))}
                    placeholder="e.g., 6 months, 1 year"
                    className="text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="completedAt" className="text-sm">Completion Date</Label>
                  <Input
                    id="completedAt"
                    type="date"
                    value={projectData.completedAt}
                    onChange={(e) => setProjectData(prev => ({ ...prev, completedAt: e.target.value }))}
                    className="text-sm"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="details" className="space-y-4 mt-4">
              <div>
                <Label htmlFor="projectValue" className="text-sm">Project Value (Optional)</Label>
                <Input
                  id="projectValue"
                  value={projectData.projectValue}
                  onChange={(e) => setProjectData(prev => ({ ...prev, projectValue: e.target.value }))}
                  placeholder="e.g., ₹50 Lakhs, $100,000"
                  className="text-sm"
                />
              </div>

              <div>
                <Label htmlFor="technologies" className="text-sm">Technologies/Methods Used</Label>
                <Input
                  id="technologies"
                  value={projectData.technologies?.join(', ') || ''}
                  onChange={(e) => setProjectData(prev => ({ 
                    ...prev, 
                    technologies: e.target.value.split(',').map(t => t.trim()).filter(t => t)
                  }))}
                  placeholder="e.g., Concrete, Steel Frame, AutoCAD, 3D Modeling (comma separated)"
                  className="text-sm"
                />
              </div>
            </TabsContent>

            <TabsContent value="media" className="space-y-4 mt-4">
              <div>
                <Label className="text-sm">Project Images</Label>
                <div className="mt-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadingImages}
                    className="w-full text-sm"
                    size="sm"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {uploadingImages ? 'Uploading...' : 'Upload Images'}
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
              </div>

              {projectData.images.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
                  {projectData.images.map((imageUrl, index) => (
                    <div key={index} className="relative group">
                      <img
                        src={imageUrl}
                        alt={`Project image ${index + 1}`}
                        className="w-full h-24 sm:h-32 object-cover rounded-lg"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        className="absolute top-1 right-1 sm:top-2 sm:right-2 opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6 sm:h-8 sm:w-8 p-0"
                        onClick={() => removeImage(imageUrl)}
                      >
                        <Trash2 className="w-3 h-3 sm:w-4 sm:h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>

          <div className="flex flex-col sm:flex-row justify-end gap-2 mt-6">
            <Button 
              variant="outline" 
              onClick={() => setIsProjectDialogOpen(false)}
              className="w-full sm:w-auto"
              size="sm"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSaveProject} 
              disabled={isSubmitting}
              className="w-full sm:w-auto"
              size="sm"
            >
              {isSubmitting ? 'Saving...' : (editingProject ? 'Update Project' : 'Add Project')}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PortfolioManagement;
