import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Package, Search, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface Shop {
  id: string;
  shop_name: string;
  description: string;
  categories: string[];
  working_hours: string;
  delivery_options: string[];
  min_order_value: number;
  featured: boolean;
  images: string[];
  logo_url: string | null;
  created_at: string;
  business_registration_id: string;
}

interface Product {
  id?: string;
  shop_id: string;
  name: string;
  description: string;
  price: number;
  unit: string;
  category: string;
  image_url: string;
  in_stock: boolean;
  min_order_quantity: number;
}

interface ProductManagementProps {
  shops: Shop[];
  selectedShop: Shop | null;
  onShopChange: (shop: Shop | null) => void;
  onProductsUpdate: () => void;
}

export function ProductManagement({ shops, selectedShop, onShopChange, onProductsUpdate }: ProductManagementProps) {
  const { toast } = useToast();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Predefined categories for construction materials
  const constructionCategories = [
    'Cement',
    'Bricks',
    'Steel & Iron',
    'Sand & Aggregates', 
    'Concrete',
    'Pipes & Plumbing',
    'Electrical Items',
    'Paints & Coatings',
    'Tiles & Flooring',
    'Doors & Windows',
    'Roofing Materials',
    'Insulation',
    'Hardware & Fasteners',
    'Tools & Equipment',
    'Other'
  ];

  const [productForm, setProductForm] = useState<Product>({
    shop_id: selectedShop?.id || '',
    name: '',
    description: '',
    price: 0,
    unit: 'piece',
    category: '',
    image_url: '',
    in_stock: true,
    min_order_quantity: 1
  });

  useEffect(() => {
    if (selectedShop) {
      fetchProducts(selectedShop.id);
      setProductForm(prev => ({ ...prev, shop_id: selectedShop.id }));
    }
  }, [selectedShop]);

  const fetchProducts = async (shopId: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('shop_products')
        .select('*')
        .eq('shop_id', shopId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching products:', error);
        toast({
          title: "Error",
          description: "Failed to load products.",
          variant: "destructive",
        });
      } else {
        setProducts(data || []);
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedShop) {
      toast({
        title: "Error",
        description: "Please select a shop first.",
        variant: "destructive",
      });
      return;
    }

    try {
      if (editingProduct) {
        // Update existing product
        const { error } = await supabase
          .from('shop_products')
          .update({
            name: productForm.name,
            description: productForm.description,
            price: productForm.price,
            unit: productForm.unit,
            category: productForm.category,
            image_url: productForm.image_url,
            in_stock: productForm.in_stock,
            min_order_quantity: productForm.min_order_quantity
          })
          .eq('id', editingProduct.id);

        if (error) throw error;

        toast({
          title: "Success",
          description: "Product updated successfully.",
        });
      } else {
        // Create new product
        const { error } = await supabase
          .from('shop_products')
          .insert([productForm]);

        if (error) throw error;

        toast({
          title: "Success",
          description: "Product added successfully.",
        });
      }

      resetForm();
      fetchProducts(selectedShop.id);
      onProductsUpdate();
    } catch (error) {
      console.error('Error saving product:', error);
      toast({
        title: "Error",
        description: "Failed to save product.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;

    try {
      const { error } = await supabase
        .from('shop_products')
        .delete()
        .eq('id', productId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Product deleted successfully.",
      });

      if (selectedShop) {
        fetchProducts(selectedShop.id);
        onProductsUpdate();
      }
    } catch (error) {
      console.error('Error deleting product:', error);
      toast({
        title: "Error",
        description: "Failed to delete product.",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setProductForm({
      shop_id: selectedShop?.id || '',
      name: '',
      description: '',
      price: 0,
      unit: 'piece',
      category: '',
      image_url: '',
      in_stock: true,
      min_order_quantity: 1
    });
    setEditingProduct(null);
    setShowProductForm(false);
  };

  const openEditForm = (product: Product) => {
    setProductForm({ ...product });
    setEditingProduct(product);
    setShowProductForm(true);
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || product.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const categories = [...new Set(products.map(p => p.category))];
  const units = ['piece', 'kg', 'ton', 'bag', 'box', 'meter', 'sq ft', 'cubic ft', 'truck', 'bundle'];

  return (
    <div className="space-y-6">
      {/* Shop Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Select Shop</CardTitle>
        </CardHeader>
        <CardContent>
          <Select 
            value={selectedShop?.id || ''} 
            onValueChange={(value) => {
              const shop = shops.find(s => s.id === value);
              onShopChange(shop || null);
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="Choose a shop to manage products" />
            </SelectTrigger>
            <SelectContent>
              {shops.map(shop => (
                <SelectItem key={shop.id} value={shop.id}>
                  {shop.shop_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {selectedShop && (
        <>
          {/* Product Management Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold">Products for {selectedShop.shop_name}</h2>
              <p className="text-muted-foreground">{products.length} products</p>
            </div>
            <Button onClick={() => setShowProductForm(true)} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Product
            </Button>
          </div>

          {/* Filters */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search products..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Products Grid */}
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : filteredProducts.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Package className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">
                  {products.length === 0 ? 'No products yet' : 'No products found'}
                </h3>
                <p className="text-muted-foreground text-center mb-4">
                  {products.length === 0 
                    ? 'Add your first product to start selling.' 
                    : 'Try adjusting your search or filter criteria.'
                  }
                </p>
                {products.length === 0 && (
                  <Button onClick={() => setShowProductForm(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Your First Product
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <Card key={product.id} className="overflow-hidden">
                  <div className="relative">
                    {product.image_url ? (
                      <img 
                        src={product.image_url} 
                        alt={product.name}
                        className="w-full h-48 object-cover"
                      />
                    ) : (
                      <div className="w-full h-48 bg-muted flex items-center justify-center">
                        <Package className="h-12 w-12 text-muted-foreground" />
                      </div>
                    )}
                    <Badge 
                      className={`absolute top-2 right-2 ${
                        product.in_stock ? 'bg-green-500' : 'bg-red-500'
                      }`}
                    >
                      {product.in_stock ? 'In Stock' : 'Out of Stock'}
                    </Badge>
                  </div>
                  
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <div className="flex items-start justify-between">
                        <h3 className="font-semibold truncate">{product.name}</h3>
                        <Badge variant="outline">{product.category}</Badge>
                      </div>
                      
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {product.description}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold text-primary">
                          ₹{product.price}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          per {product.unit}
                        </span>
                      </div>
                      
                      <div className="text-xs text-muted-foreground">
                        Min order: {product.min_order_quantity} {product.unit}
                      </div>
                      
                      <div className="flex gap-2 pt-2">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="flex-1"
                          onClick={() => openEditForm(product)}
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Edit
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => product.id && handleDeleteProduct(product.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </>
      )}

      {/* Product Form Dialog */}
      <Dialog open={showProductForm} onOpenChange={() => resetForm()}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingProduct ? 'Edit Product' : 'Add New Product'}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleProductSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Product Name *</Label>
                <Input
                  id="name"
                  value={productForm.name}
                  onChange={(e) => setProductForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter product name"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="category">Category *</Label>
                <Select 
                  value={productForm.category} 
                  onValueChange={(value) => setProductForm(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent className="bg-white z-50 border shadow-lg">
                    {constructionCategories.map(category => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={productForm.description}
                onChange={(e) => setProductForm(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe the product"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="price">Price (₹) *</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={productForm.price}
                  onChange={(e) => setProductForm(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                  placeholder="0.00"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="unit">Unit *</Label>
                <Select 
                  value={productForm.unit} 
                  onValueChange={(value) => setProductForm(prev => ({ ...prev, unit: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {units.map(unit => (
                      <SelectItem key={unit} value={unit}>
                        {unit}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="min_quantity">Min Order Quantity</Label>
                <Input
                  id="min_quantity"
                  type="number"
                  value={productForm.min_order_quantity}
                  onChange={(e) => setProductForm(prev => ({ ...prev, min_order_quantity: parseInt(e.target.value) || 1 }))}
                  min="1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="image_url">Product Image URL</Label>
              <Input
                id="image_url"
                value={productForm.image_url}
                onChange={(e) => setProductForm(prev => ({ ...prev, image_url: e.target.value }))}
                placeholder="https://example.com/image.jpg"
              />
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="in_stock"
                checked={productForm.in_stock}
                onChange={(e) => setProductForm(prev => ({ ...prev, in_stock: e.target.checked }))}
                className="rounded"
              />
              <Label htmlFor="in_stock">In Stock</Label>
            </div>

            <div className="flex gap-3 pt-4">
              <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                Cancel
              </Button>
              <Button type="submit" className="flex-1">
                {editingProduct ? 'Update Product' : 'Add Product'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}