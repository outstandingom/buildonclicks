// src/components/ProfessionalCard.tsx

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Star, MapPin, Award, Phone, Eye, Store, Heart, AlertTriangle } from 'lucide-react';
import { ContactRequestModal } from './ContactRequestModal';
import { ReportDialog } from './ReportDialog';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface Professional {
  id: string;
  name: string;
  business_name?: string;
  type: string;
  location?: string;
  rating?: number;
  review_count?: number;
  profile_image_url?: string;
  logo_url?: string;
  experience?: number;
  is_verified?: boolean;
  email?: string;
  phone?: string;
  description?: string;
  city_name?: string;
  business_type?: string;
  sub_business_type?: string;
  shop_id?: string | null;
  portfolio_id?: string | null;
  provider_user_id?: string | null;
}

interface ProfessionalCardProps {
  professional: Professional;
  onContact?: (professionalId: string) => void;
  onShop?: (professionalId: string) => void;
  isLoggedIn?: boolean;
}

const ProfessionalCard: React.FC<ProfessionalCardProps> = ({ 
  professional, 
  onContact,
  onShop,
  isLoggedIn = false 
}) => {
  if (!professional) {
    return null;
  }

  const navigate = useNavigate();
  const { user } = useAuth();
  const [showContactModal, setShowContactModal] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Check if professional is already saved
  useEffect(() => {
    const checkIfSaved = async () => {
      if (!user || !professional.id) return;

      try {
        const { data, error } = await supabase
          .from('saved_professionals')
          .select('id')
          .eq('user_id', user.id)
          .eq('professional_id', professional.id)
          .maybeSingle();

        if (error && error.code !== 'PGRST116') {
          console.error('Error checking saved status:', error);
          return;
        }

        setIsSaved(!!data);
      } catch (error) {
        console.error('Error checking saved status:', error);
      }
    };

    checkIfSaved();
  }, [user, professional.id]);

  const getTypeLabel = (type?: string) => {
    const labels: Record<string, string> = {
      contractor: 'Contractor',
      vendor: 'Vendor',
      architect: 'Architect',
      designer: 'Designer',
      engineer: 'Engineer',
      manufacturer: 'Manufacturer',
    };
    const key = (type || '').toLowerCase();
    return labels[key] || (type ? type.charAt(0).toUpperCase() + type.slice(1) : 'Professional');
  };

  const getInitials = (name?: string) =>
    (name || '')
      .split(' ')
      .filter(Boolean)
      .map((word) => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);

  // Persist small info for VendorShop fallback
  const persistForVendorShop = () => {
    try {
      const key = professional.shop_id
        ? `professional_shop_${professional.shop_id}`
        : `professional_${professional.id}`;

      const small = {
        id: professional.id,
        shop_id: professional.shop_id,
        name: professional.name,
        business_name: professional.business_name,
        location: professional.location,
        city_name: professional.city_name,
        phone: professional.phone,
      };

      localStorage.setItem(key, JSON.stringify(small));
    } catch (e) {
      // console removed for production
    }
  };

  // Handle contact button click
  const handleContactClick = () => {
    if (onContact) {
      onContact(professional.id);
    } else {
      // Check if user is logged in before opening modal
      if (!user) {
        // Redirect to auth page with return URL
        navigate(`/auth?redirect=${encodeURIComponent(window.location.pathname)}`);
        return;
      }
      setShowContactModal(true);
    }
  };

  // Handle shop button click
  const handleShopClick = (e: React.MouseEvent) => {
    if (!isLoggedIn) {
      e.preventDefault();
      if (onShop) {
        onShop(professional.id);
      }
      return;
    }
    persistForVendorShop();
  };

  // Handle save/unsave professional
  const handleSaveClick = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!user) {
      navigate(`/auth?redirect=${encodeURIComponent(window.location.pathname)}`);
      return;
    }

    setIsSaving(true);
    try {
      if (isSaved) {
        // Remove from saved
        const { error } = await supabase
          .from('saved_professionals')
          .delete()
          .eq('user_id', user.id)
          .eq('professional_id', professional.id);

        if (error) throw error;

        setIsSaved(false);
        toast.success('Removed from saved professionals');
      } else {
        // Add to saved
        const { error } = await supabase
          .from('saved_professionals')
          .insert({
            user_id: user.id,
            professional_id: professional.id
          });

        if (error) {
          // Check if it's a duplicate key error
          if (error.code === '23505') {
            setIsSaved(true);
            toast.info('Already saved');
          } else {
            throw error;
          }
        } else {
          setIsSaved(true);
          toast.success('Saved to favorites');
        }
      }
    } catch (error: any) {
      console.error('Error saving professional:', error);
      toast.error(error.message || 'Failed to save professional');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <>
      <div className="group hover:shadow-md transition-all duration-200 border border-gray-200 bg-white h-full rounded-lg flex flex-col">
        <div className="p-3 sm:p-4 lg:p-5 flex flex-col h-full gap-2 sm:gap-3">
          
          {/* Avatar + Name + Badge */}
          <div className="flex items-center gap-3">
            <div className="h-14 w-14 sm:h-16 sm:w-16 rounded-full overflow-hidden flex-shrink-0 bg-white border border-gray-200">
              {professional.logo_url || professional.profile_image_url ? (
                <img
                  src={professional.logo_url || professional.profile_image_url || undefined}
                  alt={professional.name}
                  className="h-full w-full object-contain p-1"
                />
              ) : (
                <div className="bg-[#C45A2A]/10 text-[#C45A2A] font-semibold h-full w-full flex items-center justify-center">
                  {getInitials(professional.name)}
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-base sm:text-lg text-gray-900 truncate group-hover:text-[#C45A2A] transition-colors">
                {professional.business_name || professional.name}
              </h3>
              <div className="flex items-center gap-1 flex-wrap">
                <span className="px-2 py-0.5 rounded-full text-xs bg-blue-100 text-blue-800">
                  {professional.business_type || getTypeLabel(professional.type)}
                </span>
                {professional.is_verified && <Award className="h-4 w-4 text-green-500" />}
              </div>
            </div>

            <button 
              onClick={handleSaveClick}
              disabled={isSaving}
              className={`p-2 transition-colors ${
                isSaved 
                  ? 'text-red-500 hover:text-red-600' 
                  : 'text-gray-400 hover:text-red-500'
              } ${isSaving ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
              aria-label={isSaved ? "Remove from favorites" : "Add to favorites"}
              title={isSaved ? "Remove from favorites" : "Save to favorites"}
            >
              <Heart className={`h-5 w-5 ${isSaved ? 'fill-current' : ''}`} />
            </button>
          </div>

          {/* Location */}
          <div className="flex items-center text-gray-600 text-xs sm:text-sm py-1 sm:py-2">
            <MapPin className="h-3 w-3 sm:h-4 sm:w-4 mr-1 flex-shrink-0" />
            <span className="truncate">
              {professional.location || professional.city_name || 'Location not available'}
            </span>
          </div>

          {/* Rating & Experience */}
          <div className="flex justify-between items-center text-xs sm:text-sm py-1 sm:py-2">
            <div className="flex items-center gap-1">
              {professional.review_count && professional.review_count > 0 ? (
                <>
                  <Star className="h-3 w-3 sm:h-4 sm:w-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-medium text-gray-900">{professional.rating ?? '0.0'}</span>
                  <span className="text-gray-500">({professional.review_count ?? 0})</span>
                </>
              ) : (
                <span className="text-gray-500 text-xs">No reviews yet</span>
              )}
            </div>
            <span className="text-gray-600 whitespace-nowrap text-xs sm:text-sm">
              {professional.experience ?? 0} yrs exp.
            </span>
          </div>

          {/* Footer Buttons */}
          <div className="mt-auto grid grid-cols-2 gap-2">
            {(((professional.type || '').toLowerCase() === 'vendor' ||
              (professional.type || '').toLowerCase() === 'manufacturer') &&
              professional.shop_id) ||
            (professional.type &&
              professional.type !== 'vendor' &&
              professional.type !== 'manufacturer' &&
              professional.portfolio_id) ? (
              <Link
                to={
                  ((professional.type || '').toLowerCase() === 'vendor' ||
                    (professional.type || '').toLowerCase() === 'manufacturer') &&
                  professional.shop_id
                    ? `/shop/${professional.shop_id}`
                    : `/portfolio/${professional.portfolio_id}`
                }
                className="flex-1"
                state={{ professional }}
                onClick={handleShopClick}
              >
                <button className="w-full h-8 sm:h-9 text-xs sm:text-sm rounded-lg border border-gray-300 hover:bg-gray-100 transition-colors flex items-center justify-center">
                  {((professional.type || '').toLowerCase() === 'vendor' ||
                    (professional.type || '').toLowerCase() === 'manufacturer') ? (
                    <>
                      <Store className="h-3 w-3 sm:h-4 sm:w-4 mr-1" /> Shop
                    </>
                  ) : (
                    <>
                      <Eye className="h-3 w-3 sm:h-4 sm:w-4 mr-1" /> Portfolio
                    </>
                  )}
                </button>
              </Link>
            ) : null}

            <button
              onClick={handleContactClick}
              className="flex-1 h-8 sm:h-9 text-xs sm:text-sm rounded-lg bg-[#C45A2A] text-white hover:bg-[#C45A2A]/90 transition-colors flex items-center justify-center"
            >
              <Phone className="h-3 w-3 sm:h-4 sm:w-4 mr-1" /> Contact
            </button>
            <Button
              type="button"
              variant="outline"
              className="col-span-2 h-8 sm:h-9 text-xs sm:text-sm flex items-center justify-center gap-2"
              onClick={() => setShowReportDialog(true)}
            >
              <AlertTriangle className="h-3 w-3 sm:h-4 sm:w-4 text-red-500" />
              Report Provider
            </Button>
          </div>
        </div>
      </div>

      {!onContact && (
        <ContactRequestModal
          isOpen={showContactModal}
          onClose={() => setShowContactModal(false)}
          professionalId={professional.id}
          professionalName={professional.business_name || professional.name}
        />
      )}

      <ReportDialog
        open={showReportDialog}
        onOpenChange={setShowReportDialog}
        contentType="profile"
        contentId={professional.id} // business_registration id
        reportedUserId={professional.provider_user_id || undefined}
      />
    </>
  );
};

export default ProfessionalCard;
