import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, Eye } from "lucide-react";

const ProjectsFeed = () => {
  // Mock data for demonstration
  const projects = [
    {
      id: 1,
      title: "Modern Villa Construction",
      location: "Mumbai, Maharashtra",
      date: "2 days ago",
      status: "In Progress",
      image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
      description: "3 BHK modern villa with contemporary design and premium finishes.",
      contractor: "Elite Builders",
      views: 245
    },
    {
      id: 2,
      title: "Commercial Complex Development",
      location: "Pune, Maharashtra",
      date: "5 days ago",
      status: "Planning",
      image: "https://images.unsplash.com/photo-1486718448742-163732cd1544?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
      description: "Multi-story commercial complex with retail and office spaces.",
      contractor: "Metro Constructions",
      views: 189
    },
    {
      id: 3,
      title: "Residential Township",
      location: "Bangalore, Karnataka",
      date: "1 week ago",
      status: "Completed",
      image: "https://images.unsplash.com/photo-1518005020951-eccb494ad742?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
      description: "Eco-friendly residential township with 200+ homes and amenities.",
      contractor: "Green Build Solutions",
      views: 532
    },
    {
      id: 4,
      title: "Luxury Apartment Complex",
      location: "Delhi, NCR",
      date: "2 weeks ago",
      status: "In Progress",
      image: "https://images.unsplash.com/photo-1487958449943-2429e8be8625?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
      description: "High-rise luxury apartments with world-class amenities.",
      contractor: "Skyline Developers",
      views: 367
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "In Progress":
        return "bg-yellow-100 text-yellow-800";
      case "Completed":
        return "bg-green-100 text-green-800";
      case "Planning":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-construction-secondary mb-4">
            Latest Projects
          </h2>
          <p className="text-lg text-construction-neutral max-w-2xl mx-auto">
            Discover inspiring construction projects from our community of builders and architects
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {projects.map((project) => (
            <Card key={project.id} className="group hover:shadow-hover transition-all duration-300 bg-gradient-card border-0 overflow-hidden">
              <div className="relative">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4">
                  <Badge className={getStatusColor(project.status)}>
                    {project.status}
                  </Badge>
                </div>
                <div className="absolute bottom-4 right-4 bg-black/50 backdrop-blur-sm text-white px-2 py-1 rounded text-sm flex items-center">
                  <Eye className="h-3 w-3 mr-1" />
                  {project.views}
                </div>
              </div>
              
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-construction-secondary mb-2">
                  {project.title}
                </h3>
                
                <p className="text-construction-neutral mb-4 text-sm">
                  {project.description}
                </p>
                
                <div className="flex items-center justify-between text-sm text-construction-neutral mb-4">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1 text-primary" />
                    {project.location}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1 text-primary" />
                    {project.date}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-construction-secondary">
                    by {project.contractor}
                  </span>
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline">
            View All Projects
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProjectsFeed;