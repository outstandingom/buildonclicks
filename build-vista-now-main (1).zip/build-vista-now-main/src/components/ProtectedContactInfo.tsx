import { useState, useEffect } from 'react';
import { Phone, Mail, MessageCircle, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { LeadPaywall } from './LeadPaywall';
import { useLeadCredits } from '@/hooks/useLeadCredits';
import { useAuth } from '@/hooks/useAuth';
import { showErrorToast, showSuccessToast } from '@/lib/loading-toast';

interface ProtectedContactInfoProps {
  professionalId: string;
  professionalName: string;
  phone?: string;
  email?: string;
  variant?: 'buttons' | 'text' | 'sidebar';
}

export const ProtectedContactInfo = ({
  professionalId,
  professionalName,
  phone,
  email,
  variant = 'buttons'
}: ProtectedContactInfoProps) => {
  const { user } = useAuth();
  const { consumeCredits, hasAccessedLead } = useLeadCredits();
  const [showPaywall, setShowPaywall] = useState(false);
  const [hasAccess, setHasAccess] = useState(false);
  const [loading, setLoading] = useState(true);
  const [pendingAction, setPendingAction] = useState<'phone' | 'email' | 'whatsapp' | null>(null);

  // Check access on mount
  useEffect(() => {
    const checkAccess = async () => {
      if (!user) {
        setLoading(false);
        setHasAccess(false);
        return;
      }
      
      try {
        const accessed = await hasAccessedLead(professionalId, 'contact', 'professional');
        setHasAccess(accessed);
      } catch (error) {
        console.error('Error checking access:', error);
        setHasAccess(false);
      } finally {
        setLoading(false);
      }
    };
    
    checkAccess();
  }, [user?.id, professionalId]); // Use user.id instead of user object and remove hasAccessedLead from deps

  const handleUnlock = async (actionAfterUnlock?: 'phone' | 'email' | 'whatsapp') => {
    if (!user) {
      showErrorToast({
        title: 'Login Required',
        description: 'Please login to access contact information.'
      });
      return;
    }

    try {
      const success = await consumeCredits(professionalId, 1, 'contact', 'professional');
      
      if (success) {
        setHasAccess(true);
        setShowPaywall(false);
        showSuccessToast({
          title: 'Contact Unlocked!',
          description: 'You can now access the contact details.'
        });
        
        // Automatically trigger the action after unlock if specified
        if (actionAfterUnlock) {
          setTimeout(() => {
            handleContactClick(actionAfterUnlock);
          }, 500);
        }
      }
    } catch (error) {
      console.error('Error unlocking contact:', error);
    }
  };

  const handleContactClick = (type: 'phone' | 'email' | 'whatsapp') => {
    if (!user) {
      showErrorToast({
        title: 'Login Required',
        description: 'Please login to access contact information.'
      });
      return;
    }

    if (!hasAccess) {
      setPendingAction(type);
      setShowPaywall(true);
      return;
    }

    // If has access, perform the action
    if (type === 'phone') {
      if (!phone) {
        showErrorToast({
          title: 'Phone Not Available',
          description: 'Phone number is not available for this professional.'
        });
        return;
      }
      window.location.href = `tel:${phone}`;
    } else if (type === 'email') {
      if (!email) {
        showErrorToast({
          title: 'Email Not Available',
          description: 'Email address is not available for this professional.'
        });
        return;
      }
      window.location.href = `mailto:${email}`;
    } else if (type === 'whatsapp') {
      if (!phone) {
        showErrorToast({
          title: 'Phone Not Available',
          description: 'Phone number is not available for WhatsApp contact.'
        });
        return;
      }
      const cleanPhone = phone.replace(/\D/g, '');
      if (cleanPhone.length < 10) {
        showErrorToast({
          title: 'Invalid Phone Number',
          description: 'Phone number format is invalid for WhatsApp.'
        });
        return;
      }
      window.open(`https://wa.me/${cleanPhone}`, '_blank');
    }
  };

  const maskText = (text: string, type: 'phone' | 'email') => {
    if (!text) return '';
    
    if (type === 'phone') {
      // Show only last 2 digits: +91-XXXXX-XX10
      const last2 = text.slice(-2);
      return `+91-XXXXX-XX${last2}`;
    } else {
      // Show only first 3 chars and domain: raj***@gmail.com
      const [name, domain] = text.split('@');
      const maskedName = name.slice(0, 3) + '***';
      return `${maskedName}@${domain}`;
    }
  };

  if (showPaywall) {
    return (
      <LeadPaywall
        title="Unlock Contact Information"
        description={`Access contact details for ${professionalName}. Once unlocked, you can contact them anytime.`}
        requirementId={professionalId}
        accessType="contact"
        entityType="professional"
        onUnlock={() => handleUnlock(pendingAction || undefined)}
        creditsRequired={1}
      />
    );
  }

  if (variant === 'buttons') {
    return (
      <div className="flex flex-wrap gap-3">
        <Button 
          onClick={() => handleContactClick('phone')}
          className="flex items-center gap-2 bg-construction-primary hover:bg-construction-primary/90"
          disabled={loading}
        >
          <Phone className="h-4 w-4" />
          Call Now
        </Button>
        <Button 
          variant="outline" 
          onClick={() => handleContactClick('whatsapp')}
          className="flex items-center gap-2 border-green-500 text-green-600 hover:bg-green-50"
          disabled={loading}
        >
          <MessageCircle className="h-4 w-4" />
          WhatsApp Chat
        </Button>
      </div>
    );
  }

  if (variant === 'sidebar') {
    return (
      <div className="space-y-2 sm:space-y-3">
        <Button 
          className="w-full justify-start gap-2 bg-construction-primary hover:bg-construction-primary/90 text-sm sm:text-base h-9 sm:h-10"
          onClick={() => handleContactClick('phone')}
          disabled={loading}
        >
          <Phone className="h-3 w-3 sm:h-4 sm:w-4" />
          <span className="text-xs sm:text-sm">Call Now</span>
        </Button>
        <Button 
          variant="outline" 
          className="w-full justify-start gap-2 border-green-500 text-green-600 hover:bg-green-50 text-sm sm:text-base h-9 sm:h-10"
          onClick={() => handleContactClick('whatsapp')}
          disabled={loading}
        >
          <MessageCircle className="h-3 w-3 sm:h-4 sm:w-4" />
          <span className="text-xs sm:text-sm">WhatsApp Chat</span>
        </Button>
        <div className="text-xs sm:text-sm text-muted-foreground pt-2 sm:pt-3 border-t space-y-1.5 sm:space-y-2">
          {hasAccess ? (
            <>
              {email && (
                <p className="flex items-center gap-1.5 sm:gap-2 break-words">
                  <span>📧</span>
                  <a href={`mailto:${email}`} className="hover:underline break-all">{email}</a>
                </p>
              )}
              {phone && (
                <p className="flex items-center gap-1.5 sm:gap-2">
                  <span>📱</span>
                  <a href={`tel:${phone}`} className="hover:underline">{phone}</a>
                </p>
              )}
            </>
          ) : (
            <>
              {email && (
                <p className="flex items-center gap-1.5 sm:gap-2 break-words">
                  <span>📧</span>
                  <span className="break-all">{maskText(email, 'email')}</span>
                </p>
              )}
              {phone && (
                <p className="flex items-center gap-1.5 sm:gap-2">
                  <span>📱</span>
                  <span>{maskText(phone, 'phone')}</span>
                </p>
              )}
            </>
          )}
        </div>
      </div>
    );
  }

  // variant === 'text'
  return (
    <div className="text-sm text-muted-foreground">
      {hasAccess ? (
        <>
          {email && <p>📧 {email}</p>}
          {phone && <p>📱 {phone}</p>}
        </>
      ) : (
        <>
          {email && <p>📧 {maskText(email, 'email')}</p>}
          {phone && <p>📱 {maskText(phone, 'phone')}</p>}
          <Button 
            size="sm" 
            className="mt-2"
            onClick={() => setShowPaywall(true)}
          >
            <Lock className="h-3 w-3 mr-1" />
            Unlock Contact (1 Credit)
          </Button>
        </>
      )}
    </div>
  );
};
