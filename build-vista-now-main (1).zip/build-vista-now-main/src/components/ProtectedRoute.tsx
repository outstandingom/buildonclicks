
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useProviderDashboard } from '@/hooks/useProviderDashboard';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAuth?: boolean;
  requireProvider?: boolean;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  requireAuth = true,
  requireProvider = false 
}) => {
  const { user, loading } = useAuth();
  const location = useLocation();
  const { hasRegistration, businessRegistration, loading: providerLoading } = useProviderDashboard(user?.id);

  // Show loading state
  if (loading || (requireProvider && providerLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  // Handle authentication requirements
  if (requireAuth === false && user) {
    // User is authenticated but route doesn't require auth (like /auth page)
    return <Navigate to="/" replace />;
  }

  if (requireAuth && !user) {
    // User is not authenticated but route requires auth
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  // Handle provider requirements
  if (requireProvider && user) {
    const userType = user.user_metadata?.user_type;
    
    if (userType !== 'provider') {
      return <Navigate to="/" replace />;
    }

    // Only redirect to registration if user has no registration at all
    // Or if registration is rejected
    if (!hasRegistration || businessRegistration?.status === 'rejected') {
      return <Navigate to="/business-registration" replace />;
    }
    
    // For pending or approved registrations, allow access
    // The individual pages will handle showing appropriate content based on status
  }

  return <>{children}</>;
};
