import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface QuickRequirementPopupProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const QuickRequirementPopup = ({ open, onOpenChange }: QuickRequirementPopupProps) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    service: "",
    message: ""
  });

  const serviceOptions = [
    "Material Supply",
    "Civil Contractor",
    "Electrical Work",
    "Plumbing",
    "Architecture Design",
    "Interior Design",
    "Project Management",
    "Other"
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.phone || !formData.service) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('quick_requirement_submissions')
        .insert({
          name: formData.name,
          phone: formData.phone,
          service: formData.service,
          message: formData.message || null
        });

      if (error) throw error;

      toast({
        title: "Requirement Submitted!",
        description: "We'll connect you with relevant professionals soon.",
      });

      setFormData({ name: "", phone: "", service: "", message: "" });
      onOpenChange(false);
    } catch (error) {
      console.error('Error submitting requirement:', error);
      toast({
        variant: "destructive",
        title: "Submission Failed",
        description: "Please try again later."
      });
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl">Post Your Requirement</DialogTitle>
          <DialogDescription>
            Tell us what you're looking for and we'll connect you with the right professionals
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {/* Name Field */}
          <div className="space-y-2">
            <Label htmlFor="popup-name">Full Name *</Label>
            <Input
              id="popup-name"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder="Enter your name"
              required
            />
          </div>

          {/* Phone Field */}
          <div className="space-y-2">
            <Label htmlFor="popup-phone">Phone Number *</Label>
            <Input
              id="popup-phone"
              value={formData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              placeholder="Enter your phone number"
              required
            />
          </div>

          {/* Service Selection */}
          <div className="space-y-2">
            <Label htmlFor="popup-service">Service Looking For *</Label>
            <Select value={formData.service} onValueChange={(value) => handleInputChange('service', value)}>
              <SelectTrigger id="popup-service">
                <SelectValue placeholder="Select service" />
              </SelectTrigger>
              <SelectContent>
                {serviceOptions.map((service) => (
                  <SelectItem key={service} value={service}>{service}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Custom Message Field */}
          <div className="space-y-2">
            <Label htmlFor="popup-message">
              Additional Details {formData.service && formData.service !== "Other" && "(Optional)"}
              {formData.service === "Other" && " *"}
            </Label>
            <Textarea
              id="popup-message"
              value={formData.message}
              onChange={(e) => handleInputChange('message', e.target.value)}
              placeholder={
                formData.service === "Other" 
                  ? "Please describe the service you're looking for..."
                  : "Provide any additional details about your requirement (e.g., project size, timeline, specific needs)..."
              }
              rows={4}
              required={formData.service === "Other"}
            />
            {formData.service === "Other" && (
              <p className="text-xs text-muted-foreground">
                Please provide details about the service you need since you selected "Other"
              </p>
            )}
          </div>

          <Button type="submit" className="w-full" size="lg">
            Submit Requirement
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default QuickRequirementPopup;
