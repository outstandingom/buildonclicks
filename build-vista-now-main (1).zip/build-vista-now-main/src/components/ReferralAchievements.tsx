import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Trophy, Award, Star, Crown, Target } from 'lucide-react';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  threshold: number;
  earned: boolean;
  progress: number;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
}

interface ReferralAchievementsProps {
  totalReferrals: number;
  successfulReferrals: number;
  creditsEarned: number;
}

export const ReferralAchievements: React.FC<ReferralAchievementsProps> = ({
  totalReferrals,
  successfulReferrals,
  creditsEarned
}) => {
  const achievements: Achievement[] = [
    {
      id: 'first_referral',
      title: 'First Steps',
      description: 'Send your first referral',
      icon: <Target className="w-5 h-5" />,
      threshold: 1,
      earned: totalReferrals >= 1,
      progress: Math.min((totalReferrals / 1) * 100, 100),
      tier: 'bronze'
    },
    {
      id: 'five_referrals',
      title: 'Getting Started',
      description: '5 successful referrals',
      icon: <Award className="w-5 h-5" />,
      threshold: 5,
      earned: successfulReferrals >= 5,
      progress: Math.min((successfulReferrals / 5) * 100, 100),
      tier: 'bronze'
    },
    {
      id: 'ten_referrals',
      title: 'Rising Star',
      description: '10 successful referrals',
      icon: <Star className="w-5 h-5" />,
      threshold: 10,
      earned: successfulReferrals >= 10,
      progress: Math.min((successfulReferrals / 10) * 100, 100),
      tier: 'silver'
    },
    {
      id: 'twenty_referrals',
      title: 'Champion',
      description: '20 successful referrals',
      icon: <Trophy className="w-5 h-5" />,
      threshold: 20,
      earned: successfulReferrals >= 20,
      progress: Math.min((successfulReferrals / 20) * 100, 100),
      tier: 'gold'
    },
    {
      id: 'fifty_referrals',
      title: 'Legend',
      description: '50 successful referrals',
      icon: <Crown className="w-5 h-5" />,
      threshold: 50,
      earned: successfulReferrals >= 50,
      progress: Math.min((successfulReferrals / 50) * 100, 100),
      tier: 'platinum'
    }
  ];

  const getTierColor = (tier: Achievement['tier'], earned: boolean) => {
    if (!earned) return 'secondary';
    switch (tier) {
      case 'bronze': return 'default';
      case 'silver': return 'secondary';
      case 'gold': return 'default';
      case 'platinum': return 'default';
      default: return 'secondary';
    }
  };

  const getTierBadgeClass = (tier: Achievement['tier']) => {
    switch (tier) {
      case 'bronze': return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'silver': return 'bg-slate-100 text-slate-800 border-slate-300';
      case 'gold': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'platinum': return 'bg-purple-100 text-purple-800 border-purple-300';
      default: return '';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Trophy className="w-5 h-5 mr-2" />
          Achievements
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          {achievements.map((achievement) => (
            <div
              key={achievement.id}
              className={`p-4 rounded-lg border transition-all ${
                achievement.earned 
                  ? 'bg-primary/5 border-primary/20 shadow-sm' 
                  : 'bg-muted/30 border-muted'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${
                    achievement.earned 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-muted text-muted-foreground'
                  }`}>
                    {achievement.icon}
                  </div>
                  <div>
                    <h4 className={`font-semibold ${
                      achievement.earned ? 'text-foreground' : 'text-muted-foreground'
                    }`}>
                      {achievement.title}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {achievement.description}
                    </p>
                  </div>
                </div>
                <div className="flex flex-col items-end space-y-1">
                  <Badge
                    variant={getTierColor(achievement.tier, achievement.earned)}
                    className={achievement.earned ? getTierBadgeClass(achievement.tier) : ''}
                  >
                    {achievement.tier.toUpperCase()}
                  </Badge>
                  {achievement.earned && (
                    <Badge variant="default" className="bg-green-100 text-green-800 border-green-300">
                      ✓ Earned
                    </Badge>
                  )}
                </div>
              </div>
              {!achievement.earned && (
                <div className="mt-3">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="text-muted-foreground">
                      {Math.floor(achievement.progress)}%
                    </span>
                  </div>
                  <Progress value={achievement.progress} className="h-2" />
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};