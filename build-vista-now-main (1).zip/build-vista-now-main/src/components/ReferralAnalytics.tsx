import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { TrendingUp, Users, Award, Calendar } from 'lucide-react';

interface ReferralAnalyticsProps {
  stats: {
    referral_code: string;
    total_referrals: number;
    total_credits_earned: number;
    successful_referrals: number;
    pending_referrals: number;
  } | null;
  history: Array<{
    id: string;
    referee_name: string;
    status: 'pending' | 'completed' | 'expired';
    reward_type: string;
    credits_earned: number;
    created_at: string;
    completed_at?: string;
  }>;
}

export const ReferralAnalytics: React.FC<ReferralAnalyticsProps> = ({ stats, history }) => {
  if (!stats) return null;

  // Monthly referral data (mock data for demonstration)
  const monthlyData = [
    { month: 'Jan', referrals: 2, earnings: 100 },
    { month: 'Feb', referrals: 4, earnings: 200 },
    { month: 'Mar', referrals: 3, earnings: 150 },
    { month: 'Apr', referrals: 6, earnings: 300 },
    { month: 'May', referrals: 8, earnings: 400 },
    { month: 'Jun', referrals: 5, earnings: 250 },
  ];

  // Status distribution
  const statusData = [
    { name: 'Completed', value: stats.successful_referrals, color: '#22c55e' },
    { name: 'Pending', value: stats.pending_referrals, color: '#f59e0b' },
    { name: 'Expired', value: Math.max(0, stats.total_referrals - stats.successful_referrals - stats.pending_referrals), color: '#ef4444' }
  ];

  const conversionRate = stats.total_referrals > 0 ? (stats.successful_referrals / stats.total_referrals * 100).toFixed(1) : '0';
  const avgCreditsPerReferral = stats.successful_referrals > 0 ? (stats.total_credits_earned / stats.successful_referrals).toFixed(0) : '0';

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Users className="h-4 w-4 text-muted-foreground" />
              <div className="ml-2">
                <p className="text-2xl font-bold">{stats.total_referrals}</p>
                <p className="text-xs text-muted-foreground">Total Referrals</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              <div className="ml-2">
                <p className="text-2xl font-bold">{conversionRate}%</p>
                <p className="text-xs text-muted-foreground">Success Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Award className="h-4 w-4 text-muted-foreground" />
              <div className="ml-2">
                <p className="text-2xl font-bold">{stats.total_credits_earned}</p>
                <p className="text-xs text-muted-foreground">Credits Earned</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <div className="ml-2">
                <p className="text-2xl font-bold">{avgCreditsPerReferral}</p>
                <p className="text-xs text-muted-foreground">Avg Credits/Referral</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Trend */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Referral Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Line type="monotone" dataKey="referrals" stroke="hsl(var(--primary))" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Referral Status</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center space-x-4 mt-4">
              {statusData.map((entry, index) => (
                <div key={index} className="flex items-center">
                  <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: entry.color }}></div>
                  <span className="text-sm">{entry.name}: {entry.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Earnings Trend */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Credits Earned Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Bar dataKey="earnings" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};