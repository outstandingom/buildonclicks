import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Gift, Check } from 'lucide-react';
import { useReferrals } from '@/hooks/useReferrals';

interface ReferralCodeInputProps {
  onSuccess?: () => void;
  className?: string;
}

export const ReferralCodeInput: React.FC<ReferralCodeInputProps> = ({ 
  onSuccess, 
  className 
}) => {
  const [referralCode, setReferralCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const { processReferralCode } = useReferrals();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!referralCode.trim()) return;

    setIsSubmitting(true);
    try {
      const success = await processReferralCode(referralCode.trim().toUpperCase());
      if (success) {
        setIsSuccess(true);
        onSuccess?.();
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <Card className={className}>
        <CardContent className="p-6">
          <div className="text-center space-y-3">
            <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto">
              <Check className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <h3 className="font-semibold text-green-600">Referral Applied!</h3>
              <p className="text-sm text-muted-foreground">
                Your bonus credits have been added to your account.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardHeader className="text-center">
        <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-2">
          <Gift className="h-6 w-6 text-blue-600" />
        </div>
        <CardTitle>Have a Referral Code?</CardTitle>
        <CardDescription>
          Enter your referral code to get bonus credits
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Input
              placeholder="Enter referral code"
              value={referralCode}
              onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
              className="text-center font-mono tracking-wider"
              maxLength={20}
            />
          </div>
          <Button 
            type="submit" 
            className="w-full" 
            disabled={!referralCode.trim() || isSubmitting}
          >
            {isSubmitting ? 'Applying...' : 'Apply Referral Code'}
          </Button>
        </form>
        
        <div className="mt-4 text-xs text-muted-foreground text-center">
          Don't have a referral code? No worries, you can still join and start earning credits!
        </div>
      </CardContent>
    </Card>
  );
};