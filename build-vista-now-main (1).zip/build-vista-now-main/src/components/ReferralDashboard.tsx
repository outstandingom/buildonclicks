import React, { useState } from 'react';
import { useReferrals } from '@/hooks/useReferrals';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Copy, MessageCircle, Smartphone, Share2, Gift, Users, CreditCard, Clock, QrCode, Trophy, TrendingUp, Star, Zap, Target, Award, Mail, Twitter, Facebook, Linkedin } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { ReferralQRCode } from '@/components/ReferralQRCode';
import { ReferralAnalytics } from '@/components/ReferralAnalytics';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguage } from '@/contexts/LanguageContext';
import { Progress } from '@/components/ui/progress';

export const ReferralDashboard = () => {
  const { stats, history, loading, shareReferral, generateShareUrl } = useReferrals();
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState('overview');

  // Calculate progress to next level (mock logic)
  const currentLevel = Math.floor((stats?.total_referrals || 0) / 5) + 1;
  const nextLevelReferrals = currentLevel * 5;
  const progressToNext = ((stats?.total_referrals || 0) % 5) / 5 * 100;

  if (loading) {
    return (
      <div className="space-y-8">
        {/* Hero Section Skeleton */}
        <div className="bg-gradient-hero rounded-2xl p-8 shadow-feature">
          <div className="space-y-4">
            <Skeleton className="h-8 w-64" />
            <Skeleton className="h-4 w-96" />
            <div className="flex gap-4">
              <Skeleton className="h-10 w-32" />
              <Skeleton className="h-10 w-32" />
            </div>
          </div>
        </div>
        
        {/* Stats Grid Skeleton */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="space-y-0 pb-2">
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center space-y-4">
            <div className="w-16 h-16 bg-construction-accent/10 rounded-full flex items-center justify-center mx-auto">
              <Gift className="w-8 h-8 text-construction-accent" />
            </div>
            <h3 className="text-xl font-semibold">{t('pages.referral.welcome.title')}</h3>
            <p className="text-muted-foreground">
              {t('referral.welcome.description')}
            </p>
            <Button className="w-full">{t('pages.referral.welcome.getStarted')}</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const shareUrl = generateShareUrl(stats.referral_code);

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="bg-gradient-hero rounded-2xl p-8 shadow-feature border border-border/20">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-4 flex-1">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-construction-accent/10 text-construction-accent border-construction-accent/20">
                  {t('pages.referral.level')} {currentLevel}
                </Badge>
                <Badge variant="outline">
                  <Zap className="w-3 h-3 mr-1" />
                  {stats.total_credits_earned} {t('pages.referral.creditsEarned')}
                </Badge>
              </div>
              <h1 className="text-3xl lg:text-4xl font-bold text-primary">
                {t('pages.referral.title')}
              </h1>
              <p className="text-lg text-muted-foreground max-w-xl">
                {t('pages.referral.description')}
              </p>
            </div>
            
            {/* Progress to Next Level */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">{t('pages.referral.progressToLevel')} {currentLevel + 1}</span>
                <span className="font-medium">{stats.total_referrals}/{nextLevelReferrals}</span>
              </div>
              <Progress value={progressToNext} className="h-2" />
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-col gap-3 min-w-[200px]">
            <Button 
              className="w-full bg-construction-accent hover:bg-construction-accent/90 text-white"
              onClick={() => shareReferral(stats.referral_code, 'copy')}
            >
              <Share2 className="w-4 h-4 mr-2" />
              {t('pages.referral.shareNow')}
            </Button>
            <Button variant="outline" onClick={() => setActiveTab('qr')}>
              <QrCode className="w-4 h-4 mr-2" />
              {t('pages.referral.qrCode')}
            </Button>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-gradient-card border-0 shadow-card hover:shadow-hover transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t('pages.referral.stats.referralCode')}</CardTitle>
            <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
              <Share2 className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{stats.referral_code}</div>
            <p className="text-xs text-muted-foreground mt-1">{t('pages.referral.descriptions.shareCode')}</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-card border-0 shadow-card hover:shadow-hover transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t('pages.referral.stats.totalReferrals')}</CardTitle>
            <div className="w-8 h-8 bg-construction-accent/10 rounded-lg flex items-center justify-center">
              <Users className="h-4 w-4 text-construction-accent" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total_referrals}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats.successful_referrals} {t('pages.referral.descriptions.successful')}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-card border-0 shadow-card hover:shadow-hover transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t('pages.referral.stats.creditsEarned')}</CardTitle>
            <div className="w-8 h-8 bg-green-500/10 rounded-lg flex items-center justify-center">
              <Gift className="h-4 w-4 text-green-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.total_credits_earned}</div>
            <p className="text-xs text-muted-foreground mt-1">{t('pages.referral.descriptions.fromReferrals')}</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-card border-0 shadow-card hover:shadow-hover transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{t('pages.referral.stats.pending')}</CardTitle>
            <div className="w-8 h-8 bg-orange-500/10 rounded-lg flex items-center justify-center">
              <Clock className="h-4 w-4 text-orange-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.pending_referrals}</div>
            <p className="text-xs text-muted-foreground mt-1">{t('pages.referral.descriptions.awaitingCompletion')}</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabbed Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 bg-muted/50">
          <TabsTrigger value="overview">{t('pages.referral.tabs.overview')}</TabsTrigger>
          <TabsTrigger value="share">{t('pages.referral.tabs.share')}</TabsTrigger>
          <TabsTrigger value="qr">{t('pages.referral.tabs.qrCode')}</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* How it Works */}
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-construction-accent" />
                {t('pages.referral.howItWorks.title')}
              </CardTitle>
              <CardDescription>
                {t('pages.referral.howItWorks.description')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-xl font-bold text-primary">1</span>
                  </div>
                  <h4 className="font-medium">{t('pages.referral.howItWorks.step1.title')}</h4>
                  <p className="text-sm text-muted-foreground">
                    {t('pages.referral.howItWorks.step1.description')}
                  </p>
                </div>
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 bg-construction-accent/10 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-xl font-bold text-construction-accent">2</span>
                  </div>
                  <h4 className="font-medium">{t('pages.referral.howItWorks.step2.title')}</h4>
                  <p className="text-sm text-muted-foreground">
                    {t('pages.referral.howItWorks.step2.description')}
                  </p>
                </div>
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-xl font-bold text-green-600">3</span>
                  </div>
                  <h4 className="font-medium">{t('pages.referral.howItWorks.step3.title')}</h4>
                  <p className="text-sm text-muted-foreground">
                    {t('pages.referral.howItWorks.step3.description')}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          {history.length > 0 && (
            <Card className="bg-gradient-card border-0 shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-primary" />
                  {t('pages.referral.history.title')}
                </CardTitle>
                <CardDescription>
                  {t('pages.referral.history.description')}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {history.slice(0, 5).map((item, index) => (
                    <div key={item.id}>
                      <div className="flex items-center justify-between py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-construction-accent/10 rounded-full flex items-center justify-center">
                            <Users className="w-4 h-4 text-construction-accent" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{item.referee_name}</span>
                              <Badge
                                variant={
                                  item.status === 'completed'
                                    ? 'default'
                                    : item.status === 'pending'
                                    ? 'secondary'
                                    : 'destructive'
                                }
                                className="text-xs"
                              >
                                {item.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {new Date(item.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-green-600">
                            +{item.credits_earned} {t('pages.referral.history.credits')}
                          </div>
                          <p className="text-xs text-muted-foreground capitalize">
                            {item.reward_type}
                          </p>
                        </div>
                      </div>
                      {index < Math.min(history.length, 5) - 1 && <Separator />}
                    </div>
                  ))}
                </div>
                {history.length > 5 && (
                  <Button variant="outline" className="w-full mt-4">
                    {t('pages.referral.history.viewAll')}
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="share" className="space-y-6">
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Share2 className="w-5 h-5 text-construction-accent" />
                {t('pages.referral.share.title')}
              </CardTitle>
              <CardDescription>
                {t('pages.referral.share.description')}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Referral Code Display */}
              <div className="p-4 bg-muted/30 rounded-lg border border-border/50">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{t('pages.referral.stats.referralCode')}</p>
                    <code className="text-2xl font-bold text-primary">{stats.referral_code}</code>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => shareReferral(stats.referral_code, 'copy')}
                    className="bg-construction-accent hover:bg-construction-accent/90"
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    {t('common.save') || 'Copy'}
                  </Button>
                </div>
              </div>

              {/* Referral Link */}
              <div className="p-4 bg-muted/30 rounded-lg border border-border/50">
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-muted-foreground mb-1">{t('pages.referral.share.referralLink')}</p>
                    <p className="text-sm font-mono text-primary truncate">{shareUrl}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => navigator.clipboard.writeText(shareUrl)}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Social Share Buttons */}
              <div className="space-y-4">
                <h4 className="font-medium">{t('pages.referral.share.socialMedia')}</h4>
                <div className="grid gap-3 sm:grid-cols-2">
                  <Button
                    variant="outline"
                    className="justify-start h-12"
                    onClick={() => shareReferral(stats.referral_code, 'whatsapp')}
                  >
                    <MessageCircle className="h-5 w-5 mr-3 text-green-600" />
                    {t('pages.referral.share.whatsapp')}
                  </Button>
                  <Button
                    variant="outline"
                    className="justify-start h-12"
                    onClick={() => shareReferral(stats.referral_code, 'sms')}
                  >
                    <Smartphone className="h-5 w-5 mr-3 text-blue-600" />
                    {t('pages.referral.share.sms')}
                  </Button>
                  <Button
                    variant="outline"
                    className="justify-start h-12"
                    onClick={() => window.open(`mailto:?subject=${encodeURIComponent("Join this amazing platform")}&body=${encodeURIComponent(`Use my referral code: ${stats.referral_code} or click: ${shareUrl}`)}`)}
                  >
                    <Mail className="h-5 w-5 mr-3 text-red-600" />
                    {t('pages.referral.share.email')}
                  </Button>
                  <Button
                    variant="outline"
                    className="justify-start h-12"
                    onClick={() => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(`Join this amazing platform! Use my referral code: ${stats.referral_code} ${shareUrl}`)}`)}
                  >
                    <Twitter className="h-5 w-5 mr-3 text-blue-400" />
                    {t('pages.referral.share.twitter')}
                  </Button>
                </div>
              </div>

              {/* Tips */}
              <div className="p-4 bg-construction-accent/5 rounded-lg border border-construction-accent/20">
                <h4 className="font-medium text-construction-accent mb-2">{t('pages.referral.share.tips.title')}</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• {t('pages.referral.share.tips.tip1')}</li>
                  <li>• {t('pages.referral.share.tips.tip2')}</li>
                  <li>• {t('pages.referral.share.tips.tip3')}</li>
                  <li>• {t('pages.referral.share.tips.tip4')}</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="qr">
          <Card className="bg-gradient-card border-0 shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <QrCode className="w-5 h-5 text-construction-accent" />
                {t('pages.referral.qr.title')}
              </CardTitle>
              <CardDescription>
                {t('pages.referral.qr.description')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ReferralQRCode 
                referralCode={stats.referral_code} 
                shareUrl={shareUrl}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};
