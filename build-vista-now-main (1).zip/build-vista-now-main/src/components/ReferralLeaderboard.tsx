import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Trophy, Medal, Award, Crown } from 'lucide-react';

interface LeaderboardEntry {
  rank: number;
  name: string;
  avatar?: string;
  referrals: number;
  credits: number;
  isCurrentUser?: boolean;
}

interface ReferralLeaderboardProps {
  userStats?: {
    referral_code: string;
    total_referrals: number;
    total_credits_earned: number;
    successful_referrals: number;
    pending_referrals: number;
  } | null;
}

export const ReferralLeaderboard: React.FC<ReferralLeaderboardProps> = ({ userStats }) => {
  // Mock leaderboard data - in real implementation, this would come from the backend
  const leaderboardData: LeaderboardEntry[] = [
    { rank: 1, name: 'Rahul Sharma', referrals: 125, credits: 6250 },
    { rank: 2, name: 'Priya Patel', referrals: 98, credits: 4900 },
    { rank: 3, name: 'Amit Kumar', referrals: 87, credits: 4350 },
    { rank: 4, name: 'Neha Singh', referrals: 76, credits: 3800 },
    { rank: 5, name: 'Vikash Gupta', referrals: 65, credits: 3250 },
    { rank: 6, name: 'Sunita Devi', referrals: 54, credits: 2700 },
    { rank: 7, name: 'Ravi Yadav', referrals: 43, credits: 2150 },
    { rank: 8, name: 'Anjali Mehta', referrals: 38, credits: 1900 },
    // Add current user if they have stats
    ...(userStats ? [{
      rank: 15,
      name: 'You',
      referrals: userStats.successful_referrals,
      credits: userStats.total_credits_earned,
      isCurrentUser: true
    }] : [])
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-5 h-5 text-yellow-500" />;
      case 2:
        return <Trophy className="w-5 h-5 text-gray-400" />;
      case 3:
        return <Medal className="w-5 h-5 text-amber-600" />;
      default:
        return <Award className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getRankBadgeClass = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-white';
      case 2:
        return 'bg-gradient-to-r from-gray-300 to-gray-500 text-white';
      case 3:
        return 'bg-gradient-to-r from-amber-400 to-amber-600 text-white';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Trophy className="w-5 h-5 mr-2" />
          Top Referrers This Month
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {leaderboardData.slice(0, 10).map((entry) => (
            <div
              key={`${entry.rank}-${entry.name}`}
              className={`flex items-center justify-between p-3 rounded-lg transition-all ${
                entry.isCurrentUser 
                  ? 'bg-primary/10 border border-primary/20 shadow-sm' 
                  : 'bg-muted/30 hover:bg-muted/50'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-8 h-8">
                  {entry.rank <= 3 ? (
                    getRankIcon(entry.rank)
                  ) : (
                    <Badge variant="outline" className={getRankBadgeClass(entry.rank)}>
                      {entry.rank}
                    </Badge>
                  )}
                </div>
                
                <Avatar className="w-8 h-8">
                  <AvatarImage src={entry.avatar} />
                  <AvatarFallback className="text-xs">
                    {entry.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                
                <div>
                  <p className={`font-medium ${entry.isCurrentUser ? 'text-primary' : ''}`}>
                    {entry.name}
                    {entry.isCurrentUser && (
                      <Badge variant="outline" className="ml-2 text-xs">
                        You
                      </Badge>
                    )}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {entry.referrals} referrals
                  </p>
                </div>
              </div>
              
              <div className="text-right">
                <p className="font-semibold text-primary">
                  {entry.credits.toLocaleString()} credits
                </p>
                <p className="text-xs text-muted-foreground">
                  {entry.credits > 0 ? `₹${(entry.credits * 10).toLocaleString()}` : '₹0'}
                </p>
              </div>
            </div>
          ))}
        </div>
        
        {userStats && userStats.successful_referrals === 0 && (
          <div className="mt-6 p-4 bg-muted/30 rounded-lg text-center">
            <Award className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">
              Start referring friends to see your rank on the leaderboard!
            </p>
          </div>
        )}
        
        <div className="mt-4 p-3 bg-gradient-to-r from-primary/10 to-primary/5 rounded-lg">
          <p className="text-sm text-center text-muted-foreground">
            🏆 Top 3 referrers each month win special rewards!
          </p>
        </div>
      </CardContent>
    </Card>
  );
};