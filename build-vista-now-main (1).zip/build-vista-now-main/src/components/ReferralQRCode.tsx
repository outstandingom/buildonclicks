import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, Share2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ReferralQRCodeProps {
  referralCode: string;
  shareUrl: string;
}

export const ReferralQRCode: React.FC<ReferralQRCodeProps> = ({ referralCode, shareUrl }) => {
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    const generateQRCode = async () => {
      try {
        const url = await QRCode.toDataURL(shareUrl, {
          width: 200,
          margin: 2,
          color: {
            dark: '#000000',
            light: '#FFFFFF'
          }
        });
        setQrCodeUrl(url);
      } catch (error) {
        console.error('Error generating QR code:', error);
      }
    };

    if (shareUrl) {
      generateQRCode();
    }
  }, [shareUrl]);

  const downloadQRCode = () => {
    if (qrCodeUrl) {
      const link = document.createElement('a');
      link.download = `referral-${referralCode}.png`;
      link.href = qrCodeUrl;
      link.click();
      toast({
        title: "Downloaded!",
        description: "QR code saved to your device.",
      });
    }
  };

  const shareQRCode = async () => {
    if (navigator.share && qrCodeUrl) {
      try {
        const response = await fetch(qrCodeUrl);
        const blob = await response.blob();
        const file = new File([blob], `referral-${referralCode}.png`, { type: 'image/png' });
        
        await navigator.share({
          title: 'Join using my referral code!',
          text: `Use my referral code: ${referralCode}`,
          files: [file]
        });
      } catch (error) {
        console.error('Error sharing QR code:', error);
        downloadQRCode();
      }
    } else {
      downloadQRCode();
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-center">QR Code</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center space-y-4">
        {qrCodeUrl && (
          <div className="bg-white p-4 rounded-lg shadow-inner">
            <img src={qrCodeUrl} alt="Referral QR Code" className="w-48 h-48" />
          </div>
        )}
        <p className="text-sm text-muted-foreground text-center">
          Share this QR code for easy offline referrals
        </p>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={downloadQRCode}>
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
          <Button variant="outline" size="sm" onClick={shareQRCode}>
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};