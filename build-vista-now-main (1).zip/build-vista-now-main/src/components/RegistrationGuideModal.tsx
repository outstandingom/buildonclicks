import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Building, 
  Users, 
  Share2, 
  Shield, 
  CreditCard, 
  CheckCircle, 
  FileText, 
  Clock, 
  AlertTriangle,
  Star,
  Camera,
  Phone,
  Mail,
  MapPin,
  Globe
} from 'lucide-react';

interface RegistrationGuideModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStartRegistration: () => void;
}

export const RegistrationGuideModal: React.FC<RegistrationGuideModalProps> = ({
  open,
  onOpenChange,
  onStartRegistration
}) => {
  const steps = [
    {
      id: 1,
      title: 'Business Information',
      icon: Building,
      description: 'Basic business details and licensing',
      items: [
        'Business name and type (Contractor, Supplier, Architect, etc.)',
        'Registration number and GST/VAT details',
        'Business address and service areas',
        'Years of experience and service description',
        'Business license document (PDF/Image)'
      ]
    },
    {
      id: 2,
      title: 'Contact Information',
      icon: Users,
      description: 'How clients can reach you',
      items: [
        'Primary contact person name',
        'Phone number and email address',
        'Alternate contact details',
        'Preferred communication method'
      ]
    },
    {
      id: 3,
      title: 'Social Media & Online Presence',
      icon: Share2,
      description: 'Optional but recommended',
      items: [
        'LinkedIn business profile',
        'Facebook business page',
        'Instagram handle',
        'Website or other professional links'
      ]
    },
    {
      id: 4,
      title: 'Document Verification',
      icon: Shield,
      description: 'Required for identity verification',
      items: [
        'Government ID (Aadhaar, PAN, Passport)',
        'Business registration certificate',
        'Insurance certificate (for contractors)',
        'All documents must be clear and up-to-date'
      ]
    },
    {
      id: 5,
      title: 'Banking Information',
      icon: CreditCard,
      description: 'For payments and transactions',
      items: [
        'Bank name and account number',
        'Account type (Savings/Current)',
        'IFSC code for transfers',
        'Account should be in business name'
      ]
    }
  ];

  const requirements = [
    {
      category: 'Documents Required',
      icon: FileText,
      items: [
        'Business registration/license',
        'Government issued ID',
        'Business certificate',
        'Insurance certificate (contractors)',
        'All documents in PDF, JPG, or PNG format (max 10MB)'
      ]
    },
    {
      category: 'Business Eligibility',
      icon: Building,
      items: [
        'Registered business or proprietorship',
        'Valid business license',
        'Minimum 1 year of experience',
        'Service areas within listed cities',
        'Professional contact information'
      ]
    },
    {
      category: 'Verification Process',
      icon: Shield,
      items: [
        'Document authenticity check',
        'Business license verification',
        'Contact information validation',
        'Background verification call',
        'Final approval by admin team'
      ]
    }
  ];

  const timeline = [
    { step: 'Submit Registration', time: '15-30 minutes', icon: FileText },
    { step: 'Document Review', time: '24-48 hours', icon: Clock },
    { step: 'Verification Call', time: '1-2 hours', icon: Phone },
    { step: 'Final Approval', time: '24 hours', icon: CheckCircle }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <Building className="w-6 h-6 text-primary" />
            Provider Registration Guide
          </DialogTitle>
          <DialogDescription>
            Complete guide to becoming a verified provider on BuildOnClicks platform
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Overview */}
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-primary" />
                Why Register as a Provider?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-semibold">Benefits:</h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Access to verified client leads</li>
                    <li>• Professional business profile</li>
                    <li>• Direct client communication</li>
                    <li>• Secure payment processing</li>
                    <li>• Marketing and promotion support</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold">Requirements:</h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Valid business registration</li>
                    <li>• Professional experience</li>
                    <li>• Complete documentation</li>
                    <li>• Service area coverage</li>
                    <li>• Quality commitment</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Registration Steps */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-primary" />
              Registration Process (5 Easy Steps)
            </h3>
            <div className="grid gap-4">
              {steps.map((step, index) => {
                const StepIcon = step.icon;
                return (
                  <Card key={step.id} className="border-l-4 border-l-primary">
                    <CardHeader className="pb-3">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                          {step.id}
                        </div>
                        <StepIcon className="w-5 h-5" />
                        {step.title}
                      </CardTitle>
                      <CardDescription>{step.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-1">
                        {step.items.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm">
                            <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Requirements */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Requirements & Eligibility
            </h3>
            <div className="grid md:grid-cols-3 gap-4">
              {requirements.map((req, index) => {
                const ReqIcon = req.icon;
                return (
                  <Card key={index}>
                    <CardHeader className="pb-3">
                      <CardTitle className="flex items-center gap-2 text-base">
                        <ReqIcon className="w-5 h-5 text-primary" />
                        {req.category}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-1">
                        {req.items.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm">
                            <CheckCircle className="w-3 h-3 text-green-600 mt-1 flex-shrink-0" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Timeline */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              Approval Timeline
            </h3>
            <Card>
              <CardContent className="pt-6">
                <div className="grid md:grid-cols-4 gap-4">
                  {timeline.map((item, index) => {
                    const TimeIcon = item.icon;
                    return (
                      <div key={index} className="text-center">
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                          <TimeIcon className="w-6 h-6 text-primary" />
                        </div>
                        <h4 className="font-medium text-sm">{item.step}</h4>
                        <p className="text-xs text-muted-foreground">{item.time}</p>
                        {index < timeline.length - 1 && (
                          <div className="hidden md:block absolute top-6 left-full w-full h-0.5 bg-border transform translate-x-2"></div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Important Notes */}
          <Card className="border-amber-200 bg-amber-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-amber-800">
                <AlertTriangle className="w-5 h-5" />
                Important Notes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-amber-700">
                <li>• All information provided must be accurate and verifiable</li>
                <li>• Incomplete applications will be rejected and require resubmission</li>
                <li>• Document quality is crucial - ensure all text is clearly readable</li>
                <li>• False information may result in permanent ban from the platform</li>
                <li>• Registration approval is at the discretion of BuildOnClicks admin team</li>
                <li>• Approved providers must maintain service quality standards</li>
              </ul>
            </CardContent>
          </Card>

          {/* Contact Support */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-800">
                <Phone className="w-5 h-5" />
                Need Help?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4 text-sm text-blue-700">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>support@buildonclicks.com</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>+91 98765 43210</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>Mon-Sat, 9AM-6PM</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Separator />

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Close Guide
            </Button>
            <Button 
              onClick={() => {
                onOpenChange(false);
                onStartRegistration();
              }}
              className="flex items-center gap-2"
            >
              <Building className="w-4 h-4" />
              Start Registration Now
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};