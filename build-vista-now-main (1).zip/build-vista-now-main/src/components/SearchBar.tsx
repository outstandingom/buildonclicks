import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, User, Package, Star, MapPin, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useSearch } from '@/hooks/useSearch';
import { cn } from '@/lib/utils';

interface SearchBarProps {
  className?: string;
}

const SearchBar: React.FC<SearchBarProps> = ({ className }) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  
  const { results, loading, search, clearResults } = useSearch();

  // Handle search when query changes
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (query.trim()) {

        search(query);
        setIsOpen(true);
      } else {
        clearResults();
        setIsOpen(false);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query, search, clearResults]);

  // Handle clicks outside search component
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setIsFocused(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleResultClick = (result: any) => {
    if (result.type === 'professional') {
      if (result.category === 'vendor') {
        navigate(`/shop/${result.id}`);
      } else {
        navigate(`/portfolio/${result.id}`);
      }
    } else if (result.type === 'product') {
      navigate(`/product/${result.id}`);
    }
    setQuery('');
    setIsOpen(false);
    setIsFocused(false);
    clearResults();
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
      setQuery('');
      setIsOpen(false);
      setIsFocused(false);
      clearResults();
    }
  };

  const handleClear = () => {
    setQuery('');
    setIsOpen(false);
    clearResults();
    inputRef.current?.focus();
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div ref={searchRef} className={cn("relative w-full max-w-2xl", className)}>
      <form onSubmit={handleSearchSubmit} className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            ref={inputRef}
            type="text"
            placeholder="Search..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => {
              setIsFocused(true);
              if (query.trim() && results.length > 0) {
                setIsOpen(true);
              }
            }}
            className={cn(
              "pl-10 pr-10 h-10 w-full",
              isFocused && "ring-2 ring-primary ring-offset-2"
            )}
          />
          
          {/* Clear button */}
          {query && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleClear}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 h-7 w-7 p-0 hover:bg-muted z-10"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </form>

      {/* Search Results Dropdown */}
      {isOpen && (query.trim() || loading) && (
        <Card className="absolute top-full left-0 right-0 mt-1 z-50 shadow-lg border max-h-96 overflow-y-auto">
          <CardContent className="p-0">
            {loading ? (
              <div className="p-4 text-center">
                <div className="inline-flex items-center space-x-2">
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                  <span className="text-sm text-muted-foreground">Searching...</span>
                </div>
              </div>
            ) : results.length > 0 ? (
              <div className="py-2">
                {results.map((result, index) => (
                  <div
                    key={`${result.type}-${result.id}`}
                    onClick={() => handleResultClick(result)}
                    className="px-4 py-3 hover:bg-accent cursor-pointer border-b last:border-b-0 transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      {/* Icon based on type */}
                      <div className="flex-shrink-0 mt-1">
                        {result.type === 'professional' ? (
                          <User className="h-4 w-4 text-blue-500" />
                        ) : (
                          <Package className="h-4 w-4 text-green-500" />
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="text-sm font-medium text-foreground truncate">
                              {result.title}
                            </h4>
                            <p className="text-xs text-muted-foreground truncate mt-1">
                              {result.description}
                            </p>
                            
                            {/* Business name */}
                            {result.businessName && (
                              <p className="text-xs text-muted-foreground mt-1">
                                {result.businessName}
                              </p>
                            )}

                            {/* Metadata */}
                            <div className="flex items-center space-x-2 mt-2">
                              <Badge variant="secondary" className="text-xs">
                                {result.type === 'professional' ? result.category : result.category}
                              </Badge>
                              
                              {result.rating && (
                                <div className="flex items-center space-x-1">
                                  <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                                  <span className="text-xs text-muted-foreground">
                                    {result.rating}
                                  </span>
                                </div>
                              )}
                              
                              {result.location && (
                                <div className="flex items-center space-x-1">
                                  <MapPin className="h-3 w-3 text-muted-foreground" />
                                  <span className="text-xs text-muted-foreground">
                                    {result.location}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Price for products */}
                          {result.type === 'product' && result.price && (
                            <div className="text-sm font-medium text-primary">
                              {formatPrice(result.price)}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {/* View all results link */}
                {results.length >= 10 && (
                  <div className="px-4 py-2 border-t">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleSearchSubmit({ preventDefault: () => {} } as React.FormEvent)}
                      className="w-full text-primary hover:text-primary/80"
                    >
                      View all results for "{query}"
                    </Button>
                  </div>
                )}
              </div>
            ) : query.trim() ? (
              <div className="p-4 text-center text-sm text-muted-foreground">
                No results found for "{query}"
              </div>
            ) : null}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SearchBar;
