import { useNavigate } from "react-router-dom";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { useBanners } from "@/hooks/useBanners";
import Autoplay from "embla-carousel-autoplay";
import { LazyImage } from "@/components/LazyImage";
import offerBanner1 from "@/assets/offer-banner-1.jpg";
import offerBanner2 from "@/assets/offer-banner-2.jpg";
import offerBanner3 from "@/assets/offer-banner-3.jpg";
import offerBanner4 from "@/assets/offer-banner-4.jpg";
import offerBanner5 from "@/assets/offer-banner-5.jpg";

interface Service {
  title: string;
  icon: string;
  id: string;
  color: string;
  optionsCount: number;
}

const ServicesSection = () => {
  const navigate = useNavigate();
  const { banners } = useBanners();
  
  const services: Service[] = [
    {
      title: "Architects",
      icon: "/lovable-uploads/Archictect.png",
      id: "architects",
      color: "#0000000",
      optionsCount: 30
    },
    {
      title: "Engineers",
      icon: "/lovable-uploads/Engineer.png",
      id: "engineers",
      color: "#C45A2A",
      optionsCount: 17
    },
    {
      title: "Designers",
      icon: "/lovable-uploads/Designer.png",
      id: "designers",
      color: "#000000",
      optionsCount: 40
    },
    
    {
      title: "Manufacturer",
      icon: "/lovable-uploads/Manufacturer.png",
      id: "manufacturer",
      color: "#10B981",
      optionsCount: 21
    },
    {
      title: "Wholesaler",
      icon: "/lovable-uploads/Wholesale.png",
      id: "wholesaler",
      color: "#FBBF24",
      optionsCount: 15
    },
    {
      title: "Retailer",
      icon: "/lovable-uploads/Retail.png",
      id: "retailer",
      color: "#EC4899",
      optionsCount: 27
    },
    {
      title: "Contractors",
      icon: "/lovable-uploads/Contractor.png",
      id: "contractors",
      color: "#EF4444",
      optionsCount: 22
    },
    
    {
      title: "Maintenance",
      icon: "/lovable-uploads/maintenance.png",
      id: "vendors",
      color: "#8B5CF6",
      optionsCount: 18
    }
  ];

  const staticImages = [
    { src: offerBanner1, alt: "Special Construction Offer" },
    { src: offerBanner2, alt: "Building Materials Discount" },
    { src: offerBanner3, alt: "Professional Services" },
    { src: offerBanner4, alt: "Quality Assurance" },
    { src: offerBanner5, alt: "Expert Consultation" }
  ];

  const carouselImages = banners.length > 0 
    ? banners.map(banner => ({ 
        src: banner.image_url, 
        alt: banner.alt_text || banner.title 
      }))
    : staticImages;

  
  const handleServiceClick = (serviceType: string) => {
    navigate(`/professionals?type=${serviceType.toLowerCase()}`);
  };

  return (
    <section className="py-6 sm:py-8 lg:py-10 bg-[#e6e6e6] relative bg-cover bg-center bg-no-repeat" style={{ backgroundImage: 'url(/service-bg.svg)' }}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header - Reduced spacing */}
        <div className="text-center mb-6 sm:mb-8 lg:mb-10">
          <h2 className="text-xl sm:text-2xl lg:text-3xl xl:text-4xl font-bold text-black mb-2 sm:mb-3 lg:mb-4">
            <span className="text-[#C45A2A]">Construction</span> service at your trust
          </h2>
          <p className="text-sm lg:text-base text-black max-w-2xl mx-auto">
            From materials to manpower - All in one place
          </p>
        </div>

        {/* Services Grid - Reduced spacing */}
        <div className="grid grid-cols-4 sm:grid-cols-4 lg:grid-cols-8 gap-4 sm:gap-6 lg:gap-4 max-w-7xl mx-auto mb-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              id={service.id} 
              className="flex flex-col items-center gap-2 cursor-pointer group"
              onClick={() => handleServiceClick(service.title)}
            >
              {/* Updated icon container with exact CSS you provided */}
              <div 
                className="icon-square bg-[#C45A2A] flex items-center justify-center border-4 border-black flex-shrink-0 rounded-[12px] transition-transform duration-300 group-hover:scale-105"
                style={{
                  width: '60px',
                  height: '60px'
                }}
              >
              <LazyImage 
  src={service.icon} 
  alt={service.title}
  className={`object-contain ${
    service.title === "Maintenance" 
      ? "w-[35px] h-[35px]"  // Smaller size for maintenance
      : "w-[60px] h-[60px]"  // Normal size for others
  }`}
  priority={index < 4}
/>
              </div>
              
              {/* Title */}
              <h3 className="text-xs sm:text-sm lg:text-base font-semibold text-gray-900 text-center mt-2">
                {service.title}
              </h3>
            </div>
          ))}
        </div>

        {/* Integrated Banner Carousel - Full width with minimal spacing */}
        <div className="relative z-10 w-full px-0">
          <Carousel 
            className="w-full"
            plugins={[
              Autoplay({
                delay: 3000,
              }) as any,
            ]}
          >
            <CarouselContent>
              {carouselImages.map((image, index) => (
                <CarouselItem key={index}>
                  <div className="relative w-full aspect-[16/9] md:aspect-[3/1] rounded-xl overflow-hidden shadow-xl bg-gray-200">
                    <LazyImage 
                      src={image.src}
                      alt={image.alt}
                      className="object-cover w-full h-full"
                      priority={index === 0}
                    />
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="hidden md:flex absolute left-4 top-1/2 -translate-y-1/2 bg-black/20 border-black/30 text-white hover:bg-black/30 transition-colors rounded-full" />
            <CarouselNext className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 bg-black/20 border-black/30 text-white hover:bg-black/30 transition-colors rounded-full" />
          </Carousel>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
