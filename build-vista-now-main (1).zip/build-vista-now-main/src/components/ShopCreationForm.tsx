
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Plus, Store, Clock, Truck } from 'lucide-react';

interface ShopCreationFormProps {
  onSubmit: (data: ShopData) => Promise<boolean>;
  isSubmitting: boolean;
  onClose?: () => void;
}

interface ShopData {
  shopName: string;
  description: string;
  categories: string[];
  workingHours: string;
  deliveryOptions: string[];
  minOrderValue?: number;
  images: string[];
  featured: boolean;
}

const ShopCreationForm: React.FC<ShopCreationFormProps> = ({ onSubmit, isSubmitting, onClose }) => {
  const [formData, setFormData] = useState<ShopData>({
    shopName: '',
    description: '',
    categories: [],
    workingHours: '',
    deliveryOptions: [],
    minOrderValue: undefined,
    images: [],
    featured: false,
  });

  const [newCategory, setNewCategory] = useState('');
  const [newDeliveryOption, setNewDeliveryOption] = useState('');
  const [workingHoursOption, setWorkingHoursOption] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await onSubmit(formData);
    if (success) {
      setFormData({
        shopName: '',
        description: '',
        categories: [],
        workingHours: '',
        deliveryOptions: [],
        minOrderValue: undefined,
        images: [],
        featured: false,
      });
    }
  };

  const addCategory = () => {
    if (newCategory.trim() && !formData.categories.includes(newCategory.trim())) {
      setFormData(prev => ({
        ...prev,
        categories: [...prev.categories, newCategory.trim()]
      }));
      setNewCategory('');
    }
  };

  const removeCategory = (category: string) => {
    setFormData(prev => ({
      ...prev,
      categories: prev.categories.filter(c => c !== category)
    }));
  };

  const addDeliveryOption = () => {
    if (newDeliveryOption.trim() && !formData.deliveryOptions.includes(newDeliveryOption.trim())) {
      setFormData(prev => ({
        ...prev,
        deliveryOptions: [...prev.deliveryOptions, newDeliveryOption.trim()]
      }));
      setNewDeliveryOption('');
    }
  };

  const removeDeliveryOption = (option: string) => {
    setFormData(prev => ({
      ...prev,
      deliveryOptions: prev.deliveryOptions.filter(o => o !== option)
    }));
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Store className="w-5 h-5 text-construction-primary" />
            Create Your Shop
          </CardTitle>
          {onClose && (
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
        <CardDescription>
          Set up your shop to showcase and sell your products or services to customers.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Shop Name */}
          <div>
            <Label htmlFor="shopName">Shop Name *</Label>
            <Input
              id="shopName"
              value={formData.shopName}
              onChange={(e) => setFormData(prev => ({ ...prev, shopName: e.target.value }))}
              placeholder="Enter your shop name"
              required
            />
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Shop Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Describe your shop and what you offer"
              className="min-h-[100px]"
              required
            />
          </div>

          {/* Categories */}
          <div>
            <Label>Product/Service Categories</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="Add a category"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCategory())}
              />
              <Button type="button" onClick={addCategory} variant="outline">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.categories.map((category) => (
                <Badge key={category} variant="secondary" className="flex items-center gap-1">
                  {category}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeCategory(category)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Working Hours */}
          <div>
            <Label htmlFor="workingHours" className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Working Hours *
            </Label>
            <div className="flex flex-col gap-3">
              <Select
                onValueChange={(value) => {
                  setWorkingHoursOption(value);
                  if (value !== 'custom') {
                    setFormData(prev => ({ ...prev, workingHours: value }));
                  } else {
                    setFormData(prev => ({ ...prev, workingHours: '' }));
                  }
                }}
                value={workingHoursOption}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select working hours" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mon-Fri: 9AM-6PM">Mon-Fri: 9AM-6PM</SelectItem>
                  <SelectItem value="Mon-Sat: 10AM-8PM">Mon-Sat: 10AM-8PM</SelectItem>
                  <SelectItem value="All days: 10AM-7PM">All days: 10AM-7PM</SelectItem>
                  <SelectItem value="24/7">24/7</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
              {(workingHoursOption === 'custom' || !workingHoursOption) && (
                <Input
                  id="workingHours"
                  value={formData.workingHours}
                  onChange={(e) => setFormData(prev => ({ ...prev, workingHours: e.target.value }))}
                  placeholder="e.g., Mon-Fri: 9AM-6PM, Sat: 10AM-4PM"
                  required
                />
              )}
            </div>
          </div>

          {/* Delivery Options */}
          <div>
            <Label className="flex items-center gap-2">
              <Truck className="w-4 h-4" />
              Delivery Options
            </Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newDeliveryOption}
                onChange={(e) => setNewDeliveryOption(e.target.value)}
                placeholder="Add delivery option"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addDeliveryOption())}
              />
              <Button type="button" onClick={addDeliveryOption} variant="outline">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.deliveryOptions.map((option) => (
                <Badge key={option} variant="secondary" className="flex items-center gap-1">
                  {option}
                  <X 
                    className="w-3 h-3 cursor-pointer" 
                    onClick={() => removeDeliveryOption(option)}
                  />
                </Badge>
              ))}
            </div>
          </div>

          {/* Minimum Order Value */}
          <div>
            <Label htmlFor="minOrderValue">Minimum Order Value (Optional)</Label>
            <Input
              id="minOrderValue"
              type="number"
              value={formData.minOrderValue || ''}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                minOrderValue: e.target.value ? parseFloat(e.target.value) : undefined 
              }))}
              placeholder="Enter minimum order value"
            />
          </div>

          {/* Featured */}
          <div className="flex items-center space-x-2">
            <Checkbox
              id="featured"
              checked={formData.featured}
              onCheckedChange={(checked) => setFormData(prev => ({ 
                ...prev, 
                featured: checked as boolean 
              }))}
            />
            <Label htmlFor="featured" className="text-sm">
              Featured Shop (Higher visibility in search results)
            </Label>
          </div>

          <Button 
            type="submit" 
            disabled={isSubmitting}
            className="w-full bg-construction-primary hover:bg-construction-primary/90"
          >
            {isSubmitting ? 'Creating Shop...' : 'Create Shop'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default ShopCreationForm;
