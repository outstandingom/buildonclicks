import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, FileText } from "lucide-react";
import { useSubscriptionHistory } from "@/hooks/useSubscriptionHistory";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { generateInvoicePDF } from "@/lib/invoice-generator";

export const SubscriptionHistory = () => {
  const { data: subscriptions, isLoading } = useSubscriptionHistory();

  const handleDownloadInvoice = (subscription: any) => {
    generateInvoicePDF(subscription);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Subscription History</CardTitle>
          <CardDescription>View and download your subscription invoices</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!subscriptions || subscriptions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Subscription History</CardTitle>
          <CardDescription>View and download your subscription invoices</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No subscription history yet</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Subscription History</CardTitle>
        <CardDescription>View and download your subscription invoices</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Plan</TableHead>
              <TableHead>Credits</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Invoice</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {subscriptions.map((subscription) => (
              <TableRow key={subscription.id}>
                <TableCell>
                  {format(new Date(subscription.created_at), "MMM dd, yyyy")}
                </TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium">{subscription.plan_name}</p>
                    <p className="text-sm text-muted-foreground">
                      {subscription.plan_description}
                    </p>
                  </div>
                </TableCell>
                <TableCell>{subscription.credits_added}</TableCell>
                <TableCell>₹{subscription.amount}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      subscription.status === "active"
                        ? "default"
                        : subscription.status === "pending"
                        ? "secondary"
                        : "destructive"
                    }
                  >
                    {subscription.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  {subscription.status === "active" && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDownloadInvoice(subscription)}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};
