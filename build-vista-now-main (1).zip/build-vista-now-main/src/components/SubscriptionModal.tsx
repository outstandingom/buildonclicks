import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useLeadCredits } from '@/hooks/useLeadCredits';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Coins, Check, Loader2, CreditCard } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SubscriptionModal = ({ isOpen, onClose }: SubscriptionModalProps) => {
  const { plans, credits, refreshCredits } = useLeadCredits();
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState<string | null>(null);

  const handlePurchase = async (planId: string) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to purchase credits",
        variant: "destructive",
      });
      return;
    }

    setLoading(planId);

    try {
      // Find the selected plan
      const selectedPlan = plans.find(plan => plan.id === planId);
      if (!selectedPlan) {
        throw new Error('Plan not found');
      }

      // Create Razorpay order
      console.log('Calling create-razorpay-order with planId:', planId);
      const { data: orderData, error: orderError } = await supabase.functions.invoke('create-razorpay-order', {
        body: { planId }
      });

      console.log('Edge function response:', { orderData, orderError });

      if (orderError || !orderData) {
        console.error('Error creating order:', orderError);
        const errorMessage = orderError?.message || orderError?.details || 'Failed to create payment order. Please try again.';
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
        return;
      }

      // Initialize Razorpay payment
      const options = {
        key: orderData.keyId,
        amount: orderData.amount,
        currency: orderData.currency,
        name: "BuildOnClicks",
        description: `${orderData.planName} - ${orderData.credits} Credits`,
        order_id: orderData.orderId,
        handler: async function (response: any) {
          try {
            // Verify payment on backend
            const { data: verificationData, error: verificationError } = await supabase.functions.invoke('verify-razorpay-payment', {
              body: {
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
                subscription_id: orderData.subscriptionId
              }
            });

            if (verificationError || !verificationData?.success) {
              console.error('Payment verification failed:', verificationError);
              toast({
                title: "Payment Verification Failed",
                description: "Please contact support if amount was deducted.",
                variant: "destructive",
              });
              return;
            }

            // Refresh credits and show success
            await refreshCredits();
            toast({
              title: "Payment Successful!",
              description: `${selectedPlan.lead_credits} credits added to your account`,
              variant: "default",
            });
            onClose();
          } catch (error) {
            console.error('Payment verification error:', error);
            toast({
              title: "Error",
              description: "Payment verification failed. Please contact support.",
              variant: "destructive",
            });
          }
        },
        modal: {
          ondismiss: function() {
            setLoading(null);
          }
        },
        theme: {
          color: "#007bff"
        }
      };

      // Check if Razorpay is loaded
      if (typeof (window as any).Razorpay === 'undefined') {
        // Load Razorpay script dynamically
        const script = document.createElement('script');
        script.src = 'https://checkout.razorpay.com/v1/checkout.js';
        script.onload = () => {
          const rzp = new (window as any).Razorpay(options);
          rzp.open();
        };
        script.onerror = () => {
          toast({
            title: "Error",
            description: "Failed to load payment gateway. Please try again.",
            variant: "destructive",
          });
          setLoading(null);
        };
        document.body.appendChild(script);
      } else {
        const rzp = new (window as any).Razorpay(options);
        rzp.open();
      }

    } catch (error) {
      console.error('Purchase error:', error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
      setLoading(null);
    }
  };

  const getPopularBadge = (index: number) => {
    if (index === 1) return <Badge variant="secondary">Most Popular</Badge>;
    if (index === 2) return <Badge variant="outline">Best Value</Badge>;
    return null;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Purchase Lead Credits
          </DialogTitle>
          {credits && (
            <p className="text-sm text-muted-foreground">
              Current balance: {credits.available_credits} leads available
            </p>
          )}
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          {plans.map((plan, index) => (
            <Card key={plan.id} className="relative">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{plan.name}</CardTitle>
                  {getPopularBadge(index)}
                </div>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold">₹{plan.price_inr}</div>
                    <div className="text-sm text-muted-foreground">
                      ₹{(plan.price_inr / plan.lead_credits).toFixed(0)} per lead
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-center gap-2">
                    <Coins className="h-4 w-4 text-primary" />
                    <span className="font-semibold">{plan.lead_credits} leads</span>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500" />
                      <span>Access to verified leads</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500" />
                      <span>Contact details included</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500" />
                      <span>Valid for {plan.duration_days} days</span>
                    </div>
                  </div>

                  <Button 
                    className="w-full" 
                    onClick={() => handlePurchase(plan.id)}
                    disabled={loading === plan.id}
                  >
                    {loading === plan.id ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Processing...
                      </>
                     ) : (
                       <>
                         <CreditCard className="h-4 w-4 mr-2" />
                         Buy Credits
                       </>
                     )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-6 p-4 bg-muted rounded-lg">
          <h4 className="font-semibold mb-2">Secure Payment with Razorpay</h4>
          <ul className="text-sm space-y-1 text-muted-foreground">
            <li>• Multiple payment options: UPI, Cards, Net Banking, Wallets</li>
            <li>• Bank-level security with 256-bit SSL encryption</li>
            <li>• Instant payment confirmation and credit activation</li>
            <li>• Get GST invoice for all transactions</li>
            <li>• 24/7 customer support for payment issues</li>
          </ul>
        </div>
      </DialogContent>
    </Dialog>
  );
};