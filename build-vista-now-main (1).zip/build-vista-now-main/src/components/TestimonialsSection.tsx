import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Star, Quote } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useInView } from "react-intersection-observer";

const TestimonialsSection = () => {
  const [activeTab, setActiveTab] = useState("buyers");
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const buyerTestimonials = 
    [
  {
    name: "Rajesh Kumar",
    city: "Arera Colony, Bhopal",
    rating: 5,
    review: "BuildOnClicks helped me find reliable contractors for my home renovation in Arera Colony. The quality of work exceeded my expectations!"
  },
  {
    name: "Priya Sharma",
    city: "MP Nagar, Bhopal",
    rating: 5,
    review: "Amazing platform! Got quotes from multiple vendors and saved 30% on building materials for my office setup in MP Nagar. Highly recommended!"
  },
  {
    name: "Amit Patel",
    city: "Hoshangabad Road, Bhopal",
    rating: 4,
    review: "The architects I found through BuildOnClicks designed my dream home perfectly in Hoshangabad Road area. Professional and creative team!"
  },
  {
    name: "Sunita Singh",
    city: "Kolar Road, Bhopal",
    rating: 5,
    review: "Excellent service! All vendors were verified and delivered on time for my villa project near Danish Kunj, Kolar Road. Made my construction project stress-free."
  }
];

  const businessTestimonials = [
    {
      name: "Construction Pro",
      city: "Chennai",
      rating: 5,
      review: "As a contractor, BuildOnClicks has been a game-changer. I get quality leads daily and my business has grown 3x!"
    },
    {
      name: "Steel Solutions",
      city: "Hyderabad",
      rating: 4,
      review: "Great platform for material suppliers. The lead quality is excellent and payment process is smooth."
    },
    {
      name: "Design Masters",
      city: "Kolkata",
      rating: 5,
      review: "Being an architect on BuildOnClicks has opened doors to numerous high-value projects. Highly professional platform!"
    },
    {
      name: "Build Right",
      city: "Ahmedabad",
      rating: 5,
      review: "The best decision for my construction business. Regular projects and verified customers make it worthwhile."
    }
  ];

  const activeTestimonials = activeTab === "buyers" ? buyerTestimonials : businessTestimonials;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <section className="py-8 sm:py-10 lg:py-12" ref={ref}>
      <div className="container mx-auto px-4  sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-6 sm:mb-8 lg:mb-10"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          {/* Main heading color changed to orange-500 */}
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-black mb-2 sm:mb-3 lg:mb-4">
            What Our <span className="text-orange-500">Community </span>Says
          </h2>
          <p className="text-sm sm:text-base lg:text-lg text-gray-600 max-w-2xl mx-auto">
            Real experiences from real people
          </p>
        </motion.div>

        {/* Tab Navigation */}
        <motion.div 
          className="flex justify-center mb-6 sm:mb-8 lg:mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="bg-card rounded-lg p-1 shadow-md flex">
<Button
  variant={activeTab === "buyers" ? "default" : "ghost"}
  onClick={() => setActiveTab("buyers")}
  className={`px-4 py-2 sm:px-6 sm:py-3 text-sm sm:text-base transition-all duration-300 ${
    activeTab === "buyers"
      ? 'bg-black text-white hover:bg-neutral-800'
      : 'text-gray-600 hover:bg-gray-200'
  }`}
>
  Buyers
</Button>

<Button
  variant={activeTab === "business" ? "default" : "ghost"}
  onClick={() => setActiveTab("business")}
  className={`px-4 py-2 sm:px-6 sm:py-3 text-sm sm:text-base transition-all duration-300 ${
    activeTab === "business"
      ? 'bg-black text-white hover:bg-neutral-800'
      : 'text-gray-600 hover:bg-gray-200'
  }`}
>
  Business Professionals
</Button>

          </div>
        </motion.div>

        {/* Testimonials Grid */}
        <AnimatePresence mode="wait">
          <motion.div 
            key={activeTab}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            exit="hidden"
          >
            {activeTestimonials.map((testimonial, index) => (
              <motion.div
                key={`${activeTab}-${index}`}
                variants={itemVariants}
                whileHover={{ 
                  scale: 1.03,
                  y: -5,
                  transition: { duration: 0.2 }
                }}
                className="group"
              >
                <Card className="h-full hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-4 sm:p-5 lg:p-6">
                    <div className="flex items-center mb-4">
                      <motion.div
                        animate={{ rotate: [0, 10, 0] }}
                        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                      >
                        <Quote className="h-6 w-6 sm:h-7 sm:w-7 lg:h-8 lg:w-8 text-orange-500 mr-2 sm:mr-3" />
                      </motion.div>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <motion.div
                            key={i}
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ delay: i * 0.1, duration: 0.3 }}
                          >
                            <Star
                              className={`h-4 w-4 ${
                                i < testimonial.rating ? "text-yellow-500 fill-current" : "text-gray-300"
                              }`}
                            />
                          </motion.div>
                        ))}
                      </div>
                    </div>
                    
                    <p className="text-gray-700 mb-4 sm:mb-5 lg:mb-6 italic leading-relaxed">
                      "{testimonial.review}"
                    </p>
                    
                    <div className="border-t border-gray-200 pt-3 sm:pt-4">
                      <p className="font-semibold text-gray-900 group-hover:text-orange-500 transition-colors">
                        {testimonial.name}
                      </p>
                      <p className="text-sm text-gray-600">
                        {testimonial.city}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
          
        </AnimatePresence>
      </div>
    </section>
  );
};

export default TestimonialsSection;
