import { Card, CardContent } from "@/components/ui/card";
import {
  CheckCircle,
  Shield,
  Phone,
  Building2,
  MapPin,
  Star,
} from "lucide-react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { useLanguage } from "@/contexts/LanguageContext";
import constructionBg from "/service-bg.svg";

const TrustFactorSection = () => {
  const { t } = useLanguage();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const trustFactors = [
    {
      icon: CheckCircle,
      title: t('trustFactor.items.verifiedExperts.title'),
      description: t('trustFactor.items.verifiedExperts.description'),
    },
    {
      icon: Shield,
      title: t('trustFactor.items.safeSecure.title'),
      description: t('trustFactor.items.safeSecure.description'),
    },
    {
      icon: Phone,
      title: t('trustFactor.items.quickQuotes.title'),
      description: t('trustFactor.items.quickQuotes.description'),
    },
    {
      icon: Building2,
      title: t('trustFactor.items.qualityProducts.title'),
      description: t('trustFactor.items.qualityProducts.description'),
    },
    {
      icon: MapPin,
      title: t('trustFactor.items.cityWise.title'),
      description: t('trustFactor.items.cityWise.description'),
    },
    {
      icon: Star,
      title: t('trustFactor.items.ratingsReviews.title'),
      description: t('trustFactor.items.ratingsReviews.description'),
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <section className="relative py-8 sm:py-10 lg:py-12" ref={ref}>
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${constructionBg})` }}
      >
        <div className="absolute inset-0 bg-black/80"></div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          className="text-center mb-6 sm:mb-8 lg:mb-10"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          {/* {t('trustFactor.title')} */}
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-4">
             Why Choose<span className="text-orange-500"> BuildOnClicks?</span>
          </h2>
          <p className="text-sm sm:text-base lg:text-lg text-white max-w-2xl mx-auto">
            {t('trustFactor.description')}
          </p>
        </motion.div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 lg:gap-6 justify-center"
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {trustFactors.map((factor, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{
                scale: 1.05,
                transition: { duration: 0.2 },
              }}
              className="group"
            >
              <Card className="h-full hover:shadow-lg transition-all duration-300 bg-card border border-gray-300 text-center cursor-pointer rounded-2xl">
                <CardContent className="p-4 sm:p-5 lg:p-6">
                  <motion.div
                    className="flex justify-center mb-4 sm:mb-5 lg:mb-6"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="p-3 sm:p-4 bg-gray-200 rounded-full group-hover:bg-black transition-colors duration-300">
                      <factor.icon className="h-8 w-8 sm:h-9 sm:w-9 lg:h-10 lg:w-10 text-black group-hover:text-white" />
                    </div>
                  </motion.div>
                  <h3 className="text-lg sm:text-xl font-semibold text-black mb-2 sm:mb-3 group-hover:text-black transition-colors duration-300">
                    {factor.title}
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    {factor.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default TrustFactorSection;
