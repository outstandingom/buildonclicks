import React, { useRef, useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2 } from "lucide-react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import { useNavigate } from "react-router-dom";
import constructionBg from "/service-bg.svg";

const partners = [
  { name: "Bhopal Contractors", logo: "https://placehold.co/160x80/3b82f6/ffffff?text=Partner+1" },
  { name: "Architect Planning", logo: "https://placehold.co/160x80/0d9488/ffffff?text=Partner+2" },
  { name: "Architecture", logo: "https://placehold.co/160x80/f97316/ffffff?text=Partner+3" },
  { name: "Contractor Team", logo: "https://placehold.co/160x80/8b5cf6/ffffff?text=Partner+4" },
  { name: "Hero Construction", logo: "https://placehold.co/160x80/ec4899/ffffff?text=Partner+5" },
  { name: "Kolar Road", logo: "https://placehold.co/160x80/10b981/ffffff?text=Partner+6" },
  { name: "Materials Warehouse", logo: "https://placehold.co/160x80/eab308/ffffff?text=Partner+7" },
  { name: "Steel", logo: "https://placehold.co/160x80/64748b/ffffff?text=Partner+8" },
];

const TrustedPartnersSection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const marqueeRef = useRef(null);
  const [marqueeWidth, setMarqueeWidth] = useState(0);

  const navigate = useNavigate(); 

  const duplicatedPartners = [...partners, ...partners];

  useEffect(() => {
    if (marqueeRef.current) {
      setMarqueeWidth(marqueeRef.current.scrollWidth / 2);
    }
  }, []);

  return (
    <section className="relative py-8 sm:py-10 lg:py-12" ref={ref}>
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${constructionBg})` }}
      >
        <div className="absolute inset-0 bg-black/80"></div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          className="text-center mb-8 sm:mb-10 lg:mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-4">
            Our Trusted <span className="text-orange-500">Partners</span>
          </h2>
          <p className="text-sm sm:text-base lg:text-lg text-white max-w-2xl mx-auto">
            We collaborate with leading brands to bring you the best construction solutions
          </p>
        </motion.div>

        {/* Marquee Container */}
        <div className="relative overflow-hidden mb-8 sm:mb-10 lg:mb-16">
          <div className="flex space-x-4 sm:space-x-6 lg:space-x-8">
            <motion.div
              ref={marqueeRef}
              className="flex space-x-4 sm:space-x-6 lg:space-x-8 min-w-max"
              animate={{ x: marqueeWidth ? [0, -marqueeWidth] : 0 }}
              transition={{
                duration: marqueeWidth ? marqueeWidth / 30 : 40,
                repeat: Infinity,
                ease: "linear",
              }}
            >
              {duplicatedPartners.map((partner, index) => (
                <motion.div
                  key={`${partner.name}-${index}`}
                  whileHover={{ scale: 1.05 }}
                  className="flex-shrink-0"
                >
                  <Card className="group hover:shadow-hover transition-all duration-300">
                    <CardContent className="p-0 w-32 h-16 sm:w-36 sm:h-18 lg:w-40 lg:h-20">
                      <img 
                        src={partner.logo} 
                        alt={partner.name}
                        className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-300 rounded-lg"
                      />
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>

        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button 
              variant="outline" 
              className="h-10 px-4 py-2 sm:h-11 sm:px-8 border-2 border-black text-sm sm:text-base text-black hover:bg-black hover:text-white transition-all duration-300 shadow-lg hover:shadow-xl"
              onClick={() => navigate("/auth")} 
            >
              <Building2 className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
              Join the platform as a verified business
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default TrustedPartnersSection;
