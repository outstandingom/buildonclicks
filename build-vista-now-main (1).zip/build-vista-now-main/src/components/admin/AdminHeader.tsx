
import React from 'react';
import { Button } from "@/components/ui/button";
import { useAdminAuth } from "@/hooks/useAdminAuth";
import { useNavigate } from 'react-router-dom';
import { LogOut, User } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

export const AdminHeader = () => {
  const { admin, logout } = useAdminAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
      navigate('/admin-login');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to logout. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="bg-white border-b border-border shadow-sm">
      <div className="flex items-center justify-between px-8 py-4">
        <div className="flex items-center gap-3">
          <img 
            src="/lovable-uploads/672c8b35-7c22-4402-bd29-4160240af405.png" 
            alt="BuildOnClicks Logo" 
            className="h-6 w-6 rounded-full"
          />
          <div>
            <p className="text-sm font-medium text-construction-secondary">
              {admin?.name}
            </p>
            <p className="text-xs text-construction-neutral">
              {admin?.email} • {admin?.role}
            </p>
          </div>
        </div>
        
        <Button
          onClick={handleLogout}
          variant="outline"
          size="sm"
          className="flex items-center gap-2"
        >
          <LogOut className="h-4 w-4" />
          Logout
        </Button>
      </div>
    </div>
  );
};
