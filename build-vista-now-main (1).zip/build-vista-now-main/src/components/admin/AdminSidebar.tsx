
import React from 'react';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, 
  Clock, 
  Users, 
  FileText, 
  AlertTriangle,
  Building2,
  Coins,
  BarChart3,
  MessageSquare,
  TrendingUp,
  Mail,
  Shield
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface AdminSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'approvals', label: 'Pending Approvals', icon: Clock },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'posts', label: 'Post Moderation', icon: FileText },
    { id: 'banners', label: 'Banner Management', icon: FileText },
    { id: 'reports', label: 'Reports', icon: AlertTriangle },
    { id: 'contact-submissions', label: 'Contact Submissions', icon: Mail },
    { id: 'quick-requirements', label: 'Quick Requirements', icon: MessageSquare },
    { id: 'admin-management', label: 'Admin Management', icon: Shield },
  ];

const leadSubscriptionItems = [
  { id: 'credits', label: 'Credit Management', icon: Coins },
  { id: 'subscriptions', label: 'Subscription Analytics', icon: BarChart3 },
  { id: 'subscription-management', label: 'Manage Plans', icon: FileText },
  // { id: 'leads', label: 'Lead Analytics', icon: TrendingUp },
  { id: 'communication', label: 'User Communication', icon: MessageSquare },
  { id: 'referral-management', label: 'Referral Management', icon: MessageSquare },
];

export const AdminSidebar: React.FC<AdminSidebarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="fixed left-0 top-0 h-screen w-64 bg-white border-r border-border shadow-lg z-10">
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-3">
          <img 
            src="/lovable-uploads/672c8b35-7c22-4402-bd29-4160240af405.png" 
            alt="BuildOnClicks Logo" 
            className="h-8 w-8 rounded-full"
          />
          <div>
            <h2 className="text-xl font-bold text-construction-secondary">BuildOnClicks</h2>
            <p className="text-sm text-construction-neutral">Admin Panel</p>
          </div>
        </div>
      </div>

      <nav className="p-4">
        {/* Main Navigation */}
        <div className="mb-6">
          <h3 className="text-xs font-semibold text-construction-neutral uppercase tracking-wider mb-3">
            Main
          </h3>
          <ul className="space-y-2">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveTab(item.id)}
                    className={cn(
                      "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-200",
                      isActive
                        ? "bg-construction-primary text-white shadow-md"
                        : "text-construction-neutral hover:bg-accent hover:text-construction-secondary"
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="font-medium">{item.label}</span>
                    {isActive && (
                      <motion.div
                        layoutId="activeTab"
                        className="ml-auto w-2 h-2 bg-white rounded-full"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                      />
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        {/* Lead Subscription Management */}
        <div>
          <h3 className="text-xs font-semibold text-construction-neutral uppercase tracking-wider mb-3">
            Lead Subscriptions
          </h3>
          <ul className="space-y-2">
            {leadSubscriptionItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveTab(item.id)}
                    className={cn(
                      "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-200",
                      isActive
                        ? "bg-construction-primary text-white shadow-md"
                        : "text-construction-neutral hover:bg-accent hover:text-construction-secondary"
                    )}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="font-medium">{item.label}</span>
                    {isActive && (
                      <motion.div
                        layoutId="activeTab"
                        className="ml-auto w-2 h-2 bg-white rounded-full"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                      />
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </nav>
    </div>
  );
};
