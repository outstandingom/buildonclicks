import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Loader2 } from 'lucide-react';

interface BanUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reportId: string;
  userId: string;
  userName: string;
  onBan: (reportId: string, userId: string, reason: string, banType: 'temporary' | 'permanent', expiresAt?: string) => Promise<void>;
}

export const BanUserDialog = ({
  open,
  onOpenChange,
  reportId,
  userId,
  userName,
  onBan,
}: BanUserDialogProps) => {
  const [banType, setBanType] = useState<'temporary' | 'permanent'>('temporary');
  const [reason, setReason] = useState('');
  const [days, setDays] = useState('7');
  const [loading, setLoading] = useState(false);

  const handleBan = async () => {
    if (!reason.trim()) return;

    try {
      setLoading(true);
      
      let expiresAt: string | undefined;
      if (banType === 'temporary') {
        const expireDate = new Date();
        expireDate.setDate(expireDate.getDate() + parseInt(days));
        expiresAt = expireDate.toISOString();
      }

      await onBan(reportId, userId, reason.trim(), banType, expiresAt);
      setReason('');
      setBanType('temporary');
      setDays('7');
      onOpenChange(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="text-destructive">Ban User: {userName}</DialogTitle>
          <DialogDescription>
            This will suspend the user's account access
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Ban Type</Label>
            <Select value={banType} onValueChange={(value: any) => setBanType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="temporary">Temporary Ban</SelectItem>
                <SelectItem value="permanent">Permanent Ban</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {banType === 'temporary' && (
            <div className="space-y-2">
              <Label>Duration (Days)</Label>
              <Input
                type="number"
                min="1"
                max="365"
                value={days}
                onChange={(e) => setDays(e.target.value)}
              />
            </div>
          )}

          <div className="space-y-2">
            <Label>Ban Reason</Label>
            <Textarea
              placeholder="Explain why this user is being banned..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={4}
            />
          </div>

          <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3">
            <p className="text-sm text-destructive">
              ⚠️ This action will immediately restrict the user's access to the platform.
              {banType === 'temporary' && ` The ban will automatically expire in ${days} days.`}
            </p>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={handleBan} disabled={loading || !reason.trim()}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {banType === 'permanent' ? 'Ban Permanently' : `Ban for ${days} Days`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
