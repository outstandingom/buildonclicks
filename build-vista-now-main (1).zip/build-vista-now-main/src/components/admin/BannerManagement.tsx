import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, Edit, Trash2, Eye, EyeOff, Move, ArrowUp, ArrowDown, Hash } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useAdminBanners, Banner } from '@/hooks/useBanners';

const BannerManagement = () => {
  const { banners, loading, uploadBanner, updateBanner, deleteBanner } = useAdminBanners();
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [uploadForm, setUploadForm] = useState({
    title: '',
    altText: '',
    displayOrder: 0,
    file: null as File | null
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadForm(prev => ({ ...prev, file }));
    }
  };

  const handleUpload = async () => {
    if (!uploadForm.file || !uploadForm.title) return;

    await uploadBanner(uploadForm.file, uploadForm.title, uploadForm.altText, uploadForm.displayOrder);
    setUploadForm({ title: '', altText: '', displayOrder: 0, file: null });
    setIsUploadDialogOpen(false);
  };

  const handleUpdateBanner = async (id: string, updates: Partial<Banner>) => {
    await updateBanner(id, updates);
    setEditingBanner(null);
  };

  const handleToggleActive = async (banner: Banner) => {
    await updateBanner(banner.id, { is_active: !banner.is_active });
  };

  const handlePriorityChange = async (banner: Banner, direction: 'up' | 'down') => {
    const sortedBanners = [...banners].sort((a, b) => a.display_order - b.display_order);
    const currentIndex = sortedBanners.findIndex(b => b.id === banner.id);
    
    if (direction === 'up' && currentIndex > 0) {
      const targetBanner = sortedBanners[currentIndex - 1];
      await updateBanner(banner.id, { display_order: targetBanner.display_order });
      await updateBanner(targetBanner.id, { display_order: banner.display_order });
    } else if (direction === 'down' && currentIndex < sortedBanners.length - 1) {
      const targetBanner = sortedBanners[currentIndex + 1];
      await updateBanner(banner.id, { display_order: targetBanner.display_order });
      await updateBanner(targetBanner.id, { display_order: banner.display_order });
    }
  };

  if (loading && banners.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-construction-secondary">Banner Management</h2>
        <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Upload className="h-4 w-4 mr-2" />
              Upload Banner
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Upload New Banner</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="banner-file">Banner Image</Label>
                <Input
                  id="banner-file"
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                />
              </div>
              <div>
                <Label htmlFor="banner-title">Title</Label>
                <Input
                  id="banner-title"
                  value={uploadForm.title}
                  onChange={(e) => setUploadForm(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter banner title"
                />
              </div>
              <div>
                <Label htmlFor="banner-alt">Alt Text (Optional)</Label>
                <Textarea
                  id="banner-alt"
                  value={uploadForm.altText}
                  onChange={(e) => setUploadForm(prev => ({ ...prev, altText: e.target.value }))}
                  placeholder="Enter alt text for accessibility"
                />
              </div>
              <div>
                <Label htmlFor="banner-order">Display Priority (0 = highest priority)</Label>
                <Input
                  id="banner-order"
                  type="number"
                  min="0"
                  value={uploadForm.displayOrder}
                  onChange={(e) => setUploadForm(prev => ({ ...prev, displayOrder: parseInt(e.target.value) || 0 }))}
                  placeholder="Enter display order (0 for first)"
                />
              </div>
              <Button 
                onClick={handleUpload} 
                disabled={!uploadForm.file || !uploadForm.title}
                className="w-full"
              >
                Upload Banner
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...banners].sort((a, b) => a.display_order - b.display_order).map((banner, index) => (
          <motion.div
            key={banner.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="overflow-hidden">
              <div className="relative aspect-video">
                <img
                  src={banner.image_url}
                  alt={banner.alt_text || banner.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2 flex gap-2">
                  <Button
                    size="sm"
                    variant={banner.is_active ? "default" : "secondary"}
                    onClick={() => handleToggleActive(banner)}
                  >
                    {banner.is_active ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                  </Button>
                </div>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm truncate">{banner.title}</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Hash className="h-3 w-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">Priority: {banner.display_order}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-xs">Active:</span>
                      <Switch
                        checked={banner.is_active}
                        onCheckedChange={() => handleToggleActive(banner)}
                      />
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handlePriorityChange(banner, 'up')}
                        disabled={index === 0}
                        title="Move up in priority"
                      >
                        <ArrowUp className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handlePriorityChange(banner, 'down')}
                        disabled={index === banners.length - 1}
                        title="Move down in priority"
                      >
                        <ArrowDown className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="flex gap-1">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="outline">
                          <Edit className="h-3 w-3" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Edit Banner</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label>Title</Label>
                            <Input
                              value={editingBanner?.title || banner.title}
                              onChange={(e) => setEditingBanner(prev => 
                                prev ? { ...prev, title: e.target.value } : { ...banner, title: e.target.value }
                              )}
                            />
                          </div>
                          <div>
                            <Label>Alt Text</Label>
                            <Textarea
                              value={editingBanner?.alt_text || banner.alt_text || ''}
                              onChange={(e) => setEditingBanner(prev => 
                                prev ? { ...prev, alt_text: e.target.value } : { ...banner, alt_text: e.target.value }
                              )}
                            />
                          </div>
                          <div>
                            <Label>Display Order</Label>
                            <Input
                              type="number"
                              value={editingBanner?.display_order || banner.display_order}
                              onChange={(e) => setEditingBanner(prev => 
                                prev ? { ...prev, display_order: parseInt(e.target.value) } : { ...banner, display_order: parseInt(e.target.value) }
                              )}
                            />
                          </div>
                          <Button 
                            onClick={() => handleUpdateBanner(banner.id, editingBanner || banner)}
                            className="w-full"
                          >
                            Update Banner
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => deleteBanner(banner.id, banner.image_url)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {banners.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Upload className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No banners yet</h3>
            <p className="text-muted-foreground mb-4">Upload your first banner to get started</p>
            <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
              <DialogTrigger asChild>
                <Button>Upload Banner</Button>
              </DialogTrigger>
            </Dialog>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default BannerManagement;