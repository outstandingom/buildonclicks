import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, UserPlus } from 'lucide-react';

interface CreateUserDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const CreateUserDialog: React.FC<CreateUserDialogProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    fullName: '',
    mobileNumber: '',
    userType: 'user' as 'user' | 'provider',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.email || !formData.password || !formData.fullName || !formData.mobileNumber) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    if (formData.password.length < 6) {
      toast({
        title: 'Error',
        description: 'Password must be at least 6 characters long',
        variant: 'destructive',
      });
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast({
        title: 'Error',
        description: 'Please enter a valid email address',
        variant: 'destructive',
      });
      return;
    }

    // Validate mobile number (Indian format)
    const mobileRegex = /^[6-9]\d{9}$/;
    if (!mobileRegex.test(formData.mobileNumber)) {
      toast({
        title: 'Error',
        description: 'Please enter a valid 10-digit mobile number',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      // Create user using Supabase Auth Admin API via Edge Function
      let data, error;
      
      try {
        const response = await supabase.functions.invoke('create-user', {
          body: {
            email: formData.email,
            password: formData.password,
            full_name: formData.fullName,
            mobile_number: formData.mobileNumber,
            user_type: formData.userType,
          },
        });
        
        data = response.data;
        error = response.error;
      } catch (invokeError: any) {
        // Catch network errors or function not found errors
        console.error('Edge function invocation failed:', invokeError);
        const errorMsg = invokeError?.message || invokeError?.toString() || 'Unknown error';
        
        if (errorMsg.includes('Failed to fetch') || 
            errorMsg.includes('network') || 
            errorMsg.includes('not found') ||
            errorMsg.includes('404') ||
            errorMsg.includes('Failed to send')) {
          throw new Error(
            'Edge function "create-user" is not deployed or not accessible. ' +
            'Please deploy the function using: supabase functions deploy create-user ' +
            'or contact your administrator. See DEPLOY_EDGE_FUNCTION.md for details.'
          );
        }
        throw invokeError;
      }

      if (error) {
        console.error('Edge function error:', error);
        // Check if it's a network/connection error
        if (error.message?.includes('Failed to fetch') || 
            error.message?.includes('network') || 
            error.message?.includes('not found') ||
            error.message?.includes('404')) {
          throw new Error(
            'Edge function not deployed. Please deploy using: supabase functions deploy create-user'
          );
        }
        throw new Error(error.message || error.error || 'Failed to create user account');
      }

      if (data?.error) {
        throw new Error(data.error);
      }

      // Check if response indicates success
      if (!data?.success && !data?.user_id) {
        throw new Error(data?.message || 'Failed to create user account');
      }

      toast({
        title: 'Success',
        description: `${formData.userType === 'provider' ? 'Provider' : 'User'} account created successfully`,
      });

      // Reset form
      setFormData({
        email: '',
        password: '',
        fullName: '',
        mobileNumber: '',
        userType: 'user',
      });

      onSuccess();
      onClose();
    } catch (error: any) {
      console.error('Error creating user:', error);
      
      let errorMessage = 'Failed to create user account';
      
      if (error.message) {
        errorMessage = error.message;
      } else if (error.error) {
        errorMessage = error.error;
      } else if (typeof error === 'string') {
        errorMessage = error;
      }
      
      // Provide helpful messages for common errors
      if (errorMessage.includes('edge function') || errorMessage.includes('Failed to fetch') || errorMessage.includes('network')) {
        errorMessage = 'Edge function not available. Please ensure the create-user function is deployed. Contact your administrator.';
      }
      
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5" />
            Create New User/Provider
          </DialogTitle>
          <DialogDescription>
            Create a new user or provider account. The user will receive an email with their login credentials.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="userType">Account Type *</Label>
              <Select
                value={formData.userType}
                onValueChange={(value: 'user' | 'provider') =>
                  setFormData((prev) => ({ ...prev, userType: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select account type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">User</SelectItem>
                  <SelectItem value="provider">Provider</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name *</Label>
              <Input
                id="fullName"
                placeholder="Enter full name"
                value={formData.fullName}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, fullName: e.target.value }))
                }
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                type="email"
                placeholder="user@example.com"
                value={formData.email}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, email: e.target.value }))
                }
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="mobileNumber">Mobile Number *</Label>
              <Input
                id="mobileNumber"
                type="tel"
                placeholder="9876543210"
                value={formData.mobileNumber}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, mobileNumber: e.target.value.replace(/\D/g, '') }))
                }
                maxLength={10}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password *</Label>
              <Input
                id="password"
                type="password"
                placeholder="Minimum 6 characters"
                value={formData.password}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, password: e.target.value }))
                }
                required
                minLength={6}
              />
              <p className="text-xs text-muted-foreground">
                Password must be at least 6 characters long
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <UserPlus className="mr-2 h-4 w-4" />
                  Create Account
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

