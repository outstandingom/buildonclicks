import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useAdminLeadCredits } from '@/hooks/useAdminLeadCredits';
import { Coins, Plus, RefreshCw, TrendingUp, Users, CreditCard } from 'lucide-react';
import { motion } from 'framer-motion';

export const CreditManagement: React.FC = () => {
  const { subscriptionAnalytics, usersSummary, loading, addCreditsToUser, refreshData } =
    useAdminLeadCredits();

  const [selectedUser, setSelectedUser] = useState<string>('');
  const [creditsToAdd, setCreditsToAdd] = useState('');
  const [reason, setReason] = useState('');
  const [isAddingCredits, setIsAddingCredits] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const [openDialog, setOpenDialog] = useState(false);

  // Safe search
  const filteredUsers = usersSummary.filter((user) => {
    const name = user.user_name?.toLowerCase() || '';
    const type = user.user_type?.toLowerCase() || '';
    const s = searchTerm.toLowerCase();
    return name.includes(s) || type.includes(s);
  });

  const handleAddCredits = async () => {
    if (!selectedUser || !creditsToAdd || parseInt(creditsToAdd) <= 0) {
      return;
    }

    setIsAddingCredits(true);

    const success = await addCreditsToUser(
      selectedUser,
      parseInt(creditsToAdd),
      reason || 'Admin allocation'
    );

    if (success) {
      // Reset UI
      setSelectedUser('');
      setCreditsToAdd('');
      setReason('');

      // Close dialog
      setOpenDialog(false);
    }

    setIsAddingCredits(false);
  };

  const getSubscriptionStatusColor = (status: string) => {
    return status === 'active'
      ? 'bg-green-100 text-green-800'
      : 'bg-gray-100 text-gray-800';
  };

  const getUserTypeColor = (type: string) => {
    return type === 'provider'
      ? 'bg-blue-100 text-blue-800'
      : 'bg-purple-100 text-purple-800';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Coins className="h-5 w-5 text-yellow-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Credits Distributed</p>
                  <p className="text-2xl font-bold">{subscriptionAnalytics?.total_credits_distributed || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Credits Used</p>
                  <p className="text-2xl font-bold">{subscriptionAnalytics?.total_credits_used || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Avg Credits/User</p>
                  <p className="text-2xl font-bold">
                    {Math.round(subscriptionAnalytics?.avg_credits_per_user || 0)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <CreditCard className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Active Subscriptions</p>
                  <p className="text-2xl font-bold">{subscriptionAnalytics?.total_active_subscriptions || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Users Credit Management */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Coins className="h-5 w-5" />
              <span>User Credits Management</span>
            </CardTitle>

            <div className="flex items-center space-x-2">
              <Dialog open={openDialog} onOpenChange={setOpenDialog}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Credits
                  </Button>
                </DialogTrigger>

                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Credits to User</DialogTitle>
                  </DialogHeader>

                  <div className="space-y-4">
                    <div>
                      <Label>Select User</Label>
                      <select
                        value={selectedUser}
                        onChange={(e) => setSelectedUser(e.target.value)}
                        className="w-full mt-1 p-2 border rounded-md"
                      >
                        <option value="">Select a user...</option>
                        {usersSummary.map((user) => (
                          <option key={user.user_id} value={user.user_id}>
                            {user.user_name} ({user.user_type}) - {user.available_credits} credits
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <Label>Credits to Add</Label>
                      <Input
                        type="number"
                        value={creditsToAdd}
                        onChange={(e) => setCreditsToAdd(e.target.value)}
                        placeholder="Enter number of credits"
                        min="1"
                      />
                    </div>

                    <div>
                      <Label>Reason (Optional)</Label>
                      <Textarea
                        value={reason}
                        onChange={(e) => setReason(e.target.value)}
                        placeholder="Enter reason"
                      />
                    </div>

                    <Button
                      onClick={handleAddCredits}
                      disabled={!selectedUser || !creditsToAdd || isAddingCredits}
                      className="w-full"
                    >
                      {isAddingCredits ? 'Adding...' : 'Add Credits'}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Button variant="outline" size="sm" onClick={refreshData}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          <div className="mb-4">
            <Input
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Total Credits</TableHead>
                  <TableHead>Used Credits</TableHead>
                  <TableHead>Available</TableHead>
                  <TableHead>Subscription</TableHead>
                  <TableHead>Last Activity</TableHead>
                </TableRow>
              </TableHeader>

              <TableBody>
                {filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-6 text-muted-foreground">
                      No matching users found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.user_id}>
                      <TableCell className="font-medium">{user.user_name}</TableCell>

                      <TableCell>
                        <Badge className={getUserTypeColor(user.user_type)}>
                          {user.user_type}
                        </Badge>
                      </TableCell>

                      <TableCell>{user.total_credits}</TableCell>
                      <TableCell>{user.used_credits}</TableCell>

                      <TableCell>
                        <span
                          className={
                            user.available_credits < 5 ? 'text-red-600 font-medium' : ''
                          }
                        >
                          {user.available_credits}
                        </span>
                      </TableCell>

                      <TableCell>
                        <Badge className={getSubscriptionStatusColor(user.subscription_status)}>
                          {user.subscription_status}
                        </Badge>
                      </TableCell>

                      <TableCell>
                        {user.last_activity
                          ? new Date(user.last_activity).toLocaleDateString()
                          : 'No activity'}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
