
import React from 'react';
import { motion } from 'framer-motion';
import { Users, CheckCircle, Clock, FileText, Building2, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAdminDashboard } from '@/hooks/useAdminDashboard';

export const DashboardHome = () => {
  const { stats, recentActivity, loading, refreshData } = useAdminDashboard();

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-construction-primary"></div>
      </div>
    );
  }

  const kpiData = [
    {
      title: 'Total Users',
      value: stats?.total_users?.toLocaleString() || '0',
      change: '+12%',
      changeType: 'positive',
      icon: Users,
      description: 'Active platform users'
    },
    {
      title: 'Approved Vendors',
      value: stats?.approved_vendors?.toLocaleString() || '0',
      change: '+8%',
      changeType: 'positive',
      icon: CheckCircle,
      description: 'Verified service providers'
    },
    {
      title: 'Pending Requests',
      value: stats?.pending_requests?.toLocaleString() || '0',
      change: '-5%',
      changeType: 'negative',
      icon: Clock,
      description: 'Awaiting approval'
    },
    {
      title: 'Total Feed Posts',
      value: stats?.total_posts?.toLocaleString() || '0',
      change: '+23%',
      changeType: 'positive',
      icon: FileText,
      description: 'User-generated content'
    }
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'vendor_registration': return '🏢';
      case 'user_registration': return '👤';
      case 'project_posted': return '📝';
      default: return '📄';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 60) return `${diffMins} minutes ago`;
    if (diffHours < 24) return `${diffHours} hours ago`;
    return `${diffDays} days ago`;
  };

  return (
    <div className="space-y-8">
      {/* Header with Refresh Button */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-construction-secondary">Dashboard Overview</h2>
        <Button onClick={refreshData} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiData.map((kpi, index) => {
          const Icon = kpi.icon;
          return (
            <motion.div
              key={kpi.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="hover:shadow-hover transition-shadow duration-300">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-construction-neutral">
                    {kpi.title}
                  </CardTitle>
                  <Icon className="h-4 w-4 text-construction-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-construction-secondary">
                    {kpi.value}
                  </div>
                  <div className="flex items-center text-xs text-construction-neutral mt-1">
                    <span className={`${
                      kpi.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
                    } font-medium mr-1`}>
                      {kpi.change}
                    </span>
                    from last month
                  </div>
                  <p className="text-xs text-construction-neutral mt-1">
                    {kpi.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-construction-primary" />
              Recent Activity
            </CardTitle>
            <CardDescription>Latest platform activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.length > 0 ? (
                recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gradient-card rounded-lg">
                    <div>
                      <p className="font-medium text-construction-secondary flex items-center gap-2">
                        <span>{getActivityIcon(activity.activity_type)}</span>
                        {activity.description}
                      </p>
                      <p className="text-sm text-construction-neutral">{activity.user_name}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-construction-neutral">{formatDate(activity.created_at)}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4 text-construction-neutral">
                  <Building2 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No recent activity</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
