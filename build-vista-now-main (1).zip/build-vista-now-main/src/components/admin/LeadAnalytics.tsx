import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useAdminLeadCredits } from '@/hooks/useAdminLeadCredits';
import { 
  Eye, 
  Phone, 
  Users, 
  Coins,
  RefreshCw,
  TrendingUp,
  Calendar
} from 'lucide-react';
import { motion } from 'framer-motion';

export const LeadAnalytics: React.FC = () => {
  const { leadAnalytics, loading, refreshData } = useAdminLeadCredits();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLeads = leadAnalytics.filter(lead =>
    lead.requirement_title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Calculate summary stats
  const totalViews = leadAnalytics.reduce((sum, lead) => sum + lead.total_views, 0);
  const totalContacts = leadAnalytics.reduce((sum, lead) => sum + lead.total_contacts, 0);
  const totalCreditsConsumed = leadAnalytics.reduce((sum, lead) => sum + lead.credits_consumed_total, 0);
  const totalUniqueViewers = leadAnalytics.reduce((sum, lead) => sum + lead.unique_viewers, 0);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getEngagementRate = (views: number, contacts: number) => {
    if (views === 0) return 0;
    return Math.round((contacts / views) * 100);
  };

  const getEngagementColor = (rate: number) => {
    if (rate >= 20) return 'bg-green-100 text-green-800';
    if (rate >= 10) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Eye className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Views</p>
                  <p className="text-2xl font-bold">{totalViews}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Contacts</p>
                  <p className="text-2xl font-bold">{totalContacts}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Unique Viewers</p>
                  <p className="text-2xl font-bold">{totalUniqueViewers}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Coins className="h-5 w-5 text-yellow-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Credits Consumed</p>
                  <p className="text-2xl font-bold">{totalCreditsConsumed}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Lead Performance Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5" />
              <span>Lead Performance</span>
            </CardTitle>
            <Button variant="outline" size="sm" onClick={refreshData}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <Input
              placeholder="Search leads..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
          
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Lead Title</TableHead>
                  <TableHead>Views</TableHead>
                  <TableHead>Contacts</TableHead>
                  <TableHead>Unique Viewers</TableHead>
                  <TableHead>Credits Used</TableHead>
                  <TableHead>Engagement Rate</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Last Accessed</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLeads.map((lead) => {
                  const engagementRate = getEngagementRate(lead.total_views, lead.total_contacts);
                  return (
                    <TableRow key={lead.requirement_id}>
                      <TableCell className="font-medium max-w-xs truncate">
                        {lead.requirement_title}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <Eye className="h-4 w-4 text-blue-600" />
                          <span>{lead.total_views}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <Phone className="h-4 w-4 text-green-600" />
                          <span>{lead.total_contacts}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <Users className="h-4 w-4 text-purple-600" />
                          <span>{lead.unique_viewers}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <Coins className="h-4 w-4 text-yellow-600" />
                          <span>{lead.credits_consumed_total}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getEngagementColor(engagementRate)}>
                          {engagementRate}%
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4 text-gray-500" />
                          <span className="text-sm">{formatDate(lead.requirement_created_at)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {lead.last_accessed ? (
                          <span className="text-sm">{formatDate(lead.last_accessed)}</span>
                        ) : (
                          <span className="text-sm text-gray-400">Never</span>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>

          {filteredLeads.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              {searchTerm ? 'No leads found matching your search.' : 'No leads available.'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};