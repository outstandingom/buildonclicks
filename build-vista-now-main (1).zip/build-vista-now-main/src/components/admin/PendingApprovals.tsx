
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Eye, Check, X, FileText, MapPin, Calendar } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useAdminApprovals } from '@/hooks/useAdminApprovals';
import { RegistrationDetailsModal } from './RegistrationDetailsModal';

export const PendingApprovals = () => {
  const { approvals, loading, updateApprovalStatus, getRegistrationDetails } = useAdminApprovals();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [selectedRegistration, setSelectedRegistration] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const filteredApprovals = approvals.filter(approval => {
    const matchesSearch = approval.business_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         approval.contact_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === 'all' || approval.business_type.toLowerCase() === filterType.toLowerCase();
    return matchesSearch && matchesFilter;
  });

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'contractor': return 'bg-blue-100 text-blue-800';
      case 'architect': return 'bg-green-100 text-green-800';
      case 'vendor': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleApprove = async (id: string) => {
    await updateApprovalStatus(id, 'approved');
  };

  const handleReject = async (id: string) => {
    const reason = prompt("Please provide a reason for rejection (this will be sent to the applicant):");
    if (reason && reason.trim()) {
      await updateApprovalStatus(id, 'rejected', reason.trim());
    }
  };

  const handleViewDetails = async (id: string) => {
    const details = await getRegistrationDetails(id);
    if (details) {
      setSelectedRegistration(details);
      setIsModalOpen(true);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-construction-primary"></div>
      </div>
    );
  }

  const businessTypes = [...new Set(approvals.map(a => a.business_type))];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-construction-primary" />
            Pending Approvals
          </CardTitle>
          <CardDescription>
            Review and approve vendor, contractor, and architect applications
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-construction-neutral" />
              <Input
                placeholder="Search by business name or contact..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={filterType === 'all' ? 'default' : 'outline'}
                onClick={() => setFilterType('all')}
              >
                All
              </Button>
              {businessTypes.map((type) => (
                <Button
                  key={type}
                  variant={filterType === type ? 'default' : 'outline'}
                  onClick={() => setFilterType(type)}
                  className="capitalize"
                >
                  {type}
                </Button>
              ))}
            </div>
          </div>

          {/* Approvals Table */}
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Business Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Cities Served</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredApprovals.map((approval, index) => (
                  <motion.tr
                    key={approval.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="hover:bg-muted/50"
                  >
                    <TableCell>
                      <div className="font-medium text-construction-secondary">
                        {approval.business_name}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getTypeColor(approval.business_type)}>
                        {approval.business_type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{approval.contact_name}</div>
                        <div className="text-sm text-construction-neutral">{approval.email_address}</div>
                        <div className="text-sm text-construction-neutral">{approval.phone_number}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {approval.cities_served.slice(0, 2).map((city, cityIndex) => (
                          <Badge key={cityIndex} variant="outline" className="text-xs">
                            {city}
                          </Badge>
                        ))}
                        {approval.cities_served.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{approval.cities_served.length - 2} more
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-construction-neutral" />
                        {new Date(approval.created_at).toLocaleDateString()}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleViewDetails(approval.id)}
                        >
                          <Eye className="h-3 w-3 mr-1" />
                          View
                        </Button>
                        <Button 
                          size="sm" 
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => handleApprove(approval.id)}
                        >
                          <Check className="h-3 w-3 mr-1" />
                          Approve
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleReject(approval.id)}
                        >
                          <X className="h-3 w-3 mr-1" />
                          Reject
                        </Button>
                      </div>
                    </TableCell>
                  </motion.tr>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredApprovals.length === 0 && (
            <div className="text-center py-8 text-construction-neutral">
              <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No pending approvals found</p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <RegistrationDetailsModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        registration={selectedRegistration}
      />
    </div>
  );
};
