
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Eye, CheckCircle, X, Flag, Calendar, RefreshCw, MessageCircle, Image as ImageIcon } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useAdminPosts } from '@/hooks/useAdminPosts';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';

export const PostModeration = () => {
  const { posts, loading, refreshPosts, approvePost, removePost } = useAdminPosts();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedPost, setSelectedPost] = useState<any>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isRemoveDialogOpen, setIsRemoveDialogOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.user_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || post.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'flagged': return 'bg-orange-100 text-orange-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleView = (post: any) => {
    setSelectedPost(post);
    setIsViewDialogOpen(true);
  };

  const handleApprove = async (postId: string) => {
    setIsProcessing(true);
    await approvePost(postId);
    setIsProcessing(false);
  };

  const handleRemoveClick = (post: any) => {
    setSelectedPost(post);
    setIsRemoveDialogOpen(true);
  };

  const handleRemoveConfirm = async () => {
    if (!selectedPost) return;
    setIsProcessing(true);
    const success = await removePost(selectedPost.id);
    setIsProcessing(false);
    if (success) {
      setIsRemoveDialogOpen(false);
      setSelectedPost(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-construction-primary"></div>
      </div>
    );
  }

  const statusTypes = [...new Set(posts.map(p => p.status))];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flag className="h-5 w-5 text-construction-primary" />
              Post Moderation
            </div>
            <Button onClick={refreshPosts} variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </CardTitle>
          <CardDescription>
            Review and moderate user-generated content and project posts
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-construction-neutral" />
              <Input
                placeholder="Search posts by title or user..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={filterStatus === 'all' ? 'default' : 'outline'}
                onClick={() => setFilterStatus('all')}
              >
                All
              </Button>
              {statusTypes.map((status) => (
                <Button
                  key={status}
                  variant={filterStatus === status ? 'default' : 'outline'}
                  onClick={() => setFilterStatus(status)}
                  className="capitalize"
                >
                  {status}
                </Button>
              ))}
            </div>
          </div>

          {/* Posts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="hover:shadow-hover transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <h4 className="font-medium text-construction-secondary line-clamp-2">
                          {post.content}
                        </h4>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-sm text-construction-neutral">By {post.user_name}</span>
                          <Calendar className="h-3 w-3 text-construction-neutral" />
                          <span className="text-xs text-construction-neutral">
                            {new Date(post.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2 ml-2">
                        <Badge className={getStatusColor(post.status)}>
                          {post.status}
                        </Badge>
                      </div>
                    </div>

                    <p className="text-sm text-construction-neutral mb-3 line-clamp-3">
                      {post.content}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 mb-4 text-sm text-construction-neutral">
                      <div className="flex items-center gap-1">
                        <CheckCircle className="h-4 w-4 text-construction-primary" />
                        <span>{post.likes_count} likes</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MessageCircle className="h-4 w-4 text-construction-primary" />
                        <span>{post.comments_count} comments</span>
                      </div>
                      {post.media_url && (
                        <div className="flex items-center gap-1">
                          <ImageIcon className="h-4 w-4 text-construction-primary" />
                          <a
                            href={post.media_url}
                            target="_blank"
                            rel="noreferrer"
                            className="underline"
                          >
                            View media
                          </a>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2 flex-wrap">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleView(post)}
                        disabled={isProcessing}
                      >
                        <Eye className="h-3 w-3 mr-1" />
                        View
                      </Button>
                      {post.status !== 'approved' && (
                        <Button 
                          size="sm" 
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => handleApprove(post.id)}
                          disabled={isProcessing}
                        >
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Approve
                        </Button>
                      )}
                      <Button 
                        size="sm" 
                        variant="destructive"
                        onClick={() => handleRemoveClick(post)}
                        disabled={isProcessing}
                      >
                        <X className="h-3 w-3 mr-1" />
                        Remove
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {filteredPosts.length === 0 && (
            <div className="text-center py-8 text-construction-neutral">
              <Flag className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No posts found</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Post Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Social Post</DialogTitle>
            <DialogDescription>
              Post details and information
            </DialogDescription>
          </DialogHeader>
          {selectedPost && (
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Content</h4>
                <p className="text-sm text-construction-neutral whitespace-pre-wrap">
                  {selectedPost.content}
                </p>
              </div>
              {selectedPost.media_url && (
                <div>
                  <h4 className="font-semibold mb-2">Media</h4>
                  <a
                    href={selectedPost.media_url}
                    target="_blank"
                    rel="noreferrer"
                    className="text-sm text-construction-primary underline"
                  >
                    Open media ({selectedPost.media_type || 'file'})
                  </a>
                </div>
              )}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-1">Author</h4>
                  <p className="text-sm text-construction-neutral">{selectedPost.user_name}</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-1">Status</h4>
                  <Badge className={getStatusColor(selectedPost.status)}>
                    {selectedPost.status}
                  </Badge>
                </div>
                <div>
                  <h4 className="font-semibold mb-1">Created At</h4>
                  <p className="text-sm text-construction-neutral">
                    {new Date(selectedPost.created_at).toLocaleString()}
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-1">Metrics</h4>
                  <p className="text-sm text-construction-neutral">
                    {selectedPost.likes_count} likes • {selectedPost.comments_count} comments
                  </p>
                </div>
                {selectedPost.admin_notes && (
                  <div className="col-span-2">
                    <h4 className="font-semibold mb-1">Admin Notes</h4>
                    <p className="text-sm text-construction-neutral whitespace-pre-wrap">
                      {selectedPost.admin_notes}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Remove Confirmation Dialog */}
      <Dialog open={isRemoveDialogOpen} onOpenChange={setIsRemoveDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Removal</DialogTitle>
            <DialogDescription>
              Are you sure you want to remove this post? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          {selectedPost && (
            <div className="py-4">
              <p className="text-sm font-medium mb-2 line-clamp-2">{selectedPost.content}</p>
              <p className="text-xs text-construction-neutral">By {selectedPost.user_name}</p>
            </div>
          )}
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setIsRemoveDialogOpen(false);
                setSelectedPost(null);
              }}
              disabled={isProcessing}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleRemoveConfirm}
              disabled={isProcessing}
            >
              {isProcessing ? 'Removing...' : 'Remove Post'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
