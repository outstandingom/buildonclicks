import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  FileText, 
  Upload, 
  Eye, 
  Loader2, 
  CheckCircle, 
  XCircle,
  ExternalLink
} from 'lucide-react';

interface ProviderDocumentsProps {
  userId: string;
}

interface BusinessRegistration {
  id: string;
  business_name: string;
  status: 'approved' | 'pending' | 'rejected';
  government_id_url: string | null;
  business_certificate_url: string | null;
  insurance_certificate_url: string | null;
  business_license_url: string | null;
}

interface DocumentInfo {
  key: keyof Pick<BusinessRegistration, 'government_id_url' | 'business_certificate_url' | 'insurance_certificate_url' | 'business_license_url'>;
  label: string;
  description: string;
  required: boolean;
}

const DOCUMENTS: DocumentInfo[] = [
  {
    key: 'government_id_url',
    label: 'Government ID',
    description: 'Aadhar Card, PAN Card, Passport, etc.',
    required: true,
  },
  {
    key: 'business_certificate_url',
    label: 'Business Certificate',
    description: 'Company registration certificate',
    required: false,
  },
  {
    key: 'business_license_url',
    label: 'Business License',
    description: 'Trade license or business permit',
    required: false,
  },
  {
    key: 'insurance_certificate_url',
    label: 'Insurance Certificate',
    description: 'Business insurance documents',
    required: false,
  },
];

const statusColors: Record<BusinessRegistration['status'], string> = {
  approved: 'bg-green-500',
  pending: 'bg-yellow-500',
  rejected: 'bg-red-500',
};

export const ProviderDocuments = ({ userId }: ProviderDocumentsProps) => {
  const [registration, setRegistration] = useState<BusinessRegistration | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchRegistration = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('get_provider_documents_for_admin', { p_user_id: userId });
      if (error) throw error;
      setRegistration(data ? (data as unknown as BusinessRegistration) : null);
      if (!data) {
        toast({
          title: 'No documents found',
          description: 'This user has no business registration yet.',
        });
      }
    } catch (error) {
      console.error('Failed to load provider documents', error);
      setRegistration(null);
      toast({
        title: 'Failed to load documents',
        description: error instanceof Error ? error.message : 'Could not fetch provider documents.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (userId) fetchRegistration();
  }, [userId]);

  const handleUpload = async (documentKey: string, file: File) => {
    if (!registration) {
      toast({
        title: 'No registration found',
        description: 'Cannot upload without an approved or pending registration.',
        variant: 'destructive',
      });
      return;
    }

    const allowedExtensions = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
    const fileExt = file.name.split('.').pop()?.toLowerCase();
    if (!fileExt || !allowedExtensions.includes(fileExt)) {
      toast({
        title: 'Invalid file type',
        description: `Allowed: ${allowedExtensions.join(', ')}`,
        variant: 'destructive',
      });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'File too large',
        description: 'Max file size is 5MB',
        variant: 'destructive',
      });
      return;
    }

    try {
      setUploading(documentKey);

      const fileName = `${userId}/${documentKey}_${Date.now()}.${fileExt}`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('business-documents')
        .upload(fileName, file, { cacheControl: '3600', upsert: true });
      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('business-documents')
        .getPublicUrl(uploadData?.path || fileName);
      const publicUrl = urlData?.publicUrl;
      if (!publicUrl) {
        throw new Error('Could not retrieve public URL after upload');
      }

      const { error: updateError } = await supabase.rpc('admin_update_provider_document', {
        p_registration_id: registration.id,
        p_document_key: documentKey,
        p_document_url: publicUrl,
      });
      if (updateError) throw updateError;

      toast({ title: 'Success', description: 'Document uploaded successfully' });
      fetchRegistration();
    } catch (error) {
      console.error(error);
      toast({
        title: 'Upload Failed',
        description: error instanceof Error ? error.message : 'Failed to upload document',
        variant: 'destructive',
      });
    } finally {
      setUploading(null);
    }
  };

  const openDocument = async (url: string) => {
    if (!url) return;

    // If it's already a full URL, just open it
    if (url.startsWith('http')) {
      window.open(url, '_blank');
      return;
    }

    try {
      const { data, error } = await supabase.storage
        .from('business-documents')
        .createSignedUrl(url, 3600);

      if (error || !data?.signedUrl) {
        throw error || new Error('Could not create signed URL');
      }

      window.open(data.signedUrl, '_blank');
    } catch (err) {
      console.error('Failed to open document', err);
      toast({
        title: 'Unable to open document',
        description: err instanceof Error ? err.message : 'Please try again.',
        variant: 'destructive',
      });
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          <span className="ml-2 text-muted-foreground">Loading documents...</span>
        </CardContent>
      </Card>
    );
  }

  if (!registration) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>No business registration found for this user.</p>
          <p className="text-sm mt-2">This user is not a registered provider.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Business: {registration.business_name}</span>
            <Badge className={statusColors[registration.status]}>{registration.status}</Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        {DOCUMENTS.map((doc) => (
          <DocumentCard
            key={doc.key}
            doc={doc}
            documentUrl={registration[doc.key]}
            isUploading={uploading === doc.key}
            onUpload={handleUpload}
            onView={openDocument}
          />
        ))}
      </div>
    </div>
  );
};

// ---------------- DocumentCard ----------------

interface DocumentCardProps {
  doc: DocumentInfo;
  documentUrl: string | null;
  isUploading: boolean;
  onUpload: (documentKey: string, file: File) => void;
  onView: (url: string) => void;
}

const DocumentCard = ({ doc, documentUrl, isUploading, onUpload, onView }: DocumentCardProps) => {
  const { toast } = useToast();
  const hasDocument = !!documentUrl;

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) onUpload(doc.key, file);
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center justify-between">
          <span className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            {doc.label}
            {doc.required && <span className="text-red-500">*</span>}
          </span>
          {hasDocument ? (
            <CheckCircle className="h-5 w-5 text-green-500" />
          ) : (
            <XCircle className="h-5 w-5 text-red-500" />
          )}
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground">{doc.description}</p>

        {hasDocument && (
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => onView(documentUrl)} className="flex-1">
              <Eye className="h-4 w-4 mr-2" />
              View
            </Button>
            <Button variant="outline" size="sm" onClick={() => onView(documentUrl)}>
              <ExternalLink className="h-4 w-4" />
            </Button>
          </div>
        )}

        <div className="relative">
          <Input
            type="file"
            id={`upload-${doc.key}`}
            className="hidden"
            accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
            onChange={handleFileSelect}
            disabled={isUploading}
          />
          <Label htmlFor={`upload-${doc.key}`}>
            <Button
              variant={hasDocument ? 'outline' : 'default'}
              size="sm"
              className="w-full cursor-pointer"
              disabled={isUploading}
              asChild
            >
              <span>
                {isUploading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    {hasDocument ? 'Replace Document' : 'Upload Document'}
                  </>
                )}
              </span>
            </Button>
          </Label>
        </div>

        <p className="text-xs text-muted-foreground">
          Accepted: PDF, JPG, PNG, DOC (Max 5MB)
        </p>
      </CardContent>
    </Card>
  );
};
