import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Share2, Users, Gift, TrendingUp, Plus, Edit } from 'lucide-react';

interface ReferralReward {
  id: string;
  reward_type: string;
  referrer_credits: number;
  referee_credits: number;
  user_type: string;
  is_active: boolean;
}

interface ReferralStats {
  total_codes: number;
  total_referrals: number;
  total_rewards_given: number;
  active_campaigns: number;
}

export const ReferralManagement = () => {
  const [rewards, setRewards] = useState<ReferralReward[]>([]);
  const [stats, setStats] = useState<ReferralStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [editingReward, setEditingReward] = useState<ReferralReward | null>(null);
  const { toast } = useToast();

  const fetchReferralRewards = async () => {
    try {
      const { data, error } = await supabase
        .from('referral_rewards')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching referral rewards:', error);
        return;
      }

      setRewards(data || []);
    } catch (error) {
      console.error('Error fetching referral rewards:', error);
    }
  };

  const fetchReferralStats = async () => {
    try {
      const [codesResponse, referralsResponse, transactionsResponse] = await Promise.all([
        supabase.from('referral_codes').select('id', { count: 'exact' }),
        supabase.from('referrals').select('id', { count: 'exact' }),
        supabase.from('referral_transactions').select('credits_amount')
      ]);

      const totalRewards = transactionsResponse.data?.reduce((sum, t) => sum + t.credits_amount, 0) || 0;

      setStats({
        total_codes: codesResponse.count || 0,
        total_referrals: referralsResponse.count || 0,
        total_rewards_given: totalRewards,
        active_campaigns: rewards.filter(r => r.is_active).length
      });
    } catch (error) {
      console.error('Error fetching referral stats:', error);
    }
  };

  const saveReward = async (rewardData: {
    reward_type: string;
    referrer_credits: number;
    referee_credits: number;
    user_type: string;
    is_active: boolean;
  }) => {
    try {
      if (editingReward && editingReward.id) {
        const { error } = await supabase
          .from('referral_rewards')
          .update(rewardData)
          .eq('id', editingReward.id);

        if (error) throw error;

        toast({
          title: "Success",
          description: "Referral reward updated successfully.",
        });
      } else {
        const { error } = await supabase
          .from('referral_rewards')
          .insert([rewardData]);

        if (error) throw error;

        toast({
          title: "Success",
          description: "New referral reward created successfully.",
        });
      }

      setEditingReward(null);
      await fetchReferralRewards();
    } catch (error) {
      console.error('Error saving reward:', error);
      toast({
        title: "Error",
        description: "Failed to save referral reward.",
        variant: "destructive",
      });
    }
  };

  const toggleRewardStatus = async (rewardId: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('referral_rewards')
        .update({ is_active: !isActive })
        .eq('id', rewardId);

      if (error) throw error;

      await fetchReferralRewards();
      toast({
        title: "Success",
        description: `Reward ${!isActive ? 'activated' : 'deactivated'} successfully.`,
      });
    } catch (error) {
      console.error('Error toggling reward status:', error);
      toast({
        title: "Error",
        description: "Failed to update reward status.",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchReferralRewards(), fetchReferralStats()]);
      setLoading(false);
    };

    loadData();
  }, []);

  useEffect(() => {
    if (rewards.length > 0) {
      fetchReferralStats();
    }
  }, [rewards]);

  if (loading) {
    return <div className="space-y-6 animate-pulse">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      {stats && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Referral Codes</CardTitle>
              <Share2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total_codes}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Referrals</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total_referrals}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Credits Distributed</CardTitle>
              <Gift className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.total_rewards_given}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Campaigns</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{stats.active_campaigns}</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Reward Configuration */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Referral Rewards Configuration</CardTitle>
              <CardDescription>
                Manage referral reward amounts and rules
              </CardDescription>
            </div>
            <Button onClick={() => setEditingReward({} as ReferralReward)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Reward
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {rewards.map((reward) => (
              <div key={reward.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium capitalize">{reward.reward_type.replace('_', ' ')}</span>
                    <Badge variant={reward.is_active ? 'default' : 'secondary'}>
                      {reward.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                    <Badge variant="outline" className="capitalize">
                      {reward.user_type}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Referrer: {reward.referrer_credits} credits • Referee: {reward.referee_credits} credits
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setEditingReward(reward)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={reward.is_active ? 'destructive' : 'default'}
                    size="sm"
                    onClick={() => toggleRewardStatus(reward.id, reward.is_active)}
                  >
                    {reward.is_active ? 'Deactivate' : 'Activate'}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Edit/Create Reward Modal */}
      {editingReward && (
        <Card>
          <CardHeader>
            <CardTitle>
              {editingReward.id ? 'Edit Referral Reward' : 'Create New Referral Reward'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.target as HTMLFormElement);
                saveReward({
                  reward_type: formData.get('reward_type') as string,
                  referrer_credits: parseInt(formData.get('referrer_credits') as string),
                  referee_credits: parseInt(formData.get('referee_credits') as string),
                  user_type: formData.get('user_type') as string,
                  is_active: formData.get('is_active') === 'true'
                });
              }}
              className="space-y-4"
            >
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="reward_type">Reward Type</Label>
                  <Select name="reward_type" defaultValue={editingReward.reward_type}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select reward type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="signup">Signup</SelectItem>
                      <SelectItem value="first_purchase">First Purchase</SelectItem>
                      <SelectItem value="business_verification">Business Verification</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="user_type">User Type</Label>
                  <Select name="user_type" defaultValue={editingReward.user_type}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select user type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Users</SelectItem>
                      <SelectItem value="user">Regular Users</SelectItem>
                      <SelectItem value="provider">Service Providers</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="referrer_credits">Referrer Credits</Label>
                  <Input
                    name="referrer_credits"
                    type="number"
                    min="0"
                    defaultValue={editingReward.referrer_credits}
                    placeholder="Credits for referrer"
                  />
                </div>

                <div>
                  <Label htmlFor="referee_credits">Referee Credits</Label>
                  <Input
                    name="referee_credits"
                    type="number"
                    min="0"
                    defaultValue={editingReward.referee_credits}
                    placeholder="Credits for referee"
                  />
                </div>

                <div>
                  <Label htmlFor="is_active">Status</Label>
                  <Select name="is_active" defaultValue={editingReward.is_active?.toString()}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="true">Active</SelectItem>
                      <SelectItem value="false">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              <div className="flex gap-2">
                <Button type="submit">
                  {editingReward.id ? 'Update Reward' : 'Create Reward'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setEditingReward(null)}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
};