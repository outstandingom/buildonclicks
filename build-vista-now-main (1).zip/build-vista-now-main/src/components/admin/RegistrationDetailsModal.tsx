import React from 'react';
import { motion } from 'framer-motion';
import { X, Building, User, Phone, Mail, MapPin, Calendar, FileText, CreditCard, Globe, Eye } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';

interface RegistrationDetails {
  id: string;
  business_name: string;
  business_type: string;
  registration_number: string;
  vat_gst_number?: string;
  website?: string;
  business_license_url?: string;
  business_address: string;
  cities_served: string[];
  service_area: string;
  years_in_business: number;
  about_services: string;
  contact_name: string;
  phone_number: string;
  email_address: string;
  alternate_contact?: string;
  preferred_communication: string;
  linkedin_profile?: string;
  facebook_page?: string;
  instagram_handle?: string;
  other_links?: string[];
  government_id_url: string;
  business_certificate_url?: string;
  insurance_certificate_url?: string;
  bank_name: string;
  account_number: string;
  account_type: string;
  ifsc_code?: string;
  sub_business_types?: string[];
  status: string;
  created_at: string;
  updated_at: string;
}

interface RegistrationDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  registration: RegistrationDetails | null;
}

export const RegistrationDetailsModal: React.FC<RegistrationDetailsModalProps> = ({
  isOpen,
  onClose,
  registration
}) => {
  if (!registration) return null;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleDocumentView = async (filePath: string) => {
    if (!filePath) {
      console.error('No file path provided');
      return;
    }

    try {
      console.log('Attempting to view document:', filePath);
      
      const { data, error } = await supabase.storage
        .from('business-documents')
        .createSignedUrl(filePath, 3600); // 1 hour expiry
      
      if (error) {
        console.error('Error creating signed URL:', error);
        alert('Error accessing document. Please try again or contact support.');
        return;
      }
      
      if (data?.signedUrl) {
        console.log('Opening document URL:', data.signedUrl);
        window.open(data.signedUrl, '_blank');
      } else {
        console.error('No signed URL received');
        alert('Unable to access document. Please try again.');
      }
    } catch (error) {
      console.error('Unexpected error viewing document:', error);
      alert('An unexpected error occurred. Please try again.');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building className="h-5 w-5 text-primary" />
            Business Registration Details
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status and Basic Info */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-secondary">{registration.business_name}</h2>
              <p className="text-neutral">{registration.business_type}</p>
            </div>
            <Badge className={getStatusColor(registration.status)}>
              {registration.status.toUpperCase()}
            </Badge>
          </div>

          <Separator />

          {/* Business Information */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Building className="h-4 w-4" />
                Business Information
              </h3>
              
              <div className="space-y-2">
                <div>
                  <label className="text-sm font-medium text-neutral">Registration Number</label>
                  <p className="text-sm">{registration.registration_number}</p>
                </div>
                
                {registration.vat_gst_number && (
                  <div>
                    <label className="text-sm font-medium text-neutral">VAT/GST Number</label>
                    <p className="text-sm">{registration.vat_gst_number}</p>
                  </div>
                )}
                
                <div>
                  <label className="text-sm font-medium text-neutral">Years in Business</label>
                  <p className="text-sm">{registration.years_in_business} years</p>
                </div>
                
                {registration.website && (
                  <div>
                    <label className="text-sm font-medium text-neutral">Website</label>
                    <p className="text-sm">
                      <a href={registration.website} target="_blank" rel="noopener noreferrer" 
                         className="text-primary hover:underline">
                        {registration.website}
                      </a>
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <User className="h-4 w-4" />
                Contact Information
              </h3>
              
              <div className="space-y-2">
                <div>
                  <label className="text-sm font-medium text-neutral">Contact Name</label>
                  <p className="text-sm">{registration.contact_name}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-neutral">Phone Number</label>
                  <p className="text-sm">{registration.phone_number}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-neutral">Email Address</label>
                  <p className="text-sm">{registration.email_address}</p>
                </div>
                
                {registration.alternate_contact && (
                  <div>
                    <label className="text-sm font-medium text-neutral">Alternate Contact</label>
                    <p className="text-sm">{registration.alternate_contact}</p>
                  </div>
                )}
                
                <div>
                  <label className="text-sm font-medium text-neutral">Preferred Communication</label>
                  <p className="text-sm capitalize">{registration.preferred_communication}</p>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Address and Service Area */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Address & Service Area
            </h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-neutral">Business Address</label>
                <p className="text-sm">{registration.business_address}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-neutral">Service Area</label>
                <p className="text-sm">{registration.service_area}</p>
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium text-neutral">Cities Served</label>
              <div className="flex flex-wrap gap-1 mt-1">
                {registration.cities_served.map((city, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {city}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <Separator />

          {/* Services */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Services & Specialization
            </h3>
            
            {registration.sub_business_types && registration.sub_business_types.length > 0 && (
              <div>
                <label className="text-sm font-medium text-neutral">Specializations</label>
                <div className="flex flex-wrap gap-1 mt-1">
                  {registration.sub_business_types.map((type, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {type}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            
            <div>
              <label className="text-sm font-medium text-neutral">About Services</label>
              <p className="text-sm mt-1 text-muted-foreground">{registration.about_services}</p>
            </div>
          </div>

          <Separator />

          {/* Social Media */}
          {(registration.linkedin_profile || registration.facebook_page || registration.instagram_handle || 
            (registration.other_links && registration.other_links.length > 0)) && (
            <>
              <div className="space-y-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  Social Media & Links
                </h3>
                
                <div className="grid md:grid-cols-2 gap-4">
                  {registration.linkedin_profile && (
                    <div>
                      <label className="text-sm font-medium text-neutral">LinkedIn</label>
                      <p className="text-sm">
                        <a href={registration.linkedin_profile} target="_blank" rel="noopener noreferrer" 
                           className="text-primary hover:underline">
                          {registration.linkedin_profile}
                        </a>
                      </p>
                    </div>
                  )}
                  
                  {registration.facebook_page && (
                    <div>
                      <label className="text-sm font-medium text-neutral">Facebook</label>
                      <p className="text-sm">
                        <a href={registration.facebook_page} target="_blank" rel="noopener noreferrer" 
                           className="text-primary hover:underline">
                          {registration.facebook_page}
                        </a>
                      </p>
                    </div>
                  )}
                  
                  {registration.instagram_handle && (
                    <div>
                      <label className="text-sm font-medium text-neutral">Instagram</label>
                      <p className="text-sm">
                        <a href={registration.instagram_handle} target="_blank" rel="noopener noreferrer" 
                           className="text-primary hover:underline">
                          {registration.instagram_handle}
                        </a>
                      </p>
                    </div>
                  )}
                </div>
                
                {registration.other_links && registration.other_links.length > 0 && (
                  <div>
                    <label className="text-sm font-medium text-neutral">Other Links</label>
                    <div className="space-y-1 mt-1">
                      {registration.other_links.map((link, index) => (
                        <p key={index} className="text-sm">
                          <a href={link} target="_blank" rel="noopener noreferrer" 
                             className="text-primary hover:underline">
                            {link}
                          </a>
                        </p>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              
              <Separator />
            </>
          )}

          {/* Documents */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Documents
            </h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => registration.business_license_url && handleDocumentView(registration.business_license_url)}
                  className="w-full justify-start"
                  disabled={!registration.business_license_url}
                >
                  <Eye className="h-3 w-3 mr-2" />
                  Business License {!registration.business_license_url && "(Not Uploaded)"}
                </Button>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => handleDocumentView(registration.government_id_url)}
                  className="w-full justify-start"
                >
                  <Eye className="h-3 w-3 mr-2" />
                  Government ID (Required)
                </Button>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => registration.business_certificate_url && handleDocumentView(registration.business_certificate_url)}
                  className="w-full justify-start"
                  disabled={!registration.business_certificate_url}
                >
                  <Eye className="h-3 w-3 mr-2" />
                  Business Certificate {!registration.business_certificate_url && "(Not Uploaded)"}
                </Button>
              </div>
              
              <div className="space-y-2">
                {registration.insurance_certificate_url ? (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleDocumentView(registration.insurance_certificate_url!)}
                    className="w-full justify-start"
                  >
                    <Eye className="h-3 w-3 mr-2" />
                    Insurance Certificate
                  </Button>
                ) : (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full justify-start"
                    disabled
                  >
                    <Eye className="h-3 w-3 mr-2" />
                    Insurance Certificate (Not Uploaded)
                  </Button>
                )}
              </div>
            </div>
          </div>

          <Separator />

          {/* Banking Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Banking Information
            </h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-neutral">Bank Name</label>
                <p className="text-sm">{registration.bank_name}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-neutral">Account Type</label>
                <p className="text-sm capitalize">{registration.account_type}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-neutral">Account Number</label>
                <p className="text-sm">***{registration.account_number.slice(-4)}</p>
              </div>
              
              {registration.ifsc_code && (
                <div>
                  <label className="text-sm font-medium text-neutral">IFSC Code</label>
                  <p className="text-sm">{registration.ifsc_code}</p>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Timeline */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Timeline
            </h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-neutral">Submitted</label>
                <p className="text-sm">{formatDate(registration.created_at)}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium text-neutral">Last Updated</label>
                <p className="text-sm">{formatDate(registration.updated_at)}</p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};