import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { RefreshCw, Search, AlertTriangle, Ban, AlertCircle, Flag, Loader2 } from "lucide-react";
import { useAdminReports } from "@/hooks/useAdminReports";
import { WarnUserDialog } from "./WarnUserDialog";
import { BanUserDialog } from "./BanUserDialog";

export const Reports = () => {
  const { reports, loading, fetchReports, updateReportStatus, warnUser, banUser } = useAdminReports();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  
  const [warnDialogOpen, setWarnDialogOpen] = useState(false);
  const [banDialogOpen, setBanDialogOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState<any>(null);

  const filteredReports = reports.filter(report => {
    const matchesSearch = 
      report.reporter_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.reported_user_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || report.status === filterStatus;
    const matchesPriority = filterPriority === "all" || report.priority === filterPriority;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open": return "bg-red-100 text-red-800";
      case "investigating": return "bg-yellow-100 text-yellow-800";
      case "resolved": return "bg-green-100 text-green-800";
      case "dismissed": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-orange-100 text-orange-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case "post": return "📝";
      case "comment": return "💬";
      case "profile": return "👤";
      case "shop": return "🏪";
      case "portfolio": return "💼";
      default: return "📄";
    }
  };

  const getReasonLabel = (reason: string) => {
    const labels: Record<string, string> = {
      spam: "Spam",
      harassment: "Harassment",
      inappropriate_content: "Inappropriate Content",
      fake_profile: "Fake Profile",
      scam: "Scam",
      copyright: "Copyright Violation",
      other: "Other"
    };
    return labels[reason] || reason;
  };

  const handleWarn = (report: any) => {
    setSelectedReport(report);
    setWarnDialogOpen(true);
  };

  const handleBan = (report: any) => {
    setSelectedReport(report);
    setBanDialogOpen(true);
  };

  const handleDismiss = async (reportId: string) => {
    await updateReportStatus(reportId, 'dismissed', 'Report dismissed after review');
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-construction-primary" />
              Reports & Issues
            </div>
            <Button variant="outline" size="sm" onClick={() => fetchReports()} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </CardTitle>
          <CardDescription>
            Review reported content and take appropriate actions ({reports.length} total reports)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Search and Filters */}
            <div className="flex gap-2 flex-wrap">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search reports..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <Button 
                  variant={filterStatus === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterStatus("all")}
                >
                  All Status
                </Button>
                <Button 
                  variant={filterStatus === "open" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterStatus("open")}
                >
                  Open
                </Button>
                <Button 
                  variant={filterStatus === "investigating" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterStatus("investigating")}
                >
                  Investigating
                </Button>
                <Button 
                  variant={filterStatus === "resolved" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterStatus("resolved")}
                >
                  Resolved
                </Button>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant={filterPriority === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterPriority("all")}
                >
                  All Priority
                </Button>
                <Button 
                  variant={filterPriority === "high" ? "destructive" : "outline"}
                  size="sm"
                  onClick={() => setFilterPriority("high")}
                >
                  High
                </Button>
                <Button 
                  variant={filterPriority === "medium" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterPriority("medium")}
                >
                  Medium
                </Button>
                <Button 
                  variant={filterPriority === "low" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFilterPriority("low")}
                >
                  Low
                </Button>
              </div>
            </div>

            {/* Reports Table */}
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Reporter</TableHead>
                      <TableHead>Reported User</TableHead>
                      <TableHead>Content</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredReports.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                          <Flag className="h-8 w-8 mx-auto mb-2 opacity-50" />
                          No reports found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredReports.map((report, index) => (
                        <motion.tr
                          key={report.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className="hover:bg-muted/50"
                        >
                          <TableCell className="font-medium">{report.reporter_name}</TableCell>
                          <TableCell>{report.reported_user_name}</TableCell>
                          <TableCell>
                            <span className="inline-flex items-center gap-1">
                              {getContentTypeIcon(report.content_type)}
                              <span className="capitalize">{report.content_type}</span>
                            </span>
                          </TableCell>
                          <TableCell>
                            <div className="max-w-[200px]">
                              <div className="font-medium text-sm">{getReasonLabel(report.reason)}</div>
                              <div className="text-xs text-muted-foreground truncate">{report.description}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={getPriorityColor(report.priority)}>
                              {report.priority}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(report.status)}>
                              {report.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">
                            {new Date(report.created_at).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              {report.status !== 'resolved' && report.status !== 'dismissed' && (
                                <>
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    onClick={() => handleWarn(report)}
                                    title="Warn User"
                                  >
                                    <AlertTriangle className="h-4 w-4 text-yellow-600" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    onClick={() => handleBan(report)}
                                    title="Ban User"
                                  >
                                    <Ban className="h-4 w-4 text-red-600" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    onClick={() => handleDismiss(report.id)}
                                    title="Dismiss Report"
                                  >
                                    <AlertCircle className="h-4 w-4" />
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        </motion.tr>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Dialogs */}
      {selectedReport && (
        <>
          <WarnUserDialog
            open={warnDialogOpen}
            onOpenChange={setWarnDialogOpen}
            reportId={selectedReport.id}
            userId={selectedReport.reported_user_id}
            userName={selectedReport.reported_user_name}
            onWarn={warnUser}
          />
          <BanUserDialog
            open={banDialogOpen}
            onOpenChange={setBanDialogOpen}
            reportId={selectedReport.id}
            userId={selectedReport.reported_user_id}
            userName={selectedReport.reported_user_name}
            onBan={banUser}
          />
        </>
      )}
    </div>
  );
};
