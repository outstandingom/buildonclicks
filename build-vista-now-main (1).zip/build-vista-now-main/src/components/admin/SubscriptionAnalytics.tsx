import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAdminLeadCredits } from '@/hooks/useAdminLeadCredits';
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  Calendar,
  Crown,
  BarChart3
} from 'lucide-react';
import { motion } from 'framer-motion';

export const SubscriptionAnalytics: React.FC = () => {
  const { subscriptionAnalytics, loading } = useAdminLeadCredits();

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(amount);
  };

  const analytics = [
    {
      title: "Total Revenue",
      value: formatCurrency(subscriptionAnalytics?.total_revenue || 0),
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-100",
      change: "+12.5%",
      changeColor: "text-green-600"
    },
    {
      title: "Monthly Revenue",
      value: formatCurrency(subscriptionAnalytics?.monthly_revenue || 0),
      icon: Calendar,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      change: "+8.2%",
      changeColor: "text-blue-600"
    },
    {
      title: "Active Subscriptions",
      value: subscriptionAnalytics?.total_active_subscriptions || 0,
      icon: Users,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      change: "+5.1%",
      changeColor: "text-purple-600"
    },
    {
      title: "Popular Plan",
      value: subscriptionAnalytics?.popular_plan_name || 'None',
      subtitle: `${subscriptionAnalytics?.popular_plan_count || 0} users`,
      icon: Crown,
      color: "text-yellow-600",
      bgColor: "bg-yellow-100"
    }
  ];

  const creditStats = [
    {
      title: "Total Credits Distributed",
      value: subscriptionAnalytics?.total_credits_distributed || 0,
      icon: BarChart3,
      color: "text-indigo-600"
    },
    {
      title: "Total Credits Used",
      value: subscriptionAnalytics?.total_credits_used || 0,
      icon: TrendingUp,
      color: "text-red-600"
    },
    {
      title: "Average Credits per User",
      value: Math.round(subscriptionAnalytics?.avg_credits_per_user || 0),
      icon: Users,
      color: "text-teal-600"
    }
  ];

  const usagePercentage = subscriptionAnalytics?.total_credits_distributed 
    ? Math.round((subscriptionAnalytics.total_credits_used / subscriptionAnalytics.total_credits_distributed) * 100)
    : 0;

  return (
    <div className="space-y-6">
      {/* Revenue Analytics */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Revenue Analytics</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {analytics.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">
                        {item.title}
                      </p>
                      <p className="text-2xl font-bold mt-1">
                        {item.value}
                      </p>
                      {item.subtitle && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {item.subtitle}
                        </p>
                      )}
                      {item.change && (
                        <p className={`text-sm mt-2 ${item.changeColor}`}>
                          {item.change} from last month
                        </p>
                      )}
                    </div>
                    <div className={`p-3 rounded-full ${item.bgColor}`}>
                      <item.icon className={`h-6 w-6 ${item.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Credit Analytics */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Credit Analytics</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {creditStats.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <item.icon className={`h-8 w-8 ${item.color}`} />
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">
                        {item.title}
                      </p>
                      <p className="text-3xl font-bold">
                        {item.value.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Credit Usage Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Credit Usage Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Total Usage Rate</span>
                <Badge variant={usagePercentage > 80 ? "destructive" : usagePercentage > 60 ? "secondary" : "default"}>
                  {usagePercentage}%
                </Badge>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className={`h-3 rounded-full transition-all duration-500 ${
                    usagePercentage > 80 
                      ? 'bg-red-500' 
                      : usagePercentage > 60 
                        ? 'bg-yellow-500' 
                        : 'bg-green-500'
                  }`}
                  style={{ width: `${Math.min(usagePercentage, 100)}%` }}
                ></div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Credits Remaining:</span>
                  <p className="font-semibold">
                    {((subscriptionAnalytics?.total_credits_distributed || 0) - 
                      (subscriptionAnalytics?.total_credits_used || 0)).toLocaleString()}
                  </p>
                </div>
                <div>
                  <span className="text-muted-foreground">Popular Plan:</span>
                  <p className="font-semibold">
                    {subscriptionAnalytics?.popular_plan_name || 'None'} 
                    ({subscriptionAnalytics?.popular_plan_count || 0} users)
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};