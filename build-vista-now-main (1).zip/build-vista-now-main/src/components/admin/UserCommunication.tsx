import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useAdminLeadCredits } from '@/hooks/useAdminLeadCredits';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  MessageSquare, 
  Send,
  AlertTriangle,
  Users,
  Filter,
  Bell
} from 'lucide-react';
import { motion } from 'framer-motion';

export const UserCommunication: React.FC = () => {
  const { usersSummary, loading } = useAdminLeadCredits();
  const { toast } = useToast();
  
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [messageTitle, setMessageTitle] = useState('');
  const [messageContent, setMessageContent] = useState('');
  const [messageType, setMessageType] = useState<'info' | 'warning' | 'credit_update'>('info');
  const [isSending, setIsSending] = useState(false);
  const [filterType, setFilterType] = useState<'all' | 'low_credits' | 'no_subscription' | 'inactive'>('all');

  const getFilteredUsers = () => {
    switch (filterType) {
      case 'low_credits':
        return usersSummary.filter(user => user.available_credits < 5);
      case 'no_subscription':
        return usersSummary.filter(user => user.subscription_status === 'inactive');
      case 'inactive':
        return usersSummary.filter(user => !user.last_activity || 
          new Date(user.last_activity) < new Date(Date.now() - 30 * 24 * 60 * 60 * 1000));
      default:
        return usersSummary;
    }
  };

  const filteredUsers = getFilteredUsers();

  const handleUserSelection = (userId: string, checked: boolean) => {
    if (checked) {
      setSelectedUsers([...selectedUsers, userId]);
    } else {
      setSelectedUsers(selectedUsers.filter(id => id !== userId));
    }
  };

  const selectAllFiltered = () => {
    setSelectedUsers(filteredUsers.map(user => user.user_id));
  };

  const clearSelection = () => {
    setSelectedUsers([]);
  };

  const sendMessage = async () => {
    if (!messageTitle || !messageContent || selectedUsers.length === 0) {
      toast({
        title: "Error",
        description: "Please fill in all fields and select at least one user.",
        variant: "destructive",
      });
      return;
    }

    setIsSending(true);
    
    try {
      const promises = selectedUsers.map(userId => 
        supabase.rpc('create_notification', {
          p_user_id: userId,
          p_title: messageTitle,
          p_message: messageContent,
          p_type: messageType
        })
      );

      await Promise.all(promises);

      toast({
        title: "Success",
        description: `Message sent to ${selectedUsers.length} users successfully.`,
      });

      // Reset form
      setMessageTitle('');
      setMessageContent('');
      setSelectedUsers([]);
      setMessageType('info');
    } catch (error) {
      console.error('Error sending messages:', error);
      toast({
        title: "Error",
        description: "Failed to send messages. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  const getFilterBadgeColor = (filter: string) => {
    switch (filter) {
      case 'low_credits': return 'bg-red-100 text-red-800';
      case 'no_subscription': return 'bg-yellow-100 text-yellow-800';
      case 'inactive': return 'bg-gray-100 text-gray-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const getMessageTypeColor = (type: string) => {
    switch (type) {
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'credit_update': return 'bg-green-100 text-green-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="cursor-pointer hover:shadow-md transition-shadow" 
                onClick={() => setFilterType('low_credits')}>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Low Credits</p>
                  <p className="text-2xl font-bold">{usersSummary.filter(u => u.available_credits < 5).length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setFilterType('no_subscription')}>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-yellow-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">No Subscription</p>
                  <p className="text-2xl font-bold">{usersSummary.filter(u => u.subscription_status === 'inactive').length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setFilterType('inactive')}>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Bell className="h-5 w-5 text-gray-600" />
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Inactive Users</p>
                  <p className="text-2xl font-bold">
                    {usersSummary.filter(u => !u.last_activity || 
                      new Date(u.last_activity) < new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Dialog>
            <DialogTrigger asChild>
              <Card className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <MessageSquare className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Send Message</p>
                      <p className="text-lg font-bold">Quick Send</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Send Message to Users</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title">Message Title</Label>
                    <Input
                      id="title"
                      value={messageTitle}
                      onChange={(e) => setMessageTitle(e.target.value)}
                      placeholder="Enter message title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="type">Message Type</Label>
                    <select
                      id="type"
                      value={messageType}
                      onChange={(e) => setMessageType(e.target.value as any)}
                      className="w-full mt-1 p-2 border rounded-md"
                    >
                      <option value="info">Information</option>
                      <option value="warning">Warning</option>
                      <option value="credit_update">Credit Update</option>
                    </select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="content">Message Content</Label>
                  <Textarea
                    id="content"
                    value={messageContent}
                    onChange={(e) => setMessageContent(e.target.value)}
                    placeholder="Enter your message content"
                    rows={4}
                  />
                </div>
                <div className="text-sm text-muted-foreground">
                  Selected users: {selectedUsers.length}
                </div>
                <Button 
                  onClick={sendMessage} 
                  disabled={isSending || selectedUsers.length === 0}
                  className="w-full"
                >
                  {isSending ? 'Sending...' : `Send to ${selectedUsers.length} users`}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </motion.div>
      </div>

      {/* User Selection Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>User Communication</span>
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Badge className={getFilterBadgeColor(filterType)}>
                <Filter className="h-3 w-3 mr-1" />
                {filterType.replace('_', ' ')} ({filteredUsers.length})
              </Badge>
              <Button variant="outline" size="sm" onClick={selectAllFiltered}>
                Select All Filtered
              </Button>
              <Button variant="outline" size="sm" onClick={clearSelection}>
                Clear Selection
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex space-x-2">
            {['all', 'low_credits', 'no_subscription', 'inactive'].map((filter) => (
              <Button
                key={filter}
                variant={filterType === filter ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterType(filter as any)}
              >
                {filter.replace('_', ' ')}
              </Button>
            ))}
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">Select</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Credits</TableHead>
                  <TableHead>Subscription</TableHead>
                  <TableHead>Last Activity</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.user_id}>
                    <TableCell>
                      <input
                        type="checkbox"
                        checked={selectedUsers.includes(user.user_id)}
                        onChange={(e) => handleUserSelection(user.user_id, e.target.checked)}
                        className="rounded"
                      />
                    </TableCell>
                    <TableCell className="font-medium">{user.user_name}</TableCell>
                    <TableCell>
                      <Badge className={user.user_type === 'provider' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}>
                        {user.user_type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className={user.available_credits < 5 ? 'text-red-600 font-medium' : ''}>
                        {user.available_credits}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge className={user.subscription_status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                        {user.subscription_status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {user.last_activity 
                        ? new Date(user.last_activity).toLocaleDateString()
                        : 'Never'
                      }
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {selectedUsers.length > 0 && (
            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm font-medium text-blue-900">
                {selectedUsers.length} users selected for messaging
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};