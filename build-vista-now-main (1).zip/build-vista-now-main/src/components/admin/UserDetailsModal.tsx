import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useUserDetails } from '@/hooks/useUserDetails';
import { useBusinessTypes } from '@/hooks/useBusinessTypes';
import { ProviderDocuments } from './ProviderDocuments';
import { 
  User, Mail, Phone, MapPin, Calendar, CreditCard, 
  TrendingUp, Gift, Activity, Download, FileText, Building2, ShieldCheck 
} from 'lucide-react';
import { format } from 'date-fns';

interface UserDetailsModalProps {
  userId: string | null;
  isOpen: boolean;
  onClose: () => void;
}

export const UserDetailsModal = ({ userId, isOpen, onClose }: UserDetailsModalProps) => {
  const { 
    profile, 
    creditSummary, 
    subscriptions, 
    referralStats, 
    referralTransactions,
    loading,
    addCredits,
    businessRegistration,
    updateBusinessRegistration,
    refreshDetails,
    createBusinessRegistration,
  } = useUserDetails(userId);

  const [addCreditsAmount, setAddCreditsAmount] = useState('');
  const [addCreditsReason, setAddCreditsReason] = useState('');
  const [isAddingCredits, setIsAddingCredits] = useState(false);
  const { businessTypes, subBusinessTypes } = useBusinessTypes();
  const [brForm, setBrForm] = useState({
    business_name: '',
    business_type_name: '',
    registration_number: '',
    vat_gst_number: '',
    website: '',
    status: '',
    rejection_reason: '',
    contact_name: '',
    phone_number: '',
    email_address: '',
    alternate_contact: '',
    business_address: '',
    service_area: '',
    years_in_business: '',
    about_services: '',
    cities_served: '',
    sub_business_types: [] as string[],
    preferred_communication: '',
    linkedin_profile: '',
    facebook_page: '',
    instagram_handle: '',
    other_links: '',
    bank_name: '',
    account_number: '',
    account_type: '',
    ifsc_code: '',
  });
  const [isUpdatingBr, setIsUpdatingBr] = useState(false);

  const handleAddCredits = async () => {
    const amount = parseInt(addCreditsAmount);
    if (!amount || amount <= 0) return;

    setIsAddingCredits(true);
    const success = await addCredits(amount, addCreditsReason);
    if (success) {
      setAddCreditsAmount('');
      setAddCreditsReason('');
    }
    setIsAddingCredits(false);
  };

  const emptyBrForm = {
    business_name: '',
    business_type_name: '',
    registration_number: '',
    vat_gst_number: '',
    website: '',
    status: '',
    rejection_reason: '',
    contact_name: '',
    phone_number: '',
    email_address: '',
    alternate_contact: '',
    business_address: '',
    service_area: '',
    years_in_business: '',
    about_services: '',
    cities_served: '',
    sub_business_types: [] as string[],
    preferred_communication: '',
    linkedin_profile: '',
    facebook_page: '',
    instagram_handle: '',
    other_links: '',
    bank_name: '',
    account_number: '',
    account_type: '',
    ifsc_code: '',
  };

  const hydrateBrForm = () => {
    if (!businessRegistration) {
      setBrForm(emptyBrForm);
      return;
    }
    setBrForm({
      business_name: businessRegistration.business_name || '',
      business_type_name: businessRegistration.business_type_name || '',
      registration_number: businessRegistration.registration_number || '',
      vat_gst_number: businessRegistration.vat_gst_number || '',
      website: businessRegistration.website || '',
      status: businessRegistration.status || '',
      rejection_reason: businessRegistration.rejection_reason || '',
      contact_name: businessRegistration.contact_name || '',
      phone_number: businessRegistration.phone_number || '',
      email_address: businessRegistration.email_address || '',
      alternate_contact: businessRegistration.alternate_contact || '',
      business_address: businessRegistration.business_address || '',
      service_area: businessRegistration.service_area || '',
      years_in_business: businessRegistration.years_in_business?.toString() || '',
      about_services: businessRegistration.about_services || '',
      cities_served: (businessRegistration.cities_served || []).join(', '),
      sub_business_types: (businessRegistration.sub_business_types || []),
      preferred_communication: businessRegistration.preferred_communication || '',
      linkedin_profile: businessRegistration.linkedin_profile || '',
      facebook_page: businessRegistration.facebook_page || '',
      instagram_handle: businessRegistration.instagram_handle || '',
      other_links: (businessRegistration.other_links || []).join(', '),
      bank_name: businessRegistration.bank_name || '',
      account_number: businessRegistration.account_number || '',
      account_type: businessRegistration.account_type || '',
      ifsc_code: businessRegistration.ifsc_code || '',
    });
  };

  const handleUpdateBr = async () => {
    if (!businessRegistration) return;
    setIsUpdatingBr(true);
    const updates = {
      business_name: brForm.business_name,
      status: brForm.status,
      rejection_reason: brForm.rejection_reason || null,
      registration_number: brForm.registration_number,
      vat_gst_number: brForm.vat_gst_number,
      website: brForm.website,
      contact_name: brForm.contact_name,
      phone_number: brForm.phone_number,
      email_address: brForm.email_address,
      alternate_contact: brForm.alternate_contact,
      business_address: brForm.business_address,
      service_area: brForm.service_area,
      years_in_business: brForm.years_in_business ? Number(brForm.years_in_business) : null,
      about_services: brForm.about_services,
      cities_served: brForm.cities_served.split(',').map(s => s.trim()).filter(Boolean),
      sub_business_types: brForm.sub_business_types,
      preferred_communication: brForm.preferred_communication,
      linkedin_profile: brForm.linkedin_profile,
      facebook_page: brForm.facebook_page,
      instagram_handle: brForm.instagram_handle,
                          other_links: Array.isArray(brForm.other_links) ? brForm.other_links : [],
      bank_name: brForm.bank_name,
      account_number: brForm.account_number,
      account_type: brForm.account_type,
      ifsc_code: brForm.ifsc_code,
    };
    const success = await updateBusinessRegistration(updates);
    if (success) {
      await refreshDetails();
      hydrateBrForm();
    }
    setIsUpdatingBr(false);
  };

  useEffect(() => {
    hydrateBrForm();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [businessRegistration?.id, userId]);

  const getStatusBadge = (status: string) => {
    const statusColors: Record<string, string> = {
      active: 'bg-green-500',
      expired: 'bg-gray-500',
      pending: 'bg-yellow-500',
    };
    return (
      <Badge className={statusColors[status] || 'bg-gray-500'}>
        {status}
      </Badge>
    );
  };

  const getUserTypeBadge = (type: string) => {
    const typeColors: Record<string, string> = {
      provider: 'bg-blue-500',
      user: 'bg-purple-500',
      admin: 'bg-red-500',
    };
    return (
      <Badge className={typeColors[type] || 'bg-gray-500'}>
        {type}
      </Badge>
    );
  };

  if (!isOpen || !userId) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            User Details
          </DialogTitle>
          <DialogDescription>
            View and manage complete user information, subscriptions, and activity
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center p-8">
            <div className="text-muted-foreground">Loading user details...</div>
          </div>
        ) : (
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-7">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              {profile?.user_type === 'provider' && (
                <TabsTrigger value="documents">
                  <FileText className="h-4 w-4 mr-1" />
                  Documents
                </TabsTrigger>
              )}
              <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
              <TabsTrigger value="referrals">Referrals</TabsTrigger>
              <TabsTrigger value="credits">Credits</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
              {profile?.user_type === 'provider' && (
                <TabsTrigger value="business">
                  <Building2 className="h-4 w-4 mr-1" />
                  Business Registration
                </TabsTrigger>
              )}
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <div className="text-sm text-muted-foreground">Name</div>
                      <div className="font-medium">{profile?.full_name || 'N/A'}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <div className="text-sm text-muted-foreground">Email</div>
                      <div className="font-medium">{profile?.email || 'N/A'}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <div className="text-sm text-muted-foreground">Mobile</div>
                      <div className="font-medium">{profile?.mobile_number || 'N/A'}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <div className="text-sm text-muted-foreground">City</div>
                      <div className="font-medium">{profile?.city_name || 'N/A'}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <div className="text-sm text-muted-foreground">Joined</div>
                      <div className="font-medium">
                        {profile?.created_at ? format(new Date(profile.created_at), 'PP') : 'N/A'}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-sm text-muted-foreground">User Type</div>
                    {profile && getUserTypeBadge(profile.user_type)}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <div className="grid md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-2xl font-bold">{creditSummary?.available_credits || 0}</div>
                    <div className="text-sm text-muted-foreground">Available Credits</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-2xl font-bold">{subscriptions.filter(s => s.status === 'active').length}</div>
                    <div className="text-sm text-muted-foreground">Active Subscriptions</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-2xl font-bold">{referralStats?.total_referrals || 0}</div>
                    <div className="text-sm text-muted-foreground">Total Referrals</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-2xl font-bold">{referralStats?.total_credits_earned || 0}</div>
                    <div className="text-sm text-muted-foreground">Referral Credits</div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {profile?.user_type === 'provider' && (
              <TabsContent value="documents" className="space-y-4">
                {userId && <ProviderDocuments userId={userId} />}
              </TabsContent>
            )}

            {/* Subscriptions Tab */}
            <TabsContent value="subscriptions" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Subscription History</CardTitle>
                </CardHeader>
                <CardContent>
                  {subscriptions.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No subscriptions found
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {subscriptions.map((sub) => (
                        <Card key={sub.id}>
                          <CardContent className="pt-6">
                            <div className="flex justify-between items-start">
                              <div className="space-y-1">
                                <div className="font-semibold">{sub.plan_name}</div>
                                <div className="text-sm text-muted-foreground">{sub.plan_description}</div>
                                <div className="flex gap-4 text-sm">
                                  <span>Credits: {sub.credits_added}</span>
                                  <span>Amount: ₹{sub.amount}</span>
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {format(new Date(sub.starts_at), 'PP')} - {format(new Date(sub.expires_at), 'PP')}
                                </div>
                              </div>
                              <div className="space-y-2">
                                {getStatusBadge(sub.status)}
                                {sub.razorpay_payment_id && (
                                  <div className="text-xs text-muted-foreground">
                                    Payment ID: {sub.razorpay_payment_id.slice(0, 20)}...
                                  </div>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Referrals Tab */}
            <TabsContent value="referrals" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Referral Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  {referralStats ? (
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-muted-foreground">Referral Code</div>
                        <div className="font-mono font-bold text-lg">{referralStats.referral_code}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Total Credits Earned</div>
                        <div className="font-bold text-lg">{referralStats.total_credits_earned}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Successful Referrals</div>
                        <div className="font-bold text-lg text-green-600">{referralStats.successful_referrals}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Pending Referrals</div>
                        <div className="font-bold text-lg text-yellow-600">{referralStats.pending_referrals}</div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-4 text-muted-foreground">No referral data available</div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Referral Transactions</CardTitle>
                </CardHeader>
                <CardContent>
                  {referralTransactions.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      No referral transactions found
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {referralTransactions.map((trans) => (
                        <div key={trans.id} className="flex justify-between items-center p-3 border rounded">
                          <div>
                            <div className="font-medium">
                              {trans.transaction_type === 'referrer_reward' ? 'Referrer Reward' : 'Referee Reward'}
                            </div>
                            {trans.referee_name && (
                              <div className="text-sm text-muted-foreground">From: {trans.referee_name}</div>
                            )}
                            <div className="text-xs text-muted-foreground">
                              {format(new Date(trans.created_at), 'PPp')}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-green-600">+{trans.credits_amount} credits</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Credits Tab */}
            <TabsContent value="credits" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Credit Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  {creditSummary ? (
                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <div className="text-sm text-muted-foreground">Total Credits</div>
                        <div className="text-2xl font-bold">{creditSummary.total_credits}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Used Credits</div>
                        <div className="text-2xl font-bold text-red-600">{creditSummary.used_credits}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Available Credits</div>
                        <div className="text-2xl font-bold text-green-600">{creditSummary.available_credits}</div>
                      </div>
                      <div className="md:col-span-3">
                        <div className="text-sm text-muted-foreground">Free Credits Given</div>
                        <Badge className={creditSummary.free_credits_given ? 'bg-green-500' : 'bg-gray-500'}>
                          {creditSummary.free_credits_given ? 'Yes' : 'No'}
                        </Badge>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-4 text-muted-foreground">No credit data available</div>
                  )}
                </CardContent>
              </Card>

              {/* Add Credits Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Add Credits</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Number of Credits</Label>
                    <Input
                      type="number"
                      placeholder="Enter credits amount"
                      value={addCreditsAmount}
                      onChange={(e) => setAddCreditsAmount(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Reason (Optional)</Label>
                    <Textarea
                      placeholder="Reason for adding credits"
                      value={addCreditsReason}
                      onChange={(e) => setAddCreditsReason(e.target.value)}
                    />
                  </div>
                  <Button 
                    onClick={handleAddCredits}
                    disabled={!addCreditsAmount || isAddingCredits}
                    className="w-full"
                  >
                    {isAddingCredits ? 'Adding...' : 'Add Credits'}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Activity Tab */}
            <TabsContent value="activity" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Lead Access</CardTitle>
                </CardHeader>
                <CardContent>
                  {creditSummary?.access_logs && creditSummary.access_logs.length > 0 ? (
                    <div className="space-y-2">
                      {creditSummary.access_logs.map((log: any, index: number) => (
                        <div key={index} className="flex justify-between items-center p-3 border rounded">
                          <div>
                            <div className="font-medium capitalize">{log.access_type} Access</div>
                            <div className="text-sm text-muted-foreground">
                              {format(new Date(log.created_at), 'PPp')}
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge variant="outline">{log.credits_consumed} credits</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      No activity logs found
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {profile?.user_type === 'provider' && (
              <TabsContent value="business" className="space-y-4">
                {businessRegistration ? (
                <div className="grid md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <ShieldCheck className="h-4 w-4 text-construction-primary" />
                        Registration Overview
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <div className="text-sm text-muted-foreground">Business Name</div>
                        <div className="font-medium">{businessRegistration.business_name || 'N/A'}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Business Address</div>
                        <div className="font-medium break-words">{businessRegistration.business_address || 'N/A'}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Type</div>
                        <div className="font-medium">{businessRegistration.business_type_name || 'N/A'}</div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="text-sm text-muted-foreground">Reg. Number</div>
                          <div className="font-medium break-words">{businessRegistration.registration_number || 'N/A'}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">GST/VAT</div>
                          <div className="font-medium break-words">{businessRegistration.vat_gst_number || 'N/A'}</div>
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Website</div>
                        <div className="font-medium break-words">{businessRegistration.website || 'N/A'}</div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="text-sm text-muted-foreground">Years in Business</div>
                          <div className="font-medium break-words">{businessRegistration.years_in_business ?? 'N/A'}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Service Area</div>
                          <div className="font-medium break-words">{businessRegistration.service_area || 'N/A'}</div>
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">About Services</div>
                        <div className="font-medium break-words">{businessRegistration.about_services || 'N/A'}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Status</div>
                        <div className="font-medium capitalize">{businessRegistration.status || 'pending'}</div>
                        {businessRegistration.rejection_reason && (
                          <div className="text-xs text-red-600 mt-1">
                            Reason: {businessRegistration.rejection_reason}
                          </div>
                        )}
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Cities Served</div>
                        <div className="font-medium break-words">
                          {(businessRegistration.cities_served || []).join(', ') || 'N/A'}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Sub Business Types</div>
                        <div className="font-medium break-words">
                          {(businessRegistration.sub_business_types || []).join(', ') || 'N/A'}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Preferred Communication</div>
                        <div className="font-medium break-words">
                          {businessRegistration.preferred_communication || 'N/A'}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="text-sm text-muted-foreground">Contact Name</div>
                          <div className="font-medium break-words">{businessRegistration.contact_name || 'N/A'}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Phone</div>
                          <div className="font-medium break-words">{businessRegistration.phone_number || 'N/A'}</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="text-sm text-muted-foreground">Email</div>
                          <div className="font-medium break-words">{businessRegistration.email_address || 'N/A'}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Alternate Contact</div>
                          <div className="font-medium break-words">{businessRegistration.alternate_contact || 'N/A'}</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <div className="text-sm text-muted-foreground">LinkedIn</div>
                          <div className="font-medium break-words">{businessRegistration.linkedin_profile || 'N/A'}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Facebook</div>
                          <div className="font-medium break-words">{businessRegistration.facebook_page || 'N/A'}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Instagram</div>
                          <div className="font-medium break-words">{businessRegistration.instagram_handle || 'N/A'}</div>
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Other Links</div>
                        <div className="font-medium break-words">
                          {(businessRegistration.other_links || []).join(', ') || 'N/A'}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="text-sm text-muted-foreground">Bank Name</div>
                          <div className="font-medium break-words">{businessRegistration.bank_name || 'N/A'}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Account Type</div>
                          <div className="font-medium break-words">{businessRegistration.account_type || 'N/A'}</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="text-sm text-muted-foreground">Account Number</div>
                          <div className="font-medium break-words">{businessRegistration.account_number || 'N/A'}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">IFSC</div>
                          <div className="font-medium break-words">{businessRegistration.ifsc_code || 'N/A'}</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="text-sm text-muted-foreground">Business License</div>
                          <div className="font-medium break-words">{businessRegistration.business_license_url || 'N/A'}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Government ID</div>
                          <div className="font-medium break-words">{businessRegistration.government_id_url || 'N/A'}</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="text-sm text-muted-foreground">Business Certificate</div>
                          <div className="font-medium break-words">{businessRegistration.business_certificate_url || 'N/A'}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Insurance Certificate</div>
                          <div className="font-medium break-words">{businessRegistration.insurance_certificate_url || 'N/A'}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Edit & Update (Admin)</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Status</Label>
                          <Input
                            value={brForm.status}
                            onChange={(e) => setBrForm(prev => ({ ...prev, status: e.target.value }))}
                            placeholder="pending / approved / rejected"
                          />
                        </div>
                        <div>
                          <Label>Rejection Reason</Label>
                          <Input
                            value={brForm.rejection_reason}
                            onChange={(e) => setBrForm(prev => ({ ...prev, rejection_reason: e.target.value }))}
                            placeholder="If rejected, add reason"
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Business Name</Label>
                        <Input
                          value={brForm.business_name}
                          onChange={(e) => setBrForm(prev => ({ ...prev, business_name: e.target.value }))}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Registration Number</Label>
                          <Input
                            value={brForm.registration_number}
                            onChange={(e) => setBrForm(prev => ({ ...prev, registration_number: e.target.value }))}
                          />
                        </div>
                        <div>
                          <Label>VAT/GST</Label>
                          <Input
                            value={brForm.vat_gst_number}
                            onChange={(e) => setBrForm(prev => ({ ...prev, vat_gst_number: e.target.value }))}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Website</Label>
                          <Input
                            value={brForm.website}
                            onChange={(e) => setBrForm(prev => ({ ...prev, website: e.target.value }))}
                          />
                        </div>
                        <div>
                          <Label>Years in Business</Label>
                          <Input
                            value={brForm.years_in_business}
                            onChange={(e) => setBrForm(prev => ({ ...prev, years_in_business: e.target.value }))}
                            placeholder="e.g., 5"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Contact Name</Label>
                          <Input
                            value={brForm.contact_name}
                            onChange={(e) => setBrForm(prev => ({ ...prev, contact_name: e.target.value }))}
                          />
                        </div>
                        <div>
                          <Label>Phone</Label>
                          <Input
                            value={brForm.phone_number}
                            onChange={(e) => setBrForm(prev => ({ ...prev, phone_number: e.target.value }))}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Email</Label>
                          <Input
                            value={brForm.email_address}
                            onChange={(e) => setBrForm(prev => ({ ...prev, email_address: e.target.value }))}
                          />
                        </div>
                        <div>
                          <Label>Alternate Contact</Label>
                          <Input
                            value={brForm.alternate_contact}
                            onChange={(e) => setBrForm(prev => ({ ...prev, alternate_contact: e.target.value }))}
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Business Address</Label>
                        <Textarea
                          value={brForm.business_address}
                          onChange={(e) => setBrForm(prev => ({ ...prev, business_address: e.target.value }))}
                          rows={2}
                        />
                      </div>
                      <div>
                        <Label>Service Area</Label>
                        <Input
                          value={brForm.service_area}
                          onChange={(e) => setBrForm(prev => ({ ...prev, service_area: e.target.value }))}
                          placeholder="Primary service area"
                        />
                      </div>
                      <div>
                        <Label>About Services</Label>
                        <Textarea
                          value={brForm.about_services}
                          onChange={(e) => setBrForm(prev => ({ ...prev, about_services: e.target.value }))}
                          rows={3}
                        />
                      </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label>Cities Served (comma separated)</Label>
                        <Input
                          value={brForm.cities_served}
                          onChange={(e) => setBrForm(prev => ({ ...prev, cities_served: e.target.value }))}
                          placeholder="City1, City2"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Sub Business Types (select multiple)</Label>
                        <div className="flex flex-wrap gap-2">
                          {(subBusinessTypes[brForm.business_type_name] || []).map((sub) => {
                            const checked = brForm.sub_business_types.includes(sub);
                            return (
                              <div key={sub} className="flex items-center space-x-2 border rounded px-2 py-1">
                                <Checkbox
                                  checked={checked}
                                  onCheckedChange={() => {
                                    setBrForm(prev => ({
                                      ...prev,
                                      sub_business_types: checked
                                        ? prev.sub_business_types.filter(s => s !== sub)
                                        : [...prev.sub_business_types, sub]
                                    }));
                                  }}
                                  id={`sub-edit-${sub}`}
                                />
                                <Label htmlFor={`sub-edit-${sub}`} className="text-sm cursor-pointer">
                                  {sub}
                                </Label>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                      <div>
                        <Label>Preferred Communication</Label>
                        <Input
                          value={brForm.preferred_communication}
                          onChange={(e) => setBrForm(prev => ({ ...prev, preferred_communication: e.target.value }))}
                          placeholder="Email / Phone / WhatsApp"
                        />
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <Label>LinkedIn</Label>
                          <Input
                            value={brForm.linkedin_profile}
                            onChange={(e) => setBrForm(prev => ({ ...prev, linkedin_profile: e.target.value }))}
                          />
                        </div>
                        <div>
                          <Label>Facebook</Label>
                          <Input
                            value={brForm.facebook_page}
                            onChange={(e) => setBrForm(prev => ({ ...prev, facebook_page: e.target.value }))}
                          />
                        </div>
                        <div>
                          <Label>Instagram</Label>
                          <Input
                            value={brForm.instagram_handle}
                            onChange={(e) => setBrForm(prev => ({ ...prev, instagram_handle: e.target.value }))}
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Other Links (comma separated)</Label>
                        <Input
                          value={Array.isArray(brForm.other_links) ? brForm.other_links.join(', ') : brForm.other_links}
                          onChange={(e) => setBrForm(prev => ({ ...prev, other_links: e.target.value.split(',').map(s => s.trim()).filter(Boolean) }))}
                          placeholder="https://example.com, https://another.com"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Bank Name</Label>
                          <Input
                            value={brForm.bank_name}
                            onChange={(e) => setBrForm(prev => ({ ...prev, bank_name: e.target.value }))}
                          />
                        </div>
                        <div>
                          <Label>Account Type</Label>
                          <Input
                            value={brForm.account_type}
                            onChange={(e) => setBrForm(prev => ({ ...prev, account_type: e.target.value }))}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Account Number</Label>
                          <Input
                            value={brForm.account_number}
                            onChange={(e) => setBrForm(prev => ({ ...prev, account_number: e.target.value }))}
                          />
                        </div>
                        <div>
                          <Label>IFSC</Label>
                          <Input
                            value={brForm.ifsc_code}
                            onChange={(e) => setBrForm(prev => ({ ...prev, ifsc_code: e.target.value }))}
                          />
                        </div>
                      </div>
                      <Button
                        className="w-full bg-construction-primary hover:bg-construction-primary/90"
                        disabled={isUpdatingBr}
                        onClick={handleUpdateBr}
                      >
                        {isUpdatingBr ? 'Updating...' : 'Save Changes'}
                      </Button>
                    </CardContent>
                  </Card>
                </div>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>No Business Registration</CardTitle>
                    </CardHeader>
                    <CardContent className="py-6 text-muted-foreground">
                      This provider has not submitted a business registration yet.
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            )}
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
};
