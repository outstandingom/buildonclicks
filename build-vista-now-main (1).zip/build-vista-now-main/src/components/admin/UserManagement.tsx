import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, MoreHorizontal, UserCheck, UserX, RefreshCw, Shield, MapPin, ShieldCheck, AlertTriangle, Filter, X } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAdminUsers } from '@/hooks/useAdminUsers';
import { UserDetailsModal } from './UserDetailsModal';
import { CreateUserDialog } from './CreateUserDialog';
import { ResetPasswordDialog } from './ResetPasswordDialog';
import { useToast } from '@/hooks/use-toast';
import { UserPlus } from 'lucide-react';

export const UserManagement = () => {
  const { users, loading, refreshUsers, activateUser, suspendUser, resetAccess } = useAdminUsers();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [resetPasswordUser, setResetPasswordUser] = useState<{id: string, email: string | null, name: string} | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const { toast } = useToast();

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.full_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'all' || user.user_type.toLowerCase() === filterRole.toLowerCase();
    const matchesStatus = filterStatus === 'all' || 
      (filterStatus === 'active' && user.is_active) || 
      (filterStatus === 'inactive' && !user.is_active);
    const matchesCategory = filterCategory === 'all' || 
      (user.business_category && user.business_category.toLowerCase() === filterCategory.toLowerCase());
    return matchesSearch && matchesRole && matchesStatus && matchesCategory;
  });

  const getRoleColor = (role: string) => {
    switch (role.toLowerCase()) {
      case 'contractor': return 'bg-blue-100 text-blue-800';
      case 'architect': return 'bg-green-100 text-green-800';
      case 'vendor': return 'bg-purple-100 text-purple-800';
      case 'user': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: boolean) => {
    return status ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  };

  const handleUserAction = async (userId: string, action: 'activate' | 'suspend' | 'reset') => {
    const user = users.find(u => u.id === userId);
    if (action === 'activate') {
      await activateUser(userId);
    } else if (action === 'suspend') {
      await suspendUser(userId);
    } else if (action === 'reset') {
      // Open password reset dialog instead of sending email
      if (user) {
        setResetPasswordUser({
          id: user.id,
          email: user.email,
          name: user.full_name
        });
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-construction-primary"></div>
      </div>
    );
  }

  const userTypes = [...new Set(users.map(u => u.user_type))];
  const businessCategories = [...new Set(users.map(u => u.business_category).filter(Boolean))].sort();

  return (
    <div className="space-y-4 md:space-y-6">
      <Card>
        <CardHeader className="p-4 md:p-6">
          <CardTitle className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-construction-primary" />
              <span className="text-lg md:text-xl">User Management</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Button 
                onClick={() => setShowCreateDialog(true)} 
                className="bg-construction-primary hover:bg-construction-primary/90 w-full md:w-auto"
                size="sm"
              >
                <UserPlus className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Add User/Provider</span>
                <span className="sm:hidden">Add User</span>
              </Button>
              <Button onClick={refreshUsers} variant="outline" size="sm" className="w-full md:w-auto mt-2 md:mt-0">
                <RefreshCw className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Refresh</span>
                <span className="sm:hidden">Refresh</span>
              </Button>
            </div>
          </CardTitle>
          <CardDescription className="text-sm md:text-base">
            Manage users, roles, and account status across the platform
          </CardDescription>
        </CardHeader>
        <CardContent className="p-4 md:p-6">
          {/* Search and Filters */}
          <div className="space-y-3 mb-6">
            {/* Search Bar */}
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-construction-neutral" />
                <Input
                  placeholder="Search by name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              {/* Mobile Filter Toggle */}
              <Button
                variant="outline"
                size="icon"
                className="md:hidden"
                onClick={() => setShowFilters(!showFilters)}
              >
                {showFilters ? <X className="h-4 w-4" /> : <Filter className="h-4 w-4" />}
              </Button>
            </div>
            
            {/* Compact Filter Buttons - Desktop */}
            <div className="hidden md:flex flex-wrap items-center gap-2 text-sm">
              {/* User Type Filter */}
              <div className="flex items-center gap-1.5 bg-muted/50 rounded-md p-1">
                <span className="text-xs font-medium text-muted-foreground px-2">Type:</span>
                <Button
                  variant={filterRole === 'all' ? 'default' : 'ghost'}
                  onClick={() => setFilterRole('all')}
                  size="sm"
                  className="h-7 px-2 text-xs"
                >
                  All
                </Button>
                {userTypes.map((role) => (
                  <Button
                    key={role}
                    variant={filterRole === role ? 'default' : 'ghost'}
                    onClick={() => setFilterRole(role)}
                    className="h-7 px-2 text-xs capitalize"
                    size="sm"
                  >
                    {role}
                  </Button>
                ))}
              </div>

              {/* Business Category Filter */}
              {businessCategories.length > 0 && (
                <div className="flex items-center gap-1.5 bg-muted/50 rounded-md p-1">
                  <span className="text-xs font-medium text-muted-foreground px-2">Category:</span>
                  <Button
                    variant={filterCategory === 'all' ? 'default' : 'ghost'}
                    onClick={() => setFilterCategory('all')}
                    size="sm"
                    className="h-7 px-2 text-xs"
                  >
                    All
                  </Button>
                  {businessCategories.map((category) => (
                    <Button
                      key={category}
                      variant={filterCategory === category ? 'default' : 'ghost'}
                      onClick={() => setFilterCategory(category || '')}
                      size="sm"
                      className="h-7 px-2 text-xs"
                    >
                      {category}
                    </Button>
                  ))}
                </div>
              )}

              {/* Status Filter */}
              <div className="flex items-center gap-1.5 bg-muted/50 rounded-md p-1">
                <span className="text-xs font-medium text-muted-foreground px-2">Status:</span>
                <Button
                  variant={filterStatus === 'all' ? 'default' : 'ghost'}
                  onClick={() => setFilterStatus('all')}
                  size="sm"
                  className="h-7 px-2 text-xs"
                >
                  All
                </Button>
                <Button
                  variant={filterStatus === 'active' ? 'default' : 'ghost'}
                  onClick={() => setFilterStatus('active')}
                  size="sm"
                  className="h-7 px-2 text-xs"
                >
                  Active
                </Button>
                <Button
                  variant={filterStatus === 'inactive' ? 'default' : 'ghost'}
                  onClick={() => setFilterStatus('inactive')}
                  size="sm"
                  className="h-7 px-2 text-xs"
                >
                  Inactive
                </Button>
              </div>
            </div>

            {/* Mobile Filter Panel */}
            {showFilters && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="md:hidden space-y-3 bg-muted/30 rounded-lg p-4"
              >
                {/* User Type Filter - Mobile */}
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-2 block">User Type</label>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant={filterRole === 'all' ? 'default' : 'outline'}
                      onClick={() => setFilterRole('all')}
                      size="sm"
                      className="text-xs h-8"
                    >
                      All
                    </Button>
                    {userTypes.map((role) => (
                      <Button
                        key={role}
                        variant={filterRole === role ? 'default' : 'outline'}
                        onClick={() => setFilterRole(role)}
                        size="sm"
                        className="text-xs h-8 capitalize"
                      >
                        {role}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Business Category Filter - Mobile */}
                {businessCategories.length > 0 && (
                  <div>
                    <label className="text-xs font-medium text-muted-foreground mb-2 block">Business Category</label>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant={filterCategory === 'all' ? 'default' : 'outline'}
                        onClick={() => setFilterCategory('all')}
                        size="sm"
                        className="text-xs h-8"
                      >
                        All
                      </Button>
                      {businessCategories.map((category) => (
                        <Button
                          key={category}
                          variant={filterCategory === category ? 'default' : 'outline'}
                          onClick={() => setFilterCategory(category || '')}
                          size="sm"
                          className="text-xs h-8"
                        >
                          {category}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Status Filter - Mobile */}
                <div>
                  <label className="text-xs font-medium text-muted-foreground mb-2 block">Status</label>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant={filterStatus === 'all' ? 'default' : 'outline'}
                      onClick={() => setFilterStatus('all')}
                      size="sm"
                      className="text-xs h-8"
                    >
                      All
                    </Button>
                    <Button
                      variant={filterStatus === 'active' ? 'default' : 'outline'}
                      onClick={() => setFilterStatus('active')}
                      size="sm"
                      className="text-xs h-8"
                    >
                      Active
                    </Button>
                    <Button
                      variant={filterStatus === 'inactive' ? 'default' : 'outline'}
                      onClick={() => setFilterStatus('inactive')}
                      size="sm"
                      className="text-xs h-8"
                    >
                      Inactive
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </div>

          {/* Users Table - Desktop */}
          <div className="border rounded-lg hidden md:block">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Business Category</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Verification</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Joined</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user, index) => (
                  <motion.tr
                    key={user.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="hover:bg-muted/50 cursor-pointer"
                    onClick={() => setSelectedUserId(user.id)}
                  >
                    <TableCell>
                      <div>
                        <div className="font-medium text-construction-secondary">
                          {user.full_name}
                        </div>
                        <div className="text-sm text-construction-neutral">
                          ID: {user.id.slice(0, 8)}...
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getRoleColor(user.user_type)}>
                        {user.user_type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {user.business_category ? (
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          {user.business_category}
                        </Badge>
                      ) : (
                        <span className="text-sm text-construction-neutral">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3 text-construction-neutral" />
                        {user.city_name || 'Not specified'}
                      </div>
                    </TableCell>
                    <TableCell>
                      {user.is_verified ? (
                        <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
                          <ShieldCheck className="h-3 w-3" />
                          Verified
                        </Badge>
                      ) : (
                        <Badge className="bg-yellow-100 text-yellow-800 flex items-center gap-1">
                          <AlertTriangle className="h-3 w-3" />
                          {user.registration_status ? user.registration_status : 'Not Verified'}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(user.is_active)}>
                        {user.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-construction-neutral">
                      {new Date(user.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger
                          asChild
                          onClick={(e) => e.stopPropagation()}
                        >
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                          <DropdownMenuItem onClick={() => handleUserAction(user.id, 'activate')}>
                            <UserCheck className="h-4 w-4 mr-2" />
                            Activate
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUserAction(user.id, 'suspend')}>
                            <UserX className="h-4 w-4 mr-2" />
                            Suspend
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUserAction(user.id, 'reset')}>
                            <RefreshCw className="h-4 w-4 mr-2" />
                            Reset Password
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </motion.tr>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Mobile Users List */}
          <div className="md:hidden space-y-3">
            {filteredUsers.map((user, index) => (
              <motion.div
                key={user.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="border rounded-lg p-4 bg-card hover:bg-muted/50 cursor-pointer"
                onClick={() => setSelectedUserId(user.id)}
              >
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <div className="font-medium text-construction-secondary text-base">
                      {user.full_name}
                    </div>
                    <div className="text-xs text-construction-neutral mt-1">
                      ID: {user.id.slice(0, 8)}...
                    </div>
                  </div>
                  <Badge className={getStatusColor(user.is_active)}>
                    {user.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Type</div>
                    <Badge className={getRoleColor(user.user_type)}>
                      {user.user_type}
                    </Badge>
                  </div>
                  
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Verification</div>
                    {user.is_verified ? (
                      <Badge className="bg-green-100 text-green-800 flex items-center gap-1 text-xs">
                        <ShieldCheck className="h-3 w-3" />
                        Verified
                      </Badge>
                    ) : (
                      <Badge className="bg-yellow-100 text-yellow-800 flex items-center gap-1 text-xs">
                        <AlertTriangle className="h-3 w-3" />
                        {user.registration_status ? user.registration_status : 'Not Verified'}
                      </Badge>
                    )}
                  </div>

                  {user.business_category && (
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Category</div>
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 text-xs">
                        {user.business_category}
                      </Badge>
                    </div>
                  )}

                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Location</div>
                    <div className="flex items-center gap-1 text-sm">
                      <MapPin className="h-3 w-3 text-construction-neutral" />
                      {user.city_name || 'Not specified'}
                    </div>
                  </div>
                </div>

                <div className="flex justify-between items-center mt-4 pt-3 border-t">
                  <div className="text-xs text-construction-neutral">
                    Joined: {new Date(user.created_at).toLocaleDateString()}
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger
                      asChild
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                      <DropdownMenuItem onClick={() => handleUserAction(user.id, 'activate')}>
                        <UserCheck className="h-4 w-4 mr-2" />
                        Activate
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleUserAction(user.id, 'suspend')}>
                        <UserX className="h-4 w-4 mr-2" />
                        Suspend
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleUserAction(user.id, 'reset')}>
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Reset Password
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </motion.div>
            ))}
          </div>

          {filteredUsers.length === 0 && (
            <div className="text-center py-8 text-construction-neutral">
              <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No users found</p>
            </div>
          )}
        </CardContent>
      </Card>

      <UserDetailsModal 
        userId={selectedUserId} 
        isOpen={!!selectedUserId}
        onClose={() => setSelectedUserId(null)}
      />

      <CreateUserDialog
        isOpen={showCreateDialog}
        onClose={() => setShowCreateDialog(false)}
        onSuccess={() => {
          refreshUsers();
        }}
      />

      {resetPasswordUser && (
        <ResetPasswordDialog
          isOpen={!!resetPasswordUser}
          onClose={() => setResetPasswordUser(null)}
          userId={resetPasswordUser.id}
          userEmail={resetPasswordUser.email}
          userName={resetPasswordUser.name}
        />
      )}
    </div>
  );
};
