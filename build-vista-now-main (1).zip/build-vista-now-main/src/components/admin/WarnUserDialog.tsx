import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';

interface WarnUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reportId: string;
  userId: string;
  userName: string;
  onWarn: (reportId: string, userId: string, reason: string, severity: 'low' | 'medium' | 'high') => Promise<void>;
}

export const WarnUserDialog = ({
  open,
  onOpenChange,
  reportId,
  userId,
  userName,
  onWarn,
}: WarnUserDialogProps) => {
  const [severity, setSeverity] = useState<'low' | 'medium' | 'high'>('medium');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  const handleWarn = async () => {
    if (!reason.trim()) return;

    try {
      setLoading(true);
      await onWarn(reportId, userId, reason.trim(), severity);
      setReason('');
      setSeverity('medium');
      onOpenChange(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Warn User: {userName}</DialogTitle>
          <DialogDescription>
            Issue a warning to this user for policy violation
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Warning Severity</Label>
            <Select value={severity} onValueChange={(value: any) => setSeverity(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low - Minor Violation</SelectItem>
                <SelectItem value="medium">Medium - Moderate Violation</SelectItem>
                <SelectItem value="high">High - Serious Violation</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Warning Reason</Label>
            <Textarea
              placeholder="Explain why this user is being warned..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={4}
            />
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleWarn} disabled={loading || !reason.trim()}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Issue Warning
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
