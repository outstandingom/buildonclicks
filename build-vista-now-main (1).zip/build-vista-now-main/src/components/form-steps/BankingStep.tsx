
import React from 'react';
import { UseFormReturn } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Lock, CreditCard, AlertTriangle } from 'lucide-react';

interface BankingStepProps {
  form: UseFormReturn<any>;
}

const accountTypes = [
  'Personal',
  'Business',
  'Current',
  'Savings'
];

export const BankingStep: React.FC<BankingStepProps> = ({ form }) => {
  const { control } = form;

  return (
    <div className="space-y-6">
      <div className="bg-amber-50 p-4 rounded-lg">
        <div className="flex items-start gap-3">
          <Lock className="w-5 h-5 text-amber-600 mt-0.5" />
          <div>
            <h3 className="font-medium text-amber-800 mb-2">
              Secure Banking Information
            </h3>
            <p className="text-sm text-amber-700">
              Your banking information is encrypted and secure. This information is used for payment processing and will only be accessible to authorized personnel.
            </p>
          </div>
        </div>
      </div>

      <FormField
        control={control}
        name="bankName"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Bank Name (Optional)
            </FormLabel>
            <FormControl>
              <Input placeholder="Enter your bank name" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="accountNumber"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Account Number (Optional)</FormLabel>
            <FormControl>
              <Input
                type="text"
                placeholder="Enter your account number"
                autoComplete="off"
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          control={control}
          name="accountType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Account Type (Optional)</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select account type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {accountTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="ifscCode"
          render={({ field }) => (
            <FormItem>
              <FormLabel>IFSC Code (Optional)</FormLabel>
              <FormControl>
                <Input placeholder="SBIN0001234" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <div className="bg-red-50 p-4 rounded-lg">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
          <div>
            <h3 className="font-medium text-red-800 mb-2">
              Important Security Notice
            </h3>
            <ul className="text-sm text-red-700 space-y-1">
              <li>• Your banking information is encrypted and stored securely</li>
              <li>• We never store your full account number in plain text</li>
              <li>• Only authorized personnel can access this information</li>
              <li>• You can update this information anytime from your dashboard</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-4 rounded-lg">
        <h3 className="font-medium text-construction-secondary mb-2">
          How payments work on BuildOnClick
        </h3>
        <ul className="text-sm text-construction-neutral space-y-1">
          <li>• Payments are processed securely through our payment gateway</li>
          <li>• You'll receive payments directly to your bank account</li>
          <li>• Payment processing typically takes 2-3 business days</li>
          <li>• You can track all payments in your dashboard</li>
        </ul>
      </div>
    </div>
  );
};
