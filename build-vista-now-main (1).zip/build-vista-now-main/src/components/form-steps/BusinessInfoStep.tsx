
import React, { useState } from 'react';
import { UseFormReturn } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Info } from 'lucide-react';

interface BusinessInfoStepProps {
  form: UseFormReturn<any>;
}

const indianCities = [
  'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad', 'Pune', 'Ahmedabad',
  'Surat', 'Jaipur', 'Lucknow', 'Kanpur', 'Nagpur', 'Indore', 'Bhopal', 'Visakhapatnam',
  'Patna', 'Vadodara', 'Ghaziabad', 'Ludhiana', 'Agra', 'Kochi', 'Coimbatore', 'Madurai'
];

const businessTypes = [
  'Architects',
  'Designers', 
  'Engineers',
  'Contractors',
  'Vendors',
  'Manufacturers'
];

const subBusinessTypes = {
  'Architects': [
    'Architect',
    'Landscape Architect'
  ],
  'Designers': [],
  'Engineers': [
    'Civil Engineer / Structural',
    'Geotechnical Engineer',
    'Site Engineer / Supervisor',
    'Land Surveyor'
  ],
  'Contractors': [
    'General contractor / Builders',
    'Government contractors',
    'Excavation contractor',
    'Shuttering / framework contractor',
    'Fall Ceiling / POP contractor',
    'Modular furniture contractor/installer',
    'flooring contractor',
    'Waterproofing Specialist',
    'Fabricators',
    'Masons',
    'Tile Mason',
    'Steel fixer / Bar Benders',
    'Plumbing (Plumber)',
    'Electrician',
    'HVAC Technician',
    'Carpenter',
    'Painter',
    'Cleaning crew',
    'Municipal / Legal consultant',
    'Advocates',
    'Notary',
    'Quality inspectors / Auditors',
    'GOVT inspectors'
  ],
  'Vendors': [
    'sand & Minerals',
    'Steel and cement',
    'Hardware',
    'Tiles and Sanitaryware',
    'plumbing Material',
    'Plywood & Decor',
    'furniture',
    'Stones'
  ],
  'Manufacturers': [
    'Steel Manufacturers',
    'Cement Manufacturers',
    'Building Materials Manufacturers',
    'Hardware Manufacturers',
    'Tiles Manufacturers',
    'Sanitaryware Manufacturers',
    'Plumbing Materials Manufacturers',
    'Electrical Equipment Manufacturers',
    'HVAC Equipment Manufacturers',
    'Prefab Manufacturers',
    'Door & Window Manufacturers',
    'Roofing Materials Manufacturers'
  ]
};

export const BusinessInfoStep: React.FC<BusinessInfoStepProps> = ({ form }) => {
  const { control, setValue, watch } = form;
  const selectedCities = watch('citiesServed') || [];
  const selectedBusinessType = watch('businessType');
  const selectedSubTypes = watch('subBusinessType') || [];
  const availableSubTypes = selectedBusinessType ? subBusinessTypes[selectedBusinessType as keyof typeof subBusinessTypes] || [] : [];

  const handleCityToggle = (city: string) => {
    const updatedCities = selectedCities.includes(city)
      ? selectedCities.filter((c: string) => c !== city)
      : [...selectedCities, city];
    setValue('citiesServed', updatedCities);
  };

  const handleSubTypeToggle = (subType: string) => {
    const updatedSubTypes = selectedSubTypes.includes(subType)
      ? selectedSubTypes.filter((s: string) => s !== subType)
      : [...selectedSubTypes, subType];
    setValue('subBusinessType', updatedSubTypes);
  };


  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          control={control}
          name="businessName"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Business Name *</FormLabel>
              <FormControl>
                <Input placeholder="Enter your business name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="businessType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Business Type *</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select business type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {businessTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      {selectedBusinessType && (
        <FormField
          control={control}
          name="subBusinessType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Sub Business Type (Select all that apply)</FormLabel>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-60 overflow-y-auto p-3 border rounded-md bg-gray-50">
                {availableSubTypes.map((subType) => (
                  <label key={subType} className="flex items-center space-x-2 cursor-pointer p-2 hover:bg-white rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedSubTypes.includes(subType)}
                      onChange={() => handleSubTypeToggle(subType)}
                      className="rounded border-gray-300 text-construction-primary focus:ring-construction-primary"
                    />
                    <span className="text-sm">{subType}</span>
                  </label>
                ))}
              </div>
              {selectedSubTypes.length > 0 && (
                <p className="text-xs text-gray-600 mt-1">
                  Selected: {selectedSubTypes.length} service{selectedSubTypes.length !== 1 ? 's' : ''}
                </p>
              )}
              <FormMessage />
            </FormItem>
          )}
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          control={control}
          name="registrationNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                Business Registration Number
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Info className="h-4 w-4 text-muted-foreground hover:text-primary cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <div className="space-y-2">
                        <p className="font-semibold">Business Registration Number</p>
                        <p className="text-sm">This is your official business registration number issued by the government.</p>
                        <div className="text-xs space-y-1">
                          <p><strong>Examples:</strong></p>
                          <p>• Company: U74900DL2020PTC123456</p>
                          <p>• LLP: AAK-1234</p>
                          <p>• Partnership: FIRM/2020/001234</p>
                          <p>• Proprietorship: Shop license number</p>
                        </div>
                        <div className="pt-2 border-t">
                          <p className="text-xs font-medium mb-1">Sample Documents:</p>
                          <div className="text-xs space-y-1">
                            <a href="https://www.mca.gov.in/content/mca/global/en/home.html" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 underline block">
                              • Certificate of Incorporation Sample
                            </a>
                            <a href="https://udyamregistration.gov.in/Government-India/Ministry-MSME-registration.htm" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 underline block">
                              • Udyam Registration Sample
                            </a>
                          </div>
                        </div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </FormLabel>
              <FormControl>
                <Input placeholder="e.g., U74900DL2020PTC123456" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="vatGstNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                VAT/GST Number
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Info className="h-4 w-4 text-muted-foreground hover:text-primary cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <div className="space-y-2">
                        <p className="font-semibold">GST Registration Number</p>
                        <p className="text-sm">Your 15-digit GST identification number (if registered).</p>
                        <div className="text-xs space-y-1">
                          <p><strong>Format:</strong> 27AABCU9603R1ZX</p>
                          <p>• First 2 digits: State code</p>
                          <p>• Next 10 digits: PAN number</p>
                          <p>• 13th digit: Entity number</p>
                          <p>• 14th digit: Z (default)</p>
                          <p>• 15th digit: Check sum</p>
                        </div>
                        <div className="pt-2 border-t">
                          <p className="text-xs font-medium mb-1">Sample Documents:</p>
                          <div className="text-xs space-y-1">
                            <a href="https://www.gst.gov.in/" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 underline block">
                              • GST Registration Certificate Sample
                            </a>
                            <a href="https://services.gst.gov.in/services/searchtp" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 underline block">
                              • Verify GST Number Format
                            </a>
                          </div>
                        </div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </FormLabel>
              <FormControl>
                <Input placeholder="e.g., 27AABCU9603R1ZX" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <FormField
        control={control}
        name="website"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Business Website</FormLabel>
            <FormControl>
              <Input placeholder="https://your-website.com" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />


      <FormField
        control={control}
        name="businessAddress"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Business Address *</FormLabel>
            <FormControl>
              <Textarea
                placeholder="Enter complete business address"
                rows={3}
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="citiesServed"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Cities or Regions Served *</FormLabel>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 max-h-40 overflow-y-auto p-2 border rounded-md">
              {indianCities.map((city) => (
                <label key={city} className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedCities.includes(city)}
                    onChange={() => handleCityToggle(city)}
                    className="rounded border-gray-300 text-construction-primary focus:ring-construction-primary"
                  />
                  <span className="text-sm">{city}</span>
                </label>
              ))}
            </div>
            <FormMessage />
          </FormItem>
        )}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <FormField
        control={control}
        name="serviceArea"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              Service Area (Zip Codes) *
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-muted-foreground hover:text-primary cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <div className="space-y-2">
                      <p className="font-semibold">Service Area Zip Codes</p>
                      <p className="text-sm">List the postal codes where you provide services.</p>
                      <div className="text-xs space-y-1">
                        <p><strong>Format:</strong> Comma-separated zip codes</p>
                        <p><strong>Example:</strong> 400001, 400002, 400003</p>
                        <p>• Include all areas you serve</p>
                        <p>• Use 6-digit Indian postal codes</p>
                      </div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </FormLabel>
            <FormControl>
              <Input
                placeholder="400001, 400002, 400003"
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

        <FormField
          control={control}
          name="yearsInBusiness"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Years in Business *</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  min="0"
                  placeholder="0"
                  {...field}
                  onChange={(e) => field.onChange(parseInt(e.target.value))}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <FormField
        control={control}
        name="aboutServices"
        render={({ field }) => (
          <FormItem>
            <FormLabel>About Your Services *</FormLabel>
            <FormControl>
              <Textarea
                placeholder="Describe your services, specializations, and what makes you unique..."
                rows={4}
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
};
