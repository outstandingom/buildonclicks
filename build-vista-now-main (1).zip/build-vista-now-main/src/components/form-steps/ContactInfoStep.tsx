
import React from 'react';
import { UseFormReturn } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

interface ContactInfoStepProps {
  form: UseFormReturn<any>;
}

const communicationMethods = [
  'Phone',
  'Email',
  'WhatsApp',
  'SMS'
];

export const ContactInfoStep: React.FC<ContactInfoStepProps> = ({ form }) => {
  const { control } = form;

  return (
    <div className="space-y-6">
      <FormField
        control={control}
        name="contactName"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Full Name (Point of Contact) *</FormLabel>
            <FormControl>
              <Input placeholder="Enter full name" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          control={control}
          name="phoneNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Phone Number *</FormLabel>
              <FormControl>
                <Input
                  placeholder="+91 9876543210"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="emailAddress"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email Address *</FormLabel>
              <FormControl>
                <Input
                  type="email"
                  placeholder="your.email@example.com"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <FormField
        control={control}
        name="alternateContact"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Alternate Contact</FormLabel>
            <FormControl>
              <Input placeholder="Alternate phone number or email" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="preferredCommunication"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Preferred Communication Methods *</FormLabel>
            <div className="space-y-3 mt-2">
              {communicationMethods.map((method) => (
                <div key={method} className="flex items-center space-x-2">
                  <Checkbox
                    id={`comm-${method}`}
                    checked={field.value?.includes(method)}
                    onCheckedChange={(checked) => {
                      const currentValues = field.value || [];
                      if (checked) {
                        field.onChange([...currentValues, method]);
                      } else {
                        field.onChange(currentValues.filter((val: string) => val !== method));
                      }
                    }}
                  />
                  <Label
                    htmlFor={`comm-${method}`}
                    className="text-sm font-normal cursor-pointer"
                  >
                    {method}
                  </Label>
                </div>
              ))}
            </div>
            <FormMessage />
          </FormItem>
        )}
      />

      <div className="bg-blue-50 p-4 rounded-lg">
        <h3 className="font-medium text-construction-secondary mb-2">
          Communication Preferences
        </h3>
        <p className="text-sm text-construction-neutral">
          We'll use your preferred communication method to send you:
        </p>
        <ul className="text-sm text-construction-neutral mt-2 space-y-1">
          <li>• New project inquiries</li>
          <li>• Account updates and notifications</li>
          <li>• Payment confirmations</li>
          <li>• Platform updates</li>
        </ul>
      </div>
    </div>
  );
};
