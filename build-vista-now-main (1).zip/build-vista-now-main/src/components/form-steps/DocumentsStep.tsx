
import React, { useState } from 'react';
import { UseFormReturn } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Upload, FileText, Shield, AlertCircle, Check, X, Info, Phone } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface DocumentsStepProps {
  form: UseFormReturn<any>;
}

export const DocumentsStep: React.FC<DocumentsStepProps> = ({ form }) => {
  const { control, setValue, watch } = form;
  const businessType = watch('businessType');
  const [uploadingFiles, setUploadingFiles] = useState<Set<string>>(new Set());
  const navigate = useNavigate();

  const FileUploadField = ({ 
    name, 
    label, 
    required = false, 
    description, 
    accept = ".pdf,.jpg,.jpeg,.png" 
  }: {
    name: string;
    label: string;
    required?: boolean;
    description?: string;
    accept?: string;
  }) => {
    const isUploading = uploadingFiles.has(name);
    
    return (
      <FormField
        control={control}
        name={name}
        render={({ field }) => {
          const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
            const files = e.target.files;
            if (files && files.length > 0) {
              setUploadingFiles(prev => new Set(prev).add(name));
              
              // Simulate upload delay for better UX
              setTimeout(() => {
                field.onChange(files);
                setValue(name, files);
                setUploadingFiles(prev => {
                  const newSet = new Set(prev);
                  newSet.delete(name);
                  return newSet;
                });
              }, 500);
            }
          };

          const hasFile = field.value && field.value.length > 0;
          
          return (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                {label} {required && <span className="text-red-500">*</span>}
              </FormLabel>
              {description && (
                <p className="text-sm text-muted-foreground mb-2">{description}</p>
              )}
              <FormControl>
                <div className={`border-2 border-dashed rounded-lg p-6 text-center transition-all ${
                  hasFile ? 'border-green-500 bg-green-50' : 
                  isUploading ? 'border-blue-500 bg-blue-50' : 
                  'border-gray-300 hover:border-primary'
                }`}>
                  {isUploading ? (
                    <div className="flex flex-col items-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-2"></div>
                      <p className="text-sm text-primary">Uploading...</p>
                    </div>
                  ) : hasFile ? (
                    <div className="flex flex-col items-center">
                      <Check className="w-8 h-8 text-green-600 mb-2" />
                      <p className="text-sm text-green-600 mb-2">
                        ✓ {field.value[0]?.name || 'File selected'}
                      </p>
                      <p className="text-xs text-muted-foreground mb-2">
                        File size: {(field.value[0]?.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center">
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground mb-2">
                        Click to upload or drag and drop
                      </p>
                      <p className="text-xs text-muted-foreground mb-2">
                        PDF, JPG, PNG up to 10MB
                      </p>
                    </div>
                  )}
                  
                  <input
                    type="file"
                    accept={accept}
                    onChange={handleFileChange}
                    className="hidden"
                    id={name}
                    disabled={isUploading}
                  />
                  
                  <div className="flex gap-2 justify-center">
                    <Button
                      type="button"
                      variant={hasFile ? "outline" : "default"}
                      size="sm"
                      disabled={isUploading}
                      onClick={() => document.getElementById(name)?.click()}
                    >
                      {hasFile ? 'Change File' : 'Choose File'}
                    </Button>
                    
                    {hasFile && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          field.onChange(null);
                          setValue(name, null);
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          );
        }}
      />
    );
  };

  return (
    <div className="space-y-6">
      <div className="bg-red-50 p-4 rounded-lg">
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-red-600 mt-0.5" />
          <div>
            <h3 className="font-medium text-red-800 mb-2">
              Document Verification Required
            </h3>
            <p className="text-sm text-red-700">
              All documents will be verified by our team before approval. Please ensure all documents are clear, valid, and up-to-date.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 mb-3">
          <FileText className="w-5 h-5 text-primary" />
          <h3 className="font-medium text-construction-secondary">Business License/Certifications</h3>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="h-4 w-4 text-muted-foreground hover:text-primary cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-sm">
                <div className="space-y-2">
                  <p className="font-semibold">Required Documents:</p>
                  <div className="text-xs space-y-1">
                    <p><strong>For Companies:</strong> Certificate of Incorporation</p>
                    <p><strong>For LLP:</strong> Certificate of Incorporation (LLP)</p>
                    <p><strong>For Partnership:</strong> Partnership Deed</p>
                    <p><strong>For Proprietorship:</strong> Shop & Establishment License</p>
                    <p><strong>For Contractors:</strong> Contractor License/Registration</p>
                    <p><strong>Sample:</strong> Document with company letterhead, registration number, and government stamp/seal</p>
                  </div>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <FileUploadField
          name="businessLicense"
          label=""
          required
          description="Upload your business license, trade license, or professional certifications"
        />
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 mb-3">
          <Shield className="w-5 h-5 text-primary" />
          <h3 className="font-medium text-construction-secondary">Government ID Verification</h3>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="h-4 w-4 text-muted-foreground hover:text-primary cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-sm">
                <div className="space-y-2">
                  <p className="font-semibold">Accepted Documents:</p>
                  <div className="text-xs space-y-1">
                    <p><strong>Aadhaar Card:</strong> Both sides, clear text</p>
                    <p><strong>PAN Card:</strong> Front side with photo</p>
                    <p><strong>Passport:</strong> Photo page with personal details</p>
                    <p><strong>Voter ID:</strong> Both sides, recent issue</p>
                    <p><strong>Sample:</strong> Document should show full name, photo, and unique ID number clearly</p>
                  </div>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <FileUploadField
          name="governmentId"
          label=""
          required
          description="Upload a clear copy of your Aadhaar Card, PAN Card, or Passport"
        />
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 mb-3">
          <FileText className="w-5 h-5 text-primary" />
          <h3 className="font-medium text-construction-secondary">Business Registration Certificate</h3>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="h-4 w-4 text-muted-foreground hover:text-primary cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-sm">
                <div className="space-y-2">
                  <p className="font-semibold">Required Certificate:</p>
                  <div className="text-xs space-y-1">
                    <p><strong>Pvt/Public Company:</strong> Certificate of Incorporation from MCA</p>
                    <p><strong>LLP:</strong> Certificate of Incorporation (LLP) from MCA</p>
                    <p><strong>Partnership:</strong> Registered Partnership Deed</p>
                    <p><strong>Sole Proprietorship:</strong> MSME Registration / Udyam Certificate</p>
                    <p><strong>Sample:</strong> Official government document with registration number, date of incorporation, and official seal</p>
                  </div>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <FileUploadField
          name="businessCertificate"
          label=""
          required
          description="Upload your business registration certificate, shop license, or incorporation documents"
        />
      </div>

      {businessType === 'Contractors' && (
        <FileUploadField
          name="insuranceCertificate"
          label="Insurance Certificate"
          description="Upload your professional liability or general insurance certificate (recommended for contractors)"
        />
      )}

      <div className="bg-blue-50 p-4 rounded-lg">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
          <div>
            <h3 className="font-medium text-blue-800 mb-2">
              Document Guidelines
            </h3>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Documents must be clear and legible</li>
              <li>• File size should not exceed 10MB</li>
              <li>• Accepted formats: PDF, JPG, JPEG, PNG</li>
              <li>• Ensure all information is visible and up-to-date</li>
              <li>• Documents should be in English or Hindi</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
        <div className="flex items-start gap-3">
          <Phone className="w-5 h-5 text-orange-600 mt-0.5" />
          <div className="flex-1">
            <h3 className="font-medium text-orange-800 mb-2">
              Don't have required documents?
            </h3>
            <p className="text-sm text-orange-700 mb-3">
              If you don't have your business license, registration certificate, or other required documents ready, our team can help guide you through the process.
            </p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => navigate('/contact')}
              className="border-orange-300 text-orange-700 hover:bg-orange-100"
            >
              <Phone className="w-4 h-4 mr-2" />
              Contact Us for Help
            </Button>
          </div>
        </div>
      </div>

      <div className="bg-green-50 p-4 rounded-lg">
        <h3 className="font-medium text-construction-secondary mb-2">
          Why do we need these documents?
        </h3>
        <ul className="text-sm text-construction-neutral space-y-1">
          <li>• To verify your identity and business legitimacy</li>
          <li>• To build trust with potential clients</li>
          <li>• To comply with legal requirements</li>
          <li>• To protect both businesses and customers</li>
        </ul>
      </div>
    </div>
  );
};
