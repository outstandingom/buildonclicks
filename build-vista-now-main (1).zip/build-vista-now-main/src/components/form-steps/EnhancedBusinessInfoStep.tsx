import React, { useState } from 'react';
import { UseFormReturn } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Skeleton } from '@/components/ui/skeleton';
import { Info, AlertCircle, CheckCircle } from 'lucide-react';
import { useBusinessTypes } from '@/hooks/useBusinessTypes';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface EnhancedBusinessInfoStepProps {
  form: UseFormReturn<any>;
}

const indianCities = [
  'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad', 'Pune', 'Ahmedabad',
  'Surat', 'Jaipur', 'Lucknow', 'Kanpur', 'Nagpur', 'Indore', 'Bhopal', 'Visakhapatnam',
  'Patna', 'Vadodara', 'Ghaziabad', 'Ludhiana', 'Agra', 'Kochi', 'Coimbatore', 'Madurai',
  'Thane', 'Faridabad', 'Nashik', 'Meerut', 'Rajkot', 'Kalyan-Dombivali', 'Vasai-Virar',
  'Varanasi', 'Srinagar', 'Aurangabad', 'Dhanbad', 'Amritsar', 'Navi Mumbai', 'Allahabad'
];

export const EnhancedBusinessInfoStep: React.FC<EnhancedBusinessInfoStepProps> = ({ form }) => {
  const { control, setValue, watch, formState: { errors } } = form;
  const { businessTypes, subBusinessTypes, isLoading } = useBusinessTypes();
  
  const [citySearch, setCitySearch] = useState('');
  
  const selectedCities = watch('citiesServed') || [];
  const selectedBusinessType = watch('businessType');
  const selectedSubTypes = watch('subBusinessType') || [];
  const businessName = watch('businessName');
  const registrationNumber = watch('registrationNumber');
  const vatGstNumber = watch('vatGstNumber');
  
  const availableSubTypes = selectedBusinessType ? subBusinessTypes[selectedBusinessType] || [] : [];

  const handleCityToggle = (city: string) => {
    const updatedCities = selectedCities.includes(city)
      ? selectedCities.filter((c: string) => c !== city)
      : [...selectedCities, city];
    setValue('citiesServed', updatedCities, { shouldValidate: true });
  };

  const handleSubTypeToggle = (subType: string) => {
    const updatedSubTypes = selectedSubTypes.includes(subType)
      ? selectedSubTypes.filter((s: string) => s !== subType)
      : [...selectedSubTypes, subType];
    setValue('subBusinessType', updatedSubTypes, { shouldValidate: true });
  };

  // Validation helpers
  const isBusinessNameValid = businessName && businessName.length >= 2;
  const isRegistrationNumberValid = registrationNumber && registrationNumber.length >= 5;
  const isGstValid = !vatGstNumber || (vatGstNumber.length === 15 && /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(vatGstNumber));

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-10 w-full" />
          </div>
          <div className="space-y-2">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-10 w-full" />
          </div>
        </div>
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  // Filter cities based on search
  const filteredCities = indianCities.filter(city => 
    city.toLowerCase().includes(citySearch.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Real-time validation alerts */}
      {businessName && !isBusinessNameValid && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Business name must be at least 2 characters long.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          control={control}
          name="businessName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                Business Name *
                {isBusinessNameValid && <CheckCircle className="h-4 w-4 text-green-500" />}
              </FormLabel>
              <FormControl>
                <Input 
                  placeholder="Enter your business name" 
                  {...field} 
                  className={errors.businessName ? 'border-destructive' : isBusinessNameValid ? 'border-green-500' : ''}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="businessType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Business Type *</FormLabel>
              <Select onValueChange={(value) => {
                field.onChange(value);
                setValue('subBusinessType', []); // Reset sub types when business type changes
              }} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger className={errors.businessType ? 'border-destructive' : ''}>
                    <SelectValue placeholder="Select business type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {businessTypes.map((type) => (
                    <SelectItem key={type.id} value={type.name}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      {selectedBusinessType && availableSubTypes.length > 0 && (
        <FormField
          control={control}
          name="subBusinessType"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                Sub Business Type (Select all that apply)
                {selectedSubTypes.length > 0 && <CheckCircle className="h-4 w-4 text-green-500" />}
              </FormLabel>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-60 overflow-y-auto p-3 border rounded-md bg-muted/50">
                {availableSubTypes.map((subType) => (
                  <label key={subType} className="flex items-center space-x-2 cursor-pointer p-2 hover:bg-background rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={selectedSubTypes.includes(subType)}
                      onChange={() => handleSubTypeToggle(subType)}
                      className="rounded border-input text-primary focus:ring-primary"
                    />
                    <span className="text-sm">{subType}</span>
                  </label>
                ))}
              </div>
              {selectedSubTypes.length > 0 && (
                <p className="text-xs text-muted-foreground mt-1">
                  Selected: {selectedSubTypes.length} service{selectedSubTypes.length !== 1 ? 's' : ''}
                </p>
              )}
              <FormMessage />
            </FormItem>
          )}
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormField
          control={control}
          name="registrationNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                Business Registration Number
                {isRegistrationNumberValid && <CheckCircle className="h-4 w-4 text-green-500" />}
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Info className="h-4 w-4 text-muted-foreground hover:text-primary cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <div className="space-y-2">
                        <p className="font-semibold">Business Registration Number</p>
                        <p className="text-sm">This is your official business registration number issued by the government.</p>
                        <div className="text-xs space-y-1">
                          <p><strong>Examples:</strong></p>
                          <p>• Company: U74900DL2020PTC123456</p>
                          <p>• LLP: AAK-1234</p>
                          <p>• Partnership: FIRM/2020/001234</p>
                          <p>• Proprietorship: Shop license number</p>
                        </div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </FormLabel>
              <FormControl>
                <Input 
                  placeholder="e.g., U74900DL2020PTC123456" 
                  {...field} 
                  className={errors.registrationNumber ? 'border-destructive' : isRegistrationNumberValid ? 'border-green-500' : ''}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="vatGstNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-2">
                VAT/GST Number
                {vatGstNumber && isGstValid && <CheckCircle className="h-4 w-4 text-green-500" />}
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Info className="h-4 w-4 text-muted-foreground hover:text-primary cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <div className="space-y-2">
                        <p className="font-semibold">GST Registration Number</p>
                        <p className="text-sm">Your 15-digit GST identification number (if registered).</p>
                        <div className="text-xs space-y-1">
                          <p><strong>Format:</strong> 27AABCU9603R1ZX</p>
                          <p>• First 2 digits: State code</p>
                          <p>• Next 10 digits: PAN number</p>
                          <p>• 13th digit: Entity number</p>
                          <p>• 14th digit: Z (default)</p>
                          <p>• 15th digit: Check sum</p>
                        </div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </FormLabel>
              <FormControl>
                <Input 
                  placeholder="e.g., 27AABCU9603R1ZX" 
                  {...field} 
                  className={vatGstNumber && !isGstValid ? 'border-destructive' : vatGstNumber && isGstValid ? 'border-green-500' : ''}
                />
              </FormControl>
              {vatGstNumber && !isGstValid && (
                <p className="text-xs text-destructive mt-1">Invalid GST format. Must be 15 characters.</p>
              )}
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <FormField
        control={control}
        name="website"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Business Website</FormLabel>
            <FormControl>
              <Input placeholder="https://your-website.com" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="businessAddress"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Business Address *</FormLabel>
            <FormControl>
              <Textarea
                placeholder="Enter complete business address"
                rows={3}
                {...field}
                className={errors.businessAddress ? 'border-destructive' : ''}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="citiesServed"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              Cities or Regions Served *
              {selectedCities.length > 0 && <CheckCircle className="h-4 w-4 text-green-500" />}
            </FormLabel>
            
            {/* Search Input */}
            <div className="mb-2">
              <Input
                type="text"
                placeholder="Search cities..."
                value={citySearch}
                onChange={(e) => setCitySearch(e.target.value)}
                className="w-full"
              />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 max-h-40 overflow-y-auto p-2 border rounded-md">
              {filteredCities.length > 0 ? (
                filteredCities.map((city) => (
                  <label key={city} className="flex items-center space-x-2 cursor-pointer hover:bg-muted/50 p-1 rounded">
                    <input
                      type="checkbox"
                      checked={selectedCities.includes(city)}
                      onChange={() => handleCityToggle(city)}
                      className="rounded border-input text-primary focus:ring-primary"
                    />
                    <span className="text-sm">{city}</span>
                  </label>
                ))
              ) : (
                <p className="text-sm text-muted-foreground col-span-full text-center py-4">
                  No cities found matching "{citySearch}"
                </p>
              )}
            </div>
            {selectedCities.length > 0 && (
              <p className="text-xs text-muted-foreground mt-1">
                Selected: {selectedCities.length} cit{selectedCities.length !== 1 ? 'ies' : 'y'}
              </p>
            )}
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
          control={control}
          name="yearsInBusiness"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Years in Business *</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  placeholder="0"
                  {...field}
                  onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                  className={errors.yearsInBusiness ? 'border-destructive' : ''}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

      <FormField
        control={control}
        name="aboutServices"
        render={({ field }) => (
          <FormItem>
            <FormLabel>About Your Services *</FormLabel>
            <FormControl>
              <Textarea
                placeholder="Describe your services, specializations, and what makes you unique..."
                rows={4}
                {...field}
                className={errors.aboutServices ? 'border-destructive' : ''}
              />
            </FormControl>
            <p className="text-xs text-muted-foreground">
              {field.value?.length || 0}/500 characters
            </p>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
};
