import React, { useState } from 'react';
import { UseFormReturn } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Upload, 
  FileText, 
  CheckCircle, 
  X, 
  AlertCircle,
  FileImage,
  FileType
} from 'lucide-react';

interface EnhancedDocumentsStepProps {
  form: UseFormReturn<any>;
}

interface FileValidation {
  maxSize: number; // in MB
  allowedTypes: string[];
  required: boolean;
}

const fileValidations: Record<string, FileValidation> = {
  businessLicense: {
    maxSize: 5,
    allowedTypes: ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'],
    required: false
  },
  governmentId: {
    maxSize: 5,
    allowedTypes: ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'],
    required: true
  },
  businessCertificate: {
    maxSize: 5,
    allowedTypes: ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'],
    required: false
  },
  insuranceCertificate: {
    maxSize: 5,
    allowedTypes: ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'],
    required: false
  }
};

export const EnhancedDocumentsStep: React.FC<EnhancedDocumentsStepProps> = ({ form }) => {
  const { control, setValue, watch, formState: { errors } } = form;
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const [fileErrors, setFileErrors] = useState<Record<string, string>>({});

  const validateFile = (file: File, fieldName: string): string | null => {
    const validation = fileValidations[fieldName];
    
    if (!validation) return null;

    // Check file size
    const fileSizeMB = file.size / (1024 * 1024);
    if (fileSizeMB > validation.maxSize) {
      return `File size must be less than ${validation.maxSize}MB. Current size: ${fileSizeMB.toFixed(2)}MB`;
    }

    // Check file type
    if (!validation.allowedTypes.includes(file.type)) {
      return `Invalid file type. Allowed types: ${validation.allowedTypes.join(', ')}`;
    }

    return null;
  };

  const handleFileUpload = (files: FileList | null, fieldName: string) => {
    if (!files || files.length === 0) return;

    const file = files[0];
    const error = validateFile(file, fieldName);

    if (error) {
      setFileErrors(prev => ({ ...prev, [fieldName]: error }));
      return;
    }

    // Clear any previous errors
    setFileErrors(prev => ({ ...prev, [fieldName]: '' }));

    // Simulate upload progress
    setUploadProgress(prev => ({ ...prev, [fieldName]: 0 }));
    
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        const currentProgress = prev[fieldName] || 0;
        if (currentProgress >= 100) {
          clearInterval(progressInterval);
          return prev;
        }
        return { ...prev, [fieldName]: currentProgress + 10 };
      });
    }, 100);

    // Set the file in form
    setValue(fieldName, files, { shouldValidate: true });
  };

  const removeFile = (fieldName: string) => {
    setValue(fieldName, null);
    setUploadProgress(prev => ({ ...prev, [fieldName]: 0 }));
    setFileErrors(prev => ({ ...prev, [fieldName]: '' }));
  };

  const getFileIcon = (fileName: string) => {
    const extension = fileName?.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf':
        return <FileText className="h-6 w-6 text-red-500" />;
      case 'jpg':
      case 'jpeg':
      case 'png':
        return <FileImage className="h-6 w-6 text-blue-500" />;
      default:
        return <FileType className="h-6 w-6 text-gray-500" />;
    }
  };

  const FileUploadField = ({ 
    name, 
    label, 
    description,
    required = false 
  }: { 
    name: string; 
    label: string; 
    description: string;
    required?: boolean;
  }) => {
    const files = watch(name);
    const file = files?.[0];
    const progress = uploadProgress[name] || 0;
    const error = fileErrors[name];
    const validation = fileValidations[name];

    return (
      <FormField
        control={control}
        name={name}
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              {label} {required && '*'}
              {file && progress === 100 && <CheckCircle className="h-4 w-4 text-green-500" />}
            </FormLabel>
            
            <div className="space-y-3">
              {!file ? (
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center hover:border-muted-foreground/50 transition-colors">
                  <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground mb-2">{description}</p>
                  <p className="text-xs text-muted-foreground mb-3">
                    Max size: {validation?.maxSize}MB | Formats: PDF, JPG, PNG
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      const input = document.createElement('input');
                      input.type = 'file';
                      input.accept = validation?.allowedTypes.join(',') || '';
                      input.onchange = (e) => {
                        const target = e.target as HTMLInputElement;
                        handleFileUpload(target.files, name);
                      };
                      input.click();
                    }}
                  >
                    Choose File
                  </Button>
                </div>
              ) : (
                <div className="border rounded-lg p-4 bg-muted/50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {getFileIcon(file.name)}
                      <div>
                        <p className="text-sm font-medium">{file.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {(file.size / (1024 * 1024)).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(name)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  {progress > 0 && progress < 100 && (
                    <div className="mt-3 space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Uploading...</span>
                        <span>{progress}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  )}
                  
                  {progress === 100 && (
                    <div className="mt-2 flex items-center gap-2 text-xs text-green-600">
                      <CheckCircle className="h-3 w-3" />
                      Upload complete
                    </div>
                  )}
                </div>
              )}
              
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </div>
            
            <FormMessage />
          </FormItem>
        )}
      />
    );
  };

  return (
    <div className="space-y-6">
      <Alert>
        <FileText className="h-4 w-4" />
        <AlertDescription>
          Please upload clear, high-quality images or PDFs of your documents. All required documents must be provided for verification.
        </AlertDescription>
      </Alert>

      <FileUploadField
        name="businessLicense"
        label="Business License (Optional)"
        description="Upload your official business license or registration certificate"
      />

      <FileUploadField
        name="governmentId"
        label="Government ID"
        description="Upload a valid government-issued ID (Aadhaar, PAN, Passport, etc.)"
        required
      />

      <FileUploadField
        name="businessCertificate"
        label="Business Certificate (Optional)"
        description="Upload your incorporation certificate or business formation document"
      />

      <FileUploadField
        name="insuranceCertificate"
        label="Insurance Certificate (Optional)"
        description="Upload your business insurance certificate if available"
      />

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          <strong>Document Requirements:</strong>
          <ul className="mt-2 space-y-1 text-xs">
            <li>• All documents must be clearly visible and readable</li>
            <li>• File size should not exceed 5MB per document</li>
            <li>• Accepted formats: PDF, JPG, PNG</li>
            <li>• Documents should be current and not expired</li>
          </ul>
        </AlertDescription>
      </Alert>
    </div>
  );
};