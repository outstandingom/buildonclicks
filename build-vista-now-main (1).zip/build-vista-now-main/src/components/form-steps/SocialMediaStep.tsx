
import React, { useState } from 'react';
import { UseFormReturn } from 'react-hook-form';
import { FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Plus, X, Linkedin, Facebook, Instagram, Link as LinkIcon } from 'lucide-react';

interface SocialMediaStepProps {
  form: UseFormReturn<any>;
}

export const SocialMediaStep: React.FC<SocialMediaStepProps> = ({ form }) => {
  const { control, setValue, watch } = form;
  const [otherLinks, setOtherLinks] = useState<string[]>(watch('otherLinks') || ['']);

  const addOtherLink = () => {
    const newLinks = [...otherLinks, ''];
    setOtherLinks(newLinks);
    setValue('otherLinks', newLinks);
  };

  const removeOtherLink = (index: number) => {
    const newLinks = otherLinks.filter((_, i) => i !== index);
    setOtherLinks(newLinks);
    setValue('otherLinks', newLinks);
  };

  const updateOtherLink = (index: number, value: string) => {
    const newLinks = [...otherLinks];
    newLinks[index] = value;
    setOtherLinks(newLinks);
    setValue('otherLinks', newLinks);
  };

  return (
    <div className="space-y-6">
      <div className="bg-amber-50 p-4 rounded-lg">
        <h3 className="font-medium text-construction-secondary mb-2">
          Optional: Social Media Presence
        </h3>
        <p className="text-sm text-construction-neutral">
          Adding your social media profiles helps build trust with potential clients. 
          You can skip this step and add them later from your dashboard.
        </p>
      </div>

      <FormField
        control={control}
        name="linkedinProfile"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              <Linkedin className="w-4 h-4 text-blue-600" />
              LinkedIn Profile
            </FormLabel>
            <FormControl>
              <Input
                placeholder="https://linkedin.com/in/your-profile"
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="facebookPage"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              <Facebook className="w-4 h-4 text-blue-600" />
              Facebook Business Page
            </FormLabel>
            <FormControl>
              <Input
                placeholder="https://facebook.com/your-business-page"
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <FormField
        control={control}
        name="instagramHandle"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              <Instagram className="w-4 h-4 text-pink-600" />
              Instagram Handle
            </FormLabel>
            <FormControl>
              <Input
                placeholder="@your_business_handle"
                {...field}
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <FormLabel className="flex items-center gap-2">
            <LinkIcon className="w-4 h-4 text-construction-primary" />
            Other Links
          </FormLabel>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addOtherLink}
            className="flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Link
          </Button>
        </div>

        {otherLinks.map((link, index) => (
          <div key={index} className="flex gap-2">
            <Input
              placeholder="https://your-website.com"
              value={link}
              onChange={(e) => updateOtherLink(index, e.target.value)}
              className="flex-1"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => removeOtherLink(index)}
              className="px-3"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        ))}
      </div>

      <div className="bg-green-50 p-4 rounded-lg">
        <h3 className="font-medium text-construction-secondary mb-2">
          Why add social media?
        </h3>
        <ul className="text-sm text-construction-neutral space-y-1">
          <li>• Increases trust and credibility with clients</li>
          <li>• Shows your work portfolio and past projects</li>
          <li>• Helps clients get to know your business better</li>
          <li>• Improves your visibility in search results</li>
        </ul>
      </div>
    </div>
  );
};
