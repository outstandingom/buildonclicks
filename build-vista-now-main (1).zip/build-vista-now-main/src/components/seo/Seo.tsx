import React from 'react';
import { Helmet } from 'react-helmet-async';
import { SeoProps } from '../../types/seo';
import { SEO_CONFIG } from '../../utils/seo-config';

const Seo: React.FC<SeoProps> = ({
  title,
  description,
  keywords,
  canonical,
  ogImage,
  twitterCard,
  noindex = false,
  structuredData
}) => {
  const fullTitle = title 
    ? `${title} | ${SEO_CONFIG.site.name}` 
    : SEO_CONFIG.site.name;
  
  const fullCanonical = canonical 
    ? `${SEO_CONFIG.site.url}${canonical}` 
    : SEO_CONFIG.site.url;
  
  const fullOgImage = ogImage 
    ? `${SEO_CONFIG.site.url}${ogImage}` 
    : `${SEO_CONFIG.site.url}${SEO_CONFIG.defaults.ogImage}`;

  const metaDescription = description || SEO_CONFIG.defaults.description;
  const metaKeywords = keywords || SEO_CONFIG.defaults.keywords;

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={metaDescription} />
      <meta name="keywords" content={metaKeywords} />
      <meta name="robots" content={noindex ? 'noindex, nofollow' : 'index, follow'} />
      
      {/* Canonical */}
      <link rel="canonical" href={fullCanonical} />
      
      {/* Open Graph */}
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={metaDescription} />
      <meta property="og:type" content="website" />
      <meta property="og:url" content={fullCanonical} />
      <meta property="og:image" content={fullOgImage} />
      <meta property="og:site_name" content={SEO_CONFIG.site.name} />
      
      {/* Twitter Card */}
      <meta name="twitter:card" content={twitterCard || SEO_CONFIG.defaults.twitterCard} />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={metaDescription} />
      <meta name="twitter:image" content={fullOgImage} />
      {SEO_CONFIG.site.twitterHandle && (
        <meta name="twitter:site" content={SEO_CONFIG.site.twitterHandle} />
      )}
      
      {/* Structured Data */}
      {structuredData && (
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      )}
    </Helmet>
  );
};

export default Seo;
