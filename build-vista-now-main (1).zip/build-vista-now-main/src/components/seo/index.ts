export { default as Seo } from './Seo';
