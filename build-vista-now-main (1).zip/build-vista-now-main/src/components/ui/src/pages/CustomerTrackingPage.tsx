import React, { useState, useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet-async';
import { 
  Search, 
  Phone, 
  MessageCircle, 
  Plus, 
  Edit, 
  Trash2, 
  Filter, 
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
  User,
  Smartphone,
  FileText,
  Building,
  ChevronDown,
  ChevronUp,
  Download
} from 'lucide-react';
import { motion } from 'framer-motion';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { DatePicker } from '@/components/ui/date-picker';

interface Customer {
  id: string;
  name: string;
  mobile_number: string;
  notes: string;
  registered: boolean;
  business_category: string;
  follow_up_date: string | null;
  created_at: string;
  updated_at: string;
  status: string;
  last_contact_date: string | null;
  call_count: number;
  whatsapp_sent: boolean;
}

interface CustomerFormData {
  name: string;
  mobile_number: string;
  notes: string;
  registered: boolean;
  business_category: string;
  follow_up_date: Date | null;
  status: string;
}

const CustomerTrackingPage = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterRegistered, setFilterRegistered] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  
  // Modal states
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  
  // Form state
  const [formData, setFormData] = useState<CustomerFormData>({
    name: '',
    mobile_number: '',
    notes: '',
    registered: false,
    business_category: '',
    follow_up_date: null,
    status: 'new'
  });

  // Business categories
  const businessCategories = [
    { value: 'plumber', label: 'Plumber' },
    { value: 'contractor', label: 'Contractor' },
    { value: 'engineer', label: 'Engineer' },
    { value: 'architect', label: 'Architect' },
    { value: 'manufacturer', label: 'Manufacturer' },
    { value: 'vendor', label: 'Vendor' },
    { value: 'other', label: 'Other' }
  ];

  // Status options
  const statusOptions = [
    { value: 'new', label: 'New', color: 'bg-blue-100 text-blue-800' },
    { value: 'contacted', label: 'Contacted', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'interested', label: 'Interested', color: 'bg-green-100 text-green-800' },
    { value: 'not_interested', label: 'Not Interested', color: 'bg-red-100 text-red-800' },
    { value: 'registered', label: 'Registered', color: 'bg-emerald-100 text-emerald-800' },
    { value: 'follow_up', label: 'Follow Up', color: 'bg-purple-100 text-purple-800' },
    { value: 'wrong_number', label: 'Wrong Number', color: 'bg-gray-100 text-gray-800' }
  ];

  // Fetch customers
  const fetchCustomers = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('customer_tracking')
        .select('*')
        .order(sortBy, { ascending: sortOrder === 'asc' });

      if (error) throw error;
      
      setCustomers(data || []);
    } catch (error) {
      console.error('Error fetching customers:', error);
      toast.error('Failed to load customers');
    } finally {
      setLoading(false);
    }
  };

  // Load customers on mount
  useEffect(() => {
    fetchCustomers();
  }, [sortBy, sortOrder]);

  // Filter customers based on search and filters
  const filteredCustomers = customers.filter(customer => {
    // Search filter
    const matchesSearch = searchTerm === '' || 
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.mobile_number.includes(searchTerm) ||
      customer.notes.toLowerCase().includes(searchTerm.toLowerCase());

    // Status filter
    const matchesStatus = filterStatus === 'all' || customer.status === filterStatus;
    
    // Category filter
    const matchesCategory = filterCategory === 'all' || customer.business_category === filterCategory;
    
    // Registered filter
    const matchesRegistered = filterRegistered === 'all' || 
      (filterRegistered === 'yes' && customer.registered) ||
      (filterRegistered === 'no' && !customer.registered);

    return matchesSearch && matchesStatus && matchesCategory && matchesRegistered;
  });

  // Handle form input changes
  const handleInputChange = (field: keyof CustomerFormData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: '',
      mobile_number: '',
      notes: '',
      registered: false,
      business_category: '',
      follow_up_date: null,
      status: 'new'
    });
  };

  // Add new customer
  const handleAddCustomer = async () => {
    if (!formData.name.trim() || !formData.mobile_number.trim()) {
      toast.error('Name and mobile number are required');
      return;
    }

    try {
      const { data, error } = await supabase
        .from('customer_tracking')
        .insert([{
          name: formData.name.trim(),
          mobile_number: formData.mobile_number.trim(),
          notes: formData.notes.trim(),
          registered: formData.registered,
          business_category: formData.business_category,
          follow_up_date: formData.follow_up_date,
          status: formData.status,
          last_contact_date: new Date().toISOString(),
          call_count: 1,
          whatsapp_sent: false
        }])
        .select()
        .single();

      if (error) throw error;

      toast.success('Customer added successfully');
      setAddModalOpen(false);
      resetForm();
      fetchCustomers();
    } catch (error) {
      console.error('Error adding customer:', error);
      toast.error('Failed to add customer');
    }
  };

  // Edit customer
  const handleEditCustomer = async () => {
    if (!selectedCustomer) return;

    try {
      const { error } = await supabase
        .from('customer_tracking')
        .update({
          name: formData.name.trim(),
          mobile_number: formData.mobile_number.trim(),
          notes: formData.notes.trim(),
          registered: formData.registered,
          business_category: formData.business_category,
          follow_up_date: formData.follow_up_date,
          status: formData.status,
          updated_at: new Date().toISOString()
        })
        .eq('id', selectedCustomer.id);

      if (error) throw error;

      toast.success('Customer updated successfully');
      setEditModalOpen(false);
      resetForm();
      fetchCustomers();
    } catch (error) {
      console.error('Error updating customer:', error);
      toast.error('Failed to update customer');
    }
  };

  // Delete customer
  const handleDeleteCustomer = async (id: string) => {
    if (!confirm('Are you sure you want to delete this customer?')) return;

    try {
      const { error } = await supabase
        .from('customer_tracking')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast.success('Customer deleted successfully');
      fetchCustomers();
    } catch (error) {
      console.error('Error deleting customer:', error);
      toast.error('Failed to delete customer');
    }
  };

  // Update call count
  const handleCallCustomer = async (customer: Customer) => {
    try {
      const { error } = await supabase
        .from('customer_tracking')
        .update({
          call_count: customer.call_count + 1,
          last_contact_date: new Date().toISOString(),
          status: 'contacted'
        })
        .eq('id', customer.id);

      if (error) throw error;

      toast.success('Call recorded');
      fetchCustomers();
    } catch (error) {
      console.error('Error updating call count:', error);
      toast.error('Failed to update call record');
    }
  };

  // Open WhatsApp
  const handleWhatsAppCustomer = (mobileNumber: string) => {
    const cleanedNumber = mobileNumber.replace(/\D/g, '');
    window.open(`https://wa.me/${cleanedNumber}`, '_blank');
    
    // Update WhatsApp sent status
    const updateWhatsAppStatus = async (customerId: string) => {
      try {
        await supabase
          .from('customer_tracking')
          .update({ whatsapp_sent: true })
          .eq('id', customerId);
        fetchCustomers();
      } catch (error) {
        console.error('Error updating WhatsApp status:', error);
      }
    };

    const customer = customers.find(c => c.mobile_number === mobileNumber);
    if (customer) {
      updateWhatsAppStatus(customer.id);
    }
  };

  // Open edit modal
  const openEditModal = (customer: Customer) => {
    setSelectedCustomer(customer);
    setFormData({
      name: customer.name,
      mobile_number: customer.mobile_number,
      notes: customer.notes,
      registered: customer.registered,
      business_category: customer.business_category || '',
      follow_up_date: customer.follow_up_date ? new Date(customer.follow_up_date) : null,
      status: customer.status
    });
    setEditModalOpen(true);
  };

  // Format date
  const formatDate = (dateString: string | null) => {
    if (!dateString) return '-';
    return format(new Date(dateString), 'dd/MM/yyyy HH:mm');
  };

  // Get status badge
  const getStatusBadge = (status: string) => {
    const statusOption = statusOptions.find(s => s.value === status);
    if (!statusOption) return null;
    
    return (
      <Badge className={`${statusOption.color} border-0`}>
        {statusOption.label}
      </Badge>
    );
  };

  // Get category badge
  const getCategoryBadge = (category: string) => {
    const categoryOption = businessCategories.find(c => c.value === category);
    return (
      <Badge variant="outline" className="capitalize">
        {categoryOption?.label || category}
      </Badge>
    );
  };

  // Export to CSV
  const exportToCSV = () => {
    const headers = ['Name', 'Mobile Number', 'Notes', 'Registered', 'Business Category', 'Status', 'Follow Up Date', 'Created At', 'Call Count', 'Last Contact'];
    
    const csvContent = [
      headers.join(','),
      ...filteredCustomers.map(customer => [
        `"${customer.name}"`,
        `"${customer.mobile_number}"`,
        `"${customer.notes}"`,
        customer.registered ? 'Yes' : 'No',
        `"${customer.business_category || ''}"`,
        `"${customer.status}"`,
        `"${customer.follow_up_date ? formatDate(customer.follow_up_date) : ''}"`,
        `"${formatDate(customer.created_at)}"`,
        customer.call_count,
        `"${customer.last_contact_date ? formatDate(customer.last_contact_date) : ''}"`
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `customer_tracking_${format(new Date(), 'dd-MM-yyyy')}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  // Stats
  const totalCustomers = customers.length;
  const registeredCustomers = customers.filter(c => c.registered).length;
  const followUpNeeded = customers.filter(c => c.status === 'follow_up').length;
  const interestedCustomers = customers.filter(c => c.status === 'interested').length;

  return (
    <>
      <Helmet>
        <title>Customer Tracking | BuildOnClicks</title>
        <meta name="description" content="Track customer registration process and daily follow-ups" />
      </Helmet>

      <Header />

      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">
                  Customer Registration Tracking
                </h1>
                <p className="text-gray-600">
                  Track and manage customer registration process with daily follow-ups
                </p>
              </div>
              
              <div className="flex flex-wrap gap-3">
                <Button 
                  variant="outline" 
                  onClick={exportToCSV}
                  className="flex items-center gap-2"
                >
                  <Download className="h-4 w-4" />
                  Export CSV
                </Button>
                
                <Dialog open={addModalOpen} onOpenChange={setAddModalOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2 bg-construction-primary hover:bg-construction-primary/90">
                      <Plus className="h-4 w-4" />
                      Add Customer
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Add New Customer</DialogTitle>
                      <DialogDescription>
                        Enter customer details for tracking registration process
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Customer Name *</label>
                        <Input
                          value={formData.name}
                          onChange={(e) => handleInputChange('name', e.target.value)}
                          placeholder="Enter full name"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Mobile Number *</label>
                        <Input
                          value={formData.mobile_number}
                          onChange={(e) => handleInputChange('mobile_number', e.target.value)}
                          placeholder="Enter 10-digit mobile number"
                          type="tel"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Business Category</label>
                        <Select
                          value={formData.business_category}
                          onValueChange={(value) => handleInputChange('business_category', value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="">None</SelectItem>
                            {businessCategories.map(category => (
                              <SelectItem key={category.value} value={category.value}>
                                {category.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Notes</label>
                        <Textarea
                          value={formData.notes}
                          onChange={(e) => handleInputChange('notes', e.target.value)}
                          placeholder="Enter conversation notes, responses, or follow-up details"
                          rows={3}
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Status</label>
                          <Select
                            value={formData.status}
                            onValueChange={(value) => handleInputChange('status', value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                            <SelectContent>
                              {statusOptions.map(status => (
                                <SelectItem key={status.value} value={status.value}>
                                  {status.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Registered?</label>
                          <Select
                            value={formData.registered ? 'yes' : 'no'}
                            onValueChange={(value) => handleInputChange('registered', value === 'yes')}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="yes">Yes</SelectItem>
                              <SelectItem value="no">No</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Follow-up Date</label>
                        <DatePicker
                          date={formData.follow_up_date}
                          setDate={(date) => handleInputChange('follow_up_date', date)}
                        />
                      </div>
                    </div>
                    
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setAddModalOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAddCustomer}>
                        Add Customer
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Customers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalCustomers}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Registered</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{registeredCustomers}</div>
                  <p className="text-xs text-gray-500 mt-1">{Math.round((registeredCustomers / totalCustomers) * 100) || 0}% conversion</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Follow-up Needed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-yellow-600">{followUpNeeded}</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-gray-600">Interested</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{interestedCustomers}</div>
                </CardContent>
              </Card>
            </div>

            {/* Filters and Search */}
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Search</label>
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search by name, mobile, notes..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">Status</label>
                    <Select value={filterStatus} onValueChange={setFilterStatus}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        {statusOptions.map(status => (
                          <SelectItem key={status.value} value={status.value}>
                            {status.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">Category</label>
                    <Select value={filterCategory} onValueChange={setFilterCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {businessCategories.map(category => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">Registered</label>
                    <Select value={filterRegistered} onValueChange={setFilterRegistered}>
                      <SelectTrigger>
                        <SelectValue placeholder="All" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Customers Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>Customer List ({filteredCustomers.length})</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-normal text-gray-500">Sort by:</span>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm" className="gap-2">
                        {sortBy === 'created_at' ? 'Date Added' : 
                         sortBy === 'name' ? 'Name' : 'Last Contact'}
                        {sortOrder === 'desc' ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => { setSortBy('created_at'); setSortOrder('desc'); }}>
                        Date Added (Newest First)
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => { setSortBy('created_at'); setSortOrder('asc'); }}>
                        Date Added (Oldest First)
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => { setSortBy('name'); setSortOrder('asc'); }}>
                        Name (A-Z)
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => { setSortBy('name'); setSortOrder('desc'); }}>
                        Name (Z-A)
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => { setSortBy('last_contact_date'); setSortOrder('desc'); }}>
                        Last Contact (Recent First)
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                  <p className="mt-2 text-gray-500">Loading customers...</p>
                </div>
              ) : filteredCustomers.length === 0 ? (
                <div className="text-center py-12">
                  <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No customers found</h3>
                  <p className="text-gray-500 mb-4">
                    {searchTerm || filterStatus !== 'all' || filterCategory !== 'all' || filterRegistered !== 'all'
                      ? 'Try changing your filters or search term'
                      : 'Start by adding your first customer'}
                  </p>
                  <Button onClick={() => setAddModalOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Customer
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Mobile</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Notes</TableHead>
                        <TableHead>Registered</TableHead>
                        <TableHead>Follow Up</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredCustomers.map((customer) => (
                        <TableRow key={customer.id}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              <User className="h-4 w-4 text-gray-400" />
                              {customer.name}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Smartphone className="h-4 w-4 text-gray-400" />
                              <span className="font-mono">{customer.mobile_number}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {getCategoryBadge(customer.business_category)}
                          </TableCell>
                          <TableCell>
                            {getStatusBadge(customer.status)}
                            {customer.call_count > 0 && (
                              <span className="text-xs text-gray-500 block mt-1">
                                {customer.call_count} call(s)
                              </span>
                            )}
                          </TableCell>
                          <TableCell className="max-w-xs">
                            <div className="truncate" title={customer.notes}>
                              {customer.notes || '-'}
                            </div>
                          </TableCell>
                          <TableCell>
                            {customer.registered ? (
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            ) : (
                              <XCircle className="h-5 w-5 text-red-500" />
                            )}
                          </TableCell>
                          <TableCell>
                            {customer.follow_up_date ? (
                              <div className="flex items-center gap-1">
                                <Calendar className="h-4 w-4 text-gray-400" />
                                {formatDate(customer.follow_up_date)}
                              </div>
                            ) : '-'}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleCallCustomer(customer)}
                                className="h-8 w-8 p-0"
                                title="Call Customer"
                              >
                                <Phone className="h-4 w-4" />
                              </Button>
                              
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleWhatsAppCustomer(customer.mobile_number)}
                                className={`h-8 w-8 p-0 ${customer.whatsapp_sent ? 'bg-green-50 border-green-200' : ''}`}
                                title="Send WhatsApp"
                              >
                                <MessageCircle className="h-4 w-4" />
                              </Button>
                              
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => openEditModal(customer)}
                                className="h-8 w-8 p-0"
                                title="Edit"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDeleteCustomer(customer.id)}
                                className="h-8 w-8 p-0"
                                title="Delete"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Edit Customer Modal */}
      <Dialog open={editModalOpen} onOpenChange={setEditModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Customer</DialogTitle>
            <DialogDescription>
              Update customer details and registration status
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Customer Name *</label>
              <Input
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="Enter full name"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Mobile Number *</label>
              <Input
                value={formData.mobile_number}
                onChange={(e) => handleInputChange('mobile_number', e.target.value)}
                placeholder="Enter 10-digit mobile number"
                type="tel"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Business Category</label>
              <Select
                value={formData.business_category}
                onValueChange={(value) => handleInputChange('business_category', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">None</SelectItem>
                  {businessCategories.map(category => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Notes</label>
              <Textarea
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
                placeholder="Enter conversation notes, responses, or follow-up details"
                rows={3}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Status</label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => handleInputChange('status', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map(status => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Registered?</label>
                <Select
                  value={formData.registered ? 'yes' : 'no'}
                  onValueChange={(value) => handleInputChange('registered', value === 'yes')}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="yes">Yes</SelectItem>
                    <SelectItem value="no">No</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Follow-up Date</label>
              <DatePicker
                date={formData.follow_up_date}
                setDate={(date) => handleInputChange('follow_up_date', date)}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setEditModalOpen(false);
              resetForm();
            }}>
              Cancel
            </Button>
            <Button onClick={handleEditCustomer}>
              Update Customer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
    </>
  );
};

export default CustomerTrackingPage;
