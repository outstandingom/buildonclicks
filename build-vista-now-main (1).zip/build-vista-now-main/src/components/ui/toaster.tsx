import { useToast } from "@/hooks/use-toast"
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "@/components/ui/toast"

export function Toaster() {
  const { toasts } = useToast()

  return (
    <ToastProvider>
      {toasts.map(function ({ id, title, description, action, ...props }) {
        return (
          <Toast key={id} {...props} className="fixed top-4 left-1/2 transform -translate-x-1/2 z-[100] w-96 max-w-[90vw] bg-gradient-card/98 border border-border/30 shadow-toast-glow backdrop-blur-xl rounded-xl">
            <div className="grid gap-2 p-1">
              {title && <ToastTitle className="text-sm font-semibold text-foreground/90">{title}</ToastTitle>}
              {description && (
                <ToastDescription className="text-sm text-muted-foreground leading-relaxed">{description}</ToastDescription>
              )}
            </div>
            {action}
            <ToastClose className="absolute top-2 right-2 opacity-70 hover:opacity-100 transition-opacity" />
          </Toast>
        )
      })}
      <ToastViewport className="fixed top-0 left-0 right-0 z-[100] flex flex-col-reverse p-4 sm:top-4 sm:right-auto sm:left-1/2 sm:transform sm:-translate-x-1/2 sm:flex-col md:max-w-[420px]" />
    </ToastProvider>
  )
}
