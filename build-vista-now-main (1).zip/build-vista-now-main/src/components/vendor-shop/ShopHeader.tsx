
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, MapPin, Clock, Phone, MessageCircle } from 'lucide-react';

interface ShopHeaderProps {
  shop: {
    id: string;
    shop_name: string;
    description: string;
    location: string;
    phone: string;
    rating: number;
    reviewCount: number;
    isOpen: boolean;
    working_hours: string;
    coverImage: string;
    logoUrl: string;
    categories: string[];
    min_order_value: number;
  };
}

const ShopHeader: React.FC<ShopHeaderProps> = ({ shop }) => {
  return (
    <Card className="overflow-hidden shadow-lg">
      {/* Cover Image */}
      <div className="relative h-48 md:h-64">
        <img 
          src={shop.coverImage} 
          alt={shop.shop_name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        
        {/* Shop Logo */}
        <div className="absolute bottom-4 left-4">
          <div className="w-16 h-16 md:w-20 md:h-20 rounded-full overflow-hidden border-4 border-white shadow-lg">
            <img 
              src={shop.logoUrl} 
              alt={`${shop.shop_name} logo`}
              className="w-full h-full object-contain"
            />
          </div>
        </div>
      </div>

      <CardContent className="p-6">
        {/* Shop Info */}
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-2xl md:text-3xl font-bold text-construction-secondary">
              {shop.shop_name}
            </h1>
            <div className="flex items-center gap-1">
              <div className={`w-3 h-3 rounded-full ${shop.isOpen ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className={`text-sm font-medium ${shop.isOpen ? 'text-green-600' : 'text-red-600'}`}>
                {shop.isOpen ? 'Open' : 'Closed'}
              </span>
            </div>
          </div>

          <p className="text-construction-neutral mb-4 leading-relaxed">
            {shop.description}
          </p>

          {/* Categories */}
          <div className="flex flex-wrap gap-2 mb-4">
            {shop.categories.map((category, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                {category}
              </Badge>
            ))}
          </div>

          {/* Shop Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="flex items-center gap-2 text-sm text-construction-neutral">
              <MapPin className="w-4 h-4" />
              <span>{shop.location}</span>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-construction-neutral">
              <Clock className="w-4 h-4" />
              <span>{shop.working_hours}</span>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-construction-neutral">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span>{shop.rating} ({shop.reviewCount} reviews)</span>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-construction-neutral">
              <span className="font-medium">Min. Order:</span>
              <span>₹{shop.min_order_value ? shop.min_order_value.toLocaleString() : '0'}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ShopHeader;
