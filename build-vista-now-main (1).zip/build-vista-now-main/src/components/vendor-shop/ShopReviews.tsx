
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Star, Plus } from 'lucide-react';

interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
  avatar: string;
}

interface ShopReviewsProps {
  reviews: Review[];
  shopRating: number;
  onWriteReview?: () => void;
}

const ShopReviews: React.FC<ShopReviewsProps> = ({ reviews, shopRating, onWriteReview }) => {
  const renderStars = (rating: number, size = 'w-4 h-4') => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`${size} ${
              star <= rating
                ? 'fill-yellow-400 text-yellow-400'
                : 'text-gray-300'
            }`}
          />
        ))}
      </div>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <CardTitle className="text-xl text-construction-secondary mb-2">
              Reviews & Ratings
            </CardTitle>
            <div className="flex items-center gap-2">
              {renderStars(shopRating, 'w-5 h-5')}
              <span className="text-lg font-semibold text-construction-secondary">
                {shopRating}
              </span>
              <span className="text-construction-neutral">
                ({reviews.length} reviews)
              </span>
            </div>
          </div>
          
          <Button 
            className="bg-construction-primary hover:bg-construction-primary/90"
            onClick={onWriteReview}
          >
            <Plus className="w-4 h-4 mr-2" />
            Write Review
          </Button>
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-6">
          {reviews.map(review => (
            <div key={review.id} className="border-b border-gray-200 pb-6 last:border-b-0 last:pb-0">
              <div className="flex items-start gap-4">
                <Avatar className="w-10 h-10">
                  <AvatarImage src={review.avatar} alt={review.userName} />
                  <AvatarFallback>
                    {review.userName.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <h4 className="font-semibold text-construction-secondary">
                        {review.userName}
                      </h4>
                      {renderStars(review.rating)}
                    </div>
                    <span className="text-sm text-construction-neutral">
                      {formatDate(review.date)}
                    </span>
                  </div>
                  
                  <p className="text-construction-neutral leading-relaxed">
                    {review.comment}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {reviews.length === 0 && (
          <div className="text-center py-12 text-construction-neutral">
            <p className="text-lg mb-4">No reviews yet</p>
            <Button 
              className="bg-construction-primary hover:bg-construction-primary/90"
              onClick={onWriteReview}
            >
              Be the first to review
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ShopReviews;
