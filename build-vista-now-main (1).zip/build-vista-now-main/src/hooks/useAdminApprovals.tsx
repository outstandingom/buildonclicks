
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface PendingApproval {
  id: string;
  business_name: string;
  business_type: string;
  contact_name: string;
  email_address: string;
  phone_number: string;
  cities_served: string[];
  created_at: string;
  status: string;
  rejection_reason?: string;
}

export const useAdminApprovals = () => {
  const [approvals, setApprovals] = useState<PendingApproval[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchApprovals = async () => {
    try {
      const { data, error } = await supabase.rpc('get_pending_business_registrations');
      
      if (error) {
        console.error('Error fetching approvals:', error);
        toast({
          title: "Error",
          description: "Failed to load pending approvals.",
          variant: "destructive",
        });
        return;
      }

      setApprovals(data || []);
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRegistrationDetails = async (id: string) => {
    try {
      const { data, error } = await supabase.rpc('get_business_registration_details', {
        registration_id: id
      });

      if (error) {
        console.error('Error fetching registration details:', error);
        toast({
          title: "Error",
          description: "Failed to load registration details.",
          variant: "destructive",
        });
        return null;
      }

      return data;
    } catch (error) {
      console.error('Unexpected error:', error);
      return null;
    }
  };

  const getUserIdFromRegistration = async (id: string) => {
    try {
      const { data, error } = await supabase
        .from('business_registrations')
        .select('user_id')
        .eq('id', id)
        .single();

      if (error) {
        console.error('Error fetching user_id:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Unexpected error:', error);
      return null;
    }
  };

  const updateApprovalStatus = async (id: string, status: 'approved' | 'rejected', rejectionReason?: string) => {
    try {
      const { data, error } = await supabase.rpc('update_business_registration_status', {
        registration_id: id,
        new_status: status,
        rejection_reason_param: rejectionReason || null
      });

      // If rejection, add a notification with reason
      if (status === 'rejected' && rejectionReason) {
        // Get registration details to find user_id
        const registrationDetails = await getUserIdFromRegistration(id);
        if (registrationDetails) {
          // Create notification for the user
          const { error: notificationError } = await supabase.rpc('create_notification', {
            p_user_id: registrationDetails.user_id,
            p_title: 'Business Registration Rejected',
            p_message: `Your business registration has been rejected. Reason: ${rejectionReason}. You can reapply after addressing the issues.`,
            p_type: 'error'
          });
          
          if (notificationError) {
            console.error('Error creating notification:', notificationError);
          }
        }
      } else if (status === 'approved') {
        // Get registration details to find user_id for approval notification
        const registrationDetails = await getUserIdFromRegistration(id);
        if (registrationDetails) {
          // Create approval notification
          const { error: notificationError } = await supabase.rpc('create_notification', {
            p_user_id: registrationDetails.user_id,
            p_title: 'Business Registration Approved',
            p_message: 'Congratulations! Your business registration has been approved. You can now access all provider features.',
            p_type: 'success'
          });
          
          if (notificationError) {
            console.error('Error creating notification:', notificationError);
          }
        }
      }

      if (error) {
        console.error('Error updating approval status:', error);
        toast({
          title: "Error",
          description: "Failed to update approval status.",
          variant: "destructive",
        });
        return false;
      }

      toast({
        title: "Success",
        description: `Registration ${status} successfully.`,
      });

      // Refresh the list
      await fetchApprovals();
      return true;
    } catch (error) {
      console.error('Unexpected error:', error);
      return false;
    }
  };

  useEffect(() => {
    fetchApprovals();
  }, []);

  return {
    approvals,
    loading,
    updateApprovalStatus,
    getRegistrationDetails,
    refreshApprovals: fetchApprovals
  };
};
