
import { useState, useEffect, createContext, useContext } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: string;
}

interface AdminAuthContextType {
  admin: AdminUser | null;
  loading: boolean;
  sessionToken: string | null;
  login: (email: string, password: string) => Promise<{ error?: string }>;
  logout: () => Promise<void>;
}

const AdminAuthContext = createContext<AdminAuthContextType | undefined>(undefined);

export const AdminAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [admin, setAdmin] = useState<AdminUser | null>(null);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAdminSession();
  }, []);

  const checkAdminSession = async () => {
    try {
      // Get session token from localStorage
      const storedToken = localStorage.getItem('admin_session_token');
      
      if (!storedToken) {
        setAdmin(null);
        setSessionToken(null);
        setLoading(false);
        return;
      }
      
      // Verify session with the token
      const { data, error } = await supabase.functions.invoke('admin-auth', {
        body: { 
          action: 'verify',
          sessionToken: storedToken
        }
      });

      if (error || !data.success) {
        setAdmin(null);
        setSessionToken(null);
        localStorage.removeItem('admin_session_token');
      } else {
        setAdmin(data.admin);
        setSessionToken(storedToken);
      }
    } catch (error) {
      setAdmin(null);
      setSessionToken(null);
      localStorage.removeItem('admin_session_token');
    }

    setLoading(false);
  };

  const login = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-auth', {
        body: { 
          action: 'login',
          email,
          password 
        }
      });

      if (error || !data.success) {
        return { error: data?.error || 'Login failed' };
      }

      // Store session token in localStorage for subsequent requests
      const token = data.session_token;
      if (token) {
        localStorage.setItem('admin_session_token', token);
      }
      
      setAdmin(data.admin);
      setSessionToken(token || null);
      return {};
    } catch (error) {
      return { error: 'Login failed' };
    }
  };

  const logout = async () => {
    try {
      const storedToken = localStorage.getItem('admin_session_token');
      
      // Send logout request with token
      await supabase.functions.invoke('admin-auth', {
        body: { 
          action: 'logout',
          sessionToken: storedToken
        }
      });
    } catch (error) {
      // Silent error handling for logout
    }

    // Clear local state and storage
    setAdmin(null);
    setSessionToken(null);
    localStorage.removeItem('admin_session_token');
  };

  return (
    <AdminAuthContext.Provider value={{ admin, loading, sessionToken, login, logout }}>
      {children}
    </AdminAuthContext.Provider>
  );
};

export const useAdminAuth = () => {
  const context = useContext(AdminAuthContext);
  if (context === undefined) {
    throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  }
  return context;
};
