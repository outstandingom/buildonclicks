
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface DashboardStats {
  total_users: number;
  approved_vendors: number;
  pending_requests: number;
  total_posts: number;
}

interface RecentActivity {
  activity_type: string;
  user_name: string;
  created_at: string;
  description: string;
}

export const useAdminDashboard = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchDashboardStats = async () => {
    try {
      const { data, error } = await supabase.rpc('get_admin_dashboard_stats');
      
      if (error) {
        console.error('Error fetching dashboard stats:', error);
        toast({
          title: "Error",
          description: "Failed to load dashboard statistics.",
          variant: "destructive",
        });
        return;
      }

      if (data && data.length > 0) {
        setStats(data[0]);
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    }
  };

  const fetchRecentActivity = async () => {
    try {
      const { data, error } = await supabase.rpc('get_admin_recent_activity');
      
      if (error) {
        console.error('Error fetching recent activity:', error);
        toast({
          title: "Error",
          description: "Failed to load recent activity.",
          variant: "destructive",
        });
        return;
      }

      setRecentActivity(data || []);
    } catch (error) {
      console.error('Unexpected error:', error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchDashboardStats(), fetchRecentActivity()]);
      setLoading(false);
    };

    loadData();
  }, []);

  return {
    stats,
    recentActivity,
    loading,
    refreshData: async () => {
      setLoading(true);
      await Promise.all([fetchDashboardStats(), fetchRecentActivity()]);
      setLoading(false);
    }
  };
};
