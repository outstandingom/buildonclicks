import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface UserCreditHistory {
  user_name: string;
  total_credits: number;
  used_credits: number;
  available_credits: number;
  free_credits_given: boolean;
  subscription_count: number;
  last_access: string | null;
  access_logs: any;
}

interface SubscriptionAnalytics {
  total_active_subscriptions: number;
  total_revenue: number;
  monthly_revenue: number;
  popular_plan_name: string;
  popular_plan_count: number;
  avg_credits_per_user: number;
  total_credits_distributed: number;
  total_credits_used: number;
}

interface LeadAnalytics {
  requirement_id: string;
  requirement_title: string;
  total_views: number;
  total_contacts: number;
  unique_viewers: number;
  credits_consumed_total: number;
  requirement_created_at: string;
  last_accessed: string | null;
}

interface UserCreditSummary {
  user_id: string;
  user_name: string;
  user_type: string;
  total_credits: number;
  used_credits: number;
  available_credits: number;
  last_activity: string | null;
  subscription_status: string;
  created_at: string;
}

export const useAdminLeadCredits = () => {
  const [subscriptionAnalytics, setSubscriptionAnalytics] =
    useState<SubscriptionAnalytics | null>(null);

  const [leadAnalytics, setLeadAnalytics] = useState<LeadAnalytics[]>([]);
  const [usersSummary, setUsersSummary] = useState<UserCreditSummary[]>([]);
  const [loading, setLoading] = useState(true);

  const { toast } = useToast();

  /* ------------------ SUBSCRIPTION ANALYTICS ------------------ */
  const fetchSubscriptionAnalytics = async () => {
    try {
      const { data, error } = await supabase.rpc("get_subscription_analytics");

      if (error) {
        console.error("Subscription analytics error:", error);
        toast({
          title: "Error",
          description: "Failed to load subscription analytics.",
          variant: "destructive",
        });
        return;
      }

      setSubscriptionAnalytics(data?.[0] ?? null);
    } catch (error) {
      console.error("Unexpected error:", error);
    }
  };

  /* ------------------ LEAD ANALYTICS ------------------ */
  const fetchLeadAnalytics = async () => {
    try {
      const { data, error } = await supabase.rpc("get_lead_access_analytics");

      if (error) {
        console.error("Lead analytics error:", error);
        toast({
          title: "Error",
          description: "Failed to load lead analytics.",
          variant: "destructive",
        });
        return;
      }

      setLeadAnalytics(data ?? []);
    } catch (error) {
      console.error("Unexpected error:", error);
    }
  };

  /* ------------------ USERS SUMMARY ------------------ */
  const fetchUsersCreditSummary = async () => {
    try {
      const { data, error } = await supabase.rpc("get_users_credit_summary");

      if (error) {
        console.error("Users credit summary error:", error);
        toast({
          title: "Error",
          description: "Failed to load users credit summary.",
          variant: "destructive",
        });
        return;
      }

      setUsersSummary(data ?? []);
    } catch (error) {
      console.error("Unexpected error:", error);
    }
  };

  /* ------------------ SINGLE USER HISTORY ------------------ */
  const fetchUserCreditHistory = async (
    userId: string
  ): Promise<UserCreditHistory | null> => {
    try {
      const { data, error } = await supabase.rpc("get_user_credit_history", {
        p_user_id: userId,
      });

      if (error) {
        console.error("User credit history error:", error);
        toast({
          title: "Error",
          description: "Failed to load user credit history.",
          variant: "destructive",
        });
        return null;
      }

      return data?.[0] ?? null;
    } catch (error) {
      console.error("Unexpected error:", error);
      return null;
    }
  };

  /* ------------------ ADD CREDITS ------------------ */
  const addCreditsToUser = async (
    userId: string,
    credits: number,
    reason: string = "Admin allocation"
  ): Promise<boolean> => {
    try {
      const { data, error } = await supabase.rpc("admin_add_credits", {
        p_user_id: userId,
        p_credits: credits,
        p_reason: reason,
      });

      if (error) {
        console.error("Add credits error:", error);
        toast({
          title: "Error",
          description: "Failed to add credits to user.",
          variant: "destructive",
        });
        return false;
      }

      toast({
        title: "Success",
        description: `Successfully added ${credits} credits.`,
      });

      await fetchUsersCreditSummary();

      return !!data;
    } catch (error) {
      console.error("Unexpected error:", error);
      return false;
    }
  };

  /* ------------------ INITIAL LOAD ------------------ */
  useEffect(() => {
    const load = async () => {
      setLoading(true);
      await Promise.all([
        fetchSubscriptionAnalytics(),
        fetchLeadAnalytics(),
        fetchUsersCreditSummary(),
      ]);
      setLoading(false);
    };
    load();
  }, []);

  /* ------------------ REFRESH ------------------ */
  const refreshData = async () => {
    setLoading(true);
    await Promise.all([
      fetchSubscriptionAnalytics(),
      fetchLeadAnalytics(),
      fetchUsersCreditSummary(),
    ]);
    setLoading(false);
  };

  return {
    subscriptionAnalytics,
    leadAnalytics,
    usersSummary,
    loading,
    fetchUserCreditHistory,
    addCreditsToUser,
    refreshData,
  };
};
