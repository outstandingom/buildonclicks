
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface AdminSocialPost {
  id: string;
  content: string;
  media_url: string | null;
  media_type: string | null;
  user_name: string;
  created_at: string;
  status: string;
  likes_count: number;
  comments_count: number;
  admin_notes: string | null;
}

export const useAdminPosts = () => {
  const [posts, setPosts] = useState<AdminSocialPost[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchPosts = useCallback(async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.rpc('get_social_posts_for_moderation');
      
      if (error) {
        console.error('Error fetching posts:', error);
        toast({
          title: "Error",
          description: "Failed to load posts.",
          variant: "destructive",
        });
        return;
      }

      setPosts(data || []);
    } catch (error) {
      console.error('Unexpected error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const approvePost = async (postId: string) => {
    try {
      const { error } = await supabase.rpc('update_social_post_status', {
        p_post_id: postId,
        p_status: 'approved'
      });

      if (error) {
        console.error('Error approving post:', error);
        toast({
          title: "Error",
          description: "Failed to approve post.",
          variant: "destructive",
        });
        return false;
      }

      toast({
        title: "Success",
        description: "Post approved successfully.",
      });
      await fetchPosts();
      return true;
    } catch (error) {
      console.error('Unexpected error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
      return false;
    }
  };

  const removePost = async (postId: string) => {
    try {
      const { error } = await supabase.rpc('delete_social_post', {
        p_post_id: postId
      });

      if (error) {
        console.error('Error removing post:', error);
        toast({
          title: "Error",
          description: "Failed to remove post.",
          variant: "destructive",
        });
        return false;
      }

      toast({
        title: "Success",
        description: "Post removed successfully.",
      });
      await fetchPosts();
      return true;
    } catch (error) {
      console.error('Unexpected error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
      return false;
    }
  };

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts]);

  return {
    posts,
    loading,
    refreshPosts: fetchPosts,
    approvePost,
    removePost
  };
};
