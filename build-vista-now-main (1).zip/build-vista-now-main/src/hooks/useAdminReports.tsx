import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface AdminReport {
  id: string;
  reporter_name: string;
  reported_user_name: string;
  content_type: 'post' | 'comment' | 'profile' | 'shop' | 'portfolio';
  content_id: string;
  reason: 'spam' | 'harassment' | 'inappropriate_content' | 'fake_profile' | 'scam' | 'copyright' | 'other';
  description: string;
  status: 'open' | 'investigating' | 'resolved' | 'dismissed';
  priority: 'low' | 'medium' | 'high';
  admin_notes: string | null;
  resolved_by_name: string | null;
  resolved_at: string | null;
  created_at: string;
  reporter_id: string;
  reported_user_id: string;
}

export const useAdminReports = () => {
  const [reports, setReports] = useState<AdminReport[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchReports = async (status?: string, priority?: string) => {
    try {
      setLoading(true);
      const { data, error } = await supabase.rpc('get_admin_reports', {
        p_status: status || null,
        p_priority: priority || null
      });

      if (error) throw error;
      setReports(data || []);
    } catch (error) {
      console.error('Error fetching reports:', error);
      toast({
        title: "Error",
        description: "Failed to load reports",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateReportStatus = async (
    reportId: string, 
    status: 'investigating' | 'resolved' | 'dismissed',
    adminNotes?: string
  ) => {
    try {
      const { error } = await supabase
        .from('user_reports')
        .update({ 
          status,
          admin_notes: adminNotes,
          resolved_at: status !== 'investigating' ? new Date().toISOString() : null
        })
        .eq('id', reportId);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Report ${status}`,
      });

      fetchReports();
    } catch (error) {
      console.error('Error updating report:', error);
      toast({
        title: "Error",
        description: "Failed to update report",
        variant: "destructive",
      });
    }
  };

  const warnUser = async (
    reportId: string,
    userId: string,
    reason: string,
    severity: 'low' | 'medium' | 'high'
  ) => {
    try {
      // Get admin session
      const adminSession = localStorage.getItem('admin_session');
      if (!adminSession) {
        throw new Error('Admin session not found');
      }

      const { data: sessionData } = await supabase.rpc('verify_admin_session', {
        p_session_token: adminSession
      });

      if (!sessionData || sessionData.length === 0) {
        throw new Error('Invalid admin session');
      }

      const adminId = sessionData[0].admin_id;

      // Insert warning
      const { error: warningError } = await supabase
        .from('user_warnings')
        .insert({
          user_id: userId,
          admin_id: adminId,
          report_id: reportId,
          reason,
          severity,
          message: `You have received a ${severity} warning: ${reason}`
        });

      if (warningError) throw warningError;

      // Create notification
      await supabase.rpc('create_notification', {
        p_user_id: userId,
        p_title: 'Account Warning',
        p_message: `Your account has received a ${severity} warning. Reason: ${reason}`,
        p_type: 'warning'
      });

      // Update report status
      await updateReportStatus(reportId, 'resolved', `User warned with ${severity} severity`);

      toast({
        title: "Success",
        description: "User warned successfully",
      });
    } catch (error) {
      console.error('Error warning user:', error);
      toast({
        title: "Error",
        description: "Failed to warn user",
        variant: "destructive",
      });
    }
  };

  const banUser = async (
    reportId: string,
    userId: string,
    reason: string,
    banType: 'temporary' | 'permanent',
    expiresAt?: string
  ) => {
    try {
      // Get admin session
      const adminSession = localStorage.getItem('admin_session');
      if (!adminSession) {
        throw new Error('Admin session not found');
      }

      const { data: sessionData } = await supabase.rpc('verify_admin_session', {
        p_session_token: adminSession
      });

      if (!sessionData || sessionData.length === 0) {
        throw new Error('Invalid admin session');
      }

      const adminId = sessionData[0].admin_id;

      // Insert ban
      const { error: banError } = await supabase
        .from('user_bans')
        .insert({
          user_id: userId,
          admin_id: adminId,
          report_id: reportId,
          reason,
          ban_type: banType,
          expires_at: expiresAt || null
        });

      if (banError) throw banError;

      // Create notification
      await supabase.rpc('create_notification', {
        p_user_id: userId,
        p_title: 'Account Suspended',
        p_message: `Your account has been ${banType === 'permanent' ? 'permanently' : 'temporarily'} suspended. Reason: ${reason}`,
        p_type: 'ban'
      });

      // Update report status
      await updateReportStatus(reportId, 'resolved', `User banned (${banType})`);

      toast({
        title: "Success",
        description: "User banned successfully",
      });
    } catch (error) {
      console.error('Error banning user:', error);
      toast({
        title: "Error",
        description: "Failed to ban user",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  return {
    reports,
    loading,
    fetchReports,
    updateReportStatus,
    warnUser,
    banUser,
  };
};
