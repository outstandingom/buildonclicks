
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface AdminUser {
  id: string;
  full_name: string;
  user_type: string;
  created_at: string;
  city_name: string;
  is_active: boolean;
  email: string | null;
  is_verified: boolean;
  registration_status: string | null;
  business_category: string | null;
}

export const useAdminUsers = () => {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchUsers = useCallback(async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.rpc('get_users_for_admin');
      
      if (error) {
        console.error('Error fetching users:', error);
        toast({
          title: "Error",
          description: "Failed to load users.",
          variant: "destructive",
        });
        return;
      }

      setUsers(
        (data || []).map((u) => ({
          ...u,
          email: (u as any).email ?? null,
          is_verified: Boolean((u as any).is_verified),
          registration_status: (u as any).registration_status ?? null,
          business_category: (u as any).business_category ?? null,
        }))
      );
    } catch (error) {
      console.error('Unexpected error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const updateUserStatus = useCallback(async (userId: string, isActive: boolean) => {
    try {
      const { error } = await supabase.rpc('update_user_active_status' as any, {
        p_user_id: userId,
        p_is_active: isActive
      });

      if (error) {
        console.error('Error updating user status:', error);
        toast({
          title: "Error",
          description: "Failed to update user status.",
          variant: "destructive",
        });
        return false;
      }

      toast({
        title: "Success",
        description: `User ${isActive ? 'activated' : 'suspended'} successfully.`,
      });

      await fetchUsers();
      return true;
    } catch (error) {
      console.error('Unexpected error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
      return false;
    }
  }, [toast, fetchUsers]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const resetAccess = useCallback(async (email: string | null) => {
    if (!email) {
      toast({
        title: "Missing email",
        description: "Cannot reset access: user email not available.",
        variant: "destructive",
      });
      return false;
    }

    try {
      const redirectUrl = `${window.location.origin}/reset-password`;
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: redirectUrl,
      });

      if (error) {
        console.error('Error resetting access:', error);
        toast({
          title: "Error",
          description: "Failed to send reset email.",
          variant: "destructive",
        });
        return false;
      }

      toast({
        title: "Reset email sent",
        description: `Password reset link sent to ${email}.`,
      });
      return true;
    } catch (error) {
      console.error('Unexpected error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
      return false;
    }
  }, [toast]);

  return {
    users,
    loading,
    refreshUsers: fetchUsers,
    activateUser: (userId: string) => updateUserStatus(userId, true),
    suspendUser: (userId: string) => updateUserStatus(userId, false),
    resetAccess,
  };
};
