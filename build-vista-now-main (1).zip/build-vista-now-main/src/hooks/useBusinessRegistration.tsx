
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface BusinessRegistrationData {
  businessName: string;
  businessType: string;
  subBusinessType: string[]; // Fixed: should be array
  registrationNumber: string;
  vatGstNumber?: string;
  website?: string;
  businessLicense?: FileList;
  businessAddress: string;
  citiesServed: string[];
  yearsInBusiness: number;
  aboutServices: string;
  contactName: string;
  phoneNumber: string;
  emailAddress: string;
  alternateContact?: string;
  preferredCommunication: string[];
  linkedinProfile?: string;
  facebookPage?: string;
  instagramHandle?: string;
  otherLinks?: string[];
  governmentId: FileList;
  businessCertificate?: FileList;
  insuranceCertificate?: FileList;
  bankName: string;
  accountNumber: string;
  accountType: string;
  ifscCode?: string;
}

export interface BusinessType {
  id: string;
  name: string;
}

const isMissingDraftTable = (error: any) => {
  if (!error) return false;
  const msg = (error.message || '').toString().toLowerCase();
  return error.code === '42P01' || msg.includes('business_registration_drafts');
};

export const useBusinessRegistration = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const getUserId = async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw new Error('User not authenticated');
    return data.user.id;
  };

  const loadDraft = async () => {
    try {
      const userId = await getUserId();
      const { data, error } = await supabase
        .from('business_registration_drafts')
        .select('data, current_step')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) {
        if (isMissingDraftTable(error)) {
          console.warn('Draft table missing; run latest migrations.');
          return null;
        }
        console.error('Error loading draft:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error loading draft:', error);
      return null;
    }
  };

  const saveDraft = async (data: any, currentStep: number) => {
    try {
      const userId = await getUserId();
      const { error } = await supabase
        .from('business_registration_drafts')
        .upsert({
          user_id: userId,
          data,
          current_step: currentStep,
        }, { onConflict: 'user_id' });

      if (error) {
        if (isMissingDraftTable(error)) {
          console.warn("Draft table missing; skipping draft save. Run latest migrations to enable server drafts.");
          return;
        }
        console.error('Error saving draft:', error);
        throw error;
      }

      toast({
        title: "Progress Saved",
        description: "Your registration draft has been saved to your account.",
      });
    } catch (error) {
      console.error('Error saving draft:', error);
      toast({
        title: "Save Failed",
        description: "Could not save your progress. Please try again.",
        variant: "destructive",
      });
    }
  };

  const clearDraft = async () => {
    try {
      const userId = await getUserId();
      const { error } = await supabase
        .from('business_registration_drafts')
        .delete()
        .eq('user_id', userId);

      if (error) {
        if (isMissingDraftTable(error)) {
          return;
        }
        console.error('Error clearing draft:', error);
      }
    } catch (error) {
      console.error('Error clearing draft:', error);
    }
  };

  const submitRegistration = async (data: BusinessRegistrationData) => {
    setIsSubmitting(true);
    
    try {
      // Get current user
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      
      if (userError || !user) {
        throw new Error('User not authenticated');
      }

      // Get business type ID - business types should already exist
      const { data: businessTypeData, error: typeError } = await supabase
        .from('business_types')
        .select('id')
        .eq('name', data.businessType)
        .maybeSingle();

      if (typeError) {
        throw new Error('Error fetching business type');
      }

      if (!businessTypeData) {
        throw new Error(`Business type "${data.businessType}" not found. Please contact support.`);
      }

      const businessTypeId = businessTypeData.id;

      // Enhanced file upload with validation
      const uploadFile = async (file: File, bucket: string, path: string) => {
        // Validate file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
          throw new Error(`File ${file.name} is too large. Maximum size is 5MB.`);
        }

        // Validate file type
        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
        if (!allowedTypes.includes(file.type)) {
          throw new Error(`File ${file.name} has invalid type. Allowed: PDF, JPG, PNG.`);
        }

        const { data, error } = await supabase.storage
          .from(bucket)
          .upload(path, file, { 
            upsert: true,
            contentType: file.type
          });
        
        if (error) {
          console.error('Storage upload error:', error);
          throw new Error(`Failed to upload ${file.name}: ${error.message}`);
        }
        
        return data.path;
      };

      // Upload business documents
      const timestamp = Date.now();
      const userId = user.id;
      
      let businessLicenseUrl: string | null = null;
      let governmentIdUrl: string | null = null;
      let businessCertificateUrl: string | null = null;
      let insuranceCertificateUrl: string | null = null;

      try {
        if (data.businessLicense && data.businessLicense[0]) {
          const licenseFile = data.businessLicense[0];
          const licenseExtension = licenseFile.name.split('.').pop();
          businessLicenseUrl = await uploadFile(
            licenseFile, 
            'business-documents', 
            `${userId}/license_${timestamp}.${licenseExtension}`
          );
        }

        if (data.governmentId && data.governmentId[0]) {
          const govIdFile = data.governmentId[0];
          const govIdExtension = govIdFile.name.split('.').pop();
          governmentIdUrl = await uploadFile(
            govIdFile, 
            'business-documents', 
            `${userId}/gov_id_${timestamp}.${govIdExtension}`
          );
        }

        if (data.businessCertificate && data.businessCertificate[0]) {
          const certFile = data.businessCertificate[0];
          const certExtension = certFile.name.split('.').pop();
          businessCertificateUrl = await uploadFile(
            certFile, 
            'business-documents', 
            `${userId}/certificate_${timestamp}.${certExtension}`
          );
        }

        if (data.insuranceCertificate && data.insuranceCertificate[0]) {
          const insuranceFile = data.insuranceCertificate[0];
          const insuranceExtension = insuranceFile.name.split('.').pop();
          insuranceCertificateUrl = await uploadFile(
            insuranceFile, 
            'business-documents', 
            `${userId}/insurance_${timestamp}.${insuranceExtension}`
          );
        }
      } catch (uploadError) {
        console.error('File upload error:', uploadError);
        throw new Error(uploadError instanceof Error ? uploadError.message : 'Failed to upload documents. Please try again.');
      }

      // Validate required uploads
      if (!governmentIdUrl) {
        throw new Error('Government ID is required and must be uploaded.');
      }

      // Prepare business registration data
      const businessRegistration = {
        user_id: user.id,
        business_name: data.businessName,
        business_type_id: businessTypeId,
        sub_business_types: data.subBusinessType,
        registration_number: data.registrationNumber,
        vat_gst_number: data.vatGstNumber || null,
        website: data.website || null,
        business_license_url: businessLicenseUrl,
        business_address: data.businessAddress,
        cities_served: data.citiesServed,
        years_in_business: data.yearsInBusiness,
        about_services: data.aboutServices,
        contact_name: data.contactName,
        phone_number: data.phoneNumber,
        email_address: data.emailAddress,
        alternate_contact: data.alternateContact || null,
        preferred_communication: data.preferredCommunication.join(', '),
        linkedin_profile: data.linkedinProfile || null,
        facebook_page: data.facebookPage || null,
        instagram_handle: data.instagramHandle || null,
        other_links: data.otherLinks || null,
        government_id_url: governmentIdUrl,
        business_certificate_url: businessCertificateUrl,
        insurance_certificate_url: insuranceCertificateUrl,
        bank_name: data.bankName,
        account_number: data.accountNumber,
        account_type: data.accountType,
        ifsc_code: data.ifscCode || null,
      };

      // Insert business registration directly
      const { error: insertError } = await supabase
        .from('business_registrations')
        .insert([businessRegistration]);

      if (insertError) {
        throw insertError;
      }

      toast({
        title: "Registration Submitted Successfully!",
        description: "Your business registration has been submitted for review. We'll contact you within 48 hours.",
        variant: "default",
      });

      return true;
    } catch (error) {
      console.error('Error submitting business registration:', error);
      toast({
        title: "Submission Failed",
        description: error instanceof Error ? error.message : "There was an error submitting your registration. Please try again.",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  const getBusinessTypes = async (): Promise<BusinessType[]> => {
    try {
      // Get business types directly from table
      const { data, error } = await supabase
        .from('business_types')
        .select('id, name')
        .order('name');

      if (error) {
        console.error('Error fetching business types:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('Error fetching business types:', error);
      return [];
    }
  };

  return {
    submitRegistration,
    getBusinessTypes,
    loadDraft,
    saveDraft,
    clearDraft,
    isSubmitting,
  };
};
