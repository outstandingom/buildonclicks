import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface BusinessType {
  id: string;
  name: string;
}

export interface SubBusinessTypeMapping {
  [key: string]: string[];
}

export const useBusinessTypes = () => {
  const [businessTypes, setBusinessTypes] = useState<BusinessType[]>([]);
  const [subBusinessTypes, setSubBusinessTypes] = useState<SubBusinessTypeMapping>({});
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  // Database-synced sub-business types mapping
  const subBusinessTypeMappings: SubBusinessTypeMapping = {
    'Architects': [
      'Architect',
      'Landscape Architect',
      'Interior Architect'
    ],
    'Architecture Firm': [
      'Residential Architecture',
      'Commercial Architecture', 
      'Industrial Architecture',
      'Landscape Architecture Firm'
    ],
    'Designers': [
      'Interior Designer',
      'Landscape Designer',
      'Graphic Designer',
      'Product Designer',
      'Furniture Designer'
    ],
    'Engineers': [
      'Civil Engineer / Structural',
      'Geotechnical Engineer',
      'Site Engineer / Supervisor',
      'Land Surveyor',
      'Mechanical Engineer',
      'Electrical Engineer',
      'Civil Engineer',
      'Structural Engineer'
    ],
    'Engineering Services': [
      'Structural Engineering',
      'MEP Engineering',
      'Geotechnical Engineering',
      'Environmental Engineering'
    ],
    'Contractors': [
      'General contractor / Builders',
      'Government contractors',
      'Excavation contractor',
      'Shuttering / framework contractor',
      'Fall Ceiling / POP contractor',
      'Modular furniture contractor/installer',
      'Flooring contractor',
      'Waterproofing Specialist',
      'Fabricators',
      'Masons',
      'Tile Mason',
      'Steel fixer / Bar Benders'
    ],
    'General Contractor': [
      'Residential Construction',
      'Commercial Construction',
      'Industrial Construction',
      'Renovation Specialist'
    ],
    'Electrical Contractor': [
      'Residential Electrical',
      'Commercial Electrical',
      'Industrial Electrical',
      'Solar Installation'
    ],
    'Roofing Contractor': [
      'Residential Roofing',
      'Commercial Roofing',
      'Industrial Roofing',
      'Roof Repair Specialist'
    ],
    'Vendors': [
      'Sand & Minerals',
      'Steel and cement',
      'Hardware',
      'Tiles and Sanitaryware',
      'Plumbing Material',
      'Plywood & Decor',
      'Furniture',
      'Stones'
    ],
    'Manufacturer': [
      'Building Materials',
      'Hardware Manufacturing',
      'Electrical Equipment',
      'Plumbing Equipment'
    ],
    'Plumbing Services': [
      'Residential Plumbing',
      'Commercial Plumbing',
      'Emergency Plumbing',
      'Pipe Installation'
    ],
    'Painting Services': [
      'Interior Painting',
      'Exterior Painting',
      'Commercial Painting',
      'Decorative Painting'
    ],
    'Landscaping Services': [
      'Garden Design',
      'Lawn Maintenance',
      'Tree Services',
      'Irrigation Systems'
    ],
    'Interior Design': [
      'Residential Interior Design',
      'Commercial Interior Design',
      'Office Interior Design',
      'Retail Interior Design'
    ]
  };

  useEffect(() => {
    fetchBusinessTypes();
  }, []);

  const fetchBusinessTypes = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('business_types')
        .select('id, name')
        .order('name');

      if (error) {
        throw error;
      }

      setBusinessTypes(data || []);
      
      // Map sub business types based on fetched business types
      const mappedSubTypes: SubBusinessTypeMapping = {};
      data?.forEach(type => {
        mappedSubTypes[type.name] = subBusinessTypeMappings[type.name] || [];
      });
      
      setSubBusinessTypes(mappedSubTypes);
    } catch (error) {
      console.error('Error fetching business types:', error);
      toast({
        title: "Error Loading Business Types",
        description: "Failed to load business types. Please refresh the page.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return {
    businessTypes,
    subBusinessTypes,
    isLoading,
    refetch: fetchBusinessTypes
  };
};