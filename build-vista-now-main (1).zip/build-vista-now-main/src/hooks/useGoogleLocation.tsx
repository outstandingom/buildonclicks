import { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from './useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

declare global {
  interface Window {
    google: any;
  }
}

export interface LocationData {
  city: string;
  fullAddress: string;
  latitude: number;
  longitude: number;
  state?: string;
  country?: string;
}

interface LocationState {
  location: LocationData | null;
  loading: boolean;
  error: string | null;
  isGoogleMapsLoaded: boolean;
}

export const useGoogleLocation = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [state, setState] = useState<LocationState>({
    location: null,
    loading: false,
    error: null,
    isGoogleMapsLoaded: false,
  });
  const scriptLoadedRef = useRef(false);
  const loadingCheckRef = useRef<NodeJS.Timeout | null>(null);

  // Load Google Maps API
  useEffect(() => {
    // Listen for Google Maps API errors
    const handleGoogleMapsError = (event: ErrorEvent) => {
      if (event.message?.includes('RefererNotAllowedMapError') || 
          event.message?.includes('referer-not-allowed')) {
        const siteUrl = window.location.origin;
        setState(prev => ({
          ...prev,
          error: 'Google Maps API key is not authorized for this domain. Please add this URL to allowed referrers in Google Cloud Console.',
          isGoogleMapsLoaded: false
        }));
        toast({
          title: 'Google Maps API Error',
          description: `Your site URL needs to be authorized: ${siteUrl}/*\n\nSee GOOGLE_MAPS_SETUP.md for instructions.`,
          variant: 'destructive',
          duration: 10000,
        });
        console.error('Google Maps RefererNotAllowedMapError');
        console.error(`Add this URL to allowed referrers: ${siteUrl}/*`);
        console.error('See GOOGLE_MAPS_SETUP.md for detailed instructions');
      }
    };

    // Check if already loaded
    if (window.google?.maps?.places && window.google?.maps?.Geocoder) {
      setState(prev => ({ ...prev, isGoogleMapsLoaded: true }));
      return;
    }

    // Check if script is already in DOM
    const existingScript = document.querySelector(`script[src*="maps.googleapis.com"]`);
    if (existingScript) {
      // Poll until loaded with more frequent checks
      const checkLoaded = setInterval(() => {
        if (window.google?.maps?.places && window.google?.maps?.Geocoder) {
          setState(prev => ({ ...prev, isGoogleMapsLoaded: true }));
          clearInterval(checkLoaded);
          if (loadingCheckRef.current === checkLoaded) {
            loadingCheckRef.current = null;
          }
        }
      }, 100);
      
      loadingCheckRef.current = checkLoaded;
      
      // Cleanup after 15 seconds (increased timeout)
      setTimeout(() => {
        if (loadingCheckRef.current === checkLoaded) {
          clearInterval(checkLoaded);
          loadingCheckRef.current = null;
          // If still not loaded after timeout, check one more time
          if (!window.google?.maps?.places) {
            console.warn('Google Maps loading timeout - may still be loading');
          }
        }
      }, 15000);
      
      // Set up error handler for existing script
      window.addEventListener('error', handleGoogleMapsError);
      
      return () => {
        window.removeEventListener('error', handleGoogleMapsError);
        if (loadingCheckRef.current === checkLoaded) {
          clearInterval(checkLoaded);
          loadingCheckRef.current = null;
        }
      };
    }

    // Prevent multiple script additions
    if (scriptLoadedRef.current) {
      return;
    }
    scriptLoadedRef.current = true;

    // Validate API key
    if (!GOOGLE_MAPS_API_KEY) {
      console.error('Google Maps API key is missing. Please add VITE_GOOGLE_MAPS_API_KEY to your .env file.');
      setState(prev => ({
        ...prev,
        error: 'Google Maps API key is missing. Please add VITE_GOOGLE_MAPS_API_KEY to your .env file.',
        isGoogleMapsLoaded: false
      }));
      toast({
        title: 'Configuration Error',
        description: 'Google Maps API key is missing. Please check your .env file.',
        variant: 'destructive',
      });
      return;
    }

    // Create and load script
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places`;
    script.async = true;
    script.defer = true;
    script.id = 'google-maps-script';
    
    script.onload = () => {
      // Wait a bit for Google Maps to fully initialize
      setTimeout(() => {
        if (window.google?.maps?.places && window.google?.maps?.Geocoder) {
          setState(prev => ({ ...prev, isGoogleMapsLoaded: true }));
        } else {
          // Check again after a short delay
          setTimeout(() => {
            if (window.google?.maps?.places && window.google?.maps?.Geocoder) {
              setState(prev => ({ ...prev, isGoogleMapsLoaded: true }));
            } else {
              console.error('Google Maps script loaded but places/geocoder library not available');
              scriptLoadedRef.current = false;
            }
          }, 500);
        }
      }, 100);
    };
    
    script.onerror = () => {
      console.error('Failed to load Google Maps script');
      scriptLoadedRef.current = false;
      setState(prev => ({ 
        ...prev, 
        error: 'Failed to load Google Maps. Please check API key restrictions in Google Cloud Console.',
        isGoogleMapsLoaded: false 
      }));
    };

    window.addEventListener('error', handleGoogleMapsError);
    
    document.head.appendChild(script);

    return () => {
      window.removeEventListener('error', handleGoogleMapsError);
      if (loadingCheckRef.current) {
        clearInterval(loadingCheckRef.current);
        loadingCheckRef.current = null;
      }
    };
  }, [toast]);

  // Load saved location from localStorage
  useEffect(() => {
    const savedCity = localStorage.getItem('userCity');
    const savedFullAddress = localStorage.getItem('userFullAddress');
    const savedLat = localStorage.getItem('userLatitude');
    const savedLng = localStorage.getItem('userLongitude');
    const savedState = localStorage.getItem('userState');
    const savedCountry = localStorage.getItem('userCountry');

    if (savedCity && savedFullAddress && savedLat && savedLng) {
      setState(prev => ({
        ...prev,
        location: {
          city: savedCity,
          fullAddress: savedFullAddress,
          latitude: parseFloat(savedLat),
          longitude: parseFloat(savedLng),
          state: savedState || undefined,
          country: savedCountry || undefined,
        },
      }));
    }
  }, []);

  // Reverse geocode coordinates to address
  const reverseGeocode = useCallback(async (lat: number, lng: number): Promise<LocationData> => {
    // Double check Google Maps is available
    if (!window.google?.maps?.Geocoder) {
      // Wait a bit and check again
      await new Promise(resolve => setTimeout(resolve, 500));
      if (!window.google?.maps?.Geocoder) {
        throw new Error('Google Maps Geocoder not available. Please refresh the page.');
      }
    }

    return new Promise((resolve, reject) => {
      try {
        const geocoder = new window.google.maps.Geocoder();
      
      geocoder.geocode(
        { location: { lat, lng } },
        (results: any, status: any) => {
          if (status === 'OK' && results && results.length > 0) {
            const place = results[0];
            const addressComponents = place.address_components || [];
            const fullAddress = place.formatted_address || '';

            // Extract city
            const cityComponent = addressComponents.find((c: any) => 
              c.types.includes('locality') || 
              c.types.includes('administrative_area_level_2')
            );
            
            const city = cityComponent?.long_name || 
              addressComponents.find((c: any) => c.types.includes('sublocality'))?.long_name ||
              addressComponents.find((c: any) => c.types.includes('sublocality_level_1'))?.long_name ||
              fullAddress.split(',')[0] ||
              'Unknown Location';

            // Extract state
            const stateComponent = addressComponents.find((c: any) => 
              c.types.includes('administrative_area_level_1')
            );
            const state = stateComponent?.long_name || '';

            // Extract country
            const countryComponent = addressComponents.find((c: any) => 
              c.types.includes('country')
            );
            const country = countryComponent?.long_name || '';

            // Format city display
            let displayCity = city;
            if (state && !city.includes(state)) {
              displayCity = `${city}, ${state}`;
            }

            const locationData: LocationData = {
              city: displayCity,
              fullAddress,
              latitude: lat,
              longitude: lng,
              state: state || undefined,
              country: country || undefined,
            };

            resolve(locationData);
          } else if (status === 'ZERO_RESULTS') {
            reject(new Error('No address found for this location'));
          } else if (status === 'OVER_QUERY_LIMIT') {
            reject(new Error('Geocoding quota exceeded. Please try again later.'));
          } else if (status === 'REQUEST_DENIED') {
            reject(new Error('Geocoding request denied. Check API key permissions.'));
          } else {
            reject(new Error(`Geocoding failed: ${status}`));
          }
        }
      );
      } catch (err) {
        reject(new Error(`Geocoding error: ${err instanceof Error ? err.message : 'Unknown error'}`));
      }
    });
  }, [state.isGoogleMapsLoaded]);

  // Forward geocode address to coordinates
  const forwardGeocode = useCallback(async (query: string): Promise<LocationData[]> => {
    if (!state.isGoogleMapsLoaded || !window.google?.maps) {
      console.error('Google Maps not loaded yet');
      return [];
    }

    return new Promise((resolve, reject) => {
      const geocoder = new window.google.maps.Geocoder();
      
      geocoder.geocode({ address: query }, (results: any, status: any) => {
        if (status === 'OK' && results && results.length > 0) {
          const locations: LocationData[] = results.slice(0, 5).map((place: any) => {
            const addressComponents = place.address_components || [];
            const fullAddress = place.formatted_address || '';
            const location = place.geometry?.location;

            const cityComponent = addressComponents.find((c: any) => 
              c.types.includes('locality') || 
              c.types.includes('administrative_area_level_2')
            );
            
            const city = cityComponent?.long_name || 
              addressComponents.find((c: any) => c.types.includes('sublocality'))?.long_name ||
              fullAddress.split(',')[0] ||
              'Unknown Location';

            const stateComponent = addressComponents.find((c: any) => 
              c.types.includes('administrative_area_level_1')
            );
            const state = stateComponent?.long_name || '';

            const countryComponent = addressComponents.find((c: any) => 
              c.types.includes('country')
            );
            const country = countryComponent?.long_name || '';

            let displayCity = city;
            if (state && !city.includes(state)) {
              displayCity = `${city}, ${state}`;
            }

            return {
              city: displayCity,
              fullAddress,
              latitude: location ? (typeof location.lat === 'function' ? location.lat() : location.lat) : 0,
              longitude: location ? (typeof location.lng === 'function' ? location.lng() : location.lng) : 0,
              state: state || undefined,
              country: country || undefined,
            };
          });

          resolve(locations);
        } else if (status === 'ZERO_RESULTS') {
          resolve([]);
        } else if (status === 'OVER_QUERY_LIMIT') {
          reject(new Error('Geocoding quota exceeded. Please try again later.'));
        } else if (status === 'REQUEST_DENIED') {
          reject(new Error('Geocoding request denied. Check API key permissions.'));
        } else {
          resolve([]);
        }
      });
    });
  }, [state.isGoogleMapsLoaded]);

  // Save location to localStorage and database
  const saveLocation = useCallback(async (locationData: LocationData) => {
    // Save to localStorage
    localStorage.setItem('userCity', locationData.city);
    localStorage.setItem('userFullAddress', locationData.fullAddress);
    localStorage.setItem('userLatitude', locationData.latitude.toString());
    localStorage.setItem('userLongitude', locationData.longitude.toString());
    if (locationData.state) {
      localStorage.setItem('userState', locationData.state);
    }
    if (locationData.country) {
      localStorage.setItem('userCountry', locationData.country);
    }

    // Update state
    setState(prev => ({ ...prev, location: locationData }));

    // Save to database if user is logged in
    if (user) {
      try {
        await supabase
          .from('profiles')
          .update({
            address: locationData.fullAddress,
            latitude: locationData.latitude,
            longitude: locationData.longitude,
          })
          .eq('id', user.id);
      } catch (error) {
        console.error('Error saving location to database:', error);
      }
    }
  }, [user]);

  // Get current location using GPS
  const getCurrentLocation = useCallback(async (): Promise<LocationData> => {
    console.log('getCurrentLocation called, isGoogleMapsLoaded:', state.isGoogleMapsLoaded);
    
    // Wait for Google Maps to load if not already loaded
    if (!state.isGoogleMapsLoaded) {
      console.log('Google Maps not loaded, waiting...');
      // Wait up to 10 seconds for Google Maps to load
      let attempts = 0;
      const maxAttempts = 50; // 50 * 200ms = 10 seconds
      
      while (!window.google?.maps?.places && attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 200));
        attempts++;
        if (attempts % 10 === 0) {
          console.log(`Waiting for Google Maps... attempt ${attempts}/${maxAttempts}`);
        }
      }
      
      if (!window.google?.maps?.places) {
        console.error('Google Maps failed to load after waiting');
        throw new Error('Google Maps failed to load. Please check your internet connection and refresh the page.');
      }
      
      console.log('Google Maps loaded successfully');
      // Update state to reflect that Google Maps is now loaded
      setState(prev => ({ ...prev, isGoogleMapsLoaded: true }));
    }

    if (!navigator.geolocation) {
      console.error('Geolocation not supported');
      throw new Error('Geolocation is not supported by your browser.');
    }

    console.log('Requesting GPS location...');
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      // Get GPS coordinates
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        console.log('Calling navigator.geolocation.getCurrentPosition...');
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            console.log('GPS position received:', pos.coords.latitude, pos.coords.longitude);
            resolve(pos);
          },
          (error) => {
            console.error('Geolocation error:', error);
            let message = 'Location permission denied';
            switch (error.code) {
              case error.PERMISSION_DENIED:
                message = 'Location permission denied. Please enable location access in your browser settings.';
                break;
              case error.POSITION_UNAVAILABLE:
                message = 'Location information unavailable.';
                break;
              case error.TIMEOUT:
                message = 'Location request timed out. Please try again.';
                break;
            }
            reject(new Error(message));
          },
          {
            enableHighAccuracy: true,
            timeout: 20000, // Increased timeout to 20 seconds
            maximumAge: 0, // Always get fresh location
          }
        );
      });

      const { latitude, longitude } = position.coords;
      console.log('GPS coordinates obtained:', latitude, longitude);

      // Ensure Google Maps is ready before reverse geocoding
      if (!window.google?.maps?.Geocoder) {
        // Wait a bit more and check again
        console.log('Geocoder not ready, waiting...');
        await new Promise(resolve => setTimeout(resolve, 1000));
        if (!window.google?.maps?.Geocoder) {
          throw new Error('Google Maps Geocoder not available. Please refresh the page.');
        }
      }

      // Reverse geocode to get address
      const locationData = await reverseGeocode(latitude, longitude);
      console.log('Reverse geocode result:', locationData);

      // Save location
      await saveLocation(locationData);

      setState(prev => ({ ...prev, loading: false }));
      toast({
        title: 'Location detected',
        description: `Set to ${locationData.city}`,
      });

      return locationData;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to get location';
      console.error('Location fetch error:', error);
      setState(prev => ({ 
        ...prev, 
        loading: false, 
        error: errorMessage 
      }));
      toast({
        title: 'Location error',
        description: errorMessage,
        variant: 'destructive',
      });
      throw error;
    }
  }, [state.isGoogleMapsLoaded, reverseGeocode, saveLocation, toast]);

  // Set location manually
  const setLocation = useCallback(async (locationData: LocationData | string): Promise<LocationData> => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      let finalLocation: LocationData;

      if (typeof locationData === 'string') {
        // Search for location
        const results = await forwardGeocode(locationData);
        if (results.length === 0) {
          throw new Error('Location not found. Please try a different search term.');
        }
        finalLocation = results[0];
      } else {
        finalLocation = locationData;
      }

      // Save location
      await saveLocation(finalLocation);

      setState(prev => ({ ...prev, loading: false }));
      toast({
        title: 'Location set',
        description: `Set to ${finalLocation.city}`,
      });

      return finalLocation;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to set location';
      setState(prev => ({ 
        ...prev, 
        loading: false, 
        error: errorMessage 
      }));
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      throw error;
    }
  }, [forwardGeocode, saveLocation, toast]);

  // Search locations (for autocomplete)
  const searchLocations = useCallback(async (query: string): Promise<LocationData[]> => {
    if (!query || query.length < 2) {
      return [];
    }

    try {
      return await forwardGeocode(query);
    } catch (error) {
      console.error('Search error:', error);
      return [];
    }
  }, [forwardGeocode]);

  // Clear location
  const clearLocation = useCallback(() => {
    localStorage.removeItem('userCity');
    localStorage.removeItem('userFullAddress');
    localStorage.removeItem('userLatitude');
    localStorage.removeItem('userLongitude');
    localStorage.removeItem('userState');
    localStorage.removeItem('userCountry');
    
    setState(prev => ({ 
      ...prev, 
      location: null, 
      error: null 
    }));
  }, []);

  return {
    location: state.location,
    loading: state.loading,
    error: state.error,
    isGoogleMapsLoaded: state.isGoogleMapsLoaded,
    getCurrentLocation,
    setLocation,
    searchLocations,
    clearLocation,
    reverseGeocode,
    forwardGeocode,
  };
};

