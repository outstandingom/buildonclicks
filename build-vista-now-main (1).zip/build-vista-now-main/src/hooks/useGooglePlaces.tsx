import { useState, useEffect, useRef } from 'react';

const GOOGLE_MAPS_API_KEY = 'AIzaSyBz8TJrPNKb7lzxwLC4P6C6vWl7Ut3akOY';

// Add Google Maps type declaration
declare global {
  interface Window {
    google: any;
  }
}

interface PlaceLocation {
  address: string;
  city: string;
  state: string;
  country: string;
  latitude: number;
  longitude: number;
  formattedAddress: string;
}

export const useGooglePlaces = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const scriptLoadedRef = useRef(false);

  useEffect(() => {
    // Check if Google Maps is already loaded
    if (window.google?.maps) {
      setIsLoaded(true);
      return;
    }

    // Check if script is already being loaded or exists
    const existingScript = document.querySelector(`script[src*="maps.googleapis.com"]`);
    if (existingScript) {
      // Script exists, wait for it to load
      const checkLoaded = setInterval(() => {
        if (window.google?.maps) {
          setIsLoaded(true);
          clearInterval(checkLoaded);
        }
      }, 100);

      // Cleanup interval after 10 seconds
      setTimeout(() => clearInterval(checkLoaded), 10000);
      return;
    }

    // Prevent multiple script additions
    if (scriptLoadedRef.current) {
      return;
    }
    scriptLoadedRef.current = true;

    // Load Google Maps JavaScript API
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places`;
    script.async = true;
    script.defer = true;
    script.id = 'google-maps-script';
    
    script.onload = () => {
      // Double check that google.maps is available
      if (window.google?.maps) {
        setIsLoaded(true);
      } else {
        console.error('Google Maps script loaded but google.maps is not available');
      }
    };
    
    script.onerror = (error) => {
      console.error('Failed to load Google Maps:', error);
      scriptLoadedRef.current = false;
    };
    
    document.head.appendChild(script);

    return () => {
      // Don't remove script on cleanup as it might be used by other components
    };
  }, []);

  const getCurrentLocation = async (): Promise<PlaceLocation | null> => {
    if (!isLoaded || !window.google?.maps) {
      console.error('Google Maps not loaded yet');
      return null;
    }

    if (!navigator.geolocation) {
      console.error('Geolocation is not supported by this browser');
      return null;
    }

    setLoading(true);

    try {
      // Get user's current position
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          resolve, 
          (error) => {
            console.error('Geolocation error:', error);
            reject(new Error(`Geolocation failed: ${error.message}`));
          },
          {
            enableHighAccuracy: true,
            timeout: 15000,
            maximumAge: 60000 // Accept cached position up to 1 minute old
          }
        );
      });

      const { latitude, longitude } = position.coords;

      // Use Google Geocoding to get address details
      const geocoder = new window.google.maps.Geocoder();
      const result = await new Promise<any[]>((resolve, reject) => {
        geocoder.geocode(
          { location: { lat: latitude, lng: longitude } },
          (results: any, status: any) => {
            if (status === 'OK' && results && results.length > 0) {
              resolve(results);
            } else if (status === 'ZERO_RESULTS') {
              reject(new Error('No results found for this location'));
            } else if (status === 'OVER_QUERY_LIMIT') {
              reject(new Error('Geocoding quota exceeded. Please try again later.'));
            } else if (status === 'REQUEST_DENIED') {
              reject(new Error('Geocoding request denied. Check API key permissions.'));
            } else {
              reject(new Error(`Geocoding failed with status: ${status}`));
            }
          }
        );
      });

      if (result && result[0]) {
        const place = result[0];
        const addressComponents = place.address_components || [];

        const city = addressComponents.find((c: any) => 
          c.types.includes('locality') || c.types.includes('administrative_area_level_2')
        )?.long_name || '';

        const state = addressComponents.find((c: any) => 
          c.types.includes('administrative_area_level_1')
        )?.long_name || '';

        const country = addressComponents.find((c: any) => 
          c.types.includes('country')
        )?.long_name || '';

        const locationData: PlaceLocation = {
          address: place.formatted_address || '',
          city,
          state,
          country,
          latitude,
          longitude,
          formattedAddress: place.formatted_address || ''
        };

        setLoading(false);
        return locationData;
      }

      throw new Error('No results found');
    } catch (error) {
      console.error('Error getting location:', error);
      setLoading(false);
      throw error; // Re-throw to let caller handle the error
    }
  };

  const searchPlace = async (query: string): Promise<PlaceLocation | null> => {
    if (!isLoaded || !window.google?.maps) {
      console.error('Google Maps not loaded yet');
      return null;
    }

    setLoading(true);

    try {
      const geocoder = new window.google.maps.Geocoder();
      const result = await new Promise<any[]>((resolve, reject) => {
        geocoder.geocode({ address: query }, (results: any, status: any) => {
          if (status === 'OK' && results && results.length > 0) {
            resolve(results);
          } else if (status === 'ZERO_RESULTS') {
            reject(new Error('No results found for this query'));
          } else if (status === 'OVER_QUERY_LIMIT') {
            reject(new Error('Geocoding quota exceeded. Please try again later.'));
          } else if (status === 'REQUEST_DENIED') {
            reject(new Error('Geocoding request denied. Check API key permissions.'));
          } else {
            reject(new Error(`Place search failed with status: ${status}`));
          }
        });
      });

      if (result && result[0]) {
        const place = result[0];
        const addressComponents = place.address_components || [];
        const location = place.geometry?.location;

        if (!location) {
          throw new Error('Location data not available');
        }

        const city = addressComponents.find((c: any) => 
          c.types.includes('locality') || c.types.includes('administrative_area_level_2')
        )?.long_name || '';

        const state = addressComponents.find((c: any) => 
          c.types.includes('administrative_area_level_1')
        )?.long_name || '';

        const country = addressComponents.find((c: any) => 
          c.types.includes('country')
        )?.long_name || '';

        const locationData: PlaceLocation = {
          address: place.formatted_address || '',
          city,
          state,
          country,
          latitude: typeof location.lat === 'function' ? location.lat() : location.lat,
          longitude: typeof location.lng === 'function' ? location.lng() : location.lng,
          formattedAddress: place.formatted_address || ''
        };

        setLoading(false);
        return locationData;
      }

      throw new Error('No results found');
    } catch (error) {
      console.error('Error searching place:', error);
      setLoading(false);
      throw error; // Re-throw to let caller handle the error
    }
  };

  return {
    isLoaded,
    loading,
    getCurrentLocation,
    searchPlace
  };
};
