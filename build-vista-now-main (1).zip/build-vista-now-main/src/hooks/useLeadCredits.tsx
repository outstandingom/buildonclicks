import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

interface LeadCredits {
  total_credits: number;
  used_credits: number;
  available_credits: number;
  free_credits_given: boolean;
}

interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price_inr: number;
  lead_credits: number;
  duration_days: number;
}

export const useLeadCredits = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [credits, setCredits] = useState<LeadCredits | null>(null);
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [loading, setLoading] = useState(true);
  // Batch access checking for multiple leads

  const fetchCredits = useCallback(async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('user_lead_credits')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching credits:', error);
        // Set default credits on error to prevent blocking UI
        setCredits({
          total_credits: 15,
          used_credits: 0,
          available_credits: 15,
          free_credits_given: false
        });
        return;
      }

      if (data) {
        setCredits({
          total_credits: data.total_credits,
          used_credits: data.used_credits,
          available_credits: data.total_credits - data.used_credits,
          free_credits_given: data.free_credits_given
        });
      } else {
        // No credits record exists, will be created by trigger
        setCredits({
          total_credits: 15,
          used_credits: 0,
          available_credits: 15,
          free_credits_given: false
        });
      }
    } catch (error) {
      console.error('Error fetching credits:', error);
      // Set default credits on error to prevent blocking UI
      setCredits({
        total_credits: 15,
        used_credits: 0,
        available_credits: 15,
        free_credits_given: false
      });
    }
  }, [user]);

  const fetchPlans = async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('is_active', true)
        .order('price_inr', { ascending: true });

      if (error) {
        console.error('Error fetching plans:', error);
        // Set default plans on error
        setPlans([
          {
            id: 'default-1',
            name: 'Basic Plan',
            description: '50 Lead Credits',
            price_inr: 500,
            lead_credits: 50,
            duration_days: 30
          }
        ]);
        return;
      }

      setPlans(data || []);
    } catch (error) {
      console.error('Error fetching plans:', error);
      // Set default plans on error
      setPlans([]);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      if (!user) {
        setLoading(false);
        return;
      }
      
      setLoading(true);
      
      // Add timeout to prevent hanging on network issues
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 5000)
      );
      
      try {
        await Promise.race([
          Promise.all([fetchCredits(), fetchPlans()]),
          timeoutPromise
        ]);
      } catch (error) {
        console.error('Network timeout or error, using fallback data:', error);
        // Set fallback data when network fails
        setCredits({
          total_credits: 15,
          used_credits: 0,
          available_credits: 15,
          free_credits_given: false
        });
        setPlans([
          {
            id: 'fallback-plan',
            name: 'Basic Plan',
            description: '50 Lead Credits',
            price_inr: 500,
            lead_credits: 50,
            duration_days: 30
          }
        ]);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [user?.id]); // Fixed: Use user.id instead of user object to prevent infinite loop

  const checkCredits = useCallback(async (creditsNeeded: number = 1): Promise<boolean> => {
    if (!user) return false;

    try {
      const { data, error } = await supabase
        .rpc('check_user_lead_credits', {
          p_user_id: user.id,
          p_credits_needed: creditsNeeded
        });

      if (error) {
        console.error('Error checking credits:', error);
        return false;
      }

      return data === true;
    } catch (error) {
      console.error('Error checking credits:', error);
      return false;
    }
  }, [user]);

  const consumeCredits = useCallback(async (
    entityId: string, 
    creditsToConsume: number = 1, 
    accessType: 'view' | 'contact' = 'view',
    entityType: 'requirement' | 'professional' = 'requirement'
  ): Promise<boolean> => {
    if (!user) return false;

    try {
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 5000)
      );
      
      const result = await Promise.race([
        supabase.rpc('consume_lead_credits', {
          p_user_id: user.id,
          p_entity_id: entityId,
          p_credits: creditsToConsume,
          p_access_type: accessType,
          p_entity_type: entityType
        }),
        timeoutPromise
      ]) as any;
      
      const { data, error } = result;

      if (error) {
        console.error('Error consuming credits:', error);
        toast({
          title: "Error",
          description: "Failed to process credit transaction",
          variant: "destructive",
        });
        return false;
      }

      if (data === true) {
        // Refresh credits after consumption
        await fetchCredits();
        return true;
      } else {
        toast({
          title: "Insufficient Credits",
          description: "You don't have enough credits to access this lead",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      console.error('Network error consuming credits:', error);
      // In case of network error, allow access but show warning
      toast({
        title: "Network Issue",
        description: "Unable to verify credits due to connection issues. Access granted temporarily.",
        variant: "destructive",
      });
      return true; // Allow access when network fails
    }
  }, [user, fetchCredits]);

  // Batch check for multiple leads - more efficient
  const hasAccessedLeads = useCallback(async (
    entityIds: string[],
    accessType: 'view' | 'contact' = 'view',
    entityType: 'requirement' | 'professional' = 'requirement'
  ): Promise<Set<string>> => {
    if (!user || entityIds.length === 0) {
      return new Set();
    }

    try {
      const { data, error } = await supabase
        .from('lead_access_logs')
        .select('entity_id')
        .eq('user_id', user.id)
        .in('entity_id', entityIds)
        .eq('access_type', accessType)
        .eq('access_entity_type', entityType);

      if (error) {
        console.error('Error checking batch lead access:', error);
        return new Set();
      }

      return new Set(data?.map(log => log.entity_id) || []);
    } catch (error) {
      console.error('Error in hasAccessedLeads:', error);
      return new Set();
    }
  }, [user]);

  // Single lead access check - kept for backwards compatibility
  const hasAccessedLead = useCallback(async (
    entityId: string, 
    accessType: 'view' | 'contact' = 'view',
    entityType: 'requirement' | 'professional' = 'requirement'
  ): Promise<boolean> => {
    if (!user) {
      return false;
    }

    try {
      const { data, error } = await supabase
        .from('lead_access_logs')
        .select('id')
        .eq('user_id', user.id)
        .eq('entity_id', entityId)
        .eq('access_type', accessType)
        .eq('access_entity_type', entityType)
        .maybeSingle();

      if (error) {
        console.error('Error checking lead access:', error);
        return false;
      }

      return !!data;
    } catch (error) {
      console.error('Error in hasAccessedLead:', error);
      return false;
    }
  }, [user]);

  return {
    credits,
    plans,
    loading,
    checkCredits,
    consumeCredits,
    hasAccessedLead,
    hasAccessedLeads,
    refreshCredits: fetchCredits
  };
};