import { useState, useEffect, useRef } from "react";
import { useAuth } from "./useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface LocationData {
  city: string;
  fullAddress?: string;
  latitude?: number;
  longitude?: number;
  country?: string;
  state?: string;
}

const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

// Add Google Maps type declaration
declare global {
  interface Window {
    google: any;
  }
}

export const useLocation = () => {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isGoogleMapsLoaded, setIsGoogleMapsLoaded] = useState(false);
  const scriptLoadedRef = useRef(false);
  const { user } = useAuth();

  // Load Google Maps API
  useEffect(() => {
    // Check if Google Maps is already loaded
    if (window.google?.maps) {
      setIsGoogleMapsLoaded(true);
      return;
    }

    // Check if script is already being loaded or exists
    const existingScript = document.querySelector(`script[src*="maps.googleapis.com"]`);
    if (existingScript) {
      // Script exists, wait for it to load
      const checkLoaded = setInterval(() => {
        if (window.google?.maps) {
          setIsGoogleMapsLoaded(true);
          clearInterval(checkLoaded);
        }
      }, 100);

      // Cleanup interval after 10 seconds
      setTimeout(() => clearInterval(checkLoaded), 10000);
      return;
    }

    // Prevent multiple script additions
    if (scriptLoadedRef.current) {
      return;
    }
    scriptLoadedRef.current = true;

    // Load Google Maps JavaScript API
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places`;
    script.async = true;
    script.defer = true;
    script.id = 'google-maps-script';
    
    script.onload = () => {
      if (window.google?.maps) {
        setIsGoogleMapsLoaded(true);
      }
    };
    
    script.onerror = () => {
      console.error('Failed to load Google Maps');
      scriptLoadedRef.current = false;
    };
    
    document.head.appendChild(script);
  }, []);

  // ------------------------------------------------
  // Load Saved City
  // ------------------------------------------------
  useEffect(() => {
    const savedCity = localStorage.getItem("userCity");
    const savedFullAddress = localStorage.getItem("userFullAddress");
    if (savedCity) {
      setLocation({ 
        city: savedCity,
        fullAddress: savedFullAddress || savedCity 
      });
    }
  }, []);

  // ------------------------------------------------
  // Reverse Geocoding using Google Maps API
  // ------------------------------------------------
  const reverseGeocode = async (lat: number, lng: number): Promise<LocationData> => {
    if (!isGoogleMapsLoaded || !window.google?.maps) {
      throw new Error("Google Maps not loaded yet");
    }

    try {
      const geocoder = new window.google.maps.Geocoder();
      const result = await new Promise<any[]>((resolve, reject) => {
        geocoder.geocode(
          { location: { lat, lng } },
          (results: any, status: any) => {
            if (status === 'OK' && results && results.length > 0) {
              resolve(results);
            } else if (status === 'ZERO_RESULTS') {
              reject(new Error('No results found for this location'));
            } else if (status === 'OVER_QUERY_LIMIT') {
              reject(new Error('Geocoding quota exceeded. Please try again later.'));
            } else if (status === 'REQUEST_DENIED') {
              reject(new Error('Geocoding request denied. Check API key permissions.'));
            } else {
              reject(new Error(`Geocoding failed with status: ${status}`));
            }
          }
        );
      });

      if (result && result[0]) {
        const place = result[0];
        const addressComponents = place.address_components || [];
        const fullAddress = place.formatted_address || "";

        // Extract city from address components
        const cityComponent = addressComponents.find((c: any) => 
          c.types.includes('locality') || c.types.includes('administrative_area_level_2')
        );
        
        const city = cityComponent?.long_name || 
                     addressComponents.find((c: any) => c.types.includes('sublocality'))?.long_name ||
                     addressComponents.find((c: any) => c.types.includes('sublocality_level_1'))?.long_name ||
                     fullAddress.split(',')[0] ||
                     "Unknown Location";

        const stateComponent = addressComponents.find((c: any) => 
          c.types.includes('administrative_area_level_1')
        );
        const state = stateComponent?.long_name || "";

        const countryComponent = addressComponents.find((c: any) => 
          c.types.includes('country')
        );
        const country = countryComponent?.long_name || "";

        // Format city display
        let displayCity = city;
        if (state && !city.includes(state)) {
          displayCity = `${city}, ${state}`;
        }

        return {
          city: displayCity,
          fullAddress: fullAddress,
          latitude: lat,
          longitude: lng,
          state: state,
          country: country,
        };
      }

      throw new Error('No results found');
    } catch (err) {
      console.error("Reverse geocoding error:", err);
      // Return coordinates if reverse geocoding fails
      return {
        city: `${lat.toFixed(4)}, ${lng.toFixed(4)}`,
        fullAddress: `${lat.toFixed(4)}, ${lng.toFixed(4)}`,
        latitude: lat,
        longitude: lng,
        country: "",
        state: ""
      };
    }
  };

  // ------------------------------------------------
  // Forward Geocoding using Google Maps API (for manual search)
  // ------------------------------------------------
  const forwardGeocode = async (query: string): Promise<LocationData[]> => {
    if (!isGoogleMapsLoaded || !window.google?.maps) {
      console.error("Google Maps not loaded yet");
      return [];
    }

    try {
      const geocoder = new window.google.maps.Geocoder();
      const result = await new Promise<any[]>((resolve, reject) => {
        geocoder.geocode({ address: query }, (results: any, status: any) => {
          if (status === 'OK' && results && results.length > 0) {
            resolve(results.slice(0, 5)); // Limit to 5 results
          } else if (status === 'ZERO_RESULTS') {
            resolve([]); // No results, return empty array
          } else if (status === 'OVER_QUERY_LIMIT') {
            reject(new Error('Geocoding quota exceeded. Please try again later.'));
          } else if (status === 'REQUEST_DENIED') {
            reject(new Error('Geocoding request denied. Check API key permissions.'));
          } else {
            resolve([]); // Other errors, return empty array
          }
        });
      });

      if (!result || result.length === 0) {
        return [];
      }

      return result.map((place: any) => {
        const addressComponents = place.address_components || [];
        const fullAddress = place.formatted_address || "";
        const location = place.geometry?.location;

        const cityComponent = addressComponents.find((c: any) => 
          c.types.includes('locality') || c.types.includes('administrative_area_level_2')
        );
        
        const city = cityComponent?.long_name || 
                     addressComponents.find((c: any) => c.types.includes('sublocality'))?.long_name ||
                     fullAddress.split(',')[0] ||
                     "Unknown Location";

        const stateComponent = addressComponents.find((c: any) => 
          c.types.includes('administrative_area_level_1')
        );
        const state = stateComponent?.long_name || "";

        const countryComponent = addressComponents.find((c: any) => 
          c.types.includes('country')
        );
        const country = countryComponent?.long_name || "";

        let displayCity = city;
        if (state && !city.includes(state)) {
          displayCity = `${city}, ${state}`;
        }

        return {
          city: displayCity,
          fullAddress: fullAddress,
          latitude: location ? (typeof location.lat === 'function' ? location.lat() : location.lat) : 0,
          longitude: location ? (typeof location.lng === 'function' ? location.lng() : location.lng) : 0,
          state: state,
          country: country,
        };
      });
      
    } catch (err) {
      console.error("Forward geocoding error:", err);
      return [];
    }
  };

  // ------------------------------------------------
  // GPS Detection (Primary) - Using Google Maps for geocoding
  // ------------------------------------------------
  const detectFromBrowserGPS = async (): Promise<LocationData> => {
    if (!isGoogleMapsLoaded) {
      throw new Error("Google Maps not loaded yet. Please wait a moment and try again.");
    }

    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error("Geolocation not supported by browser"));
        return;
      }
      
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          try {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;
            console.log("Got coordinates:", lat, lng);
            
            const data = await reverseGeocode(lat, lng);
            console.log("Reverse geocode result:", data);
            resolve(data);
          } catch (err) {
            console.error("Reverse geocode error:", err);
            reject(err);
          }
        },
        (err) => {
          let errorMessage = "Location permission denied";
          
          switch (err.code) {
            case err.PERMISSION_DENIED:
              errorMessage = "Location permission denied. Please enable location services.";
              break;
            case err.POSITION_UNAVAILABLE:
              errorMessage = "Location information unavailable.";
              break;
            case err.TIMEOUT:
              errorMessage = "Location request timed out.";
              break;
            default:
              errorMessage = "An unknown error occurred.";
          }
          
          console.error("Geolocation error:", errorMessage, err);
          reject(new Error(errorMessage));
        },
        { 
          enableHighAccuracy: true, 
          timeout: 15000,
          maximumAge: 60000 // Accept cached position up to 1 minute old
        }
      );
    });
  };

  // ------------------------------------------------
  // MASTER DETECTOR — GPS → Reverse Geocode
  // ------------------------------------------------
  const detectLocation = async () => {
    setLoading(true);
    setError(null);

    try {
      console.log("Starting location detection...");
      const data = await detectFromBrowserGPS();
      console.log("Location detected:", data);
      await updateLocation(data);
      toast.success("Location detected successfully");
      return data;
    } catch (err) {
      console.error("Location detection failed:", err);
      setError(err instanceof Error ? err.message : "Unable to detect location");
      toast.error("Unable to detect location. Please choose manually.");
      throw err; // Re-throw so calling code knows it failed
    } finally {
      setLoading(false);
    }
  };

  // ------------------------------------------------
  // Permission Button Handler (Simplified)
  // ------------------------------------------------
  const requestLocationPermission = async () => {
    return detectLocation();
  };

  // ------------------------------------------------
  // Save Location (local + supabase) - Updated to save full address
  // ------------------------------------------------
  const updateLocation = async (loc: LocationData) => {
    console.log("Updating location:", loc);
    setLocation(loc);
    
    // Save both city and full address
    localStorage.setItem("userCity", loc.city);
    if (loc.fullAddress) {
      localStorage.setItem("userFullAddress", loc.fullAddress);
    }

    if (user) {
      try {
        await supabase
          .from("profiles")
          .update({ 
            address: loc.fullAddress || loc.city, // Use full address if available
            latitude: loc.latitude,
            longitude: loc.longitude 
          })
          .eq("id", user.id);
        console.log("Profile updated in database");
      } catch (dbError) {
        console.error("Error updating profile:", dbError);
      }
    }
  };

  // ------------------------------------------------
  // Manual Location Selection - Improved
  // ------------------------------------------------
  const setManualLocation = async (locationData: LocationData | string) => {
    setLoading(true);
    
    try {
      if (typeof locationData === 'string') {
        // Search for the location
        const results = await forwardGeocode(locationData);
        if (results.length > 0) {
          const selectedLocation = results[0];
          await updateLocation(selectedLocation);
          toast.success(`Location set to ${selectedLocation.city}`);
          return selectedLocation;
        } else {
          throw new Error("Location not found");
        }
      } else {
        // Use provided location data
        await updateLocation(locationData);
        toast.success(`Location set to ${locationData.city}`);
        return locationData;
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : "Failed to set location";
      toast.error(errorMsg);
      console.error(err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // ------------------------------------------------
  // Search Locations (for autocomplete/search) - Improved
  // ------------------------------------------------
  const searchLocations = async (query: string): Promise<LocationData[]> => {
    if (!query || query.length < 2) {
      return [];
    }
    
    try {
      console.log("Searching for:", query);
      const results = await forwardGeocode(query);
      console.log("Search results:", results);
      return results;
    } catch (err) {
      console.error("Search error:", err);
      return [];
    }
  };

  // ------------------------------------------------
  // Get Current Coordinates (like HTML version)
  // ------------------------------------------------
  const getCurrentCoordinates = (): Promise<{lat: number, lng: number}> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error("Geolocation not supported"));
        return;
      }
      
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          resolve({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude
          });
        },
        (err) => {
          reject(err);
        },
        { 
          enableHighAccuracy: true, 
          timeout: 10000,
          maximumAge: 0 
        }
      );
    });
  };

  // ------------------------------------------------
  // Get Full Address from Coordinates using Google Maps API
  // ------------------------------------------------
  const getFullAddressFromCoords = async (lat: number, lng: number): Promise<string> => {
    if (!isGoogleMapsLoaded || !window.google?.maps) {
      return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    }

    try {
      const geocoder = new window.google.maps.Geocoder();
      const result = await new Promise<any[]>((resolve, reject) => {
        geocoder.geocode(
          { location: { lat, lng } },
          (results: any, status: any) => {
            if (status === 'OK' && results && results.length > 0) {
              resolve(results);
            } else {
              reject(new Error(`Geocoding failed: ${status}`));
            }
          }
        );
      });

      if (result && result[0]) {
        return result[0].formatted_address || `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
      }

      return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    } catch (error) {
      console.error('Error reverse geocoding:', error);
      return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    }
  };

  // ------------------------------------------------
  // Clear Location
  // ------------------------------------------------
  const clearLocation = () => {
    setLocation(null);
    localStorage.removeItem("userCity");
    localStorage.removeItem("userFullAddress");
    setError(null);
  };

  return {
    location,
    loading,
    error,
    detectLocation,
    requestLocationPermission,
    setManualLocation,
    searchLocations,
    getCurrentCoordinates,
    getFullAddressFromCoords, // NEW: Export this function
    clearLocation,
    reverseGeocode,
    forwardGeocode
  };
};
