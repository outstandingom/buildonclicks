import { useEffect } from 'react';
import { useLocation } from './useLocation';

export const useLocationFilter = () => {
  const { location } = useLocation();

  // Filter professionals by current location
  const filterProfessionalsByLocation = (professionals: any[]) => {
    if (!location?.city || location.city === 'Select City') {
      return professionals;
    }

    return professionals.filter(professional => {
      // Check if professional's location matches current city
      return professional.city_name?.toLowerCase().includes(location.city.toLowerCase()) ||
             professional.location?.toLowerCase().includes(location.city.toLowerCase());
    });
  };

  // Filter products by current location
  const filterProductsByLocation = (products: any[]) => {
    if (!location?.city || location.city === 'Select City') {
      return products;
    }

    return products.filter(product => {
      // Check if product's location matches current city
      return product.city_name?.toLowerCase().includes(location.city.toLowerCase()) ||
             product.location?.toLowerCase().includes(location.city.toLowerCase());
    });
  };

  // Get current city for API filters
  const getCurrentCity = () => {
    return location?.city && location.city !== 'Select City' ? location.city : null;
  };

  return {
    currentCity: location?.city,
    filterProfessionalsByLocation,
    filterProductsByLocation,
    getCurrentCity
  };
};