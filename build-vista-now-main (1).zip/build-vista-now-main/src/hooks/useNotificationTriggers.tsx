import { useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { triggerAutoNotifications } from '@/utils/notificationHelpers';

export const useNotificationTriggers = () => {
  const { user } = useAuth();

  // Trigger welcome notification for new users
  useEffect(() => {
    if (user && user.user_metadata) {
      const userType = user.user_metadata.user_type || 'user';
      const isNewUser = !user.user_metadata.welcome_sent;
      
      if (isNewUser) {
        triggerAutoNotifications.onUserSignup(user.id, userType as 'user' | 'provider');
      }
    }
  }, [user]);

  return {
    triggerNewBid: (projectOwnerId: string, projectTitle: string, professionalName: string) =>
      triggerAutoNotifications.onNewBid(projectOwnerId, projectTitle, professionalName),
    
    triggerBidStatusUpdate: (bidderId: string, projectTitle: string, accepted: boolean) =>
      triggerAutoNotifications.onBidStatusUpdate(bidderId, projectTitle, accepted),
    
    triggerBusinessApproval: (userId: string, approved: boolean, reason?: string) =>
      triggerAutoNotifications.onBusinessApproval(userId, approved, reason),
    
    triggerNewRequirement: (providerIds: string[], serviceType: string, location: string) =>
      triggerAutoNotifications.onNewRequirement(providerIds, serviceType, location),
  };
};