import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useLocationFilter } from './useLocationFilter';

export interface Professional {
  id: string;
  name: string;
  business_name?: string;
  type: string;
  location: string;
  rating: number;
  review_count: number;
  profile_image_url?: string;
  logo_url?: string;
  experience: number;
  is_verified: boolean;
  email?: string;
  phone?: string;
  description?: string;
  city_name?: string;
  business_type?: string;
  sub_business_type?: string;
  shop_id?: string | null;
  portfolio_id?: string | null;
  provider_user_id?: string | null;
}

export interface ProfessionalFilters {
  city: string;
  experience: string;
  sortBy: string;
  type: string;
  subType: string;
}

export interface CategoryCounts {
  all: number;
  [key: string]: number; // Dynamic counts for each business type
}

export const useProfessionals = () => {
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [allProfessionals, setAllProfessionals] = useState<Professional[]>([]);
  const [categoryCounts, setCategoryCounts] = useState<CategoryCounts>({
    all: 0
  });
  const [businessTypes, setBusinessTypes] = useState<Array<{ id: string; name: string }>>([]);
  const [loading, setLoading] = useState(true);
  const [countsLoading, setCountsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { filterProfessionalsByLocation, getCurrentCity } = useLocationFilter();

  // Function to transform raw business data to Professional objects
  const transformToProfessionals = (businessListings: any[], shopsData: any[], portfoliosData: any[], reviewStats: Map<string, { total: number; count: number }>) => {
    return (businessListings || []).map((registration: any) => {
      const businessType = registration.business_type || '';
      
      // Find related shop and portfolio data
      const hasShop = shopsData?.find(s => s.business_registration_id === registration.id);
      const hasPortfolio = portfoliosData?.find(p => p.business_registration_id === registration.id);
      
      // Get review stats
      const stats = reviewStats.get(registration.id);
      const avgRating = stats ? parseFloat((stats.total / stats.count).toFixed(1)) : 0;
      const reviewCount = stats ? stats.count : 0;
      
      // Determine type based on business type
      let type = 'contractor'; // default
      if (businessType.toLowerCase().includes('vendor')) {
        type = 'vendor';
      } else if (businessType.toLowerCase().includes('manufacturer')) {
        type = 'manufacturer';
      } else if (businessType.toLowerCase().includes('architect')) {
        type = 'architect';
      } else if (businessType.toLowerCase().includes('engineer')) {
        type = 'engineer';
      } else if (businessType.toLowerCase().includes('design')) {
        type = 'designer';
      } else if (businessType.toLowerCase().includes('contractor')) {
        type = 'contractor';
      }

      return {
        id: registration.id,
        name: registration.business_name,
        business_name: registration.business_name,
        type: type,
        location: (registration.cities_served || []).join(', ') || 'Location not specified',
        rating: avgRating,
        review_count: reviewCount,
        profile_image_url: null,
        logo_url: hasShop?.logo_url || hasPortfolio?.logo_url || null,
        experience: registration.years_in_business || 0,
        is_verified: true,
        email: '',
        phone: '',
        description: registration.about_services,
        city_name: (registration.cities_served || [])[0],
        business_type: businessType,
        sub_business_type: (registration.sub_business_types || []).join(', '),
        shop_id: hasShop?.id || null,
        portfolio_id: hasPortfolio?.id || null,
        provider_user_id: registration.user_id || null,
      };
    });
  };

  // Function to calculate category counts from professionals list
  const calculateCategoryCounts = (professionalsList: Professional[]) => {
    const counts: CategoryCounts = {
      all: professionalsList.length
    };
    
    // Calculate counts for each business type from the database (if businessTypes are loaded)
    if (businessTypes && businessTypes.length > 0) {
      businessTypes.forEach(businessType => {
        const typeName = businessType.name.toLowerCase();
        counts[businessType.name] = professionalsList.filter(p => {
          if (!p.business_type) return false;
          const businessTypeLower = p.business_type.toLowerCase();
          // Match exact name or if business type contains the type name
          return businessTypeLower === typeName || businessTypeLower.includes(typeName);
        }).length;
      });
    }
    
    // Also maintain legacy category counts for backward compatibility
    counts.contractors = professionalsList.filter(p => 
      p.type === 'contractor' || 
      p.business_type?.toLowerCase().includes('contractor')).length;
    counts.architects = professionalsList.filter(p => 
      p.type === 'architect' || 
      p.business_type?.toLowerCase().includes('architect')).length;
    counts.designers = professionalsList.filter(p => 
      p.type === 'designer' || 
      p.business_type?.toLowerCase().includes('design')).length;
    counts.engineers = professionalsList.filter(p => 
      p.type === 'engineer' || 
      p.business_type?.toLowerCase().includes('engineer')).length;
    counts.vendors = professionalsList.filter(p => 
      p.type === 'vendor' || 
      p.business_type?.toLowerCase().includes('vendor')).length;
    counts.manufacturers = professionalsList.filter(p => 
      p.type === 'manufacturer' || 
      p.business_type?.toLowerCase().includes('manufactur')).length;
    
    setCategoryCounts(counts);
    return counts;
  };

  // Fetch ALL professionals for category counts (without filters)
  const fetchAllProfessionals = async () => {
    try {
      console.log('Fetching ALL professionals for category counts...');
      setCountsLoading(true);

      const { data: businessListings, error: businessListingsError } = await supabase
        .rpc('get_approved_business_listings');

      if (businessListingsError) {
        console.error('Error fetching business listings:', businessListingsError);
        return [];
      }

      // Fetch shop and portfolio data
      const { data: shopsData } = await supabase
        .from('provider_shops')
        .select('id, business_registration_id, logo_url');

      const { data: portfoliosData } = await supabase
        .from('provider_portfolios')
        .select('id, business_registration_id, logo_url');

      // Fetch review data
      const { data: reviewsData } = await supabase
        .from('reviews')
        .select('business_registration_id, rating')
        .not('business_registration_id', 'is', null);

      // Calculate review stats
      const reviewStats = new Map();
      if (reviewsData) {
        reviewsData.forEach((review: any) => {
          if (!review.business_registration_id) return;
          
          const businessId = review.business_registration_id;
          if (!reviewStats.has(businessId)) {
            reviewStats.set(businessId, { total: 0, count: 0 });
          }
          const stats = reviewStats.get(businessId);
          stats.total += review.rating;
          stats.count += 1;
        });
      }

      // Transform to professionals
      const allProfs = transformToProfessionals(businessListings, shopsData || [], portfoliosData || [], reviewStats);
      
      setAllProfessionals(allProfs);
      
      // Calculate counts after business types are loaded
      if (businessTypes.length > 0) {
        calculateCategoryCounts(allProfs);
      }
      
      console.log('Total professionals for counts:', allProfs.length);
      return allProfs;
    } catch (err) {
      console.error('Error in fetchAllProfessionals:', err);
      return [];
    } finally {
      setCountsLoading(false);
    }
  };

  // Fetch filtered professionals
  const fetchProfessionals = async (filters?: Partial<ProfessionalFilters>) => {
    try {
      console.log('Fetching filtered professionals with filters:', filters);
      setLoading(true);
      setError(null);

      // If we don't have all professionals yet, fetch them first
      if (allProfessionals.length === 0) {
        await fetchAllProfessionals();
      }

      // Start with all professionals and apply filters
      let filteredData = [...allProfessionals];

      // Apply filters
      if (filters?.type && filters.type !== 'all') {
        console.log('Applying type filter:', filters.type);
        // Map filter types (plural) to professional types (singular)
        const typeMap: { [key: string]: string } = {
          'architects': 'architect',
          'engineers': 'engineer', 
          'contractors': 'contractor',
          'vendors': 'vendor',
          'manufacturers': 'manufacturer',
          'designers': 'designer'
        };
        
        const filterTypeLower = filters.type.toLowerCase();
        const targetType = typeMap[filterTypeLower];
        
        if (targetType) {
          // Legacy filter type - use type field
          console.log('Target type to filter by:', targetType);
          filteredData = filteredData.filter(prof => prof.type === targetType);
        } else {
          // New business type name - match by business_type field
          console.log('Filtering by business type name:', filterTypeLower);
          filteredData = filteredData.filter(prof => {
            if (!prof.business_type) return false;
            const businessTypeLower = prof.business_type.toLowerCase();
            return businessTypeLower === filterTypeLower || businessTypeLower.includes(filterTypeLower);
          });
        }
        console.log('After type filter:', filteredData.length, 'professionals');
      }

      if (filters?.experience && filters.experience !== 'any') {
        const minExp = parseInt(filters.experience);
        filteredData = filteredData.filter(prof => prof.experience >= minExp);
      }

      // Apply city filter - temporarily disabled to show all professionals
      // const cityToFilter = filters?.city || getCurrentCity();
      // filteredData = filterProfessionalsByLocation(filteredData);
      
      // Apply sorting
      if (filters?.sortBy === 'rating') {
        filteredData.sort((a, b) => b.rating - a.rating);
      } else if (filters?.sortBy === 'experience') {
        filteredData.sort((a, b) => b.experience - a.experience);
      } else if (filters?.sortBy === 'reviews') {
        filteredData.sort((a, b) => b.review_count - a.review_count);
      }

      console.log('Final filtered professionals:', filteredData.length);
      setProfessionals(filteredData);
    } catch (err) {
      console.error('Error in fetchProfessionals:', err);
      setError('An unexpected error occurred');
      toast.error('Failed to load professionals');
    } finally {
      setLoading(false);
    }
  };

  const fetchBusinessTypes = async () => {
    try {
      const { data, error } = await supabase
        .from('business_types')
        .select('id, name')
        .order('name');

      if (error) {
        console.error('Error fetching business types:', error);
        return;
      }

      setBusinessTypes(data || []);
    } catch (err) {
      console.error('Error in fetchBusinessTypes:', err);
    }
  };

  const getProviderProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('provider_profiles')
        .select(`
          *,
          business_registrations (
            business_name,
            business_types (
              name
            )
          )
        `)
        .eq('user_id', userId)
        .eq('approved', true)
        .eq('is_live', true)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching provider profile:', error);
        return null;
      }

      return data;
    } catch (err) {
      console.error('Error in getProviderProfile:', err);
      return null;
    }
  };

  const getProviderShop = async (businessRegistrationId: string) => {
    try {
      const { data, error } = await supabase
        .from('provider_shops')
        .select('*')
        .eq('business_registration_id', businessRegistrationId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching provider shop:', error);
        return null;
      }

      return data;
    } catch (err) {
      console.error('Error in getProviderShop:', err);
      return null;
    }
  };

  // Recalculate counts when business types or professionals change
  useEffect(() => {
    if (businessTypes.length > 0 && allProfessionals.length > 0) {
      calculateCategoryCounts(allProfessionals);
    }
  }, [businessTypes, allProfessionals.length]);

  // Initial fetch on component mount
  useEffect(() => {
    console.log('useProfessionals: Initial data fetch');
    
    const initializeData = async () => {
      // First, fetch business types (needed for category counts)
      await fetchBusinessTypes();
      
      // Then, fetch all professionals for category counts
      await fetchAllProfessionals();
      
      // Finally, fetch filtered professionals (default: all)
      fetchProfessionals({});
    };

    initializeData();
  }, []);

  return {
    professionals,
    allProfessionals,
    categoryCounts,
    businessTypes,
    loading,
    countsLoading,
    error,
    fetchProfessionals,
    fetchAllProfessionals,
    getProviderProfile,
    getProviderShop,
    refetch: () => fetchProfessionals({})
  };
};
