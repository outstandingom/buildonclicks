
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface City {
  id: string;
  name: string;
  state: string;
}

interface Profile {
  id: string;
  full_name: string | null;
  mobile_number: string | null;
  city_id: string | null;
  address: string | null;
  profile_image_url: string | null;
  user_type: string | null;
  created_at: string | null;
  updated_at: string | null;
  city?: City;
}

export const useProfile = (userId: string | undefined) => {
  const { toast } = useToast();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      setLoading(true);
      fetchProfile();
    } else {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    // Fetch cities only once - they don't change per user
    fetchCities();
  }, []);

  const fetchProfile = async () => {
    if (!userId) return;

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select(`
          *,
          city:cities(id, name, state)
        `)
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        console.error('Error fetching profile:', error);
        toast({
          title: "Error",
          description: "Failed to load profile data.",
          variant: "destructive",
        });
      } else {
        setProfile(data || null);
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCities = async () => {
    try {
      const { data, error } = await supabase
        .from('cities')
        .select('*')
        .order('name');

      if (error) {
        console.error('Error fetching cities:', error);
      } else {
        setCities(data || []);
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    }
  };

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!userId) return { error: new Error('No user ID') };

    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', userId);

      if (error) {
        console.error('Error updating profile:', error);
        toast({
          title: "Error",
          description: "Failed to update profile.",
          variant: "destructive",
        });
        return { error };
      } else {
        await fetchProfile(); // Refresh the profile data
        toast({
          title: "Success",
          description: "Profile updated successfully.",
        });
        return { error: null };
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      return { error };
    }
  };

  return {
    profile,
    cities,
    loading,
    updateProfile,
    refreshProfile: fetchProfile
  };
};

