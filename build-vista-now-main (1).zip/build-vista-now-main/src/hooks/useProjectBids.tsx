
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ProjectBid {
  id: string;
  project_id: string;
  professional_id: string;
  user_id: string;
  bid_amount: number | null;
  timeline_estimate: string | null;
  message: string;
  status: string;
  created_at: string;
  updated_at: string;
  professional?: {
    name: string;
    business_name: string | null;
    rating: number;
    experience: number;
  };
  project?: {
    title: string;
    description: string;
    budget_range: string;
  };
}

export const useProjectBids = (projectId?: string, userId?: string) => {
  const { toast } = useToast();
  const [bids, setBids] = useState<ProjectBid[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (projectId || userId) {
      fetchBids();
    }
  }, [projectId, userId]);

  const fetchBids = async () => {
    try {
      // Get project bids without professional contact info (now secured)
      let query = supabase
        .from('project_bids')
        .select(`
          *,
          project:projects(title, description, budget_range)
        `);

      if (projectId) {
        query = query.eq('project_id', projectId);
      }
      if (userId) {
        query = query.eq('user_id', userId);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching bids:', error);
        toast({
          title: "Error",
          description: "Failed to load bids.",
          variant: "destructive",
        });
        return;
      }

      // Enhance bid data with safe professional information
      const enhancedBids = await Promise.all(
        (data || []).map(async (bid) => {
          // Get safe professional data for each bid
          const { data: profData } = await supabase.rpc(
            'get_professional_safe_data', 
            { professional_id: bid.professional_id }
          );

          return {
            ...bid,
            professional: profData?.[0] ? {
              name: profData[0].name,
              business_name: profData[0].business_name,
              rating: profData[0].rating,
              experience: profData[0].experience
            } : {
              name: 'Professional',
              business_name: 'Business Name Protected',
              rating: 0,
              experience: 0
            }
          };
        })
      );

      setBids(enhancedBids);
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setLoading(false);
    }
  };

  const createBid = async (bidData: {
    project_id: string;
    professional_id: string;
    bid_amount?: number;
    timeline_estimate?: string;
    message: string;
  }) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('project_bids')
        .insert([{ ...bidData, user_id: user.id }]);

      if (error) {
        console.error('Error creating bid:', error);
        toast({
          title: "Error",
          description: "Failed to submit bid.",
          variant: "destructive",
        });
        return false;
      } else {
        toast({
          title: "Success",
          description: "Bid submitted successfully.",
        });
        await fetchBids();
        return true;
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      return false;
    }
  };

  const updateBidStatus = async (bidId: string, status: string) => {
    try {
      const { error } = await supabase
        .from('project_bids')
        .update({ status })
        .eq('id', bidId);

      if (error) {
        console.error('Error updating bid status:', error);
        toast({
          title: "Error",
          description: "Failed to update bid status.",
          variant: "destructive",
        });
        return false;
      } else {
        toast({
          title: "Success",
          description: "Bid status updated successfully.",
        });
        await fetchBids();
        return true;
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      return false;
    }
  };

  return {
    bids,
    loading,
    createBid,
    updateBidStatus,
    refreshBids: fetchBids
  };
};
