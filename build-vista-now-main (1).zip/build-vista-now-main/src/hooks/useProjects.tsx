
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Project {
  id: string;
  user_id: string;
  title: string;
  description: string;
  budget_range: string;
  location: string;
  city_id: string | null;
  project_type: string;
  timeline: string | null;
  status: string;
  created_at: string;
  updated_at: string;
  city?: {
    name: string;
    state: string;
  };
}

export const useProjects = (userId?: string) => {
  const { toast } = useToast();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProjects();
  }, [userId]);

  const fetchProjects = async () => {
    try {
      let query = supabase
        .from('projects')
        .select(`
          *,
          city:cities(name, state)
        `);

      if (userId) {
        query = query.eq('user_id', userId);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching projects:', error);
        toast({
          title: "Error",
          description: "Failed to load projects.",
          variant: "destructive",
        });
      } else {
        setProjects(data || []);
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setLoading(false);
    }
  };

  const createProject = async (projectData: Omit<Project, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('projects')
        .insert([{ ...projectData, user_id: user.id }])
        .select()
        .single();

      if (error) {
        console.error('Error creating project:', error);
        toast({
          title: "Error",
          description: "Failed to create project.",
          variant: "destructive",
        });
        return null;
      } else {
        toast({
          title: "Success",
          description: "Project created successfully.",
        });
        await fetchProjects();
        return data;
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      return null;
    }
  };

  const updateProject = async (projectId: string, updates: Partial<Project>) => {
    try {
      const { error } = await supabase
        .from('projects')
        .update(updates)
        .eq('id', projectId);

      if (error) {
        console.error('Error updating project:', error);
        toast({
          title: "Error",
          description: "Failed to update project.",
          variant: "destructive",
        });
        return false;
      } else {
        toast({
          title: "Success",
          description: "Project updated successfully.",
        });
        await fetchProjects();
        return true;
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      return false;
    }
  };

  return {
    projects,
    loading,
    createProject,
    updateProject,
    refreshProjects: fetchProjects
  };
};
