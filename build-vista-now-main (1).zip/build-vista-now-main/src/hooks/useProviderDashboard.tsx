
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface BusinessRegistration {
  id: string;
  user_id: string;
  business_name: string;
  business_type_id: string;
  registration_number: string;
  vat_gst_number: string | null;
  website: string | null;
  business_license_url: string;
  business_address: string;
  cities_served: string[];
  service_area: string;
  years_in_business: number;
  about_services: string;
  contact_name: string;
  phone_number: string;
  email_address: string;
  alternate_contact: string | null;
  preferred_communication: string;
  linkedin_profile: string | null;
  facebook_page: string | null;
  instagram_handle: string | null;
  other_links: string[] | null;
  government_id_url: string;
  business_certificate_url: string;
  insurance_certificate_url: string | null;
  bank_name: string;
  account_number: string;
  account_type: string;
  ifsc_code: string | null;
  status: string;
  created_at: string;
  updated_at: string;
  rejection_reason: string | null;
}

export const useProviderDashboard = (userId: string | undefined) => {
  const [hasRegistration, setHasRegistration] = useState(false);
  const [businessRegistration, setBusinessRegistration] = useState<BusinessRegistration | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (userId) {
      checkRegistrationStatus();
    } else {
      setLoading(false);
      setHasRegistration(false);
      setBusinessRegistration(null);
    }
  }, [userId]);

  const checkRegistrationStatus = async () => {
    if (!userId) return;

    try {
      // Check if user has business registration
      const { data: hasRegData, error: hasRegError } = await supabase.rpc('user_has_business_registration', {
        user_uuid: userId
      });

      if (hasRegError) {
        console.error('Error checking registration status:', hasRegError);
        toast({
          title: "Error",
          description: "Failed to check registration status.",
          variant: "destructive",
        });
        return;
      }

      setHasRegistration(hasRegData || false);

      // If user has registration, fetch the details
      if (hasRegData) {
        const { data: regData, error: regError } = await supabase
          .from('business_registrations')
          .select('*')
          .eq('user_id', userId)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (regError) {
          console.error('Error fetching registration details:', regError);
        } else {
          setBusinessRegistration(regData);
        }
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setLoading(false);
    }
  };

  const getProfileCompletionPercentage = (): number => {
    if (!businessRegistration) return 20; // Account created only
    
    let completed = 20; // Account created
    
    if (hasRegistration) completed += 40; // Business registration
    if (businessRegistration.status === 'approved') completed += 40; // Admin approval
    
    return completed;
  };

  const getStatusBadgeInfo = () => {
    if (!hasRegistration) {
      return {
        text: 'Registration Required',
        variant: 'destructive' as const,
        color: 'bg-red-100 text-red-700'
      };
    }

    const status = businessRegistration?.status;
    
    switch (status) {
      case 'approved':
        return {
          text: 'Approved',
          variant: 'default' as const,
          color: 'bg-green-100 text-green-700'
        };
      case 'pending':
        return {
          text: 'Under Review',
          variant: 'secondary' as const,
          color: 'bg-yellow-100 text-yellow-700'
        };
      case 'rejected':
        return {
          text: 'Rejected',
          variant: 'destructive' as const,
          color: 'bg-red-100 text-red-700'
        };
      default:
        return {
          text: 'Unknown Status',
          variant: 'outline' as const,
          color: 'bg-gray-100 text-gray-700'
        };
    }
  };

  return {
    hasRegistration,
    businessRegistration,
    loading,
    refreshRegistration: checkRegistrationStatus,
    getProfileCompletionPercentage,
    getStatusBadgeInfo
  };
};
