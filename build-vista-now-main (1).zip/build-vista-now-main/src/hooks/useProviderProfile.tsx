import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export type ProviderRole = 'vendor' | 'contractor' | 'architect' | 'manufacturer';

interface ProviderProfile {
  id: string;
  user_id: string;
  business_registration_id?: string;
  role: ProviderRole;
  approved: boolean;
  slug?: string;
  display_name?: string;
  bio?: string;
  phone?: string;
  whatsapp?: string;
  address_street?: string;
  address_city?: string;
  address_pincode?: string;
  working_hours?: any;
  is_live: boolean;
  created_at: string;
  updated_at: string;
}

export const useProviderProfile = (userId: string | undefined) => {
  const [profile, setProfile] = useState<ProviderProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (userId) {
      fetchProfile();
    } else {
      setLoading(false);
    }
  }, [userId]);

  const fetchProfile = async () => {
    if (!userId) return;

    try {
      const { data, error } = await supabase
        .from('provider_profiles')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching provider profile:', error);
        toast({
          title: "Error",
          description: "Failed to fetch provider profile.",
          variant: "destructive",
        });
        return;
      }

      setProfile(data);
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setLoading(false);
    }
  };

  const createProfile = async (profileData: Partial<ProviderProfile>) => {
    if (!userId) return;

    try {
      const { data, error } = await supabase
        .from('provider_profiles')
        .insert({
          user_id: userId,
          role: profileData.role!,
          ...profileData
        })
        .select()
        .single();

      if (error) {
        console.error('Error creating profile:', error);
        toast({
          title: "Error",
          description: "Failed to create provider profile.",
          variant: "destructive",
        });
        return false;
      }

      setProfile(data);
      toast({
        title: "Success",
        description: "Provider profile created successfully.",
      });
      return true;
    } catch (error) {
      console.error('Unexpected error:', error);
      return false;
    }
  };

  const updateProfile = async (updates: Partial<ProviderProfile>) => {
    if (!userId || !profile) return;

    try {
      const { data, error } = await supabase
        .from('provider_profiles')
        .update(updates)
        .eq('user_id', userId)
        .select()
        .single();

      if (error) {
        console.error('Error updating profile:', error);
        toast({
          title: "Error",
          description: "Failed to update provider profile.",
          variant: "destructive",
        });
        return false;
      }

      setProfile(data);
      toast({
        title: "Success",
        description: "Provider profile updated successfully.",
      });
      return true;
    } catch (error) {
      console.error('Unexpected error:', error);
      return false;
    }
  };

  return {
    profile,
    loading,
    createProfile,
    updateProfile,
    refreshProfile: fetchProfile
  };
};