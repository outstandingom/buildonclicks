import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

interface ReferralStats {
  referral_code: string;
  total_referrals: number;
  total_credits_earned: number;
  successful_referrals: number;
  pending_referrals: number;
}

interface ReferralHistory {
  id: string;
  referee_name: string;
  status: 'pending' | 'completed' | 'expired';
  reward_type: string;
  credits_earned: number;
  created_at: string;
  completed_at?: string;
}

export const useReferrals = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [stats, setStats] = useState<ReferralStats | null>(null);
  const [history, setHistory] = useState<ReferralHistory[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchReferralStats = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .rpc('get_user_referral_stats', { p_user_id: user.id });

      if (error) {
        console.error('Error fetching referral stats:', error);
        return;
      }

      if (data && data.length > 0) {
        setStats(data[0]);
      }
    } catch (error) {
      console.error('Error fetching referral stats:', error);
    }
  };

  const fetchReferralHistory = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('referrals')
        .select(`
          id,
          status,
          reward_type,
          created_at,
          completed_at,
          profiles!referrals_referee_id_fkey(full_name),
          referral_transactions!inner(credits_amount)
        `)
        .eq('referrer_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching referral history:', error);
        return;
      }

      const formattedHistory = data?.map(item => ({
        id: item.id,
        referee_name: item.profiles?.full_name || 'Unknown User',
        status: item.status as 'pending' | 'completed' | 'expired',
        reward_type: item.reward_type,
        credits_earned: item.referral_transactions?.[0]?.credits_amount || 0,
        created_at: item.created_at,
        completed_at: item.completed_at
      })) || [];

      setHistory(formattedHistory);
    } catch (error) {
      console.error('Error fetching referral history:', error);
    }
  };

  const processReferralCode = async (referralCode: string): Promise<boolean> => {
    if (!user || !referralCode) return false;

    try {
      const { data, error } = await supabase
        .rpc('process_referral_signup', {
          p_referee_id: user.id,
          p_referral_code: referralCode
        });

      if (error) {
        console.error('Error processing referral:', error);
        return false;
      }

      if (data) {
        toast({
          title: "Welcome Bonus!",
          description: "Your referral bonus has been added to your account.",
        });
        await fetchReferralStats();
        return true;
      }

      return false;
    } catch (error) {
      console.error('Error processing referral:', error);
      return false;
    }
  };

  const generateShareUrl = (referralCode: string): string => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/?ref=${referralCode}`;
  };

  const shareReferral = async (referralCode: string, method: 'whatsapp' | 'copy' | 'sms') => {
    const shareUrl = generateShareUrl(referralCode);
    const message = `Join this amazing platform and get bonus credits! Use my referral code: ${referralCode} or click: ${shareUrl}`;

    switch (method) {
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
        break;
      case 'sms':
        window.open(`sms:?body=${encodeURIComponent(message)}`, '_blank');
        break;
      case 'copy':
        try {
          await navigator.clipboard.writeText(shareUrl);
          toast({
            title: "Copied!",
            description: "Referral link copied to clipboard.",
          });
        } catch (error) {
          console.error('Failed to copy:', error);
          toast({
            title: "Error",
            description: "Failed to copy link.",
            variant: "destructive",
          });
        }
        break;
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchReferralStats(), fetchReferralHistory()]);
      setLoading(false);
    };

    if (user) {
      loadData();
    }
  }, [user]);

  return {
    stats,
    history,
    loading,
    processReferralCode,
    shareReferral,
    generateShareUrl,
    refreshData: async () => {
      await Promise.all([fetchReferralStats(), fetchReferralHistory()]);
    }
  };
};