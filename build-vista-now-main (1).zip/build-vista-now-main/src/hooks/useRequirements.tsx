
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export interface Requirement {
  id: string;
  user_id: string;
  title: string;
  service_type: string;
  city: string;
  description: string;
  timeline: string;
  contact_preference: string;
  contact_info?: string; // New optional field
  attachments: any;
  status: 'active' | 'closed' | 'completed';
  created_at: string;
  updated_at: string;
}

export const useRequirements = () => {
  const { user } = useAuth();
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRequirements = async () => {
    if (!user) {
      setRequirements([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('requirements')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRequirements((data || []) as Requirement[]);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const deleteRequirement = async (id: string) => {
    try {
      const { error } = await supabase
        .from('requirements')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setRequirements(prev => prev.filter(req => req.id !== id));
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const updateRequirementStatus = async (id: string, status: 'active' | 'closed' | 'completed') => {
    try {
      const { error } = await supabase
        .from('requirements')
        .update({ status })
        .eq('id', id);

      if (error) throw error;
      
      setRequirements(prev => 
        prev.map(req => req.id === id ? { ...req, status } : req)
      );
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  useEffect(() => {
    fetchRequirements();
  }, [user]);

  return {
    requirements,
    loading,
    error,
    refetch: fetchRequirements,
    deleteRequirement,
    updateRequirementStatus
  };
};

// Hook for service providers to view matching requirements  
export const useMatchingRequirements = () => {
  const { user } = useAuth();
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMatchingRequirements = async () => {
    if (!user) {
      setRequirements([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      // Add timeout to prevent hanging on network issues
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 8000)
      );
      
      // First, check if user has approved business registration
      const businessRegPromise = supabase
        .from('business_registrations')
        .select('status, cities_served')
        .eq('user_id', user.id)
        .single();

      const businessResult = await Promise.race([
        businessRegPromise,
        timeoutPromise
      ]) as any;
      
      const { data: businessReg, error: businessError } = businessResult;

      if (businessError) {
        if (businessError.message.includes('timeout')) {
          // Network timeout - show offline fallback
          setError('Network connectivity issues. Showing sample data.');
          setRequirements([
            {
              id: 'sample-1',
              user_id: 'sample-user',
              title: 'Need Construction Materials',
              service_type: 'Material Supplier',
              city: 'Bhopal',
              description: 'Looking for high quality cement and steel for residential construction project.',
              timeline: 'Within 2 weeks',
              contact_preference: 'WhatsApp',
              contact_info: null,
              attachments: [],
              status: 'active' as const,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            }
          ]);
          return;
        } else if (businessError.code === 'PGRST116') {
          setError('Please complete your business registration first.');
        } else {
          setError('Error checking business registration: ' + businessError.message);
        }
        return;
      }

      if (!businessReg) {
        setError('No business registration found. Please complete your registration.');
        return;
      }

      if (businessReg.status !== 'approved') {
        setError(`Your business registration is ${businessReg.status}. Please wait for approval or complete your registration.`);
        return;
      }

      console.log('Business registration found:', {
        status: businessReg.status,
        cities_served: businessReg.cities_served
      });

      // Now fetch all active requirements (no city filtering for now)
      const requirementsPromise = supabase
        .from('requirements')
        .select('*')
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      const requirementsResult = await Promise.race([
        requirementsPromise,
        timeoutPromise
      ]) as any;
      
      const { data, error } = requirementsResult;

      if (error) {
        console.error('Error fetching requirements:', error);
        if (error.message.includes('timeout')) {
          setError('Network connectivity issues. Please try again later.');
        } else {
          setError('Failed to load requirements: ' + error.message);
        }
        return;
      }

      setRequirements((data || []) as Requirement[]);
      
    } catch (err: any) {
      console.error('Unexpected error fetching requirements:', err);
      if (err.message.includes('timeout')) {
        setError('Network timeout. Please check your connection and try again.');
      } else {
        setError('An unexpected error occurred: ' + err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMatchingRequirements();
  }, [user]);

  return {
    requirements,
    loading,
    error,
    refetch: fetchMatchingRequirements
  };
};
