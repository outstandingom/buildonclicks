
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Review {
  id: string;
  professional_id: string | null;
  business_registration_id: string | null;
  user_id: string;
  project_id: string | null;
  rating: number;
  comment: string | null;
  created_at: string;
  professional?: {
    name: string;
    business_name: string | null;
  };
  project?: {
    title: string;
  };
  profiles?: {
    full_name: string;
    profile_image_url: string | null;
  };
}

export const useReviews = (professionalId?: string, userId?: string, businessRegistrationId?: string) => {
  const { toast } = useToast();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (professionalId || userId || businessRegistrationId) {
      fetchReviews();
    }
  }, [professionalId, userId, businessRegistrationId]);

  const fetchReviews = async () => {
    try {
      // Get reviews data
      let query = supabase
        .from('reviews')
        .select(`
          *,
          project:projects(title)
        `);

      if (professionalId) {
        query = query.eq('professional_id', professionalId);
      }
      if (userId) {
        query = query.eq('user_id', userId);
      }
      if (businessRegistrationId) {
        query = query.eq('business_registration_id', businessRegistrationId);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching reviews:', error);
        toast({
          title: "Error",
          description: "Failed to load reviews.",
          variant: "destructive",
        });
        return;
      }

      // Enhance review data with user profiles and professional information
      const enhancedReviews = await Promise.all(
        (data || []).map(async (review) => {
          // Get user profile data
          const { data: profileData } = await supabase
            .from('profiles')
            .select('full_name, profile_image_url')
            .eq('id', review.user_id)
            .single();

          // Get safe professional data if professional_id exists
          let professionalData = null;
          if (review.professional_id) {
            const { data: profData } = await supabase.rpc(
              'get_professional_safe_data', 
              { professional_id: review.professional_id }
            );
            professionalData = profData?.[0] ? {
              name: profData[0].name,
              business_name: profData[0].business_name
            } : null;
          }

          return {
            ...review,
            profiles: profileData || { full_name: 'Anonymous User', profile_image_url: null },
            professional: professionalData
          };
        })
      );

      setReviews(enhancedReviews as Review[]);
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setLoading(false);
    }
  };

  const createReview = async (reviewData: {
    professional_id?: string;
    business_registration_id?: string;
    project_id?: string;
    rating: number;
    comment?: string;
  }) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('reviews')
        .insert([{ ...reviewData, user_id: user.id }]);

      if (error) {
        console.error('Error creating review:', error);
        toast({
          title: "Error",
          description: "Failed to submit review.",
          variant: "destructive",
        });
        return false;
      } else {
        toast({
          title: "Success",
          description: "Review submitted successfully.",
        });
        await fetchReviews();
        return true;
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      return false;
    }
  };

  const updateReview = async (reviewId: string, updates: { rating?: number; comment?: string }) => {
    try {
      const { error } = await supabase
        .from('reviews')
        .update(updates)
        .eq('id', reviewId);

      if (error) {
        console.error('Error updating review:', error);
        toast({
          title: "Error",
          description: "Failed to update review.",
          variant: "destructive",
        });
        return false;
      } else {
        toast({
          title: "Success",
          description: "Review updated successfully.",
        });
        await fetchReviews();
        return true;
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      return false;
    }
  };

  return {
    reviews,
    loading,
    createReview,
    updateReview,
    refreshReviews: fetchReviews
  };
};
