import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface SavedPost {
  id: string;
  post_id: string;
  created_at: string;
  post: {
    id: string;
    content: string;
    media_url: string | null;
    media_type: string | null;
    likes_count: number;
    comments_count: number;
    created_at: string;
    user_id: string;
    profiles: {
      full_name: string | null;
      profile_image_url: string | null;
    } | null;
    business_registrations: {
      business_name: string;
    } | null;
  };
}

export const useSavedPosts = (userId: string | undefined) => {
  const { toast } = useToast();
  const [savedPosts, setSavedPosts] = useState<SavedPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      setLoading(true);
      fetchSavedPosts();
    } else {
      setLoading(false);
    }
  }, [userId]);

  const fetchSavedPosts = async () => {
    if (!userId) return;

    try {
      // First get saved posts with basic post data
      const { data: savedData, error: savedError } = await supabase
        .from('saved_social_posts')
        .select(`
          id,
          post_id,
          created_at,
          social_posts!inner (
            id,
            content,
            media_url,
            media_type,
            likes_count,
            comments_count,
            created_at,
            user_id
          )
        `)
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (savedError) throw savedError;

      if (!savedData || savedData.length === 0) {
        setSavedPosts([]);
        setLoading(false);
        return;
      }

      // Get unique user IDs from posts
      const userIds = [...new Set(savedData.map((item: any) => item.social_posts.user_id))];

      // Fetch profiles for these users
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, profile_image_url')
        .in('id', userIds);

      if (profilesError) {
        console.error('Error fetching profiles:', profilesError);
      }

      // Fetch business registrations for these users (if they have approved businesses)
      const { data: businessRegData, error: businessRegError } = await supabase
        .from('business_registrations')
        .select('user_id, business_name')
        .in('user_id', userIds)
        .eq('status', 'approved');

      if (businessRegError) {
        console.error('Error fetching business registrations:', businessRegError);
      }

      // Create maps for profiles and business registrations
      const profilesMap = new Map(
        profilesData?.map(profile => [profile.id, profile]) || []
      );
      
      const businessRegMap = new Map(
        businessRegData?.map(business => [business.user_id, business]) || []
      );

      // Transform the data to match our interface
      const transformedData = savedData.map((item: any) => {
        const userId = item.social_posts.user_id;
        return {
          id: item.id,
          post_id: item.post_id,
          created_at: item.created_at,
          post: {
            ...item.social_posts,
            profiles: profilesMap.get(userId) || null,
            business_registrations: businessRegMap.get(userId) || null
          }
        };
      });

      setSavedPosts(transformedData);
    } catch (error) {
      console.error('Error fetching saved posts:', error);
      toast({
        title: "Error",
        description: "Failed to load saved posts.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const removeSavedPost = async (savedId: string) => {
    try {
      const { error } = await supabase
        .from('saved_social_posts')
        .delete()
        .eq('id', savedId);

      if (error) throw error;

      setSavedPosts(prev => prev.filter(p => p.id !== savedId));
      toast({
        title: "Success",
        description: "Post removed from saved items.",
      });
    } catch (error) {
      console.error('Error removing saved post:', error);
      toast({
        title: "Error",
        description: "Failed to remove post.",
        variant: "destructive",
      });
    }
  };

  return {
    savedPosts,
    loading,
    removeSavedPost,
    refreshSavedPosts: fetchSavedPosts
  };
};
