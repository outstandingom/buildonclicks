import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface SavedProfessional {
  id: string;
  professional_id: string;
  professional: {
    id: string;
    name: string;
    business_name: string | null;
    type: string;
    rating: number;
    review_count: number;
    experience: number;
    is_verified: boolean;
    profile_image_url: string | null;
    city: {
      name: string;
    } | null;
  };
}

export const useSavedProfessionals = (userId: string | undefined) => {
  const { toast } = useToast();
  const [savedProfessionals, setSavedProfessionals] = useState<SavedProfessional[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      setLoading(true);
      fetchSavedProfessionals();
    } else {
      setLoading(false);
    }
  }, [userId]);

  const fetchSavedProfessionals = async () => {
    if (!userId) return;

    try {
      // First get the saved professional IDs
      const { data: savedData, error: savedError } = await supabase
        .from('saved_professionals')
        .select('id, professional_id')
        .eq('user_id', userId);

      if (savedError) {
        console.error('Error fetching saved professionals:', savedError);
        toast({
          title: "Error",
          description: "Failed to load saved professionals.",
          variant: "destructive",
        });
        return;
      }

      if (!savedData || savedData.length === 0) {
        setSavedProfessionals([]);
        return;
      }

      // Collect business registration IDs for review stats
      const businessIds = savedData
        .map((saved) => saved.professional_id)
        .filter((id): id is string => Boolean(id));

      const reviewStats = new Map<string, { total: number; count: number }>();

      if (businessIds.length > 0) {
        const { data: reviewsData, error: reviewsError } = await supabase
          .from('reviews')
          .select('business_registration_id, rating')
          .in('business_registration_id', businessIds);

        if (reviewsError) {
          console.error('Error fetching review stats for saved professionals:', reviewsError);
        } else if (reviewsData) {
          (reviewsData as any[]).forEach((review) => {
            const businessId = review.business_registration_id as string | null;
            if (!businessId) return;

            if (!reviewStats.has(businessId)) {
              reviewStats.set(businessId, { total: 0, count: 0 });
            }

            const stats = reviewStats.get(businessId)!;
            stats.total += review.rating;
            stats.count += 1;
          });
        }
      }

      // Fetch shop and portfolio logos for all business IDs
      const { data: shopsData } = await supabase
        .from('provider_shops')
        .select('business_registration_id, logo_url')
        .in('business_registration_id', businessIds);

      const { data: portfoliosData } = await supabase
        .from('provider_portfolios')
        .select('business_registration_id, logo_url')
        .in('business_registration_id', businessIds);

      const shopsMap = new Map(shopsData?.map(s => [s.business_registration_id, s.logo_url]) || []);
      const portfoliosMap = new Map(portfoliosData?.map(p => [p.business_registration_id, p.logo_url]) || []);

      // Then get the safe business data for each saved professional using approved listings
      const professionalPromises = savedData.map(async (saved) => {
        if (!saved.professional_id) return null;

        const { data: businessData, error: businessError } = await supabase.rpc(
          'get_approved_business_listing',
          { business_id: saved.professional_id }
        );

        if (businessError || !businessData || businessData.length === 0) {
          console.error('Error fetching saved professional business data:', businessError);
          return null; // Professional data not available (security restricted or not approved)
        }

        const business = (businessData as any[])[0];
        const stats = reviewStats.get(saved.professional_id);
        const avgRating = stats ? parseFloat((stats.total / stats.count).toFixed(1)) : 0;
        const reviewCount = stats ? stats.count : 0;

        const businessType = (business.business_type || '') as string;
        let type = 'contractor';
        const lowerType = businessType.toLowerCase();
        if (lowerType.includes('vendor')) type = 'vendor';
        else if (lowerType.includes('manufacturer')) type = 'manufacturer';
        else if (lowerType.includes('architect')) type = 'architect';
        else if (lowerType.includes('engineer')) type = 'engineer';
        else if (lowerType.includes('design')) type = 'designer';
        else if (lowerType.includes('contractor')) type = 'contractor';

        // Get logo from shop or portfolio
        const logoUrl = shopsMap.get(saved.professional_id) || portfoliosMap.get(saved.professional_id) || null;

        // Get city name from cities_served if available
        const cityName = business.cities_served && business.cities_served.length > 0
          ? business.cities_served[0]
          : 'Location not specified';

        return {
          id: saved.id,
          professional_id: saved.professional_id,
          professional: {
            id: business.id,
            name: business.business_name || 'Unnamed Business',
            business_name: business.business_name || 'Unnamed Business',
            type,
            rating: avgRating,
            review_count: reviewCount,
            experience: business.years_in_business || 0,
            is_verified: true,
            profile_image_url: logoUrl,
            city: { name: cityName },
          },
        } as SavedProfessional;
      });

      const professionals = await Promise.all(professionalPromises);
      const validProfessionals = professionals.filter((p) => p !== null) as SavedProfessional[];

      setSavedProfessionals(validProfessionals);
      
      if (validProfessionals.length < savedData.length) {
        console.warn(`Some saved professionals could not be loaded. ${savedData.length - validProfessionals.length} professionals may have been removed or are no longer approved.`);
      }
    } catch (error) {
      console.error('Unexpected error fetching saved professionals:', error);
      toast({
        title: "Error",
        description: "Failed to load saved professionals. Please try refreshing the page.",
        variant: "destructive",
      });
      setSavedProfessionals([]);
    } finally {
      setLoading(false);
    }
  };

  const removeSavedProfessional = async (savedId: string) => {
    try {
      const { error } = await supabase
        .from('saved_professionals')
        .delete()
        .eq('id', savedId);

      if (error) {
        console.error('Error removing saved professional:', error);
        toast({
          title: "Error",
          description: "Failed to remove professional.",
          variant: "destructive",
        });
      } else {
        setSavedProfessionals(prev => prev.filter(p => p.id !== savedId));
        toast({
          title: "Success",
          description: "Professional removed from saved list.",
        });
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    }
  };

  return {
    savedProfessionals,
    loading,
    removeSavedProfessional,
    refreshSavedProfessionals: fetchSavedProfessionals
  };
};
