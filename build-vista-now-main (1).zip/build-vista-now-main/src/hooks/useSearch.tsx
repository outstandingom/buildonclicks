import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface SearchResult {
  id: string;
  title: string;
  description: string;
  type: 'professional' | 'product';
  location?: string;
  rating?: number;
  price?: number;
  image?: string;
  category?: string;
  businessName?: string;
}

export const useSearch = () => {
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const searchProfessionals = async (query: string): Promise<SearchResult[]> => {
    try {
      // Use the same RPC function that provides approved business listings
      const { data: businessListings, error } = await supabase
        .rpc('get_approved_business_listings');

      if (error) {
        console.error('Error searching professionals:', error);
        return [];
      }

      // Filter and map the business listings based on search query
      const filteredBusinesses = (businessListings || []).filter((business: any) => {
        const searchQuery = query.toLowerCase();
        return (
          business.business_name?.toLowerCase().includes(searchQuery) ||
          business.about_services?.toLowerCase().includes(searchQuery) ||
          business.business_type?.toLowerCase().includes(searchQuery) ||
          business.sub_business_types?.some((subType: string) => 
            subType.toLowerCase().includes(searchQuery)
          ) ||
          business.cities_served?.some((city: string) => 
            city.toLowerCase().includes(searchQuery)
          )
        );
      }).slice(0, 10); // Limit to 10 results

      return filteredBusinesses.map((business: any) => {
        // Determine type based on business type
        let type = 'contractor';
        const businessType = business.business_type?.toLowerCase() || '';
        if (businessType.includes('vendor')) {
          type = 'vendor';
        } else if (businessType.includes('manufacturer')) {
          type = 'manufacturer';
        } else if (businessType.includes('architect')) {
          type = 'architect';
        } else if (businessType.includes('engineer')) {
          type = 'engineer';
        } else if (businessType.includes('design')) {
          type = 'designer';
        } else if (businessType.includes('contractor')) {
          type = 'contractor';
        }

        return {
          id: business.id,
          title: business.business_name,
          description: business.about_services || `${business.business_type} service provider`,
          type: 'professional' as const,
          location: (business.cities_served || []).join(', '),
          rating: 4.5, // Default rating
          image: null, // No profile image from business registrations
          category: type,
          businessName: business.business_name
        };
      });
    } catch (err) {
      console.error('Error in searchProfessionals:', err);
      return [];
    }
  };

  const searchProducts = async (query: string): Promise<SearchResult[]> => {
    try {
      const { data, error } = await supabase
        .from('shop_products')
        .select(`
          id,
          name,
          description,
          price,
          category,
          image_url,
          provider_shops (
            shop_name
          )
        `)
        .or(`name.ilike.%${query}%, description.ilike.%${query}%, category.ilike.%${query}%`)
        .limit(10);

      if (error) {
        console.error('Error searching products:', error);
        return [];
      }

      return (data || []).map(product => ({
        id: product.id,
        title: product.name,
        description: product.description || `${product.category} product`,
        type: 'product' as const,
        price: Number(product.price),
        image: product.image_url,
        category: product.category,
        businessName: product.provider_shops?.shop_name
      }));
    } catch (err) {
      console.error('Error in searchProducts:', err);
      return [];
    }
  };

  const search = useCallback(async (query: string) => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const [professionals, products] = await Promise.all([
        searchProfessionals(query.trim()),
        searchProducts(query.trim())
      ]);

      // Combine and sort results - professionals first, then products
      const combinedResults = [...professionals, ...products];
      setResults(combinedResults);
    } catch (err) {
      console.error('Error in search:', err);
      setError('Search failed. Please try again.');
      toast.error('Search failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  const clearResults = useCallback(() => {
    setResults([]);
    setError(null);
  }, []);

  return {
    results,
    loading,
    error,
    search,
    clearResults
  };
};