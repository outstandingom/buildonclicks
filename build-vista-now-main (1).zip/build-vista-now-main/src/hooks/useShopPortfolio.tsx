
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Database } from '@/integrations/supabase/types';

type ShopRow = Database['public']['Tables']['provider_shops']['Row'];
type ShopInsert = Database['public']['Tables']['provider_shops']['Insert'];
type ShopUpdate = Database['public']['Tables']['provider_shops']['Update'];

type PortfolioRow = Database['public']['Tables']['provider_portfolios']['Row'];
type PortfolioInsert = Database['public']['Tables']['provider_portfolios']['Insert'];
type PortfolioUpdate = Database['public']['Tables']['provider_portfolios']['Update'];

interface ShopData {
  shopName: string;
  description: string;
  categories: string[];
  workingHours: string;
  deliveryOptions: string[];
  minOrderValue?: number;
  images: string[];
  featured: boolean;
}

interface PortfolioData {
  title: string;
  description: string;
  services: string[];
  skills: string[];
  experience: string;
  projects: ProjectData[];
  certifications: string[];
  images: string[];
  banner_url?: string;
  logo_url?: string;
}

interface ProjectData {
  title: string;
  description: string;
  duration: string;
  clientType: string;
  images: string[];
}

export const useShopPortfolio = (businessRegistrationId: string | undefined) => {
  const [shop, setShop] = useState<ShopRow | null>(null);
  const [portfolio, setPortfolio] = useState<PortfolioRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (businessRegistrationId) {
      fetchShopPortfolio();
    } else {
      setLoading(false);
      setShop(null);
      setPortfolio(null);
    }
  }, [businessRegistrationId]);

  const fetchShopPortfolio = async () => {
    if (!businessRegistrationId) {
      setLoading(false);
      return;
    }

    try {
      // Fetch both shop and portfolio in parallel to improve performance
      const [shopResult, portfolioResult] = await Promise.all([
        supabase
          .from('provider_shops')
          .select('*')
          .eq('business_registration_id', businessRegistrationId)
          .maybeSingle(),
        supabase
          .from('provider_portfolios')
          .select('*')
          .eq('business_registration_id', businessRegistrationId)
          .maybeSingle()
      ]);

      const { data: shopData, error: shopError } = shopResult;
      const { data: portfolioData, error: portfolioError } = portfolioResult;

      if (shopError && shopError.code !== 'PGRST116') {
        console.error('Error fetching shop:', shopError);
      } else {
        setShop(shopData);
      }

      if (portfolioError && portfolioError.code !== 'PGRST116') {
        console.error('Error fetching portfolio:', portfolioError);
      } else {
        setPortfolio(portfolioData);
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    } finally {
      setLoading(false);
    }
  };

  const createShop = async (shopData: ShopData) => {
    if (!businessRegistrationId) return false;

    setIsSubmitting(true);
    try {
      const shopInsert: ShopInsert = {
        business_registration_id: businessRegistrationId,
        shop_name: shopData.shopName,
        description: shopData.description,
        categories: shopData.categories,
        working_hours: shopData.workingHours,
        delivery_options: shopData.deliveryOptions,
        min_order_value: shopData.minOrderValue,
        images: shopData.images,
        featured: shopData.featured,
      };

      const { error } = await supabase
        .from('provider_shops')
        .insert(shopInsert);

      if (error) {
        throw error;
      }

      toast({
        title: "Shop Created Successfully!",
        description: "Your shop has been created and is now live.",
      });

      await fetchShopPortfolio();
      return true;
    } catch (error) {
      console.error('Error creating shop:', error);
      toast({
        title: "Failed to Create Shop",
        description: "There was an error creating your shop. Please try again.",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  const createPortfolio = async (portfolioData: PortfolioData) => {
    if (!businessRegistrationId) return false;

    setIsSubmitting(true);
    try {
      const portfolioInsert: PortfolioInsert = {
        business_registration_id: businessRegistrationId,
        title: portfolioData.title,
        description: portfolioData.description,
        services: portfolioData.services,
        skills: portfolioData.skills,
        experience: portfolioData.experience,
        projects: portfolioData.projects as any, // Type assertion to handle JSON conversion
        certifications: portfolioData.certifications,
        images: portfolioData.images,
        banner_url: portfolioData.banner_url,
        logo_url: portfolioData.logo_url,
      };

      const { error } = await supabase
        .from('provider_portfolios')
        .insert(portfolioInsert);

      if (error) {
        throw error;
      }

      toast({
        title: "Portfolio Created Successfully!",
        description: "Your portfolio has been created and is now live.",
      });

      await fetchShopPortfolio();
      return true;
    } catch (error) {
      console.error('Error creating portfolio:', error);
      toast({
        title: "Failed to Create Portfolio",
        description: "There was an error creating your portfolio. Please try again.",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  const updateShop = async (shopData: Partial<ShopData>) => {
    if (!shop?.id) return false;

    setIsSubmitting(true);
    try {
      const shopUpdate: ShopUpdate = {};
      
      if (shopData.shopName !== undefined) shopUpdate.shop_name = shopData.shopName;
      if (shopData.description !== undefined) shopUpdate.description = shopData.description;
      if (shopData.categories !== undefined) shopUpdate.categories = shopData.categories;
      if (shopData.workingHours !== undefined) shopUpdate.working_hours = shopData.workingHours;
      if (shopData.deliveryOptions !== undefined) shopUpdate.delivery_options = shopData.deliveryOptions;
      if (shopData.minOrderValue !== undefined) shopUpdate.min_order_value = shopData.minOrderValue;
      if (shopData.images !== undefined) shopUpdate.images = shopData.images;
      if (shopData.featured !== undefined) shopUpdate.featured = shopData.featured;

      const { error } = await supabase
        .from('provider_shops')
        .update(shopUpdate)
        .eq('id', shop.id);

      if (error) {
        throw error;
      }

      toast({
        title: "Shop Updated Successfully!",
        description: "Your shop has been updated.",
      });

      await fetchShopPortfolio();
      return true;
    } catch (error) {
      console.error('Error updating shop:', error);
      toast({
        title: "Failed to Update Shop",
        description: "There was an error updating your shop. Please try again.",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  const updatePortfolio = async (portfolioData: Partial<PortfolioData>) => {
    if (!portfolio?.id) return false;

    setIsSubmitting(true);
    try {
      const portfolioUpdate: PortfolioUpdate = {};
      
      if (portfolioData.title !== undefined) portfolioUpdate.title = portfolioData.title;
      if (portfolioData.description !== undefined) portfolioUpdate.description = portfolioData.description;
      if (portfolioData.services !== undefined) portfolioUpdate.services = portfolioData.services;
      if (portfolioData.skills !== undefined) portfolioUpdate.skills = portfolioData.skills;
      if (portfolioData.experience !== undefined) portfolioUpdate.experience = portfolioData.experience;
      if (portfolioData.projects !== undefined) portfolioUpdate.projects = portfolioData.projects as any; // Type assertion to handle JSON conversion
      if (portfolioData.certifications !== undefined) portfolioUpdate.certifications = portfolioData.certifications;
      if (portfolioData.images !== undefined) portfolioUpdate.images = portfolioData.images;
      if (portfolioData.banner_url !== undefined) portfolioUpdate.banner_url = portfolioData.banner_url;
      if (portfolioData.logo_url !== undefined) portfolioUpdate.logo_url = portfolioData.logo_url;

      const { error } = await supabase
        .from('provider_portfolios')
        .update(portfolioUpdate)
        .eq('id', portfolio.id);

      if (error) {
        throw error;
      }

      toast({
        title: "Portfolio Updated Successfully!",
        description: "Your portfolio has been updated.",
      });

      await fetchShopPortfolio();
      return true;
    } catch (error) {
      console.error('Error updating portfolio:', error);
      toast({
        title: "Failed to Update Portfolio",
        description: "There was an error updating your portfolio. Please try again.",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    shop,
    portfolio,
    loading,
    isSubmitting,
    createShop,
    createPortfolio,
    updateShop,
    updatePortfolio,
    refreshData: fetchShopPortfolio,
  };
};
