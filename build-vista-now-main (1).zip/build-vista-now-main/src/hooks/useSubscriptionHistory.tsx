import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface SubscriptionHistory {
  id: string;
  plan_id: string;
  plan_name: string;
  plan_description: string;
  credits_added: number;
  amount: number;
  status: string;
  starts_at: string;
  expires_at: string;
  created_at: string;
  razorpay_order_id: string;
  razorpay_payment_id: string;
}

export const useSubscriptionHistory = () => {
  return useQuery({
    queryKey: ["subscription-history"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from("user_subscriptions")
        .select(`
          id,
          credits_added,
          starts_at,
          expires_at,
          created_at,
          status,
          razorpay_order_id,
          razorpay_payment_id,
          subscription_plans (
            id,
            name,
            description,
            price_inr
          )
        `)
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;

      return data.map((sub: any) => ({
        id: sub.id,
        plan_id: sub.subscription_plans.id,
        plan_name: sub.subscription_plans.name,
        plan_description: sub.subscription_plans.description,
        credits_added: sub.credits_added,
        amount: sub.subscription_plans.price_inr,
        status: sub.status,
        starts_at: sub.starts_at,
        expires_at: sub.expires_at,
        created_at: sub.created_at,
        razorpay_order_id: sub.razorpay_order_id,
        razorpay_payment_id: sub.razorpay_payment_id,
      })) as SubscriptionHistory[];
    },
  });
};
