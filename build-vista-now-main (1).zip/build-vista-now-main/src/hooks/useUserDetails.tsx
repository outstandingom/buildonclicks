import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface UserProfile {
  id: string;
  full_name: string;
  mobile_number: string;
  user_type: string;
  city_name: string;
  is_active: boolean;
  created_at: string;
  profile_image_url?: string;
  email?: string;
}

interface CreditSummary {
  total_credits: number;
  used_credits: number;
  available_credits: number;
  free_credits_given: boolean;
  access_logs: any[];
  last_activity?: string;
}

interface Subscription {
  id: string;
  plan_name: string;
  plan_description: string;
  credits_added: number;
  amount: number;
  status: string;
  starts_at: string;
  expires_at: string;
  created_at: string;
  razorpay_payment_id: string;
}

interface ReferralStats {
  referral_code: string;
  total_referrals: number;
  total_credits_earned: number;
  successful_referrals: number;
  pending_referrals: number;
}

interface ReferralTransaction {
  id: string;
  credits_amount: number;
  transaction_type: string;
  created_at: string;
  referee_name?: string;
  status?: string;
}

interface BusinessRegistration {
  id: string;
  business_name: string;
  business_type_name?: string;
  registration_number?: string;
  vat_gst_number?: string;
  website?: string;
  business_address?: string;
  cities_served?: string[];
  service_area?: string;
  years_in_business?: number;
  sub_business_types?: string[];
  about_services?: string;
  contact_name?: string;
  phone_number?: string;
  email_address?: string;
  alternate_contact?: string;
  preferred_communication?: string;
  linkedin_profile?: string;
  facebook_page?: string;
  instagram_handle?: string;
  other_links?: string[];
  business_license_url?: string;
  government_id_url?: string;
  business_certificate_url?: string;
  insurance_certificate_url?: string;
  bank_name?: string;
  account_number?: string;
  account_type?: string;
  ifsc_code?: string;
  status?: string;
  rejection_reason?: string;
  created_at?: string;
  updated_at?: string;
}

interface UserDetails {
  profile: UserProfile | null;
  creditSummary: CreditSummary | null;
  subscriptions: Subscription[];
  referralStats: ReferralStats | null;
  referralTransactions: ReferralTransaction[];
  businessRegistration: BusinessRegistration | null;
}

export const useUserDetails = (userId: string | null) => {
  const [details, setDetails] = useState<UserDetails>({
    profile: null,
    creditSummary: null,
    subscriptions: [],
    referralStats: null,
    referralTransactions: [],
    businessRegistration: null,
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const fetchUserDetails = async (uid: string) => {
    try {
      setLoading(true);
      console.log('Fetching user details for:', uid);

      // Use the admin function to fetch all user details with service role privileges
      const { data, error } = await supabase.rpc('get_user_details_for_admin', {
        p_user_id: uid
      });

      if (error) {
        console.error('Error fetching user details:', error);
        throw error;
      }

      if (!data) {
        throw new Error('User not found');
      }

      console.log('User details data:', data);

      // Parse the JSON response
      const userDetails = typeof data === 'string' ? JSON.parse(data) : data;

      setDetails({
        profile: userDetails.profile ? {
          ...userDetails.profile,
          is_active: true,
        } : null,
        creditSummary: userDetails.credit_summary || null,
        subscriptions: userDetails.subscriptions || [],
        referralStats: userDetails.referral_stats || null,
        referralTransactions: userDetails.referral_transactions || [],
        businessRegistration: userDetails.business_registration || null,
      });
      
      console.log('Details set successfully');
    } catch (error) {
      console.error('Error fetching user details:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fetch user details",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const addCredits = async (credits: number, reason?: string) => {
    if (!userId) return false;

    try {
      const { error } = await supabase.rpc('admin_add_credits', {
        p_user_id: userId,
        p_credits: credits,
        p_reason: reason || 'Admin allocation',
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: `${credits} credits added successfully`,
      });

      // Refresh user details
      await fetchUserDetails(userId);
      return true;
    } catch (error) {
      console.error('Error adding credits:', error);
      toast({
        title: "Error",
        description: "Failed to add credits",
        variant: "destructive",
      });
      return false;
    }
  };

  useEffect(() => {
    if (userId) {
      fetchUserDetails(userId);
    }
  }, [userId]);

  return {
    ...details,
    loading,
    refreshDetails: userId ? () => fetchUserDetails(userId) : () => {},
    addCredits,
    updateBusinessRegistration: async (updates: Partial<BusinessRegistration>) => {
      if (!details.businessRegistration?.id) return false;
      try {
        const { error } = await supabase.rpc('admin_update_business_registration', {
          p_registration_id: details.businessRegistration.id,
          p_data: updates,
        });
        if (error) throw error;
        await fetchUserDetails(details.profile?.id || userId!);
        toast({
          title: "Updated",
          description: "Business registration updated successfully",
        });
        return true;
      } catch (error) {
        console.error('Error updating business registration:', error);
        toast({
          title: "Error",
          description: "Failed to update business registration",
          variant: "destructive",
        });
        return false;
      }
    }
    ,
    createBusinessRegistration: async (payload: Partial<BusinessRegistration> & { business_type_name?: string }) => {
      if (!userId) return false;
      if (!payload.business_type_name) {
        toast({
          title: "Business type required",
          description: "Please provide a valid business type name.",
          variant: "destructive",
        });
        return false;
      }
      try {
        const { error } = await supabase.rpc('admin_create_business_registration', {
          p_user_id: userId,
          p_data: payload,
        });
        if (error) throw error;
        await fetchUserDetails(userId);
        toast({
          title: "Created",
          description: "Business registration created successfully",
        });
        return true;
      } catch (error) {
        console.error('Error creating business registration:', error);
        const message = error instanceof Error ? error.message : "Failed to create business registration";
        toast({
          title: "Error",
          description: message,
          variant: "destructive",
        });
        return false;
      }
    }
  };
};
