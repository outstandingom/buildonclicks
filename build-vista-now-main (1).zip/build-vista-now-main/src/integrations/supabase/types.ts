export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      admin_login_attempts: {
        Row: {
          attempted_at: string
          email: string
          id: string
          ip_address: string | null
          success: boolean
        }
        Insert: {
          attempted_at?: string
          email: string
          id?: string
          ip_address?: string | null
          success?: boolean
        }
        Update: {
          attempted_at?: string
          email?: string
          id?: string
          ip_address?: string | null
          success?: boolean
        }
        Relationships: []
      }
      admin_sessions: {
        Row: {
          admin_id: string
          created_at: string
          expires_at: string
          id: string
          last_accessed_at: string | null
          session_token: string
        }
        Insert: {
          admin_id: string
          created_at?: string
          expires_at: string
          id?: string
          last_accessed_at?: string | null
          session_token: string
        }
        Update: {
          admin_id?: string
          created_at?: string
          expires_at?: string
          id?: string
          last_accessed_at?: string | null
          session_token?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_sessions_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "admin_users"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_users: {
        Row: {
          created_at: string
          email: string
          full_name: string
          id: string
          is_active: boolean
          last_login: string | null
          password_hash: string
          role: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          full_name: string
          id?: string
          is_active?: boolean
          last_login?: string | null
          password_hash: string
          role?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          is_active?: boolean
          last_login?: string | null
          password_hash?: string
          role?: string
          updated_at?: string
        }
        Relationships: []
      }
      banners: {
        Row: {
          alt_text: string | null
          created_at: string
          display_order: number
          id: string
          image_url: string
          is_active: boolean
          title: string
          updated_at: string
        }
        Insert: {
          alt_text?: string | null
          created_at?: string
          display_order?: number
          id?: string
          image_url: string
          is_active?: boolean
          title: string
          updated_at?: string
        }
        Update: {
          alt_text?: string | null
          created_at?: string
          display_order?: number
          id?: string
          image_url?: string
          is_active?: boolean
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      business_registrations: {
        Row: {
          about_services: string
          account_number: string
          account_type: string
          alternate_contact: string | null
          bank_name: string
          business_address: string
          business_certificate_url: string | null
          business_license_url: string | null
          business_name: string
          business_type_id: string
          cities_served: string[]
          contact_name: string
          created_at: string
          email_address: string
          facebook_page: string | null
          government_id_url: string
          id: string
          ifsc_code: string | null
          instagram_handle: string | null
          insurance_certificate_url: string | null
          linkedin_profile: string | null
          other_links: string[] | null
          phone_number: string
          preferred_communication: string
          registration_number: string
          rejection_reason: string | null
          service_area: string | null
          status: string
          sub_business_types: string[] | null
          updated_at: string
          user_id: string
          vat_gst_number: string | null
          website: string | null
          years_in_business: number
        }
        Insert: {
          about_services: string
          account_number: string
          account_type: string
          alternate_contact?: string | null
          bank_name: string
          business_address: string
          business_certificate_url?: string | null
          business_license_url?: string | null
          business_name: string
          business_type_id: string
          cities_served: string[]
          contact_name: string
          created_at?: string
          email_address: string
          facebook_page?: string | null
          government_id_url: string
          id?: string
          ifsc_code?: string | null
          instagram_handle?: string | null
          insurance_certificate_url?: string | null
          linkedin_profile?: string | null
          other_links?: string[] | null
          phone_number: string
          preferred_communication: string
          registration_number: string
          rejection_reason?: string | null
          service_area?: string | null
          status?: string
          sub_business_types?: string[] | null
          updated_at?: string
          user_id: string
          vat_gst_number?: string | null
          website?: string | null
          years_in_business: number
        }
        Update: {
          about_services?: string
          account_number?: string
          account_type?: string
          alternate_contact?: string | null
          bank_name?: string
          business_address?: string
          business_certificate_url?: string | null
          business_license_url?: string | null
          business_name?: string
          business_type_id?: string
          cities_served?: string[]
          contact_name?: string
          created_at?: string
          email_address?: string
          facebook_page?: string | null
          government_id_url?: string
          id?: string
          ifsc_code?: string | null
          instagram_handle?: string | null
          insurance_certificate_url?: string | null
          linkedin_profile?: string | null
          other_links?: string[] | null
          phone_number?: string
          preferred_communication?: string
          registration_number?: string
          rejection_reason?: string | null
          service_area?: string | null
          status?: string
          sub_business_types?: string[] | null
          updated_at?: string
          user_id?: string
          vat_gst_number?: string | null
          website?: string | null
          years_in_business?: number
        }
        Relationships: [
          {
            foreignKeyName: "business_registrations_business_type_id_fkey"
            columns: ["business_type_id"]
            isOneToOne: false
            referencedRelation: "business_types"
            referencedColumns: ["id"]
          },
        ]
      }
      business_types: {
        Row: {
          created_at: string
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      chat_memory: {
        Row: {
          content: string
          created_at: string | null
          id: number
          role: string
          session_id: string
          user_id: string | null
        }
        Insert: {
          content: string
          created_at?: string | null
          id?: never
          role: string
          session_id: string
          user_id?: string | null
        }
        Update: {
          content?: string
          created_at?: string | null
          id?: never
          role?: string
          session_id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "chat_memory_user_id_fkey1"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      cities: {
        Row: {
          created_at: string | null
          id: string
          name: string
          state: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          name: string
          state: string
        }
        Update: {
          created_at?: string | null
          id?: string
          name?: string
          state?: string
        }
        Relationships: []
      }
      contact_submissions: {
        Row: {
          admin_notes: string | null
          created_at: string
          email: string
          first_name: string
          id: string
          last_name: string
          message: string
          phone: string
          status: string
          subject: string
          updated_at: string
        }
        Insert: {
          admin_notes?: string | null
          created_at?: string
          email: string
          first_name: string
          id?: string
          last_name: string
          message: string
          phone: string
          status?: string
          subject: string
          updated_at?: string
        }
        Update: {
          admin_notes?: string | null
          created_at?: string
          email?: string
          first_name?: string
          id?: string
          last_name?: string
          message?: string
          phone?: string
          status?: string
          subject?: string
          updated_at?: string
        }
        Relationships: []
      }
      lead_access_logs: {
        Row: {
          access_entity_type: string | null
          access_type: string
          created_at: string
          credits_consumed: number
          entity_id: string
          id: string
          user_id: string
        }
        Insert: {
          access_entity_type?: string | null
          access_type?: string
          created_at?: string
          credits_consumed?: number
          entity_id: string
          id?: string
          user_id: string
        }
        Update: {
          access_entity_type?: string | null
          access_type?: string
          created_at?: string
          credits_consumed?: number
          entity_id?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          message: string
          read: boolean
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          read?: boolean
          title: string
          type?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          read?: boolean
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      professionals: {
        Row: {
          business_name: string | null
          city_id: string | null
          created_at: string | null
          description: string | null
          email: string | null
          experience: number | null
          id: string
          is_verified: boolean | null
          name: string
          phone: string | null
          profile_image_url: string | null
          rating: number | null
          review_count: number | null
          type: string
          updated_at: string | null
        }
        Insert: {
          business_name?: string | null
          city_id?: string | null
          created_at?: string | null
          description?: string | null
          email?: string | null
          experience?: number | null
          id?: string
          is_verified?: boolean | null
          name: string
          phone?: string | null
          profile_image_url?: string | null
          rating?: number | null
          review_count?: number | null
          type: string
          updated_at?: string | null
        }
        Update: {
          business_name?: string | null
          city_id?: string | null
          created_at?: string | null
          description?: string | null
          email?: string | null
          experience?: number | null
          id?: string
          is_verified?: boolean | null
          name?: string
          phone?: string | null
          profile_image_url?: string | null
          rating?: number | null
          review_count?: number | null
          type?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "professionals_city_id_fkey"
            columns: ["city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          address: string | null
          city_id: string | null
          created_at: string | null
          full_name: string | null
          id: string
          mobile_number: string | null
          profile_image_url: string | null
          updated_at: string | null
          user_type: string | null
        }
        Insert: {
          address?: string | null
          city_id?: string | null
          created_at?: string | null
          full_name?: string | null
          id: string
          mobile_number?: string | null
          profile_image_url?: string | null
          updated_at?: string | null
          user_type?: string | null
        }
        Update: {
          address?: string | null
          city_id?: string | null
          created_at?: string | null
          full_name?: string | null
          id?: string
          mobile_number?: string | null
          profile_image_url?: string | null
          updated_at?: string | null
          user_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_city_id_fkey"
            columns: ["city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
        ]
      }
      project_bids: {
        Row: {
          bid_amount: number | null
          created_at: string
          id: string
          message: string
          professional_id: string
          project_id: string
          status: string
          timeline_estimate: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          bid_amount?: number | null
          created_at?: string
          id?: string
          message: string
          professional_id: string
          project_id: string
          status?: string
          timeline_estimate?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          bid_amount?: number | null
          created_at?: string
          id?: string
          message?: string
          professional_id?: string
          project_id?: string
          status?: string
          timeline_estimate?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_bids_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "professionals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "project_bids_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      projects: {
        Row: {
          budget_range: string
          city_id: string | null
          created_at: string
          description: string
          id: string
          location: string
          project_type: string
          status: string
          timeline: string | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          budget_range: string
          city_id?: string | null
          created_at?: string
          description: string
          id?: string
          location: string
          project_type: string
          status?: string
          timeline?: string | null
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          budget_range?: string
          city_id?: string | null
          created_at?: string
          description?: string
          id?: string
          location?: string
          project_type?: string
          status?: string
          timeline?: string | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "projects_city_id_fkey"
            columns: ["city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
        ]
      }
      provider_portfolios: {
        Row: {
          banner_url: string | null
          business_registration_id: string
          certifications: string[]
          created_at: string
          description: string
          experience: string
          id: string
          images: string[]
          logo_url: string | null
          projects: Json
          services: string[]
          skills: string[]
          title: string
          updated_at: string
        }
        Insert: {
          banner_url?: string | null
          business_registration_id: string
          certifications?: string[]
          created_at?: string
          description: string
          experience: string
          id?: string
          images?: string[]
          logo_url?: string | null
          projects?: Json
          services?: string[]
          skills?: string[]
          title: string
          updated_at?: string
        }
        Update: {
          banner_url?: string | null
          business_registration_id?: string
          certifications?: string[]
          created_at?: string
          description?: string
          experience?: string
          id?: string
          images?: string[]
          logo_url?: string | null
          projects?: Json
          services?: string[]
          skills?: string[]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_provider_portfolios_business_registration"
            columns: ["business_registration_id"]
            isOneToOne: false
            referencedRelation: "business_registrations"
            referencedColumns: ["id"]
          },
        ]
      }
      provider_profiles: {
        Row: {
          address_city: string | null
          address_pincode: string | null
          address_street: string | null
          approved: boolean
          bio: string | null
          business_registration_id: string | null
          created_at: string
          display_name: string | null
          id: string
          is_live: boolean
          phone: string | null
          role: Database["public"]["Enums"]["provider_role"]
          slug: string | null
          updated_at: string
          user_id: string
          whatsapp: string | null
          working_hours: Json | null
        }
        Insert: {
          address_city?: string | null
          address_pincode?: string | null
          address_street?: string | null
          approved?: boolean
          bio?: string | null
          business_registration_id?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          is_live?: boolean
          phone?: string | null
          role: Database["public"]["Enums"]["provider_role"]
          slug?: string | null
          updated_at?: string
          user_id: string
          whatsapp?: string | null
          working_hours?: Json | null
        }
        Update: {
          address_city?: string | null
          address_pincode?: string | null
          address_street?: string | null
          approved?: boolean
          bio?: string | null
          business_registration_id?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          is_live?: boolean
          phone?: string | null
          role?: Database["public"]["Enums"]["provider_role"]
          slug?: string | null
          updated_at?: string
          user_id?: string
          whatsapp?: string | null
          working_hours?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "provider_profiles_business_registration_id_fkey"
            columns: ["business_registration_id"]
            isOneToOne: false
            referencedRelation: "business_registrations"
            referencedColumns: ["id"]
          },
        ]
      }
      provider_shops: {
        Row: {
          business_registration_id: string
          categories: string[]
          created_at: string
          delivery_options: string[]
          description: string
          featured: boolean
          id: string
          images: string[]
          logo_url: string | null
          min_order_value: number | null
          shop_name: string
          updated_at: string
          working_hours: string
        }
        Insert: {
          business_registration_id: string
          categories?: string[]
          created_at?: string
          delivery_options?: string[]
          description: string
          featured?: boolean
          id?: string
          images?: string[]
          logo_url?: string | null
          min_order_value?: number | null
          shop_name: string
          updated_at?: string
          working_hours: string
        }
        Update: {
          business_registration_id?: string
          categories?: string[]
          created_at?: string
          delivery_options?: string[]
          description?: string
          featured?: boolean
          id?: string
          images?: string[]
          logo_url?: string | null
          min_order_value?: number | null
          shop_name?: string
          updated_at?: string
          working_hours?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_provider_shops_business_registration"
            columns: ["business_registration_id"]
            isOneToOne: true
            referencedRelation: "business_registrations"
            referencedColumns: ["id"]
          },
        ]
      }
      quick_requirement_submissions: {
        Row: {
          admin_notes: string | null
          created_at: string
          id: string
          message: string | null
          name: string
          phone: string
          service: string
          status: string
          updated_at: string
        }
        Insert: {
          admin_notes?: string | null
          created_at?: string
          id?: string
          message?: string | null
          name: string
          phone: string
          service: string
          status?: string
          updated_at?: string
        }
        Update: {
          admin_notes?: string | null
          created_at?: string
          id?: string
          message?: string | null
          name?: string
          phone?: string
          service?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      referral_codes: {
        Row: {
          code: string
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          max_usage: number | null
          updated_at: string
          usage_count: number
          user_id: string
        }
        Insert: {
          code: string
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          max_usage?: number | null
          updated_at?: string
          usage_count?: number
          user_id: string
        }
        Update: {
          code?: string
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          max_usage?: number | null
          updated_at?: string
          usage_count?: number
          user_id?: string
        }
        Relationships: []
      }
      referral_rewards: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          referee_credits: number
          referrer_credits: number
          reward_type: string
          updated_at: string
          user_type: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          referee_credits?: number
          referrer_credits?: number
          reward_type: string
          updated_at?: string
          user_type?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          referee_credits?: number
          referrer_credits?: number
          reward_type?: string
          updated_at?: string
          user_type?: string
        }
        Relationships: []
      }
      referral_transactions: {
        Row: {
          created_at: string
          credits_amount: number
          id: string
          referral_id: string
          transaction_type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          credits_amount: number
          id?: string
          referral_id: string
          transaction_type: string
          user_id: string
        }
        Update: {
          created_at?: string
          credits_amount?: number
          id?: string
          referral_id?: string
          transaction_type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "referral_transactions_referral_id_fkey"
            columns: ["referral_id"]
            isOneToOne: false
            referencedRelation: "referrals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referral_transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      referrals: {
        Row: {
          completed_at: string | null
          created_at: string
          id: string
          referee_id: string
          referee_reward_given: boolean
          referral_code_id: string
          referrer_id: string
          referrer_reward_given: boolean
          reward_type: string
          status: string
          updated_at: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          id?: string
          referee_id: string
          referee_reward_given?: boolean
          referral_code_id: string
          referrer_id: string
          referrer_reward_given?: boolean
          reward_type: string
          status?: string
          updated_at?: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          id?: string
          referee_id?: string
          referee_reward_given?: boolean
          referral_code_id?: string
          referrer_id?: string
          referrer_reward_given?: boolean
          reward_type?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "referrals_referee_id_fkey"
            columns: ["referee_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referrals_referral_code_id_fkey"
            columns: ["referral_code_id"]
            isOneToOne: false
            referencedRelation: "referral_codes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referrals_referrer_id_fkey"
            columns: ["referrer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      requirements: {
        Row: {
          attachments: Json | null
          city: string
          contact_info: string | null
          contact_preference: string
          created_at: string
          description: string
          id: string
          service_type: string
          status: string
          timeline: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          attachments?: Json | null
          city: string
          contact_info?: string | null
          contact_preference: string
          created_at?: string
          description: string
          id?: string
          service_type: string
          status?: string
          timeline: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          attachments?: Json | null
          city?: string
          contact_info?: string | null
          contact_preference?: string
          created_at?: string
          description?: string
          id?: string
          service_type?: string
          status?: string
          timeline?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      reviews: {
        Row: {
          business_registration_id: string | null
          comment: string | null
          created_at: string
          id: string
          professional_id: string | null
          project_id: string | null
          rating: number
          user_id: string
        }
        Insert: {
          business_registration_id?: string | null
          comment?: string | null
          created_at?: string
          id?: string
          professional_id?: string | null
          project_id?: string | null
          rating: number
          user_id: string
        }
        Update: {
          business_registration_id?: string | null
          comment?: string | null
          created_at?: string
          id?: string
          professional_id?: string | null
          project_id?: string | null
          rating?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reviews_business_registration_id_fkey"
            columns: ["business_registration_id"]
            isOneToOne: false
            referencedRelation: "business_registrations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "professionals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      saved_professionals: {
        Row: {
          created_at: string | null
          id: string
          professional_id: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          professional_id?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          professional_id?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "saved_professionals_professional_id_fkey"
            columns: ["professional_id"]
            isOneToOne: false
            referencedRelation: "business_registrations"
            referencedColumns: ["id"]
          },
        ]
      }
      saved_social_posts: {
        Row: {
          created_at: string
          id: string
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "saved_social_posts_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "social_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      shop_products: {
        Row: {
          category: string
          created_at: string
          description: string | null
          id: string
          image_url: string | null
          in_stock: boolean
          min_order_quantity: number | null
          name: string
          price: number
          shop_id: string
          unit: string
          updated_at: string
        }
        Insert: {
          category: string
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          in_stock?: boolean
          min_order_quantity?: number | null
          name: string
          price: number
          shop_id: string
          unit?: string
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          in_stock?: boolean
          min_order_quantity?: number | null
          name?: string
          price?: number
          shop_id?: string
          unit?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "shop_products_shop_id_fkey"
            columns: ["shop_id"]
            isOneToOne: false
            referencedRelation: "provider_shops"
            referencedColumns: ["id"]
          },
        ]
      }
      social_post_comments: {
        Row: {
          content: string
          created_at: string
          id: string
          post_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          post_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          post_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      social_post_likes: {
        Row: {
          created_at: string
          id: string
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          post_id?: string
          user_id?: string
        }
        Relationships: []
      }
      social_posts: {
        Row: {
          comments_count: number
          content: string
          created_at: string
          id: string
          likes_count: number
          media_type: string | null
          media_url: string | null
          provider_profile_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          comments_count?: number
          content: string
          created_at?: string
          id?: string
          likes_count?: number
          media_type?: string | null
          media_url?: string | null
          provider_profile_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          comments_count?: number
          content?: string
          created_at?: string
          id?: string
          likes_count?: number
          media_type?: string | null
          media_url?: string | null
          provider_profile_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      subscription_plans: {
        Row: {
          created_at: string
          description: string | null
          duration_days: number
          id: string
          is_active: boolean
          lead_credits: number
          name: string
          price_inr: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          duration_days?: number
          id?: string
          is_active?: boolean
          lead_credits: number
          name: string
          price_inr: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          duration_days?: number
          id?: string
          is_active?: boolean
          lead_credits?: number
          name?: string
          price_inr?: number
          updated_at?: string
        }
        Relationships: []
      }
      user_bans: {
        Row: {
          admin_id: string
          ban_type: Database["public"]["Enums"]["ban_type"]
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          reason: string
          report_id: string | null
          user_id: string
        }
        Insert: {
          admin_id: string
          ban_type: Database["public"]["Enums"]["ban_type"]
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          reason: string
          report_id?: string | null
          user_id: string
        }
        Update: {
          admin_id?: string
          ban_type?: Database["public"]["Enums"]["ban_type"]
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          reason?: string
          report_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_bans_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "admin_users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_bans_report_id_fkey"
            columns: ["report_id"]
            isOneToOne: false
            referencedRelation: "user_reports"
            referencedColumns: ["id"]
          },
        ]
      }
      user_lead_credits: {
        Row: {
          created_at: string
          free_credits_given: boolean
          id: string
          total_credits: number
          updated_at: string
          used_credits: number
          user_id: string
        }
        Insert: {
          created_at?: string
          free_credits_given?: boolean
          id?: string
          total_credits?: number
          updated_at?: string
          used_credits?: number
          user_id: string
        }
        Update: {
          created_at?: string
          free_credits_given?: boolean
          id?: string
          total_credits?: number
          updated_at?: string
          used_credits?: number
          user_id?: string
        }
        Relationships: []
      }
      user_reports: {
        Row: {
          admin_notes: string | null
          content_id: string
          content_type: Database["public"]["Enums"]["content_type"]
          created_at: string
          description: string
          id: string
          priority: Database["public"]["Enums"]["report_priority"]
          reason: Database["public"]["Enums"]["report_reason"]
          reported_user_id: string | null
          reporter_id: string
          resolved_at: string | null
          resolved_by: string | null
          status: Database["public"]["Enums"]["report_status"]
          updated_at: string
        }
        Insert: {
          admin_notes?: string | null
          content_id: string
          content_type: Database["public"]["Enums"]["content_type"]
          created_at?: string
          description: string
          id?: string
          priority?: Database["public"]["Enums"]["report_priority"]
          reason: Database["public"]["Enums"]["report_reason"]
          reported_user_id?: string | null
          reporter_id: string
          resolved_at?: string | null
          resolved_by?: string | null
          status?: Database["public"]["Enums"]["report_status"]
          updated_at?: string
        }
        Update: {
          admin_notes?: string | null
          content_id?: string
          content_type?: Database["public"]["Enums"]["content_type"]
          created_at?: string
          description?: string
          id?: string
          priority?: Database["public"]["Enums"]["report_priority"]
          reason?: Database["public"]["Enums"]["report_reason"]
          reported_user_id?: string | null
          reporter_id?: string
          resolved_at?: string | null
          resolved_by?: string | null
          status?: Database["public"]["Enums"]["report_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_reports_resolved_by_fkey"
            columns: ["resolved_by"]
            isOneToOne: false
            referencedRelation: "admin_users"
            referencedColumns: ["id"]
          },
        ]
      }
      user_subscriptions: {
        Row: {
          created_at: string
          credits_added: number
          expires_at: string
          id: string
          plan_id: string
          razorpay_order_id: string | null
          razorpay_payment_id: string | null
          razorpay_signature: string | null
          starts_at: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          credits_added: number
          expires_at: string
          id?: string
          plan_id: string
          razorpay_order_id?: string | null
          razorpay_payment_id?: string | null
          razorpay_signature?: string | null
          starts_at?: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          credits_added?: number
          expires_at?: string
          id?: string
          plan_id?: string
          razorpay_order_id?: string | null
          razorpay_payment_id?: string | null
          razorpay_signature?: string | null
          starts_at?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      user_warnings: {
        Row: {
          admin_id: string
          created_at: string
          id: string
          message: string
          reason: string
          report_id: string | null
          severity: Database["public"]["Enums"]["warning_severity"]
          user_id: string
        }
        Insert: {
          admin_id: string
          created_at?: string
          id?: string
          message: string
          reason: string
          report_id?: string | null
          severity: Database["public"]["Enums"]["warning_severity"]
          user_id: string
        }
        Update: {
          admin_id?: string
          created_at?: string
          id?: string
          message?: string
          reason?: string
          report_id?: string | null
          severity?: Database["public"]["Enums"]["warning_severity"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_warnings_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "admin_users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_warnings_report_id_fkey"
            columns: ["report_id"]
            isOneToOne: false
            referencedRelation: "user_reports"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_user_credits: {
        Args: {
          p_credits: number
          p_subscription_id?: string
          p_user_id: string
        }
        Returns: boolean
      }
      admin_activate_user: { Args: { p_user_id: string }; Returns: boolean }
      admin_add_credits: {
        Args: { p_credits: number; p_reason?: string; p_user_id: string }
        Returns: boolean
      }
      admin_reset_user_access: { Args: { p_user_id: string }; Returns: boolean }
      admin_suspend_user: {
        Args: {
          p_admin_id: string
          p_duration_days?: number
          p_reason?: string
          p_user_id: string
        }
        Returns: boolean
      }
      admin_update_provider_document: {
        Args: {
          p_document_key: string
          p_document_url: string
          p_registration_id: string
        }
        Returns: boolean
      }
      check_admin_rate_limit: {
        Args: { p_email: string; p_ip_address: string }
        Returns: boolean
      }
      check_user_exists: {
        Args: { p_email: string; p_mobile: string }
        Returns: Json
      }
      check_user_lead_credits: {
        Args: { p_credits_needed?: number; p_user_id: string }
        Returns: boolean
      }
      consume_lead_credits: {
        Args: {
          p_access_type?: string
          p_credits?: number
          p_entity_id: string
          p_entity_type?: string
          p_user_id: string
        }
        Returns: boolean
      }
      create_admin_session: { Args: { p_admin_id: string }; Returns: string }
      create_admin_user: {
        Args: {
          p_email: string
          p_full_name: string
          p_password: string
          p_role?: string
        }
        Returns: boolean
      }
      create_notification: {
        Args: {
          p_message: string
          p_title: string
          p_type?: string
          p_user_id: string
        }
        Returns: string
      }
      create_razorpay_order: {
        Args: {
          p_amount: number
          p_currency?: string
          p_plan_id: string
          p_user_id: string
        }
        Returns: Json
      }
      delete_admin_user: { Args: { p_admin_id: string }; Returns: boolean }
      email_exists_in_auth: { Args: { p_email: string }; Returns: boolean }
      expire_temporary_bans: { Args: never; Returns: undefined }
      generate_referral_code: { Args: { p_user_id: string }; Returns: string }
      get_admin_dashboard_stats: {
        Args: never
        Returns: {
          approved_vendors: number
          pending_requests: number
          total_posts: number
          total_users: number
        }[]
      }
      get_admin_recent_activity: {
        Args: never
        Returns: {
          activity_type: string
          created_at: string
          description: string
          user_name: string
        }[]
      }
      get_admin_reports: {
        Args: { p_priority?: string; p_status?: string }
        Returns: {
          admin_notes: string
          content_id: string
          content_type: Database["public"]["Enums"]["content_type"]
          created_at: string
          description: string
          id: string
          priority: Database["public"]["Enums"]["report_priority"]
          reason: Database["public"]["Enums"]["report_reason"]
          reported_user_id: string
          reported_user_name: string
          reporter_id: string
          reporter_name: string
          resolved_at: string
          resolved_by_name: string
          status: Database["public"]["Enums"]["report_status"]
        }[]
      }
      get_all_admin_users: {
        Args: never
        Returns: {
          created_at: string
          email: string
          full_name: string
          id: string
          is_active: boolean
          last_login: string
          role: string
        }[]
      }
      get_approved_business_listing: {
        Args: { business_id: string }
        Returns: {
          about_services: string
          business_name: string
          business_type: string
          cities_served: string[]
          created_at: string
          id: string
          service_area: string
          sub_business_types: string[]
          website: string
          years_in_business: number
        }[]
      }
      get_approved_business_listings: {
        Args: never
        Returns: {
          about_services: string
          business_name: string
          business_type: string
          cities_served: string[]
          created_at: string
          id: string
          service_area: string
          sub_business_types: string[]
          website: string
          years_in_business: number
        }[]
      }
      get_business_registration_details: {
        Args: { registration_id: string }
        Returns: Json
      }
      get_business_type_id: { Args: { type_name: string }; Returns: string }
      get_business_types: {
        Args: never
        Returns: {
          id: string
          name: string
        }[]
      }
      get_contact_submissions: {
        Args: never
        Returns: {
          admin_notes: string
          created_at: string
          email: string
          first_name: string
          id: string
          last_name: string
          message: string
          phone: string
          status: string
          subject: string
          updated_at: string
        }[]
      }
      get_current_user_role: {
        Args: never
        Returns: Database["public"]["Enums"]["provider_role"]
      }
      get_lead_access_analytics: {
        Args: never
        Returns: {
          credits_consumed_total: number
          last_accessed: string
          requirement_created_at: string
          requirement_id: string
          requirement_title: string
          total_contacts: number
          total_views: number
          unique_viewers: number
        }[]
      }
      get_pending_business_registrations: {
        Args: never
        Returns: {
          business_name: string
          business_type: string
          cities_served: string[]
          contact_name: string
          created_at: string
          email_address: string
          id: string
          phone_number: string
          rejection_reason: string
          status: string
        }[]
      }
      get_professional_safe_data: {
        Args: { professional_id: string }
        Returns: {
          business_name: string
          city_id: string
          created_at: string
          description: string
          experience: number
          id: string
          is_verified: boolean
          name: string
          profile_image_url: string
          rating: number
          review_count: number
          type: string
          updated_at: string
        }[]
      }
      get_professionals_safe_data: {
        Args: never
        Returns: {
          business_name: string
          city_id: string
          created_at: string
          description: string
          experience: number
          id: string
          is_verified: boolean
          name: string
          profile_image_url: string
          rating: number
          review_count: number
          type: string
          updated_at: string
        }[]
      }
      get_projects_for_moderation: {
        Args: never
        Returns: {
          budget_range: string
          created_at: string
          description: string
          id: string
          project_type: string
          status: string
          title: string
          user_name: string
        }[]
      }
      get_provider_documents_for_admin: {
        Args: { p_user_id: string }
        Returns: Json
      }
      get_quick_requirement_submissions: {
        Args: never
        Returns: {
          admin_notes: string
          created_at: string
          id: string
          message: string
          name: string
          phone: string
          service: string
          status: string
          updated_at: string
        }[]
      }
      get_subscription_analytics: {
        Args: never
        Returns: {
          avg_credits_per_user: number
          monthly_revenue: number
          popular_plan_count: number
          popular_plan_name: string
          total_active_subscriptions: number
          total_credits_distributed: number
          total_credits_used: number
          total_revenue: number
        }[]
      }
      get_user_basic_info: {
        Args: { user_ids: string[] }
        Returns: {
          created_at: string
          email: string
          full_name: string
          id: string
          profile_image_url: string
        }[]
      }
      get_user_credit_history: {
        Args: { p_user_id: string }
        Returns: {
          access_logs: Json
          available_credits: number
          free_credits_given: boolean
          last_access: string
          subscription_count: number
          total_credits: number
          used_credits: number
          user_name: string
        }[]
      }
      get_user_details_for_admin: { Args: { p_user_id: string }; Returns: Json }
      get_user_referral_stats: {
        Args: { p_user_id: string }
        Returns: {
          pending_referrals: number
          referral_code: string
          successful_referrals: number
          total_credits_earned: number
          total_referrals: number
        }[]
      }
      get_user_warning_count: { Args: { p_user_id: string }; Returns: number }
      get_users_credit_summary: {
        Args: never
        Returns: {
          available_credits: number
          created_at: string
          last_activity: string
          subscription_status: string
          total_credits: number
          used_credits: number
          user_id: string
          user_name: string
          user_type: string
        }[]
      }
      get_users_for_admin: {
        Args: never
        Returns: {
          city_name: string
          created_at: string
          full_name: string
          id: string
          is_active: boolean
          user_type: string
        }[]
      }
      give_free_credits: {
        Args: { p_free_credits?: number; p_user_id: string }
        Returns: boolean
      }
      insert_business_registration: {
        Args: { registration_data: Json }
        Returns: undefined
      }
      is_current_user_approved: { Args: never; Returns: boolean }
      is_user_banned: { Args: { p_user_id: string }; Returns: boolean }
      log_admin_login_attempt: {
        Args: { p_email: string; p_ip_address: string; p_success: boolean }
        Returns: undefined
      }
      process_referral_signup: {
        Args: { p_referee_id: string; p_referral_code: string }
        Returns: boolean
      }
      request_professional_contact: {
        Args: { professional_id: string; requester_message?: string }
        Returns: Json
      }
      reset_admin_password: {
        Args: { p_admin_id: string; p_new_password: string }
        Returns: boolean
      }
      update_admin_role: {
        Args: { p_admin_id: string; p_role: string }
        Returns: boolean
      }
      update_admin_status: {
        Args: { p_admin_id: string; p_is_active: boolean }
        Returns: boolean
      }
      update_business_registration_status: {
        Args: {
          new_status: string
          registration_id: string
          rejection_reason_param?: string
        }
        Returns: boolean
      }
      update_contact_submission: {
        Args: {
          p_admin_notes: string
          p_status: string
          p_submission_id: string
        }
        Returns: boolean
      }
      update_professional_contact_visibility: {
        Args: {
          email_visible?: boolean
          phone_visible?: boolean
          professional_id: string
        }
        Returns: boolean
      }
      update_quick_requirement_submission: {
        Args: {
          p_admin_notes: string
          p_status: string
          p_submission_id: string
        }
        Returns: boolean
      }
      user_has_business_registration: {
        Args: { user_uuid: string }
        Returns: boolean
      }
      verify_admin_credentials: {
        Args: { p_email: string; p_password: string }
        Returns: {
          admin_email: string
          admin_id: string
          admin_name: string
          admin_role: string
        }[]
      }
      verify_admin_session: {
        Args: { p_session_token: string }
        Returns: {
          admin_email: string
          admin_id: string
          admin_name: string
          admin_role: string
        }[]
      }
      verify_razorpay_payment: {
        Args: {
          p_razorpay_order_id: string
          p_razorpay_payment_id: string
          p_razorpay_signature: string
          p_subscription_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      ban_type: "temporary" | "permanent"
      content_type: "post" | "comment" | "profile" | "shop" | "portfolio"
      provider_role: "vendor" | "contractor" | "architect" | "manufacturer"
      report_priority: "low" | "medium" | "high"
      report_reason:
        | "spam"
        | "harassment"
        | "inappropriate_content"
        | "fake_profile"
        | "scam"
        | "copyright"
        | "other"
      report_status: "open" | "investigating" | "resolved" | "dismissed"
      warning_severity: "low" | "medium" | "high"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      ban_type: ["temporary", "permanent"],
      content_type: ["post", "comment", "profile", "shop", "portfolio"],
      provider_role: ["vendor", "contractor", "architect", "manufacturer"],
      report_priority: ["low", "medium", "high"],
      report_reason: [
        "spam",
        "harassment",
        "inappropriate_content",
        "fake_profile",
        "scam",
        "copyright",
        "other",
      ],
      report_status: ["open", "investigating", "resolved", "dismissed"],
      warning_severity: ["low", "medium", "high"],
    },
  },
} as const
