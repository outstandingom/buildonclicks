import { format } from "date-fns";
import type { SubscriptionHistory } from "@/hooks/useSubscriptionHistory";

export const generateInvoicePDF = (subscription: SubscriptionHistory) => {
  // Create HTML content for the invoice
  const invoiceHTML = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Invoice - ${subscription.razorpay_order_id}</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          max-width: 800px;
          margin: 0 auto;
          padding: 40px;
          color: #333;
        }
        .header {
          text-align: center;
          margin-bottom: 40px;
          border-bottom: 2px solid #000;
          padding-bottom: 20px;
        }
        .company-name {
          font-size: 28px;
          font-weight: bold;
          margin-bottom: 5px;
        }
        .invoice-title {
          font-size: 20px;
          color: #666;
        }
        .info-section {
          display: flex;
          justify-content: space-between;
          margin-bottom: 30px;
        }
        .info-block {
          flex: 1;
        }
        .info-title {
          font-weight: bold;
          margin-bottom: 10px;
          color: #000;
        }
        .info-text {
          color: #666;
          line-height: 1.6;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin: 30px 0;
        }
        th, td {
          padding: 12px;
          text-align: left;
          border-bottom: 1px solid #ddd;
        }
        th {
          background-color: #f8f9fa;
          font-weight: bold;
        }
        .total-row {
          font-weight: bold;
          font-size: 18px;
        }
        .footer {
          margin-top: 40px;
          padding-top: 20px;
          border-top: 1px solid #ddd;
          text-align: center;
          color: #666;
          font-size: 12px;
        }
        .payment-id {
          background-color: #f8f9fa;
          padding: 15px;
          border-radius: 5px;
          margin: 20px 0;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="company-name">BuildOnClicks</div>
        <div class="invoice-title">TAX INVOICE</div>
      </div>

      <div class="info-section">
        <div class="info-block">
          <div class="info-title">Invoice Details</div>
          <div class="info-text">
            Invoice No: ${subscription.razorpay_order_id}<br>
            Invoice Date: ${format(new Date(subscription.created_at), "MMMM dd, yyyy")}<br>
            Payment Status: ${subscription.status.toUpperCase()}
          </div>
        </div>
        <div class="info-block">
          <div class="info-title">Payment Information</div>
          <div class="info-text">
            Payment ID: ${subscription.razorpay_payment_id || "N/A"}<br>
            Payment Method: Razorpay<br>
            Order ID: ${subscription.razorpay_order_id}
          </div>
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th>Description</th>
            <th>Quantity</th>
            <th>Unit Price</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <strong>${subscription.plan_name}</strong><br>
              <small>${subscription.plan_description}</small><br>
              <small>${subscription.credits_added} Lead Credits</small>
            </td>
            <td>1</td>
            <td>₹${subscription.amount.toFixed(2)}</td>
            <td>₹${subscription.amount.toFixed(2)}</td>
          </tr>
          <tr class="total-row">
            <td colspan="3" style="text-align: right;">Total Amount:</td>
            <td>₹${subscription.amount.toFixed(2)}</td>
          </tr>
        </tbody>
      </table>

      <div class="payment-id">
        <strong>Payment Reference:</strong><br>
        Transaction successful on ${format(new Date(subscription.created_at), "MMMM dd, yyyy 'at' hh:mm a")}
      </div>

      <div class="footer">
        <p>Thank you for your business!</p>
        <p>BuildOnClicks - Connecting Contractors & Customers</p>
        <p>This is a computer-generated invoice and does not require a signature.</p>
      </div>
    </body>
    </html>
  `;

  // Create a new window and print
  const printWindow = window.open("", "_blank");
  if (printWindow) {
    printWindow.document.write(invoiceHTML);
    printWindow.document.close();
    printWindow.onload = () => {
      printWindow.print();
    };
  }
};
