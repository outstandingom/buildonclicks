import { toast } from '@/hooks/use-toast';

interface LoadingToastOptions {
  title?: string;
  description?: string;
  duration?: number;
}

export const showLoadingToast = (options: LoadingToastOptions = {}) => {
  const {
    title = "Loading...",
    description = "Please wait while we process your request",
    duration = 0 // Persistent by default
  } = options;

  const toastRef = toast({
    title: `🔄 ${title}`,
    description,
    duration,
    className: "fixed top-4 left-1/2 transform -translate-x-1/2 z-[100] w-96 max-w-[90vw] bg-gradient-card/98 border border-border/30 shadow-toast-glow backdrop-blur-xl rounded-xl p-4 animate-slide-in-toast hover:shadow-hover transition-all duration-300 border-l-4 border-l-primary relative overflow-hidden before:absolute before:inset-0 before:bg-gradient-loading before:opacity-8 before:animate-pulse-glow",
  });

  return {
    dismiss: toastRef.dismiss,
    update: (newOptions: Partial<LoadingToastOptions>) => {
      if (newOptions.title || newOptions.description) {
        toastRef.update({
          id: toastRef.id,
          title: newOptions.title ? `🔄 ${newOptions.title}` : `🔄 ${title}`,
          description: newOptions.description || description,
        });
      }
    }
  };
};

export const showSuccessToast = (options: { title?: string; description?: string; duration?: number } = {}) => {
  const {
    title = "Success!",
    description = "Operation completed successfully",
    duration = 4000
  } = options;

  return toast({
    title: `✨ ${title}`,
    description,
    duration,
    className: "fixed top-4 left-1/2 transform -translate-x-1/2 z-[100] w-96 max-w-[90vw] bg-gradient-card/98 border border-border/30 shadow-toast-glow backdrop-blur-xl rounded-xl p-4 animate-slide-in-toast hover:shadow-hover transition-all duration-300 border-l-4 border-l-green-500 relative overflow-hidden before:absolute before:inset-0 before:bg-gradient-success before:opacity-12 before:animate-bounce-subtle",
  });
};

export const showErrorToast = (options: { title?: string; description?: string; duration?: number } = {}) => {
  const {
    title = "Error",
    description = "Something went wrong. Please try again.",
    duration = 5000
  } = options;

  return toast({
    title: `⚠️ ${title}`,
    description,
    duration,
    variant: "destructive",
    className: "fixed top-4 left-1/2 transform -translate-x-1/2 z-[100] w-96 max-w-[90vw] bg-gradient-card/98 border border-destructive/30 shadow-toast-glow backdrop-blur-xl rounded-xl p-4 animate-slide-in-toast hover:shadow-hover transition-all duration-300 border-l-4 border-l-destructive relative overflow-hidden before:absolute before:inset-0 before:bg-gradient-error before:opacity-12 before:animate-pulse-glow",
  });
};