import React from "react";
import { motion } from "framer-motion";
import { Search, Users, CheckCircle2, ClipboardCheck, Target, Eye } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Helmet } from "react-helmet-async";

const About = () => {
  const howItWorksSteps = [
    {
      icon: Search,
      title: "Post Your Requirement",
      description: "Share your construction needs or search for specific services in your area.",
    },
    {
      icon: Users,
      title: "Discover Professionals",
      description: "Browse verified vendors, contractors, and architects in your city.",
    },
    {
      icon: CheckCircle2,
      title: "Connect & Compare",
      description: "Chat with professionals, compare quotes, and make informed decisions.",
    },
    {
      icon: ClipboardCheck,
      title: "Track & Manage",
      description: "Monitor your construction projects digitally with real-time updates.",
    },
  ];

  return (
    <>
      <Helmet>
        <title>About BuildOnClicks - India's #1 Construction Network Platform</title>
        <meta 
          name="description" 
          content="Learn about BuildOnClicks, India's leading construction network platform connecting users with verified vendors, contractors, and architects." 
        />
        <meta name="keywords" content="about buildonclicks, construction platform, construction network, india construction" />
      </Helmet>

      <div className="min-h-screen bg-background pb-20 sm:pb-8">
        <Header />

        {/* Hero Section */}
        <section className="relative bg-[url('/lovable-uploads/About.jpeg')] bg-cover bg-center py-12 sm:py-16 md:py-24 px-3 sm:px-6 lg:px-8">
          <div className="absolute inset-0" />
          <div className="relative max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center space-y-4 sm:space-y-6 md:space-y-8"
            >
              <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold text-white px-2">
                About <span className="text-[#FF6B35]">BuildOnClicks</span>
              </h1>
              <p className="text-sm sm:text-base md:text-lg text-white max-w-5xl mx-auto leading-relaxed px-4">
                BuildOnClicks is India's #1 construction network platform where users connect with vendors, contractors, and architects — all in one place.
              </p>

              {/* How it works section */}
              <div className="pt-4 sm:pt-6 md:pt-8">
                <div className="border-2 border-dashed border-white/30 rounded-lg p-4 sm:p-6 md:p-8 lg:p-10">
                  <h2 className="text-lg sm:text-xl md:text-2xl font-semibold text-white mb-4 sm:mb-6 md:mb-8 text-center">
                    How it works?
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 md:gap-6">
                    {howItWorksSteps.map((step, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: index * 0.1 }}
                      >
                        <Card className="bg-white h-full hover:shadow-lg transition-shadow rounded-xl">
                          <CardContent className="p-4 sm:p-5 md:p-6 text-center space-y-2 sm:space-y-3">
                            <div className="w-10 h-10 sm:w-12 sm:h-12 mx-auto bg-[#FF6B35]/10 rounded-full flex items-center justify-center">
                              <step.icon className="w-5 h-5 sm:w-6 sm:h-6 text-[#FF6B35]" />
                            </div>
                            <h3 className="font-semibold text-sm sm:text-base text-gray-800">{step.title}</h3>
                            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">{step.description}</p>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Our Story Section */}
        <section className="py-10 sm:py-12 md:py-16 px-3 sm:px-6 lg:px-8 bg-background">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-10 md:gap-12 items-start">
              {/* Left Column - Story & Mission/Vision */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="space-y-6 sm:space-y-8"
              >
                <div>
                  <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6">
                    Our <span className="text-[#FF6B35]">Story</span>
                  </h2>
                  <div className="space-y-3 sm:space-y-4 text-gray-700 text-sm sm:text-base leading-relaxed">
                    <p>
                      BuildOnClicks started with a simple observation: the construction industry in India was fragmented, with a significant trust and accessibility gap between professionals and clients.
                    </p>
                    <p>
                      We recognized that finding reliable contractors, architects, and vendors was a challenge for homeowners and small builders alike. Our platform was born to solve this problem by turning a fragmented process into one transparent, trustworthy, and efficient digital ecosystem.
                    </p>
                  </div>
                </div>

                <div className="space-y-4 sm:space-y-6">
                  <Card className="border border-gray-200 shadow-sm rounded-lg">
                    <CardContent className="p-4 sm:p-5 md:p-6">
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 sm:w-10 sm:h-10 bg-[#FF6B35]/10 rounded-full flex items-center justify-center shrink-0">
                          <Target className="w-4 h-4 sm:w-5 sm:h-5 text-[#FF6B35]" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-base sm:text-lg mb-1 sm:mb-2 text-gray-800">Our Mission</h3>
                          <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                            To simplify construction and empower trust between professionals and clients through our innovative digital platform.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border border-gray-200 shadow-sm rounded-lg">
                    <CardContent className="p-4 sm:p-5 md:p-6">
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 sm:w-10 sm:h-10 bg-[#FF6B35]/10 rounded-full flex items-center justify-center shrink-0">
                          <Eye className="w-4 h-4 sm:w-5 sm:h-5 text-[#FF6B35]" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-base sm:text-lg mb-1 sm:mb-2 text-gray-800">Our Vision</h3>
                          <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                            To be India's most trusted construction ecosystem, digitally connected and empowering every stakeholder in the construction industry.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </motion.div>

              {/* Right Column - CEO Info & Placeholder */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="space-y-4 sm:space-y-6"
              >
                <div className="bg-gray-200 rounded-lg p-6 sm:p-8 h-[300px] sm:h-[400px] md:h-[500px] flex items-center justify-center border border-gray-300">
                  <p className="text-gray-500 text-center font-medium text-sm sm:text-base">Image/Video Placeholder</p>
                </div>
                <div className="text-center sm:text-right px-2">
                  <p className="text-base sm:text-lg md:text-xl font-serif italic text-gray-800">
                    Meet the CEO Akshat Gupta
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
};

export default About;
