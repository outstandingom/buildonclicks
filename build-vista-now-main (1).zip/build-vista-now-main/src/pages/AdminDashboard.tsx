import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Monitor, Menu, X } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { AdminSidebar } from '@/components/admin/AdminSidebar';
import { AdminHeader } from '@/components/admin/AdminHeader';
import { DashboardHome } from '@/components/admin/DashboardHome';
import { PendingApprovals } from '@/components/admin/PendingApprovals';
import { UserManagement } from '@/components/admin/UserManagement';
import { PostModeration } from '@/components/admin/PostModeration';
import { Reports } from '@/components/admin/Reports';
import { CreditManagement } from '@/components/admin/CreditManagement';
import { SubscriptionAnalytics } from '@/components/admin/SubscriptionAnalytics';
import { SubscriptionManagement } from '@/components/admin/SubscriptionManagement';
import { LeadAnalytics } from '@/components/admin/LeadAnalytics';
import { UserCommunication } from '@/components/admin/UserCommunication';
import { ReferralManagement } from '@/components/admin/ReferralManagement';
import BannerManagement from '@/components/admin/BannerManagement';
import { ContactSubmissions } from '@/components/admin/ContactSubmissions';
import { QuickRequirementSubmissions } from '@/components/admin/QuickRequirementSubmissions';
import { AdminManagement } from '@/components/admin/AdminManagement';


const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const isMobile = useIsMobile();

  // Mobile sidebar toggle
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  // Close sidebar when a tab is selected on mobile
  const handleTabChange = (tab) => {
    setActiveTab(tab);
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  // Remove the desktop-only message block completely

  return (
    <div className="min-h-screen bg-gradient-section pb-24 sm:pb-8">
      {/* Mobile Header with Menu Button */}
      {isMobile && (
        <div className="sticky top-0 z-50 bg-card border-b border-border p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={toggleSidebar}
              className="p-2 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors"
            >
              {sidebarOpen ? (
                <X className="h-5 w-5 text-primary" />
              ) : (
                <Menu className="h-5 w-5 text-primary" />
              )}
            </button>
            <div>
              <h1 className="text-lg font-bold text-construction-secondary">
                Admin Dashboard
              </h1>
              <p className="text-xs text-construction-neutral">
                BuildOnClicks Platform
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Shield className="h-4 w-4 text-primary" />
            <span className="hidden xs:inline">Admin</span>
          </div>
        </div>
      )}

      <div className="flex">
        {/* Sidebar - Mobile Overlay & Desktop Fixed */}

            <div
          className={`${
            isMobile
              ? `fixed inset-0 z-40 transform transition-transform duration-300 ease-in-out ${
                  sidebarOpen ? 'translate-x-0' : '-translate-x-full'
                }`
              : 'fixed left-0 top-0 h-screen'
          }`}
        >
          {/* Mobile Overlay Backdrop */}
          {isMobile && sidebarOpen && (
            <div
              className="fixed inset-0 bg-black/50 z-30"
              onClick={() => setSidebarOpen(false)}
            />
          )}
          
          {/* Sidebar Container */}
          <div className={`relative z-40 ${isMobile ? 'w-64' : 'w-64'}`}>
            <AdminSidebar 
              activeTab={activeTab} 
              setActiveTab={handleTabChange} 
            />
          </div>
        </div>

        {/* Main Content */}
        <div className={`flex-1 ${isMobile ? '' : 'ml-64'}`}>
          {/* Desktop Header */}
          {!isMobile && <AdminHeader />}
          
          <div className="p-4 sm:p-6 md:p-8">
            {/* Page Title - Desktop Only */}
            {!isMobile && (
              <motion.div 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 md:mb-8"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl sm:text-3xl font-bold text-construction-secondary mb-2">
                      Admin Dashboard
                    </h1>
                    <p className="text-construction-neutral text-sm sm:text-base">
                      Manage your BuildOnClicks platform
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-construction-neutral">
                    <Shield className="h-4 w-4" />
                    Admin Access
                  </div>
                </div>
              </motion.div>
            )}

            {/* Mobile Active Tab Indicator */}
            {isMobile && (
              <div className="mb-6 p-3 bg-card rounded-lg border border-border">
                <h2 className="text-lg font-semibold text-construction-secondary capitalize">
                  {activeTab.replace('-', ' ')}
                </h2>
              </div>
            )}

            {/* Tab Content */}
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: isMobile ? 0 : 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-x-auto"
            >
              {activeTab === 'dashboard' && <DashboardHome />}
              {activeTab === 'approvals' && <PendingApprovals />}
              {activeTab === 'users' && <UserManagement />}
              {activeTab === 'posts' && <PostModeration />}
              {activeTab === 'banners' && <BannerManagement />}
              {activeTab === 'reports' && <Reports />}
              {activeTab === 'contact-submissions' && <ContactSubmissions />}
              {activeTab === 'quick-requirements' && <QuickRequirementSubmissions />}
              {activeTab === 'admin-management' && <AdminManagement />}
              {activeTab === 'credits' && <CreditManagement />}
              {activeTab === 'subscriptions' && <SubscriptionAnalytics />}
              {activeTab === 'subscription-management' && <SubscriptionManagement />}
              {activeTab === 'leads' && <LeadAnalytics />}
              {activeTab === 'communication' && <UserCommunication />}
              {activeTab === 'referral-management' && <ReferralManagement />}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
