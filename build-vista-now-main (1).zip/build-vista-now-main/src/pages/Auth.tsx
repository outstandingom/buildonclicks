import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { InputOTP, InputOTPGroup, InputOTPSlot, InputOTPSeparator } from "@/components/ui/input-otp";
import { Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useReferrals } from "@/hooks/useReferrals";
import { useLanguage } from '@/contexts/LanguageContext';

interface PendingUser {
  email: string;
  password: string;
  fullName: string;
  mobileNumber: string;
  userType: string;
  referralCode: string;
}

const Auth = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();
  const { user, loading } = useAuth();
  const { processReferralCode } = useReferrals();
  const { t } = useLanguage();
  
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('signin');
  
  // Password visibility states
  const [showSignInPassword, setShowSignInPassword] = useState(false);
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // Sign In State
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  
  // Sign Up State
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [userType, setUserType] = useState('user');
  const [referralCode, setReferralCode] = useState('');
  const [showReferralInput, setShowReferralInput] = useState(false);

  // OTP Verification State
  const [showOtpVerification, setShowOtpVerification] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [pendingUser, setPendingUser] = useState<PendingUser | null>(null);
  const [otpResendTimer, setOtpResendTimer] = useState(0);

  // Forgot/Reset Password State
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetLoading, setResetLoading] = useState(false);
  const [isResetMode, setIsResetMode] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  // Password Reset OTP State
  const [showPasswordOtpVerification, setShowPasswordOtpVerification] = useState(false);
  const [passwordOtpCode, setPasswordOtpCode] = useState('');
  const [passwordResetEmail, setPasswordResetEmail] = useState('');
  const [passwordOtpResendTimer, setPasswordOtpResendTimer] = useState(0);
  const [showNewPasswordForm, setShowNewPasswordForm] = useState(false);

  // Redirect authenticated users and check for referral code
  useEffect(() => {
    // Don't redirect if user is in password reset flow
    if (!loading && user && !showNewPasswordForm && !showPasswordOtpVerification) {
      navigate('/');
    }
    
    // Check for referral code in URL
    const refCode = searchParams.get('ref');
    if (refCode) {
      setReferralCode(refCode);
      setShowReferralInput(true);
    }
  }, [user, loading, navigate, searchParams, showNewPasswordForm, showPasswordOtpVerification]);

  // Listen for password recovery event
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') {
        setIsResetMode(true);
        setActiveTab('signin');
      }
    });
    return () => subscription.unsubscribe();
  }, []);

  // Auto-submit OTP when 6 digits are entered
  useEffect(() => {
    if (otpCode.length === 6 && showOtpVerification && pendingUser) {
      handleVerifyOtp();
    }
  }, [otpCode]);

  // OTP resend countdown timer
  useEffect(() => {
    if (otpResendTimer > 0) {
      const timer = setTimeout(() => {
        setOtpResendTimer(otpResendTimer - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [otpResendTimer]);

  // Auto-submit password OTP when 6 digits are entered
  useEffect(() => {
    if (passwordOtpCode.length === 6 && showPasswordOtpVerification) {
      handleVerifyPasswordOtp();
    }
  }, [passwordOtpCode]);

  // Password OTP resend countdown timer
  useEffect(() => {
    if (passwordOtpResendTimer > 0) {
      const timer = setTimeout(() => {
        setPasswordOtpResendTimer(passwordOtpResendTimer - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [passwordOtpResendTimer]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!signInEmail || !signInPassword) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: signInEmail,
        password: signInPassword,
      });

      if (error) {
        toast({
          title: "Sign In Failed",
          description: error.message,
          variant: "destructive",
        });
        return;
      }

      if (data.user) {
        toast({
          title: "Welcome back!",
          description: "You have been signed in successfully.",
        });
        
        // Process pending referral code after login
        const pendingReferralCode = localStorage.getItem('pendingReferralCode');
        if (pendingReferralCode) {
          await processReferralCode(pendingReferralCode);
          localStorage.removeItem('pendingReferralCode');
        }
        
        navigate('/');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const checkExistingUser = async (email: string, mobile: string) => {
    try {
      const { data, error } = await supabase.rpc('check_user_exists', {
        p_email: email,
        p_mobile: mobile
      });

      if (error) {
        console.error('Error checking existing user:', error);
        return { exists: false, type: null };
      }

      const result = data as { mobile_exists: boolean; email_exists: boolean };
      
      if (result.mobile_exists) {
        return { exists: true, type: 'mobile' };
      }
      
      if (result.email_exists) {
        return { exists: true, type: 'email' };
      }

      return { exists: false, type: null };
    } catch (error) {
      console.error('Error in checkExistingUser:', error);
      return { exists: false, type: null };
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!signUpEmail || !signUpPassword || !fullName || !mobileNumber) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    if (signUpPassword.length < 6) {
      toast({
        title: "Error",
        description: "Password must be at least 6 characters long",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      // Check for existing user in both auth.users and profiles
      const { exists, type } = await checkExistingUser(signUpEmail, mobileNumber);
      
      if (exists) {
        let message = "";
        if (type === 'email') {
          message = "An account with this email already exists. Please sign in instead.";
        } else if (type === 'mobile') {
          message = "An account with this mobile number already exists. Please use a different number or sign in.";
        }
        
        toast({
          title: "Account Already Exists",
          description: message,
          variant: "destructive",
        });
        
        if (type === 'email') {
          setActiveTab('signin');
          setSignInEmail(signUpEmail);
        }
        
        setIsLoading(false);
        return;
      }

      // Send OTP and allow Supabase to create the user
      const { error } = await supabase.auth.signInWithOtp({
        email: signUpEmail,
        options: {
          shouldCreateUser: true,
          data: {
            full_name: fullName,
            mobile_number: mobileNumber,
            user_type: userType,
          },
          emailRedirectTo: `${window.location.origin}/`,
        }
      });

      if (error) {
        toast({
          title: "OTP Failed",
          description: error.message,
          variant: "destructive",
        });
        return;
      }

      // Store user data locally for use after OTP verification
      const pendingUserData: PendingUser = {
        email: signUpEmail,
        password: signUpPassword,
        fullName,
        mobileNumber,
        userType,
        referralCode
      };
      
      setPendingUser(pendingUserData);
      setShowOtpVerification(true);
      setOtpResendTimer(60);
      
      toast({
        title: "Verification Code Sent",
        description: "Please check your email and enter the 6-digit code to verify your account.",
      });
      
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred during sign up",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleVerifyOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    if (otpCode.length !== 6) {
      toast({
        title: "Invalid Code",
        description: "Please enter the complete 6-digit code",
        variant: "destructive",
      });
      return;
    }

    if (!pendingUser) {
      toast({
        title: "Error",
        description: "No pending user data found. Please try signing up again.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      // First verify the OTP
      const { data: otpData, error: otpError } = await supabase.auth.verifyOtp({
        email: pendingUser.email,
        token: otpCode,
        type: 'signup'
      });

      if (otpError) {
        toast({
          title: "Verification Failed",
          description: otpError.message,
          variant: "destructive",
        });
        setOtpCode('');
        return;
      }

      // Set the password and ensure metadata is stored
      const { error: updateError } = await supabase.auth.updateUser({
        password: pendingUser.password,
        data: {
          full_name: pendingUser.fullName,
          mobile_number: pendingUser.mobileNumber,
          user_type: pendingUser.userType,
        }
      });

      if (updateError) {
        toast({
          title: "Account Update Failed",
          description: updateError.message,
          variant: "destructive",
        });
        setOtpCode('');
        return;
      }

      const userId = otpData?.session?.user.id || otpData?.user?.id;

      if (userId) {
        // The handle_new_user trigger should create the profile automatically
        // But let's add a fallback just in case
        setTimeout(async () => {
          try {
            const { data: existingProfile } = await supabase
              .from('profiles')
              .select('id')
              .eq('id', userId)
              .single();

            if (!existingProfile) {
              const { error: profileError } = await supabase
                .from('profiles')
                .insert({
                  id: userId,
                  full_name: pendingUser.fullName,
                  mobile_number: pendingUser.mobileNumber,
                  user_type: pendingUser.userType,
                });

              if (profileError) {
                console.error('Fallback profile creation error:', profileError);
              }
            }
          } catch (error) {
            console.error('Profile check error:', error);
          }
        }, 100);

        toast({
          title: "Account Verified and Created!",
          description: pendingUser.userType === 'provider' 
            ? "Your account has been verified. Please complete your business registration to start offering services."
            : "Your account has been verified successfully. Welcome to our platform!",
        });

        // Process referral code if provided
        if (pendingUser.referralCode) {
          setTimeout(async () => {
            await processReferralCode(pendingUser.referralCode);
          }, 1000);
        }

        // Navigate based on user type
        if (pendingUser.userType === 'provider') {
          navigate('/business-registration');
        } else {
          navigate('/');
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred during verification",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      setPendingUser(null);
      setOtpCode('');
      setShowOtpVerification(false);
    }
  };

  const handleResendOtp = async () => {
    if (otpResendTimer > 0) {
      toast({
        title: "Please Wait",
        description: `You can resend the code in ${otpResendTimer} seconds`,
        variant: "destructive",
      });
      return;
    }

    if (!pendingUser) {
      toast({
        title: "Error",
        description: "No pending user data found. Please try signing up again.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const { error } = await supabase.auth.signInWithOtp({
        email: pendingUser.email,
        options: {
          shouldCreateUser: false,
        }
      });

      if (error) {
        toast({
          title: "Resend Failed",
          description: error.message,
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Code Resent",
        description: "A new verification code has been sent to your email",
      });

      setOtpResendTimer(60);
      setOtpCode('');
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const checkEmailExists = async (email: string) => {
    try {
      const { data, error } = await supabase.rpc('email_exists_in_auth', {
        p_email: email
      });

      if (error) {
        console.error('Error checking email:', error);
        return true; // Default to true to avoid blocking legitimate users
      }

      return data;
    } catch (error) {
      console.error('Error in checkEmailExists:', error);
      return true; // Default to true to avoid blocking legitimate users
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const email = (forgotEmail || signInEmail).trim();
    if (!email) {
      toast({ title: "Error", description: "Please enter your email", variant: "destructive" });
      return;
    }

    try {
      setResetLoading(true);
      
      // Check if email exists in our database first
      const emailExists = await checkEmailExists(email);
      
      if (!emailExists) {
        toast({ 
          title: "Email not found", 
          description: "No account found with this email address. Please check your email or sign up for a new account.",
          variant: "destructive" 
        });
        return;
      }

      // Send OTP for password recovery
      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: {
          shouldCreateUser: false,
        }
      });
      
      if (error) {
        toast({ title: "Reset failed", description: error.message, variant: "destructive" });
        return;
      }
      
      toast({ 
        title: "OTP Sent", 
        description: "Check your email for the 6-digit verification code.",
      });
      
      setPasswordResetEmail(email);
      setShowPasswordOtpVerification(true);
      setPasswordOtpResendTimer(60);
      setPasswordOtpCode('');
    } catch (err) {
      toast({ title: "Error", description: "Something went wrong. Please try again.", variant: "destructive" });
    } finally {
      setResetLoading(false);
    }
  };

  const handleVerifyPasswordOtp = async () => {
    if (passwordOtpCode.length !== 6) {
      toast({ title: "Invalid code", description: "Please enter the 6-digit code", variant: "destructive" });
      return;
    }

    try {
      setResetLoading(true);
      const { error } = await supabase.auth.verifyOtp({
        email: passwordResetEmail,
        token: passwordOtpCode,
        type: 'recovery'
      });

      if (error) {
        toast({ title: "Verification failed", description: error.message, variant: "destructive" });
        setPasswordOtpCode('');
        return;
      }

      toast({ title: "Success", description: "OTP verified! Please set your new password." });
      setShowPasswordOtpVerification(false);
      setShowNewPasswordForm(true);
      setPasswordOtpCode('');
    } catch (err) {
      toast({ title: "Error", description: "Something went wrong. Please try again.", variant: "destructive" });
      setPasswordOtpCode('');
    } finally {
      setResetLoading(false);
    }
  };

  const handleResendPasswordOtp = async () => {
    try {
      setResetLoading(true);
      const { error } = await supabase.auth.signInWithOtp({
        email: passwordResetEmail,
        options: {
          shouldCreateUser: false,
        }
      });

      if (error) {
        toast({ title: "Resend failed", description: error.message, variant: "destructive" });
        return;
      }

      toast({ title: "Code Resent", description: "A new verification code has been sent to your email" });
      setPasswordOtpResendTimer(60);
      setPasswordOtpCode('');
    } catch (err) {
      toast({ title: "Error", description: "Something went wrong. Please try again.", variant: "destructive" });
    } finally {
      setResetLoading(false);
    }
  };

  const handleSetNewPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      toast({ title: "Invalid password", description: "Password must be at least 6 characters.", variant: "destructive" });
      return;
    }
    if (newPassword !== confirmPassword) {
      toast({ title: "Passwords do not match", description: "Please re-enter to confirm.", variant: "destructive" });
      return;
    }

    try {
      setResetLoading(true);
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      
      if (error) {
        toast({ title: "Update failed", description: error.message, variant: "destructive" });
        return;
      }

      toast({ title: "Password updated", description: "Your password has been successfully updated! Please sign in." });
      
      // Reset all states and close dialog
      setForgotOpen(false);
      setForgotEmail('');
      setPasswordResetEmail('');
      setShowPasswordOtpVerification(false);
      setShowNewPasswordForm(false);
      setPasswordOtpCode('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      toast({ title: "Error", description: "Something went wrong. Please try again.", variant: "destructive" });
    } finally {
      setResetLoading(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      toast({ title: "Invalid password", description: "Password must be at least 6 characters.", variant: "destructive" });
      return;
    }
    if (newPassword !== confirmPassword) {
      toast({ title: "Passwords do not match", description: "Please re-enter to confirm.", variant: "destructive" });
      return;
    }
    try {
      setResetLoading(true);
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) {
        toast({ title: "Update failed", description: error.message, variant: "destructive" });
        return;
      }
      toast({ title: "Password updated", description: "Please sign in with your new password." });
      await supabase.auth.signOut();
      setIsResetMode(false);
      setNewPassword('');
      setConfirmPassword('');
      navigate('/auth');
    } catch (err) {
      toast({ title: "Error", description: "Something went wrong. Please try again.", variant: "destructive" });
    } finally {
      setResetLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <img 
              src="https://i.ibb.co/q3PrjBJ5/buildonclicklogo.jpg" 
              alt="BuildOnClicks Logo" 
              className="h-24 w-24 rounded-lg object-cover shadow-sm"
            />
          </div>
          
          <div className="space-y-2">
            <CardTitle className="text-2xl font-bold text-primary">{t('pages.auth.welcome')}</CardTitle>
            <CardDescription>
              {t('pages.auth.welcomeDescription')}
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          {isResetMode ? (
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="new-password">New Password</Label>
                <Input
                  id="new-password"
                  type="password"
                  placeholder="Enter a new password (min 6 characters)"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  minLength={6}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirm New Password</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  placeholder="Re-enter new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  minLength={6}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={resetLoading}>
                {resetLoading ? 'Updating...' : 'Update Password'}
              </Button>
            </form>
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signin">Sign In</TabsTrigger>
                <TabsTrigger value="signup">Sign Up</TabsTrigger>
              </TabsList>
              
              <TabsContent value="signin">
                <form onSubmit={handleSignIn} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signin-email">Email</Label>
                    <Input
                      id="signin-email"
                      type="email"
                      placeholder="Enter your email"
                      value={signInEmail}
                      onChange={(e) => setSignInEmail(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signin-password">Password</Label>
                    <div className="relative">
                      <Input
                        id="signin-password"
                        type={showSignInPassword ? "text" : "password"}
                        placeholder="Enter your password"
                        value={signInPassword}
                        onChange={(e) => setSignInPassword(e.target.value)}
                        required
                        className="pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignInPassword(!showSignInPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showSignInPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                      </button>
                    </div>
                  </div>
                  <div className="text-right -mt-1">
                    <button
                      type="button"
                      className="text-sm text-primary hover:underline"
                      onClick={() => {
                        setForgotEmail(signInEmail);
                        setForgotOpen(true);
                      }}
                    >
                      Forgot password?
                    </button>
                  </div>
                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isLoading}
                  >
                    {isLoading ? "Signing In..." : "Sign In"}
                  </Button>
                </form>
              </TabsContent>
              
              <TabsContent value="signup">
                {showOtpVerification ? (
                  <div className="space-y-6">
                    <div className="text-center space-y-2">
                      <h3 className="text-lg font-semibold">Verify Your Email</h3>
                      <p className="text-sm text-muted-foreground">
                        We've sent a 6-digit verification code to
                      </p>
                      <p className="text-sm font-medium">{pendingUser?.email}</p>
                    </div>

                    <div className="flex flex-col items-center space-y-4">
                      <InputOTP 
                        maxLength={6} 
                        value={otpCode} 
                        onChange={(value) => setOtpCode(value)}
                      >
                        <InputOTPGroup>
                          <InputOTPSlot index={0} />
                          <InputOTPSlot index={1} />
                          <InputOTPSlot index={2} />
                        </InputOTPGroup>
                        <InputOTPSeparator />
                        <InputOTPGroup>
                          <InputOTPSlot index={3} />
                          <InputOTPSlot index={4} />
                          <InputOTPSlot index={5} />
                        </InputOTPGroup>
                      </InputOTP>

                      <p className="text-xs text-muted-foreground text-center">
                        Enter the code sent to your email. It will be verified automatically.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Button
                        type="button"
                        className="w-full"
                        onClick={handleVerifyOtp}
                        disabled={isLoading || otpCode.length !== 6}
                      >
                        {isLoading ? "Verifying..." : "Verify Code"}
                      </Button>

                      <Button
                        type="button"
                        variant="outline"
                        className="w-full"
                        onClick={handleResendOtp}
                        disabled={isLoading || otpResendTimer > 0}
                      >
                        {otpResendTimer > 0 
                          ? `Resend Code in ${otpResendTimer}s` 
                          : "Resend Code"}
                      </Button>

                      <Button
                        type="button"
                        variant="ghost"
                        className="w-full"
                        onClick={() => {
                          setShowOtpVerification(false);
                          setOtpCode('');
                          setPendingUser(null);
                        }}
                      >
                        Back to Sign Up
                      </Button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSignUp} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signup-email">Email</Label>
                      <Input
                        id="signup-email"
                        type="email"
                        placeholder="Enter your email"
                        value={signUpEmail}
                        onChange={(e) => setSignUpEmail(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Password</Label>
                      <div className="relative">
                        <Input
                          id="signup-password"
                          type={showSignUpPassword ? "text" : "password"}
                          placeholder="Create a password (min 6 characters)"
                          value={signUpPassword}
                          onChange={(e) => setSignUpPassword(e.target.value)}
                          required
                          minLength={6}
                          className="pr-10"
                        />
                        <button
                          type="button"
                          onClick={() => setShowSignUpPassword(!showSignUpPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          {showSignUpPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="full-name">Full Name</Label>
                      <Input
                        id="full-name"
                        type="text"
                        placeholder="Enter your full name"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="mobile-number">Mobile Number</Label>
                      <Input
                        id="mobile-number"
                        type="tel"
                        placeholder="Enter your mobile number"
                        value={mobileNumber}
                        onChange={(e) => setMobileNumber(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Account Type</Label>
                      <RadioGroup value={userType} onValueChange={setUserType}>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="user" id="user" />
                          <Label htmlFor="user" className="font-normal">
                            User (Looking for services)
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="provider" id="provider" />
                          <Label htmlFor="provider" className="font-normal">
                            Service Provider (Offering services)
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    {showReferralInput && (
                      <div className="space-y-2">
                        <Label htmlFor="referralCode">Referral Code (Optional)</Label>
                        <Input
                          id="referralCode"
                          value={referralCode}
                          onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                          placeholder="Enter referral code"
                          className="font-mono text-center tracking-wider"
                        />
                        <p className="text-xs text-muted-foreground">
                          Have a referral code? Enter it to get bonus credits!
                        </p>
                      </div>
                    )}

                    {!showReferralInput && (
                      <Button
                        type="button"
                        variant="outline"
                        className="w-full"
                        onClick={() => setShowReferralInput(true)}
                      >
                        Have a referral code?
                      </Button>
                    )}

                    <Button
                      type="submit"
                      className="w-full"
                      disabled={isLoading}
                    >
                      {isLoading ? "Sending OTP..." : "Send Verification Code"}
                    </Button>
                  </form>
                )}
              </TabsContent>
            </Tabs>
          )}

          <Dialog open={forgotOpen} onOpenChange={(open) => {
            setForgotOpen(open);
            if (!open) {
              // Reset all states when dialog closes
              setForgotEmail('');
              setPasswordResetEmail('');
              setShowPasswordOtpVerification(false);
              setShowNewPasswordForm(false);
              setPasswordOtpCode('');
              setNewPassword('');
              setConfirmPassword('');
            }
          }}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Reset your password</DialogTitle>
                <DialogDescription>
                  {!showPasswordOtpVerification && !showNewPasswordForm && "Enter your email address and we'll send you a verification code."}
                  {showPasswordOtpVerification && `Enter the 6-digit code sent to ${passwordResetEmail}`}
                  {showNewPasswordForm && "Set your new password"}
                </DialogDescription>
              </DialogHeader>

              {/* State 1: Email Input */}
              {!showPasswordOtpVerification && !showNewPasswordForm && (
                <form onSubmit={handleResetPassword} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="forgot-email">Email</Label>
                    <Input
                      id="forgot-email"
                      type="email"
                      placeholder="you@example.com"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      required
                    />
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setForgotOpen(false)}>Cancel</Button>
                    <Button type="submit" disabled={resetLoading}>
                      {resetLoading ? 'Sending...' : 'Send OTP'}
                    </Button>
                  </DialogFooter>
                </form>
              )}

              {/* State 2: OTP Verification */}
              {showPasswordOtpVerification && !showNewPasswordForm && (
                <div className="space-y-4">
                  <div className="flex justify-center">
                    <InputOTP 
                      maxLength={6} 
                      value={passwordOtpCode} 
                      onChange={setPasswordOtpCode}
                      disabled={resetLoading}
                    >
                      <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                      </InputOTPGroup>
                      <InputOTPSeparator />
                      <InputOTPGroup>
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                        <InputOTPSlot index={5} />
                      </InputOTPGroup>
                    </InputOTP>
                  </div>
                  <DialogFooter className="flex-col sm:flex-row gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setShowPasswordOtpVerification(false);
                        setPasswordOtpCode('');
                      }}
                      disabled={resetLoading}
                    >
                      Change Email
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleResendPasswordOtp}
                      disabled={passwordOtpResendTimer > 0 || resetLoading}
                    >
                      {passwordOtpResendTimer > 0 ? `Resend in ${passwordOtpResendTimer}s` : 'Resend OTP'}
                    </Button>
                    <Button
                      onClick={handleVerifyPasswordOtp}
                      disabled={passwordOtpCode.length !== 6 || resetLoading}
                    >
                      {resetLoading ? 'Verifying...' : 'Verify OTP'}
                    </Button>
                  </DialogFooter>
                </div>
              )}

              {/* State 3: New Password Form */}
              {showNewPasswordForm && (
                <form onSubmit={handleSetNewPassword} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <div className="relative">
                      <Input
                        id="new-password"
                        type={showNewPassword ? "text" : "password"}
                        placeholder="Enter new password (min. 6 characters)"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        required
                        minLength={6}
                        className="pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showNewPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                      </button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm Password</Label>
                    <div className="relative">
                      <Input
                        id="confirm-password"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="Re-enter your password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                        minLength={6}
                        className="pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                      </button>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" disabled={resetLoading} className="w-full">
                      {resetLoading ? 'Updating...' : 'Reset Password'}
                    </Button>
                  </DialogFooter>
                </form>
              )}
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>
    </div>
  );
};

export default Auth;
