
import React from 'react';
import { BusinessRegistrationForm } from '@/components/BusinessRegistrationForm';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const BusinessRegistration: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
      <Header />
      <div className="flex-1 bg-background">
        <BusinessRegistrationForm />
      </div>
      <Footer />
    </div>
  );
};

export default BusinessRegistration;
