import React, { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Send, Bot, User, ChevronDown, ChevronUp } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

const ChatAssistant: React.FC = () => {
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello! I'm your construction assistant. I can help you with finding construction materials, connecting with contractors, project planning, and cost estimation. What would you like to know about your construction project?",
      isUser: false,
      timestamp: new Date()
    }
  ]);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);

  // Function to clean AI response text
  const cleanResponseText = (text: string): string => {
    let cleaned = text
      .replace(/\*\*/g, '')
      .replace(/\*/g, '')
      .replace(/#{1,6}\s?/g, '')
      .replace(/\[.*?\]\(.*?\)/g, (match) => {
        const linkText = match.match(/\[(.*?)\]/);
        return linkText ? linkText[1] : '';
      })
      .replace(/\n{3,}/g, '\n\n')
      .replace(/^\s*[\-\*]\s+/gm, '• ')
      .trim();

    cleaned = cleaned.replace(/([.!?])([A-Z])/g, '$1 $2');
    
    return cleaned;
  };

  // Optimized scroll function
  const scrollToBottom = useCallback(() => {
    if (messagesEndRef.current && messagesContainerRef.current) {
      const container = messagesContainerRef.current;
      container.scrollTop = container.scrollHeight;
    }
  }, []);

  // Scroll when messages change or loading state changes
  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading, scrollToBottom]);

  // Initialize scroll to bottom on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      scrollToBottom();
    }, 100);
    return () => clearTimeout(timer);
  }, [scrollToBottom]);

  const callGeminiAPI = async (userMessage: string): Promise<string> => {
    try {
      const API_KEY = import.meta.env.VITE_GOOGLE_gemni_API_KEY;
      
      if (!API_KEY) {
        throw new Error("API key not configured");
      }

      const prompt = `SYSTEM INSTRUCTION:
You are a knowledgeable Construction Assistant for BuildOnClicks.
Help users with construction materials, estimation, contractors, interior design, and general building knowledge.

IMPORTANT FORMATTING RULES:
1. Respond in clear, plain English only
2. NEVER use markdown formatting like **bold**, *italics*, or ### headers
3. NEVER use asterisks (*) for bullet points - use plain text
4. Use proper paragraphs with line breaks
5. Keep responses concise but informative
6. If listing items, use simple indentation or dashes
7. Avoid excessive symbols and emojis

USER QUESTION: ${userMessage}

Provide a helpful, professional response following the formatting rules above:`;

      const requestBody = {
        contents: [
          {
            parts: [
              {
                text: prompt
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.3,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 800,
        }
      };

      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody)
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error('API Response Error:', errorText);
        throw new Error(`API request failed with status ${response.status}`);
      }

      const data = await response.json();
      
      if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
        console.error('Invalid API response structure:', data);
        throw new Error("Invalid response format from API");
      }

      const rawResponse = data.candidates[0].content.parts[0].text;
      return cleanResponseText(rawResponse);
    } catch (error) {
      console.error('Error calling Gemini API:', error);
      throw error;
    }
  };

  const handleSendMessage = async () => {
    if (!message.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: message.trim(),
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setMessage("");
    setIsLoading(true);

    try {
      const aiResponse = await callGeminiAPI(message);
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse,
        isUser: false,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error in handleSendMessage:', error);
      
      // Fallback responses
      let fallbackResponse = "I understand your construction question. Based on your query, I recommend consulting with our verified contractors for personalized assistance.";
      
      if (message.toLowerCase().includes('material')) {
        fallbackResponse = "For construction materials, I suggest checking our material database. Common materials include cement, steel, bricks, and concrete. The best choice depends on your specific project requirements and budget.";
      } else if (message.toLowerCase().includes('cost') || message.toLowerCase().includes('price')) {
        fallbackResponse = "Construction costs vary based on location, materials, and project scope. For accurate estimation, I recommend contacting our cost estimation specialists with your project details.";
      } else if (message.toLowerCase().includes('contractor')) {
        fallbackResponse = "We have verified contractors available in your area. They specialize in various construction types including residential, commercial, and renovation projects.";
      } else if (message.toLowerCase().includes('design')) {
        fallbackResponse = "For architectural design suggestions, I recommend considering factors like your budget, space requirements, and local building codes. Our design consultants can provide personalized recommendations.";
      }
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: fallbackResponse,
        isUser: false,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setMessage(suggestion);
    setShowSuggestions(false);
    setTimeout(() => {
      handleSendMessage();
    }, 100);
  };

  const quickSuggestions = [
    "Best contractors for home construction?",
    "Building material prices in Bhopal",
    "Architectural design suggestions",
    "Project cost estimation",
    "Find verified plumbers near me",
    "Interior design consultation"
  ];

  return (
    <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
      <Header />
      
      <div className="flex-1 bg-gradient-section">
        <div className="container mx-auto px-4 py-6">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
          
          </motion.div>

          {/* Chat Interface */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="max-w-4xl mx-auto"
          >
            <Card className="shadow-lg">
              <CardHeader className="bg-construction-primary text-white">
                <CardTitle className="flex items-center gap-2">
                  <Bot className="w-6 h-6" />
                  Construction Assistant
                </CardTitle>
                <CardDescription className="text-white/80">
                  Ask me about construction materials, contractors, or project guidance
                </CardDescription>
              </CardHeader>
              
              <CardContent className="p-0">
                {/* Chat Messages */}
                <div 
                  ref={messagesContainerRef}
                  className="h-96 overflow-y-auto p-6 bg-muted/30"
                >
                  <div className="space-y-4">
                    {messages.map((msg) => (
                      <motion.div
                        key={msg.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${msg.isUser ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className="flex gap-3 max-w-[80%]">
                          {!msg.isUser && (
                            <div className="w-8 h-8 bg-construction-primary rounded-full flex items-center justify-center flex-shrink-0">
                              <Bot className="w-4 h-4 text-white" />
                            </div>
                          )}
                          <div
                            className={`px-4 py-3 rounded-2xl ${
                              msg.isUser
                                ? 'bg-construction-primary text-white rounded-br-none'
                                : 'bg-white border border-gray-200 rounded-tl-none'
                            }`}
                          >
                            <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                            <p className={`text-xs mt-1 ${msg.isUser ? 'text-white/70' : 'text-gray-500'}`}>
                              {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                          {msg.isUser && (
                            <div className="w-8 h-8 bg-gray-400 rounded-full flex items-center justify-center flex-shrink-0">
                              <User className="w-4 h-4 text-white" />
                            </div>
                          )}
                        </div>
                      </motion.div>
                    ))}
                    
                    {/* Loading Indicator */}
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="flex justify-start"
                      >
                        <div className="flex gap-3">
                          <div className="w-8 h-8 bg-construction-primary rounded-full flex items-center justify-center">
                            <Bot className="w-4 h-4 text-white" />
                          </div>
                          <div className="bg-white border border-gray-200 rounded-2xl rounded-tl-none px-4 py-3">
                            <div className="flex items-center space-x-2">
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                    <div ref={messagesEndRef} className="h-4" />
                  </div>
                </div>

                {/* Quick Suggestions Dropdown */}
                <div className="border-t border-gray-200 bg-white">
                  <button
                    onClick={() => setShowSuggestions(!showSuggestions)}
                    className="w-full px-6 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-100"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-gray-700">
                        Quick Suggestions
                      </span>
                    </div>
                    {showSuggestions ? (
                      <ChevronUp className="w-4 h-4 text-gray-500" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-gray-500" />
                    )}
                  </button>
                  
                  <AnimatePresence>
                    {showSuggestions && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                      >
                        <div className="p-4">
                          <div className="flex flex-wrap gap-2">
                            {quickSuggestions.map((suggestion, index) => (
                              <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                onClick={() => handleSuggestionClick(suggestion)}
                                disabled={isLoading}
                                className="text-xs h-8"
                              >
                                {suggestion}
                              </Button>
                            ))}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Input Area */}
                <div className="border-t border-gray-200 p-6 bg-white">
                  <div className="flex gap-4">
                    <Textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyDown={handleKeyPress}
                      placeholder="Type your construction-related question here... (e.g., 'What materials do I need for a 2BHK house?', 'Find me contractors in Bhopal')"
                      className="min-h-[80px] resize-none"
                      disabled={isLoading}
                    />
                    <Button
                      onClick={handleSendMessage}
                      disabled={!message.trim() || isLoading}
                      className="bg-construction-primary hover:bg-construction-primary/90 h-auto px-6"
                      size="lg"
                    >
                      {isLoading ? (
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <Send className="w-5 h-5" />
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Features Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="mt-8"
            >
            
            </motion.div>
          </motion.div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default ChatAssistant;
