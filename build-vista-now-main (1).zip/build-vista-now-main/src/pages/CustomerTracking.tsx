import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { Search, Phone, MessageSquare, UserPlus, RefreshCw, Download, Edit, Trash2, CheckCircle, XCircle, Building, Filter, ChevronDown, MoreVertical } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Import Supabase
import { createClient } from '@supabase/supabase-js';

// Create supabase client
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
const supabase = createClient(supabaseUrl, supabaseAnonKey);

interface Customer {
  id: string;
  name: string;
  mobile_number: string;
  notes: string;
  registered: boolean;
  business_category: string;
  follow_up_date: string | null;
  created_at: string;
  status: string;
  last_contact_date: string | null;
  call_count: number;
  whatsapp_sent: boolean;
}

const STATUS_OPTIONS = [
  { value: 'new', label: 'New', color: 'bg-blue-500' },
  { value: 'contacted', label: 'Contacted', color: 'bg-blue-400' },
  { value: 'interested', label: 'Interested', color: 'bg-green-500' },
  { value: 'not_interested', label: 'Not Interested', color: 'bg-red-500' },
  { value: 'registered', label: 'Registered', color: 'bg-green-600' },
  { value: 'follow_up', label: 'Follow Up', color: 'bg-orange-500' },
  { value: 'wrong_number', label: 'Wrong Number', color: 'bg-gray-500' },
  { value: 'busy', label: 'Busy', color: 'bg-yellow-500' },
  { value: 'call_later', label: 'Call Later', color: 'bg-orange-400' }
];

const CATEGORY_OPTIONS = [
  { value: 'plumber', label: 'Plumber' },
  { value: 'contractor', label: 'Contractor' },
  { value: 'engineer', label: 'Engineer' },
  { value: 'architect', label: 'Architect' },
  { value: 'manufacturer', label: 'Manufacturer' },
  { value: 'vendor', label: 'Vendor' },
  { value: 'other', label: 'Other' }
];

const CustomerTracking: React.FC = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [openDialog, setOpenDialog] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [newCustomer, setNewCustomer] = useState({
    name: '',
    mobile_number: '',
    notes: '',
    business_category: '',
    status: 'new',
    registered: false
  });
  const { toast } = useToast();
  const [stats, setStats] = useState({
    total: 0,
    registered: 0,
    interested: 0,
    followUp: 0,
    todayContacts: 0
  });

  useEffect(() => {
    fetchCustomers();
    fetchStats();
  }, [filterStatus, filterCategory]);

  const fetchCustomers = async () => {
    try {
      setLoading(true);
      let query = supabase
        .from('customer_tracking')
        .select('*')
        .order('created_at', { ascending: false });

      if (filterStatus !== 'all') {
        query = query.eq('status', filterStatus);
      }

      if (filterCategory !== 'all') {
        query = query.eq('business_category', filterCategory);
      }

      if (searchTerm) {
        query = query.or(`name.ilike.%${searchTerm}%,mobile_number.ilike.%${searchTerm}%`);
      }

      const { data, error } = await query;

      if (error) throw error;
      setCustomers(data || []);
    } catch (error) {
      console.error('Error fetching customers:', error);
      toast({
        title: "Error",
        description: "Failed to load customers",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const { data, error } = await supabase
        .from('customer_tracking')
        .select('status, registered, created_at');

      if (error) throw error;

      const today = new Date().toISOString().split('T')[0];
      const statsData = {
        total: data?.length || 0,
        registered: data?.filter(c => c.registered).length || 0,
        interested: data?.filter(c => c.status === 'interested').length || 0,
        followUp: data?.filter(c => c.status === 'follow_up').length || 0,
        todayContacts: data?.filter(c => 
          c.created_at && c.created_at.startsWith(today)
        ).length || 0
      };

      setStats(statsData);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleAddCustomer = async () => {
    if (!newCustomer.name.trim() || !newCustomer.mobile_number.trim()) {
      toast({
        title: "Error",
        description: "Name and mobile number are required",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('customer_tracking')
        .insert([{
          ...newCustomer,
          call_count: 0,
          whatsapp_sent: false,
          last_contact_date: new Date().toISOString(),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Customer added successfully",
      });
      setOpenDialog(false);
      setNewCustomer({
        name: '',
        mobile_number: '',
        notes: '',
        business_category: '',
        status: 'new',
        registered: false
      });
      fetchCustomers();
      fetchStats();
    } catch (error) {
      console.error('Error adding customer:', error);
      toast({
        title: "Error",
        description: "Failed to add customer",
        variant: "destructive",
      });
    }
  };

  const handleUpdateCustomer = async () => {
    if (!editingCustomer) return;

    try {
      const { error } = await supabase
        .from('customer_tracking')
        .update({
          notes: editingCustomer.notes,
          status: editingCustomer.status,
          registered: editingCustomer.registered,
          updated_at: new Date().toISOString()
        })
        .eq('id', editingCustomer.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Customer updated successfully",
      });
      setEditingCustomer(null);
      fetchCustomers();
      fetchStats();
    } catch (error) {
      console.error('Error updating customer:', error);
      toast({
        title: "Error",
        description: "Failed to update customer",
        variant: "destructive",
      });
    }
  };

  const handleDeleteCustomer = async (id: string) => {
    if (!confirm('Are you sure you want to delete this customer?')) return;

    try {
      const { error } = await supabase
        .from('customer_tracking')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Customer deleted successfully",
      });
      fetchCustomers();
      fetchStats();
    } catch (error) {
      console.error('Error deleting customer:', error);
      toast({
        title: "Error",
        description: "Failed to delete customer",
        variant: "destructive",
      });
    }
  };

  const handleCall = (mobileNumber: string) => {
    window.open(`tel:${mobileNumber}`, '_blank');
  };

  const handleWhatsApp = (mobileNumber: string, name: string) => {
    const message = `Hello ${name}, this is regarding your inquiry with BuildOnClicks. How can we assist you today?`;
    const whatsappUrl = `https://wa.me/${mobileNumber}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleStatusUpdate = async (customerId: string, newStatus: string) => {
    try {
      const currentCustomer = customers.find(c => c.id === customerId);
      if (!currentCustomer) return;

      const { error } = await supabase
        .from('customer_tracking')
        .update({
          status: newStatus,
          last_contact_date: new Date().toISOString(),
          call_count: (currentCustomer.call_count || 0) + 1
        })
        .eq('id', customerId);

      if (error) throw error;

      fetchCustomers();
      toast({
        title: "Status Updated",
        description: "Customer status has been updated",
      });
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const handleExport = () => {
    const csvContent = customers.map(c => 
      `${c.name},${c.mobile_number},${c.status},${c.business_category},${c.registered ? 'Yes' : 'No'},${c.notes}`
    ).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'customers.csv';
    a.click();
  };

  const getStatusBadge = (status: string) => {
    const statusOption = STATUS_OPTIONS.find(s => s.value === status) || STATUS_OPTIONS[0];
    return (
      <Badge className={`${statusOption.color} text-white px-2 py-1 text-xs`}>
        {statusOption.label}
      </Badge>
    );
  };

  const filteredCustomers = customers.filter(customer => {
    if (filterStatus !== 'all' && customer.status !== filterStatus) return false;
    if (filterCategory !== 'all' && customer.business_category !== filterCategory) return false;
    if (searchTerm && !customer.name.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !customer.mobile_number.includes(searchTerm)) return false;
    return true;
  });

  return (
    <div className="container mx-auto px-3 py-4 sm:px-4 sm:py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-1 sm:text-3xl sm:mb-2">Customer Tracking</h1>
        <p className="text-sm text-gray-600 sm:text-base">Track customer registration progress and daily follow-ups</p>
      </div>

      {/* Stats Cards - Mobile Responsive */}
      <div className="grid grid-cols-2 gap-3 mb-6 sm:grid-cols-5 sm:gap-4">
        <Card className="col-span-1">
          <CardContent className="p-3 sm:p-6">
            <p className="text-xs text-gray-500 mb-1 sm:text-sm sm:mb-2">Total</p>
            <p className="text-lg font-bold sm:text-2xl">{stats.total}</p>
          </CardContent>
        </Card>
        <Card className="col-span-1">
          <CardContent className="p-3 sm:p-6">
            <p className="text-xs text-gray-500 mb-1 sm:text-sm sm:mb-2">Registered</p>
            <p className="text-lg font-bold text-green-600 sm:text-2xl">{stats.registered}</p>
          </CardContent>
        </Card>
        <Card className="col-span-1">
          <CardContent className="p-3 sm:p-6">
            <p className="text-xs text-gray-500 mb-1 sm:text-sm sm:mb-2">Interested</p>
            <p className="text-lg font-bold text-blue-600 sm:text-2xl">{stats.interested}</p>
          </CardContent>
        </Card>
        <Card className="col-span-1">
          <CardContent className="p-3 sm:p-6">
            <p className="text-xs text-gray-500 mb-1 sm:text-sm sm:mb-2">Follow Up</p>
            <p className="text-lg font-bold text-orange-600 sm:text-2xl">{stats.followUp}</p>
          </CardContent>
        </Card>
        <Card className="col-span-2 sm:col-span-1">
          <CardContent className="p-3 sm:p-6">
            <p className="text-xs text-gray-500 mb-1 sm:text-sm sm:mb-2">Today</p>
            <p className="text-lg font-bold sm:text-2xl">{stats.todayContacts}</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters - Mobile Responsive */}
      <Card className="mb-6">
        <CardContent className="p-4 sm:p-6">
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by name or mobile..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-1">
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-full">
                    <div className="flex items-center">
                      <Filter className="h-3 w-3 mr-2 sm:h-4 sm:w-4" />
                      <span className="text-xs sm:text-sm">Status</span>
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    {STATUS_OPTIONS.map(status => (
                      <SelectItem key={status.value} value={status.value} className="text-xs sm:text-sm">
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="col-span-1">
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="w-full">
                    <div className="flex items-center">
                      <Building className="h-3 w-3 mr-2 sm:h-4 sm:w-4" />
                      <span className="text-xs sm:text-sm">Category</span>
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {CATEGORY_OPTIONS.map(category => (
                      <SelectItem key={category.value} value={category.value} className="text-xs sm:text-sm">
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button className="flex-1 min-w-[140px]" onClick={() => setOpenDialog(true)}>
                <UserPlus className="mr-2 h-4 w-4" />
                <span className="text-xs sm:text-sm">Add Customer</span>
              </Button>
              <Button variant="outline" size="icon" onClick={fetchCustomers}>
                <RefreshCw className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={handleExport}>
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs - Mobile Responsive */}
      <Tabs defaultValue="all" className="mb-6">
        <TabsList className="grid grid-cols-2 mb-4 w-full sm:grid-cols-4">
          <TabsTrigger value="all" className="text-xs sm:text-sm">All</TabsTrigger>
          <TabsTrigger value="follow_up" className="text-xs sm:text-sm">
            Follow Up <Badge className="ml-1 bg-orange-500 text-xs">{stats.followUp}</Badge>
          </TabsTrigger>
          <TabsTrigger value="interested" className="text-xs sm:text-sm">
            Interested <Badge className="ml-1 bg-blue-500 text-xs">{stats.interested}</Badge>
          </TabsTrigger>
          <TabsTrigger value="not_registered" className="text-xs sm:text-sm">
            Not Reg <Badge className="ml-1 bg-red-500 text-xs">{stats.total - stats.registered}</Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          {/* Customer List - Mobile Responsive */}
          <Card>
            <CardContent className="p-4 sm:p-6">
              {loading ? (
                <div className="text-center py-8">Loading customers...</div>
              ) : filteredCustomers.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No customers found. Try adding some customers or adjust your filters.
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Mobile View - Card Layout */}
                  <div className="sm:hidden">
                    {filteredCustomers.map((customer) => (
                      <Card key={customer.id} className="mb-4">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-3">
                            <div className="flex items-center">
                              <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white text-sm mr-3">
                                {customer.name.charAt(0)}
                              </div>
                              <div>
                                <p className="font-medium text-sm">{customer.name}</p>
                                <p className="text-xs text-gray-500">{customer.mobile_number}</p>
                              </div>
                            </div>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => setEditingCustomer(customer)}>
                                  <Edit className="h-4 w-4 mr-2" />
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleDeleteCustomer(customer.id)}>
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>

                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span className="text-xs text-gray-500">Category:</span>
                              <Badge variant="outline" className="text-xs">
                                {customer.business_category || 'N/A'}
                              </Badge>
                            </div>
                            
                            <div className="flex justify-between">
                              <span className="text-xs text-gray-500">Status:</span>
                              <Select
                                value={customer.status}
                                onValueChange={(value) => handleStatusUpdate(customer.id, value)}
                              >
                                <SelectTrigger className="h-7 w-28 text-xs">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {STATUS_OPTIONS.map(status => (
                                    <SelectItem key={status.value} value={status.value} className="text-xs">
                                      {status.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                            
                            <div className="flex justify-between">
                              <span className="text-xs text-gray-500">Registered:</span>
                              {customer.registered ? (
                                <CheckCircle className="h-4 w-4 text-green-600" />
                              ) : (
                                <XCircle className="h-4 w-4 text-red-600" />
                              )}
                            </div>

                            <div className="flex justify-between">
                              <span className="text-xs text-gray-500">Calls:</span>
                              <Badge variant="secondary" className="text-xs">{customer.call_count}</Badge>
                            </div>

                            {customer.notes && (
                              <div>
                                <p className="text-xs text-gray-500 mb-1">Notes:</p>
                                <p className="text-xs truncate">{customer.notes}</p>
                              </div>
                            )}
                          </div>

                          <div className="flex justify-between mt-4">
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleCall(customer.mobile_number)}
                                className="h-8 px-3"
                              >
                                <Phone className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleWhatsApp(customer.mobile_number, customer.name)}
                                className="h-8 px-3"
                              >
                                <MessageSquare className="h-4 w-4" />
                              </Button>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => setEditingCustomer(customer)}
                              className="h-8"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Desktop View - Table Layout */}
                  <div className="hidden sm:block overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[200px]">Customer</TableHead>
                          <TableHead>Mobile</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Notes</TableHead>
                          <TableHead>Registered</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredCustomers.map((customer) => (
                          <TableRow key={customer.id}>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white">
                                  {customer.name.charAt(0)}
                                </div>
                                <div>
                                  <p className="font-medium">{customer.name}</p>
                                  <p className="text-sm text-gray-500">
                                    {new Date(customer.created_at).toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <p className="font-mono text-sm">{customer.mobile_number}</p>
                              <div className="flex gap-2 mt-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleCall(customer.mobile_number)}
                                  className="h-8 w-8 p-0"
                                >
                                  <Phone className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleWhatsApp(customer.mobile_number, customer.name)}
                                  className="h-8 w-8 p-0"
                                >
                                  <MessageSquare className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="flex items-center gap-1">
                                <Building className="h-3 w-3" />
                                {customer.business_category || 'Not specified'}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Select
                                value={customer.status}
                                onValueChange={(value) => handleStatusUpdate(customer.id, value)}
                              >
                                <SelectTrigger className="w-[140px]">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {STATUS_OPTIONS.map(status => (
                                    <SelectItem key={status.value} value={status.value}>
                                      {status.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <div className="max-w-xs truncate" title={customer.notes || 'No notes'}>
                                {customer.notes || '-'}
                              </div>
                            </TableCell>
                            <TableCell>
                              {customer.registered ? (
                                <CheckCircle className="h-5 w-5 text-green-600" />
                              ) : (
                                <XCircle className="h-5 w-5 text-red-600" />
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => setEditingCustomer(customer)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleDeleteCustomer(customer.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {['follow_up', 'interested', 'not_registered'].map((tab) => (
          <TabsContent key={tab} value={tab}>
            <Card>
              <CardContent className="p-4 sm:p-6">
                <div className="space-y-4 sm:hidden">
                  {filteredCustomers
                    .filter(customer => {
                      if (tab === 'follow_up') return customer.status === 'follow_up';
                      if (tab === 'interested') return customer.status === 'interested';
                      if (tab === 'not_registered') return !customer.registered;
                      return true;
                    })
                    .map((customer) => (
                      <Card key={customer.id} className="p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white text-sm mr-3">
                              {customer.name.charAt(0)}
                            </div>
                            <div>
                              <p className="font-medium text-sm">{customer.name}</p>
                              <p className="text-xs text-gray-500">{customer.mobile_number}</p>
                            </div>
                          </div>
                          {getStatusBadge(customer.status)}
                        </div>
                        <div className="flex justify-between">
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleCall(customer.mobile_number)}
                              className="h-8 px-3"
                            >
                              <Phone className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleWhatsApp(customer.mobile_number, customer.name)}
                              className="h-8 px-3"
                            >
                              <MessageSquare className="h-4 w-4" />
                            </Button>
                          </div>
                          <Button
                            size="sm"
                            onClick={() => setEditingCustomer(customer)}
                            className="h-8"
                          >
                            Edit
                          </Button>
                        </div>
                      </Card>
                    ))}
                </div>
                
                <div className="hidden sm:block overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Customer</TableHead>
                        <TableHead>Mobile</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredCustomers
                        .filter(customer => {
                          if (tab === 'follow_up') return customer.status === 'follow_up';
                          if (tab === 'interested') return customer.status === 'interested';
                          if (tab === 'not_registered') return !customer.registered;
                          return true;
                        })
                        .map((customer) => (
                          <TableRow key={customer.id}>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white">
                                  {customer.name.charAt(0)}
                                </div>
                                <div>
                                  <p className="font-medium">{customer.name}</p>
                                  <p className="text-sm text-gray-500">{customer.mobile_number}</p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleCall(customer.mobile_number)}
                                >
                                  <Phone className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleWhatsApp(customer.mobile_number, customer.name)}
                                >
                                  <MessageSquare className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell>{getStatusBadge(customer.status)}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  onClick={() => setEditingCustomer(customer)}
                                >
                                  Edit
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      {/* Add Customer Dialog */}
      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className="max-h-[90vh] overflow-y-auto w-[95vw] sm:w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl">Add New Customer</DialogTitle>
            <DialogDescription className="text-sm sm:text-base">
              Add a new customer to track their registration progress.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name" className="text-sm sm:text-base">Name *</Label>
              <Input
                id="name"
                value={newCustomer.name}
                onChange={(e) => setNewCustomer({...newCustomer, name: e.target.value})}
                required
                className="text-sm sm:text-base"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="mobile" className="text-sm sm:text-base">Mobile Number *</Label>
              <Input
                id="mobile"
                value={newCustomer.mobile_number}
                onChange={(e) => setNewCustomer({...newCustomer, mobile_number: e.target.value})}
                required
                className="text-sm sm:text-base"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="category" className="text-sm sm:text-base">Business Category</Label>
              <Select
                value={newCustomer.business_category}
                onValueChange={(value) => setNewCustomer({...newCustomer, business_category: value})}
              >
                <SelectTrigger className="text-sm sm:text-base">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORY_OPTIONS.map(category => (
                    <SelectItem key={category.value} value={category.value} className="text-sm sm:text-base">
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="status" className="text-sm sm:text-base">Status</Label>
              <Select
                value={newCustomer.status}
                onValueChange={(value) => setNewCustomer({...newCustomer, status: value})}
              >
                <SelectTrigger className="text-sm sm:text-base">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map(status => (
                    <SelectItem key={status.value} value={status.value} className="text-sm sm:text-base">
                      {status.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="notes" className="text-sm sm:text-base">Notes</Label>
              <Textarea
                id="notes"
                value={newCustomer.notes}
                onChange={(e) => setNewCustomer({...newCustomer, notes: e.target.value})}
                rows={3}
                className="text-sm sm:text-base"
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="registered"
                checked={newCustomer.registered}
                onChange={(e) => setNewCustomer({...newCustomer, registered: e.target.checked})}
                className="h-4 w-4"
              />
              <Label htmlFor="registered" className="text-sm sm:text-base">Registered</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenDialog(false)} className="text-sm sm:text-base">
              Cancel
            </Button>
            <Button onClick={handleAddCustomer} className="text-sm sm:text-base">
              Add Customer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Customer Dialog */}
      <Dialog open={!!editingCustomer} onOpenChange={() => setEditingCustomer(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto w-[95vw] sm:w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl">Edit Customer</DialogTitle>
            <DialogDescription className="text-sm sm:text-base">
              Update customer information and notes.
            </DialogDescription>
          </DialogHeader>
          {editingCustomer && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-notes" className="text-sm sm:text-base">Notes</Label>
                <Textarea
                  id="edit-notes"
                  value={editingCustomer.notes}
                  onChange={(e) => setEditingCustomer({...editingCustomer, notes: e.target.value})}
                  rows={4}
                  className="text-sm sm:text-base"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-status" className="text-sm sm:text-base">Status</Label>
                <Select
                  value={editingCustomer.status}
                  onValueChange={(value) => setEditingCustomer({...editingCustomer, status: value})}
                >
                  <SelectTrigger className="text-sm sm:text-base">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUS_OPTIONS.map(status => (
                      <SelectItem key={status.value} value={status.value} className="text-sm sm:text-base">
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="edit-registered"
                  checked={editingCustomer.registered}
                  onChange={(e) => setEditingCustomer({...editingCustomer, registered: e.target.checked})}
                  className="h-4 w-4"
                />
                <Label htmlFor="edit-registered" className="text-sm sm:text-base">Registered</Label>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingCustomer(null)} className="text-sm sm:text-base">
              Cancel
            </Button>
            <Button onClick={handleUpdateCustomer} className="text-sm sm:text-base">
              Update
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CustomerTracking;
