import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Header from "../components/Header";
import { useReferrals } from '../hooks/useReferrals';
import { useAuth } from '../hooks/useAuth';
import { Seo } from '../components/seo';
import HeroSection from "../components/HeroSection";
import ServicesSection from "../components/ServicesSection";
import TrustFactorSection from "../components/TrustFactorSection";
import BusinessFeedSection from "../components/BusinessFeedSection";
import TrustedPartnersSection from "../components/TrustedPartnersSection";
import Footer from "../components/Footer";
import LocationInitializer from "../components/LocationInitializer";
import QuickRequirementPopup from "../components/QuickRequirementPopup";

const Index: React.FC = () => {
  const [searchParams] = useSearchParams();
  const { processReferralCode } = useReferrals();
  const { user } = useAuth();
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    const hasSeenPopup = sessionStorage.getItem('hasSeenRequirementPopup');
    if (!hasSeenPopup) {
      const timer = setTimeout(() => {
        setShowPopup(true);
        sessionStorage.setItem('hasSeenRequirementPopup', 'true');
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const localBusinessSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "BuildOnClicks",
    "description": "India's #1 platform connecting you with verified construction professionals in Bhopal",
    "url": "https://buildonclicks.com",
    "telephone": "+91-9876543210",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Bhopal",
      "addressRegion": "Madhya Pradesh",
      "addressCountry": "IN"
    },
    "areaServed": "Bhopal, Madhya Pradesh, India",
    "serviceType": [
      "Construction Services",
      "Contractor Services", 
      "Architecture Services",
      "Building Materials"
    ]
  };

  useEffect(() => {
    const referralCode = searchParams.get('ref');
    if (referralCode && user) {
      processReferralCode(referralCode);
    } else if (referralCode && !user) {
      localStorage.setItem('pendingReferralCode', referralCode);
    }
  }, [searchParams, user, processReferralCode]);

  return (
    <>
      <Seo 
        title="Best Construction Services Near Me | Verified Contractors & Architects - BuildOnClicks"
        description="Find the best construction services near you in Bhopal. Connect with 20+ verified contractors, architects, and vendors. Quality construction materials & professional services."
        keywords="best construction services near me, construction contractors near me, architects in Bhopal, building materials, home construction services, verified contractors"
        canonical="/"
        structuredData={localBusinessSchema}
      />
      <div className="min-h-screen bg-red pb-24 sm:pb-8">
        <Header />
        <HeroSection />
        <ServicesSection />
        <TrustFactorSection />
        <BusinessFeedSection />
        <TrustedPartnersSection />
        <Footer />
        <LocationInitializer />
        <QuickRequirementPopup open={showPopup} onOpenChange={setShowPopup} />
      </div>
    </>
  );
};

export default Index;
