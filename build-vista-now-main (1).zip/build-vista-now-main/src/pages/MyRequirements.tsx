import React from 'react';
import { Link } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalendarDays, MapPin, MessageCircle, Trash2, Edit, Plus, FileText } from 'lucide-react';
import { useRequirements } from '@/hooks/useRequirements';
import { format } from 'date-fns';
import { showSuccessToast, showErrorToast } from '@/lib/loading-toast';

const MyRequirements = () => {
  const { requirements, loading, deleteRequirement, updateRequirementStatus } = useRequirements();

  const handleDelete = async (id: string) => {
    const result = await deleteRequirement(id);
    if (result.success) {
      showSuccessToast({ title: 'Requirement Deleted', description: 'Your requirement has been deleted successfully.' });
    } else {
      showErrorToast({ title: 'Delete Failed', description: result.error || 'Failed to delete requirement. Please try again.' });
    }
  };

  const handleStatusChange = async (id: string, status: 'active' | 'closed' | 'completed') => {
    const result = await updateRequirementStatus(id, status);
    if (result.success) {
      showSuccessToast({ title: 'Status Updated', description: 'Requirement status has been updated successfully.' });
    } else {
      showErrorToast({ title: 'Update Failed', description: result.error || 'Failed to update status. Please try again.' });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'completed':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'closed':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return 'Active';
      case 'completed':
        return 'Completed';
      case 'closed':
        return 'Closed';
      default:
        return status;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-24 sm:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24 sm:pb-8">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold">My Requirements</h1>
              <p className="text-muted-foreground">Manage and track all your posted requirements</p>
            </div>
            <Button asChild>
              <Link to="/post-requirement">
                <Plus className="mr-2 h-4 w-4" />
                Post New Requirement
              </Link>
            </Button>
          </div>

          {/* Requirements List */}
          {requirements.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                <h2 className="text-xl font-semibold mb-2">No Requirements Yet</h2>
                <p className="text-muted-foreground text-center mb-4">
                  You haven't posted any requirements yet. Start by posting your first requirement.
                </p>
                <Button asChild>
                  <Link to="/post-requirement">
                    <Plus className="mr-2 h-4 w-4" />
                    Post Your First Requirement
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {requirements.map((requirement) => (
                <Card key={requirement.id}>
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                      <div className="flex-1">
                        <CardTitle className="text-xl">{requirement.title}</CardTitle>
                        <CardDescription className="mt-2">
                          <div className="flex flex-wrap items-center gap-4 text-sm">
                            <div className="flex items-center gap-1">
                              <Badge variant="outline">{requirement.service_type}</Badge>
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {requirement.city}
                            </div>
                            <div className="flex items-center gap-1">
                              <CalendarDays className="h-4 w-4" />
                              {requirement.timeline}
                            </div>
                            <div className="flex items-center gap-1">
                              <MessageCircle className="h-4 w-4" />
                              {requirement.contact_preference}
                            </div>
                          </div>
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={getStatusColor(requirement.status)}>
                          {getStatusLabel(requirement.status)}
                        </Badge>
                        <Select
                          value={requirement.status}
                          onValueChange={(value) => handleStatusChange(requirement.id, value as any)}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="completed">Completed</SelectItem>
                            <SelectItem value="closed">Closed</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">
                      {requirement.description}
                    </p>
                    
                    {requirement.attachments && Array.isArray(requirement.attachments) && requirement.attachments.length > 0 && (
                      <div className="mb-4">
                        <p className="text-sm font-medium mb-2">Attachments</p>
                        <div className="flex flex-wrap gap-2">
                          {requirement.attachments.map((file: any, index: number) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {file.name}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                      <div className="text-xs text-muted-foreground">
                        Posted on {format(new Date(requirement.created_at), 'PPP')}
                      </div>
                      <div className="flex items-center gap-2">
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete your requirement.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDelete(requirement.id)}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default MyRequirements;