import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';
import { 
  Building, FileText, CheckCircle, Clock, AlertCircle, Settings, Plus, User, Store, 
  Briefcase, Package, MessageSquare, LogOut, BarChart3, Eye, Edit, Search,
  ShoppingBag, Hammer, PaintBucket
} from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useAuth } from '@/hooks/useAuth';
import { useProviderProfile, ProviderRole } from '@/hooks/useProviderProfile';
import { useProviderDashboard } from '@/hooks/useProviderDashboard';
import { useShopPortfolio } from '@/hooks/useShopPortfolio';

const NewProviderDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading, signOut } = useAuth();
  const { profile, loading: profileLoading } = useProviderProfile(user?.id);
  const { businessRegistration, loading: businessLoading } = useProviderDashboard(user?.id);
  const { shop, portfolio, loading: shopPortfolioLoading, refreshData } = useShopPortfolio(businessRegistration?.id);

  const [activeTab, setActiveTab] = useState('overview');

  if (authLoading || profileLoading || businessLoading) {
    return (
      <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
        <Header />
        <div className="flex-1 bg-gradient-section flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-construction-primary mx-auto mb-4"></div>
            <p className="text-construction-neutral">Loading dashboard...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!user) {
    navigate('/auth');
    return null;
  }

  // If no provider profile exists, show setup
  if (!profile) {
    return <ProviderSetup />;
  }

  // If not approved, show pending approval screen
  if (!profile.approved) {
    return <PendingApprovalScreen profile={profile} businessRegistration={businessRegistration} />;
  }

  const getRoleIcon = (role: ProviderRole) => {
    switch (role) {
      case 'vendor': return <ShoppingBag className="w-5 h-5" />;
      case 'contractor': return <Hammer className="w-5 h-5" />;
      case 'architect': return <PaintBucket className="w-5 h-5" />;
    }
  };

  const getRoleColor = (role: ProviderRole) => {
    switch (role) {
      case 'vendor': return 'bg-blue-100 text-blue-700';
      case 'contractor': return 'bg-orange-100 text-orange-700';
      case 'architect': return 'bg-purple-100 text-purple-700';
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
      <Header />
      <div className="flex-1 bg-gradient-section">
        <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-6">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6"
          >
            <div className="w-full sm:w-auto">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-3 mb-2">
                <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-construction-secondary">
                  Provider Dashboard
                </h1>
                <Badge className={getRoleColor(profile.role)}>
                  {getRoleIcon(profile.role)}
                  <span className="ml-1 capitalize">{profile.role}</span>
                </Badge>
              </div>
              <p className="text-sm sm:text-base text-construction-neutral">
                Welcome back, {profile.display_name || businessRegistration?.contact_name || 'Provider'}
              </p>
            </div>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
              <Button 
                variant="outline" 
                onClick={() => navigate('/profile')}
                className="w-full sm:w-auto text-sm"
              >
                <User className="w-4 h-4 mr-2" />
                Profile
              </Button>
              <Button 
                variant="outline" 
                onClick={handleSignOut}
                className="w-full sm:w-auto text-sm"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </motion.div>

          {/* Dashboard Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4 sm:space-y-6">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-1 h-auto p-1">
              <TabsTrigger value="overview" className="text-xs sm:text-sm py-2">Overview</TabsTrigger>
              <TabsTrigger value="profile" className="text-xs sm:text-sm py-2">Profile</TabsTrigger>
              {profile.role === 'vendor' && <TabsTrigger value="shop" className="text-xs sm:text-sm py-2">Shop</TabsTrigger>}
              {profile.role === 'vendor' && <TabsTrigger value="products" className="text-xs sm:text-sm py-2">Products</TabsTrigger>}
              {(profile.role === 'contractor' || profile.role === 'architect') && (
                <TabsTrigger value="portfolio" className="text-xs sm:text-sm py-2">Portfolio</TabsTrigger>
              )}
              <TabsTrigger value="messages" className="text-xs sm:text-sm py-2">Messages</TabsTrigger>
              <TabsTrigger value="settings" className="text-xs sm:text-sm py-2">Settings</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <OverviewSection 
                profile={profile} 
                shop={shop} 
                portfolio={portfolio}
                businessRegistration={businessRegistration}
                refreshData={refreshData}
              />
            </TabsContent>

            {/* Profile & Documents Tab */}
            <TabsContent value="profile" className="space-y-6">
              <ProfileDocumentsSection profile={profile} businessRegistration={businessRegistration} />
            </TabsContent>

            {/* Vendor Shop Tab */}
            {profile.role === 'vendor' && (
              <TabsContent value="shop" className="space-y-6">
                <VendorShopSection shop={shop} profile={profile} />
              </TabsContent>
            )}

            {/* Vendor Products Tab */}
            {profile.role === 'vendor' && (
              <TabsContent value="products" className="space-y-6">
                <VendorProductsSection shop={shop} />
              </TabsContent>
            )}

            {/* Portfolio Tab */}
            {(profile.role === 'contractor' || profile.role === 'architect') && (
              <TabsContent value="portfolio" className="space-y-6">
                <PortfolioSection portfolio={portfolio} profile={profile} refreshData={refreshData} />
              </TabsContent>
            )}

            {/* Messages Tab */}
            <TabsContent value="messages" className="space-y-6">
              <MessagesSection />
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <SettingsSection profile={profile} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Footer />
    </div>
  );
};

// Placeholder components - will implement these step by step
const ProviderSetup: React.FC = () => (
  <div className="min-h-screen flex items-center justify-center bg-gradient-section px-4">
    <Card className="max-w-md w-full">
      <CardHeader>
        <CardTitle className="text-lg sm:text-xl">Provider Setup Required</CardTitle>
        <CardDescription className="text-sm">Please complete your provider profile setup to continue.</CardDescription>
      </CardHeader>
      <CardContent>
        <Button className="w-full text-sm">Setup Provider Profile</Button>
      </CardContent>
    </Card>
  </div>
);

const PendingApprovalScreen: React.FC<{profile: any, businessRegistration: any}> = ({ profile, businessRegistration }) => (
  <div className="min-h-screen flex items-center justify-center bg-gradient-section px-4">
    <Card className="max-w-2xl w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
          <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500" />
          Pending Approval
        </CardTitle>
        <CardDescription className="text-sm">
          Your business registration is under review. We'll contact you within 48 hours.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="bg-orange-50 p-3 sm:p-4 rounded-lg">
            <h3 className="font-semibold mb-2 text-sm sm:text-base">Submitted Documents:</h3>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li className="flex items-center gap-2">
                <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-green-500 flex-shrink-0" />
                Business Registration
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-green-500 flex-shrink-0" />
                Government ID
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-green-500 flex-shrink-0" />
                Business Certificate
              </li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  </div>
);

const OverviewSection: React.FC<{profile: any, shop: any, portfolio: any, businessRegistration: any, refreshData: () => void}> =
  ({ profile, shop, portfolio, businessRegistration, refreshData }) => (
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
          <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5" />
          Quick Stats
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-2 sm:space-y-3">
          <div className="flex justify-between items-center text-sm">
            <span>Profile Status:</span>
            <Badge className="bg-green-100 text-green-700 text-xs">Active</Badge>
          </div>
          {profile.role === 'vendor' && shop && (
            <div className="flex justify-between items-center text-sm">
              <span>Shop Status:</span>
              <Badge className={shop.is_live ? "bg-green-100 text-green-700 text-xs" : "bg-gray-100 text-gray-700 text-xs"}>
                {shop.is_live ? 'Live' : 'Draft'}
              </Badge>
            </div>
          )}
          {(profile.role === 'contractor' || profile.role === 'architect') && portfolio && (
            <div className="flex justify-between items-center text-sm">
              <span>Portfolio Status:</span>
              <Badge className="bg-green-100 text-green-700 text-xs">Active</Badge>
            </div>
          )}
        </div>
      </CardContent>
    </Card>

    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
          <MessageSquare className="w-4 h-4 sm:w-5 sm:h-5" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-sm text-muted-foreground">No recent activity</p>
      </CardContent>
    </Card>

    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
          <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5" />
          Quick Actions
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-2">
          {profile.role === 'vendor' && !shop && (
            <Button variant="outline" className="w-full justify-start text-sm">
              <Store className="w-4 h-4 mr-2" />
              Create Shop
            </Button>
          )}
          {(profile.role === 'contractor' || profile.role === 'architect') && !portfolio && (
            <Button 
              variant="outline" 
              className="w-full justify-start text-sm"
              onClick={() => {
                window.location.href = '/portfolio-management';
                setTimeout(() => refreshData(), 1000);
              }}
            >
              <Briefcase className="w-4 h-4 mr-2" />
              Create Portfolio
            </Button>
          )}
          <Button variant="outline" className="w-full justify-start text-sm">
            <Settings className="w-4 h-4 mr-2" />
            Update Profile
          </Button>
        </div>
      </CardContent>
    </Card>
  </div>
);

const ProfileDocumentsSection: React.FC<{profile: any, businessRegistration: any}> = ({ profile, businessRegistration }) => (
  <Card>
    <CardHeader>
      <CardTitle className="text-lg sm:text-xl">Profile & Documents</CardTitle>
      <CardDescription className="text-sm">Manage your business profile and uploaded documents</CardDescription>
    </CardHeader>
    <CardContent>
      <p className="text-sm text-muted-foreground">Profile management coming soon...</p>
    </CardContent>
  </Card>
);

const VendorShopSection: React.FC<{shop: any, profile: any}> = ({ shop, profile }) => (
  <div className="space-y-4 sm:space-y-6">
    {!shop ? (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg sm:text-xl">Create Your Shop</CardTitle>
          <CardDescription className="text-sm">Set up your shop to start selling products</CardDescription>
        </CardHeader>
        <CardContent>
          <Button className="w-full sm:w-auto text-sm">
            <Store className="w-4 h-4 mr-2" />
            Create Shop
          </Button>
        </CardContent>
      </Card>
    ) : (
      <Card>
        <CardHeader>
          <CardTitle className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-lg sm:text-xl">
            <span className="break-words">{shop.shop_name}</span>
            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm">
                <Eye className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                View Shop
              </Button>
              <Button variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm">
                <Edit className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                Edit Shop
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">{shop.description}</p>
        </CardContent>
      </Card>
    )}
  </div>
);

const VendorProductsSection: React.FC<{shop: any}> = ({ shop }) => (
  <div className="space-y-4 sm:space-y-6">
    {!shop ? (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg sm:text-xl">No Shop Yet</CardTitle>
          <CardDescription className="text-sm">Create your shop first to start adding products</CardDescription>
        </CardHeader>
        <CardContent>
          <Button variant="outline" className="w-full sm:w-auto text-sm">Create Shop First</Button>
        </CardContent>
      </Card>
    ) : (
      <Card>
        <CardHeader>
          <CardTitle className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-lg sm:text-xl">
            <span>Products</span>
            <Button className="w-full sm:w-auto text-sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Product
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No products yet. Add your first product to get started.</p>
        </CardContent>
      </Card>
    )}
  </div>
);

const PortfolioSection: React.FC<{portfolio: any, profile: any, refreshData: () => void}> = ({ portfolio, profile, refreshData }) => {
  const navigate = useNavigate();
  
  return (
    <div className="space-y-4 sm:space-y-6">
      {!portfolio ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">Create Your Portfolio</CardTitle>
            <CardDescription className="text-sm">Showcase your work to potential clients</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate('/portfolio-management')} className="w-full sm:w-auto text-sm">
              <Briefcase className="w-4 h-4 mr-2" />
              Create Portfolio
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4 sm:space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-lg sm:text-xl">
                <span className="break-words">{portfolio.title}</span>
                <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                  <Button variant="outline" size="sm" onClick={() => navigate('/portfolio-management')} className="w-full sm:w-auto text-xs sm:text-sm">
                    <Eye className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                    View
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => navigate('/portfolio-management')} className="w-full sm:w-auto text-xs sm:text-sm">
                    <Edit className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                    Manage
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">{portfolio.description}</p>
              <div className="grid grid-cols-3 gap-2 sm:gap-4">
                <div className="text-center">
                  <div className="text-xl sm:text-2xl font-bold text-primary">{portfolio.projects?.length || 0}</div>
                  <div className="text-xs sm:text-sm text-muted-foreground">Projects</div>
                </div>
                <div className="text-center">
                  <div className="text-xl sm:text-2xl font-bold text-primary">{portfolio.services?.length || 0}</div>
                  <div className="text-xs sm:text-sm text-muted-foreground">Services</div>
                </div>
                <div className="text-center">
                  <div className="text-xl sm:text-2xl font-bold text-primary">{portfolio.skills?.length || 0}</div>
                  <div className="text-xs sm:text-sm text-muted-foreground">Skills</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg sm:text-xl">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-4">
                <Button variant="outline" onClick={() => navigate('/portfolio-management')} className="w-full text-sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Project
                </Button>
                <Button variant="outline" onClick={() => navigate('/portfolio-management')} className="w-full text-sm">
                  <Settings className="w-4 h-4 mr-2" />
                  Portfolio Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

const MessagesSection: React.FC = () => (
  <Card>
    <CardHeader>
      <CardTitle className="text-lg sm:text-xl">Messages & Enquiries</CardTitle>
      <CardDescription className="text-sm">Manage customer inquiries and communications</CardDescription>
    </CardHeader>
    <CardContent>
      <p className="text-sm text-muted-foreground">No messages yet. Messages will appear here when customers contact you.</p>
    </CardContent>
  </Card>
);

const SettingsSection: React.FC<{profile: any}> = ({ profile }) => (
  <Card>
    <CardHeader>
      <CardTitle className="text-lg sm:text-xl">Settings</CardTitle>
      <CardDescription className="text-sm">Manage your account and notification preferences</CardDescription>
    </CardHeader>
    <CardContent>
      <p className="text-sm text-muted-foreground">Settings panel coming soon...</p>
    </CardContent>
  </Card>
);

export default NewProviderDashboard;