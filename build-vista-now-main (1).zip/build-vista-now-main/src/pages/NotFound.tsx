
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Home } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
      <Header />
      <div className="flex-1 flex items-center justify-center bg-gradient-section">
        <div className="text-center max-w-md mx-auto px-4">
          <h1 className="text-6xl font-bold text-construction-primary mb-4">404</h1>
          <h2 className="text-2xl font-semibold text-construction-secondary mb-4">Page Not Found</h2>
          <p className="text-construction-neutral mb-8">
            Sorry, the page you're looking for doesn't exist or has been moved.
          </p>
          <Button 
            onClick={() => window.location.href = '/'}
            className="bg-construction-primary hover:bg-construction-primary/90 text-white"
          >
            <Home className="w-4 h-4 mr-2" />
            Return to Home
          </Button>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default NotFound;
