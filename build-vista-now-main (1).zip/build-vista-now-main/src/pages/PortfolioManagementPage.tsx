import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Briefcase } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useAuth } from '@/hooks/useAuth';
import { useProviderDashboard } from '@/hooks/useProviderDashboard';
import { useShopPortfolio } from '@/hooks/useShopPortfolio';
import PortfolioManagement from '@/components/PortfolioManagement';
import PortfolioCreationForm from '@/components/PortfolioCreationForm';

interface Project {
  title: string;
  description: string;
  duration: string;
  clientType: string;
  images: string[];
  completedAt?: string;
  technologies?: string[];
  projectValue?: string;
}

interface Portfolio {
  id: string;
  title: string;
  description: string;
  services: string[];
  skills: string[];
  experience: string;
  projects: any; // JSON field from Supabase
  certifications: string[];
  images: string[];
  banner_url?: string;
  logo_url?: string;
}

const PortfolioManagementPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { businessRegistration, loading: businessLoading } = useProviderDashboard(user?.id);
  const { 
    portfolio, 
    loading: portfolioLoading, 
    createPortfolio, 
    updatePortfolio, 
    isSubmitting 
  } = useShopPortfolio(businessRegistration?.id);


  if (authLoading || businessLoading || portfolioLoading) {
    return (
      <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
        <Header />
        <div className="flex-1 bg-gradient-section flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-construction-primary mx-auto mb-4"></div>
            <p className="text-construction-neutral">Loading portfolio...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!user) {
    navigate('/auth');
    return null;
  }

  if (!businessRegistration) {
    return (
      <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
        <Header />
        <div className="flex-1 bg-gradient-section flex items-center justify-center">
          <Card className="max-w-md w-full mx-4">
            <CardHeader>
              <CardTitle>Access Restricted</CardTitle>
              <CardDescription>
                You need an approved business registration to manage your portfolio.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate('/provider-dashboard')} className="w-full">
                Go to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
      <Header />
      <div className="flex-1 bg-gradient-section">
        <div className="container mx-auto px-4 py-6">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-between mb-6"
          >
            <div className="flex items-center gap-4">
              <Button variant="outline" onClick={() => navigate('/provider-dashboard')}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <div>
                <h1 className="text-3xl font-bold text-construction-secondary flex items-center gap-2">
                  <Briefcase className="w-8 h-8" />
                  Portfolio Management
                </h1>
                <p className="text-construction-neutral">
                  Manage your professional portfolio and showcase your work
                </p>
              </div>
            </div>
          </motion.div>

          {!portfolio ? (
            /* Portfolio Creation */
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-4xl mx-auto"
            >
              <PortfolioCreationForm 
                onSubmit={createPortfolio}
                isSubmitting={isSubmitting}
              />
            </motion.div>
          ) : (
            /* Portfolio Management Interface */
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <PortfolioManagement
                portfolio={portfolio as Portfolio}
                onUpdate={updatePortfolio}
                isSubmitting={isSubmitting}
              />
            </motion.div>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default PortfolioManagementPage;
