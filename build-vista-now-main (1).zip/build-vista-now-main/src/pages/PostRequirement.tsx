import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Upload, X } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useAuth } from '@/hooks/useAuth';
import { useLocation } from '@/hooks/useLocation';
import { supabase } from '@/integrations/supabase/client';
import { showLoadingToast, showSuccessToast, showErrorToast } from '@/lib/loading-toast';

const serviceTypes = [
  'Contractor',
  'Architect', 
  'Material Supplier',
  'Vendors',
  'Interior Designer',
  'Other'
];

const contactPreferences = [
  'Email',
  'Phone',
  'WhatsApp'
];

const PostRequirement = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { location } = useLocation();
  
  const [formData, setFormData] = useState({
    title: '',
    serviceType: '',
    city: location?.city || '',
    description: '',
    timeline: 'ASAP',
    contactPreference: '',
    contactInfo: '', // New field for contact information
    customDate: null as Date | null
  });
  
  const [files, setFiles] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || []);
    const validFiles = selectedFiles.filter(file => {
      const isValidType = ['image/jpeg', 'image/png', 'application/pdf'].includes(file.type);
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB
      return isValidType && isValidSize;
    });
    
    setFiles(prev => [...prev, ...validFiles].slice(0, 5)); // Max 5 files
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const uploadFiles = async (requirementId: string) => {
    if (files.length === 0) return [];
    
    const uploadPromises = files.map(async (file, index) => {
      const fileName = `${requirementId}/${Date.now()}_${index}_${file.name}`;
      const { data, error } = await supabase.storage
        .from('requirement-attachments')
        .upload(`${user?.id}/${fileName}`, file);
      
      if (error) throw error;
      
      return {
        name: file.name,
        path: data.path,
        type: file.type,
        size: file.size
      };
    });

    return Promise.all(uploadPromises);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      showErrorToast({ title: 'Authentication Required', description: 'Please log in to post a requirement.' });
      navigate('/auth');
      return;
    }

    if (!formData.title || !formData.serviceType || !formData.city || !formData.description || !formData.contactPreference || !formData.contactInfo) {
      showErrorToast({ title: 'Missing Information', description: 'Please fill in all required fields including your contact information.' });
      return;
    }

    setIsSubmitting(true);
    const loadingToast = showLoadingToast({ title: 'Posting Requirement', description: 'Please wait while we save your requirement...' });

    try {
      // Determine timeline
      let timeline = formData.timeline;
      if (formData.timeline === 'custom' && formData.customDate) {
        timeline = format(formData.customDate, 'PPP');
      }

      // Insert requirement
      const { data: requirement, error: requirementError } = await supabase
        .from('requirements')
        .insert({
          user_id: user.id,
          title: formData.title,
          service_type: formData.serviceType,
          city: formData.city,
          description: formData.description,
          timeline,
          contact_preference: formData.contactPreference,
          contact_info: formData.contactInfo, // Include contact info
          attachments: []
        })
        .select()
        .single();

      if (requirementError) throw requirementError;

      // Upload files if any
      let attachments = [];
      if (files.length > 0) {
        attachments = await uploadFiles(requirement.id);
        
        // Update requirement with file attachments
        const { error: updateError } = await supabase
          .from('requirements')
          .update({ attachments })
          .eq('id', requirement.id);
          
        if (updateError) throw updateError;
      }

      loadingToast.dismiss();
      showSuccessToast({ 
        title: 'Thank You! Requirement Posted Successfully!', 
        description: 'Redirecting to your requirements page...',
        duration: 3000
      });
      
      // Redirect to my requirements page after a short delay
      setTimeout(() => {
        navigate('/my-requirements');
      }, 2000);
    } catch (error: any) {
      loadingToast.dismiss();
      showErrorToast({ 
        title: 'Failed to Post Requirement', 
        description: error.message || 'Something went wrong. Please try again.' 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background pb-24 sm:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <Card className="max-w-md mx-auto">
            <CardHeader>
              <CardTitle>Authentication Required</CardTitle>
              <CardDescription>Please log in to post a requirement.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate('/auth')} className="w-full">
                Go to Login
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24 sm:pb-8">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Post Your Requirement</CardTitle>
              <CardDescription>
                Tell us about your construction needs and get connected with relevant professionals.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Requirement Title */}
                <div className="space-y-2">
                  <Label htmlFor="title">Requirement Title *</Label>
                  <Input
                    id="title"
                    placeholder="e.g., Need contractor for home renovation"
                    value={formData.title}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    required
                  />
                </div>

                {/* Service Type */}
                <div className="space-y-2">
                  <Label htmlFor="serviceType">Type of Service Needed *</Label>
                  <Select value={formData.serviceType} onValueChange={(value) => handleInputChange('serviceType', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select service type" />
                    </SelectTrigger>
                    <SelectContent>
                      {serviceTypes.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* City */}
                <div className="space-y-2">
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    placeholder="Enter your city"
                    value={formData.city}
                    onChange={(e) => handleInputChange('city', e.target.value)}
                    required
                  />
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    placeholder="Provide detailed information about your requirement..."
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    rows={4}
                    required
                  />
                </div>

                {/* Timeline */}
                <div className="space-y-3">
                  <Label>When do you need this service? *</Label>
                  <RadioGroup value={formData.timeline} onValueChange={(value) => handleInputChange('timeline', value)}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="ASAP" id="asap" />
                      <Label htmlFor="asap">ASAP</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Within a week" id="week" />
                      <Label htmlFor="week">Within a week</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Within a month" id="month" />
                      <Label htmlFor="month">Within a month</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="custom" id="custom" />
                      <Label htmlFor="custom">Specific date</Label>
                    </div>
                  </RadioGroup>
                  
                  {formData.timeline === 'custom' && (
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !formData.customDate && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {formData.customDate ? format(formData.customDate, "PPP") : "Pick a date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={formData.customDate}
                          onSelect={(date) => setFormData(prev => ({ ...prev, customDate: date }))}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  )}
                </div>

                {/* File Upload */}
                <div className="space-y-2">
                  <Label htmlFor="files">Upload Images or Plans (Optional)</Label>
                  <div className="border-2 border-dashed border-border rounded-lg p-4">
                    <input
                      type="file"
                      id="files"
                      multiple
                      accept="image/jpeg,image/png,application/pdf"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <Label 
                      htmlFor="files" 
                      className="flex flex-col items-center justify-center cursor-pointer space-y-2"
                    >
                      <Upload className="h-8 w-8 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        Click to upload files (JPG, PNG, PDF - Max 5 files, 10MB each)
                      </span>
                    </Label>
                  </div>
                  
                  {files.length > 0 && (
                    <div className="space-y-2">
                      {files.map((file, index) => (
                        <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                          <span className="text-sm truncate">{file.name}</span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFile(index)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Contact Preference */}
                <div className="space-y-2">
                  <Label htmlFor="contactPreference">Contact Preference *</Label>
                  <Select value={formData.contactPreference} onValueChange={(value) => {
                    handleInputChange('contactPreference', value);
                    handleInputChange('contactInfo', ''); // Reset contact info when preference changes
                  }}>
                    <SelectTrigger>
                      <SelectValue placeholder="How should professionals contact you?" />
                    </SelectTrigger>
                    <SelectContent>
                      {contactPreferences.map((pref) => (
                        <SelectItem key={pref} value={pref}>{pref}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Dynamic Contact Info Input */}
                {formData.contactPreference && (
                  <div className="space-y-2">
                    <Label htmlFor="contactInfo">
                      {formData.contactPreference === 'Email' && 'Email Address *'}
                      {formData.contactPreference === 'Phone' && 'Phone Number *'}
                      {formData.contactPreference === 'WhatsApp' && 'WhatsApp Number *'}
                    </Label>
                    <Input
                      id="contactInfo"
                      type={formData.contactPreference === 'Email' ? 'email' : 'tel'}
                      placeholder={
                        formData.contactPreference === 'Email' ? 'Enter your email address' :
                        formData.contactPreference === 'Phone' ? 'Enter your phone number' :
                        'Enter your WhatsApp number'
                      }
                      value={formData.contactInfo}
                      onChange={(e) => handleInputChange('contactInfo', e.target.value)}
                      required
                    />
                  </div>
                )}

                {/* Submit Button */}
                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? 'Posting Requirement...' : 'Post Requirement'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default PostRequirement;