import React from 'react';
import { Helmet } from 'react-helmet-async';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { motion } from 'framer-motion';

const PrivacyPolicy: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy - BuildOnClicks | Data Protection & Security</title>
        <meta 
          name="description" 
          content="Read BuildOnClicks Private Limited's Privacy Policy. Learn how we collect, use, and protect your personal information on our construction networking platform." 
        />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://buildonclicks.com/privacy" />
      </Helmet>

      <div className="min-h-screen flex flex-col pb-24 sm:pb-8 bg-background">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-12 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl font-bold text-construction-primary mb-4">
              Privacy Policy
            </h1>
            <p className="text-muted-foreground mb-8">
              Effective Date: January 1, 2025
            </p>

            <div className="prose prose-lg max-w-none space-y-8">
              <section>
                <p className="text-construction-neutral leading-relaxed">
                  BuildOnClicks Private Limited ("Company", "we", "our", "us") values the trust you place in us. 
                  This Privacy Policy explains how we collect, use, disclose, and safeguard your information when 
                  you access or use our networking platform, website, and related services (collectively, the "Platform").
                </p>
                <p className="text-construction-neutral leading-relaxed mt-4">
                  By using the Platform, you agree to the practices described in this Privacy Policy.
                </p>
              </section>

              <section className="border-t pt-6">
                <h2 className="text-2xl font-semibold text-construction-secondary mb-4">
                  1. Information We Collect
                </h2>
                <p className="text-construction-neutral mb-4">
                  We may collect the following types of information from you:
                </p>
                
                <div className="space-y-4 ml-4">
                  <div>
                    <h3 className="text-xl font-semibold text-construction-secondary mb-2">
                      Personal Information:
                    </h3>
                    <p className="text-construction-neutral">
                      Name, email address, phone number, date of birth, gender, location, profile picture, 
                      and other details provided during account creation.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-construction-secondary mb-2">
                      Professional/Business Information:
                    </h3>
                    <p className="text-construction-neutral">
                      Company name, designation, skills, work experience, projects, business interests, 
                      and other professional details you choose to share.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-construction-secondary mb-2">
                      Usage Data:
                    </h3>
                    <p className="text-construction-neutral">
                      IP address, browser type, device identifiers, operating system, access times, 
                      pages viewed, and actions taken on the Platform.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-construction-secondary mb-2">
                      Sensitive Personal Data (if applicable):
                    </h3>
                    <p className="text-construction-neutral">
                      Payment details, identity proof, or government-issued IDs, only when required for 
                      verification, billing, or legal compliance.
                    </p>
                  </div>
                </div>
              </section>

              <section className="border-t pt-6">
                <h2 className="text-2xl font-semibold text-construction-secondary mb-4">
                  2. How We Use Your Information
                </h2>
                <p className="text-construction-neutral mb-4">
                  Your information may be used for the following purposes:
                </p>
                <ul className="list-disc list-inside space-y-2 text-construction-neutral ml-4">
                  <li>To create and manage your account and profile.</li>
                  <li>To enable networking, connections, and communication with other users.</li>
                  <li>To send you updates, notifications, and promotional messages.</li>
                  <li>To personalize and improve user experience.</li>
                  <li>To analyze usage patterns and improve Platform features.</li>
                  <li>To comply with applicable laws, regulations, and legal processes.</li>
                </ul>
              </section>

              <section className="border-t pt-6">
                <h2 className="text-2xl font-semibold text-construction-secondary mb-4">
                  3. Sharing of Information
                </h2>
                <p className="text-construction-neutral mb-4">
                  We do not sell your personal data to third parties. However, we may share your information with:
                </p>
                <ul className="list-disc list-inside space-y-2 text-construction-neutral ml-4">
                  <li><strong>Other Users:</strong> To enable networking and professional visibility.</li>
                  <li><strong>Service Providers:</strong> Hosting providers, payment gateways, analytics partners, and communication service providers.</li>
                  <li><strong>Legal Authorities:</strong> When required by law, regulation, or court order.</li>
                  <li><strong>Business Transfers:</strong> In case of a merger, acquisition, or sale of assets.</li>
                </ul>
              </section>

              <section className="border-t pt-6">
                <h2 className="text-2xl font-semibold text-construction-secondary mb-4">
                  4. Data Security
                </h2>
                <p className="text-construction-neutral">
                  We use reasonable security measures, including encryption, secure servers, and restricted access, 
                  to protect your information. However, no system is completely secure, and we cannot guarantee 
                  absolute protection.
                </p>
              </section>

              <section className="border-t pt-6">
                <h2 className="text-2xl font-semibold text-construction-secondary mb-4">
                  5. Your Rights
                </h2>
                <p className="text-construction-neutral mb-4">
                  As per the Digital Personal Data Protection Act, 2023 and applicable Indian laws, you have the 
                  following rights:
                </p>
                <ul className="list-disc list-inside space-y-2 text-construction-neutral ml-4">
                  <li>Right to access and confirm your personal data.</li>
                  <li>Right to correction and updating of data.</li>
                  <li>Right to deletion/erasure of your data.</li>
                  <li>Right to withdraw consent at any time.</li>
                  <li>Right to raise grievances regarding data processing.</li>
                </ul>
              </section>

              <section className="border-t pt-6">
                <h2 className="text-2xl font-semibold text-construction-secondary mb-4">
                  6. Cookies and Tracking
                </h2>
                <p className="text-construction-neutral mb-4">
                  We use cookies and similar technologies to:
                </p>
                <ul className="list-disc list-inside space-y-2 text-construction-neutral ml-4">
                  <li>Recognize repeat visitors.</li>
                  <li>Understand usage patterns.</li>
                  <li>Personalize content and ads.</li>
                  <li>Improve Platform performance.</li>
                </ul>
                <p className="text-construction-neutral mt-4">
                  You may control cookies through your browser settings, but some features may not function 
                  properly if you disable them.
                </p>
              </section>

              <section className="border-t pt-6">
                <h2 className="text-2xl font-semibold text-construction-secondary mb-4">
                  7. Data Retention
                </h2>
                <p className="text-construction-neutral">
                  We retain your personal information for as long as your account is active or as required by law. 
                  Upon deletion of your account, we may retain certain information for legal and business purposes.
                </p>
              </section>

              <section className="border-t pt-6">
                <h2 className="text-2xl font-semibold text-construction-secondary mb-4">
                  8. Third-Party Links
                </h2>
                <p className="text-construction-neutral">
                  The Platform may contain links to third-party websites or services. We are not responsible for 
                  their privacy practices. Please review their privacy policies before using such services.
                </p>
              </section>

              <section className="border-t pt-6">
                <h2 className="text-2xl font-semibold text-construction-secondary mb-4">
                  9. Changes to this Policy
                </h2>
                <p className="text-construction-neutral">
                  We may update this Privacy Policy from time to time. Changes will be posted on this page with 
                  the "Effective Date" updated. We encourage you to review this Policy periodically.
                </p>
              </section>

              <section className="border-t pt-6">
                <h2 className="text-2xl font-semibold text-construction-secondary mb-4">
                  10. Contact Us
                </h2>
                <p className="text-construction-neutral mb-4">
                  If you have any questions, concerns, or complaints regarding this Privacy Policy, please contact 
                  our Grievance Officer:
                </p>
                <div className="bg-muted p-6 rounded-lg space-y-2 text-construction-neutral">
                  <p><strong>Name:</strong> Grievance Officer - BuildOnClicks</p>
                  <p><strong>Email:</strong> support@buildonclicks.com</p>
                  <p><strong>Phone:</strong> +91-6264634451</p>
                  <p><strong>Address:</strong> Bhopal, Madhya Pradesh, India</p>
                </div>
              </section>
            </div>
          </motion.div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default PrivacyPolicy;
