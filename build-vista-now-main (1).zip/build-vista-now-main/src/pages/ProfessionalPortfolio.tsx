import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { MapPin, Calendar, Star, Award, Phone, MessageCircle, Plus, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { ProtectedContactInfo } from '@/components/ProtectedContactInfo';
import ShopReviews from '@/components/vendor-shop/ShopReviews';
import ReviewFormDialog from '@/components/ReviewFormDialog';
import { useReviews } from '@/hooks/useReviews';

// Interface for portfolio data structure
interface PortfolioData {
  id: string;
  name: string;
  category: string;
  profileImage?: string | null;
  logo_url?: string | null;
  banner_url?: string | null;
  location: string;
  experience: number;
  rating: number;
  reviewCount: number;
  bio: string;
  skills: string[];
  certifications: Array<{title: string; year: string; issuer: string}>;
  projects: Array<{
    id: number;
    title: string;
    date: string;
    description: string;
    images: string[];
    category: string;
  }>;
  phone?: string;
  email?: string;
  images: string[];
  reviews?: Array<{
    id: number;
    userName: string;
    rating: number;
    comment: string;
    date: string;
    project: string;
  }>;
}

export default function ProfessionalPortfolio() {
  const { professionalId } = useParams();
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [showAddProject, setShowAddProject] = useState(false);
  const [portfolioData, setPortfolioData] = useState<PortfolioData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isBioExpanded, setIsBioExpanded] = useState(false);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [businessRegistrationId, setBusinessRegistrationId] = useState<string | null>(null);

  // Fetch reviews using business_registration_id
  const { reviews, refreshReviews } = useReviews(
    undefined,
    undefined,
    businessRegistrationId || undefined
  );

  useEffect(() => {
    if (professionalId) {
      fetchPortfolioData();
    }
  }, [professionalId]);

  const fetchPortfolioData = async () => {
    try {
      setLoading(true);
      
      // First try to fetch from provider_portfolios table
      const { data: portfolioData, error: portfolioError } = await supabase
        .from('provider_portfolios')
        .select(`
          *,
          banner_url,
          logo_url,
          business_registrations (
            contact_name,
            business_name,
            phone_number,
            email_address,
            business_address,
            cities_served,
            years_in_business,
            about_services,
            business_types (
              name
            )
          )
        `)
        .eq('id', professionalId)
        .maybeSingle();

      if (portfolioData && !portfolioError) {
        setPortfolioData(transformPortfolioData(portfolioData));
      } else {
        // Try to find portfolio by business_registration_id matching the professional ID
        const { data: portfolioByBusinessReg, error: portfolioByBusinessError } = await supabase
          .from('provider_portfolios')
          .select(`
            *,
            banner_url,
            logo_url,
            business_registrations (
              contact_name,
              business_name,
              phone_number,
              email_address,
              business_address,
              cities_served,
              years_in_business,
              about_services,
              business_types (
                name
              )
            )
          `)
          .eq('business_registration_id', professionalId)
          .maybeSingle();

        if (portfolioByBusinessReg && !portfolioByBusinessError) {
          setPortfolioData(transformPortfolioData(portfolioByBusinessReg));
        } else {
          // Fallback: try to fetch approved business listing using secure function
          const { data: businessData, error: businessError } = await supabase
            .rpc('get_approved_business_listing', { business_id: professionalId });

          if (businessData && businessData.length > 0 && !businessError) {
            // Transform the secure business data to match expected portfolio format
            // Note: get_approved_business_listing doesn't return sensitive fields like
            // contact_name, phone_number, email_address for security reasons
            const secureBusinessData = businessData[0];
            const transformedData: any = {
              id: secureBusinessData.id,
              business_name: secureBusinessData.business_name,
              about_services: secureBusinessData.about_services,
              cities_served: secureBusinessData.cities_served,
              service_area: secureBusinessData.service_area,
              years_in_business: secureBusinessData.years_in_business,
              business_types: {
                name: secureBusinessData.business_type
              }
            };
            setPortfolioData(transformBusinessToPortfolio(transformedData));
            // If business_registration_id wasn't set, use professionalId as fallback
            if (!businessRegistrationId && professionalId) {
              setBusinessRegistrationId(professionalId);
            }
          } else {
            console.error('Portfolio not found for ID:', professionalId);
            toast.error('Portfolio not found');
            // Try using professionalId as business_registration_id as last resort
            if (professionalId) {
              setBusinessRegistrationId(professionalId);
            }
          }
        }
      }
    } catch (error) {
      console.error('Error fetching portfolio:', error);
      toast.error('Failed to load portfolio');
    } finally {
      setLoading(false);
    }
  };

  const transformPortfolioData = (data: any) => {
    // Handle case where business_registrations might be an array or null
    const businessReg = Array.isArray(data.business_registrations) 
      ? data.business_registrations[0] 
      : data.business_registrations;
    
    // Store business_registration_id for reviews
    if (data.business_registration_id) {
      setBusinessRegistrationId(data.business_registration_id);
    } else if (businessReg?.id) {
      setBusinessRegistrationId(businessReg.id);
    }
    
    // Get name: prioritize portfolio title, then business_name, then contact_name
    const name = data.title || businessReg?.business_name || businessReg?.contact_name || 'Professional';
    
    // Get category: use business type name, or extract from title/business name
    const category = businessReg?.business_types?.name || 
                    (businessReg?.business_name ? 'Business' : 'Professional');
    
    // Get location: prioritize cities_served, then business_address
    const location = businessReg?.cities_served?.length > 0 
      ? businessReg.cities_served.join(', ')
      : businessReg?.business_address || 'Location not specified';
    
    // Get experience: prioritize portfolio experience field (as string), then years_in_business
    let experience = 0;
    if (data.experience) {
      // Try to parse experience string to number
      const expMatch = String(data.experience).match(/\d+/);
      experience = expMatch ? parseInt(expMatch[0], 10) : 0;
    }
    if (experience === 0 && businessReg?.years_in_business) {
      experience = businessReg.years_in_business;
    }
    
    // Get bio: clean description, fallback to about_services
    let bio = data.description || businessReg?.about_services || 'No description available';
    // Remove any garbled/nonsensical text (basic validation)
    if (bio && bio.length > 0) {
      const cleanedBio = bio.replace(/\s/g, '');
      // If bio is just random characters without spaces (20+ consecutive letters), use fallback
      if (/^[a-z]{20,}$/i.test(cleanedBio)) {
        bio = businessReg?.about_services || 'No description available';
      }
    }
    
    return {
      id: data.id,
      name: name,
      category: category,
      profileImage: data.logo_url || null,
      logo_url: data.logo_url || null,
      banner_url: data.banner_url || null,
      location: location,
      experience: experience,
      rating: 4.5,
      reviewCount: 0,
      bio: bio,
      skills: Array.isArray(data.skills) ? data.skills : [],
      certifications: Array.isArray(data.certifications) ? data.certifications : [],
      projects: Array.isArray(data.projects) ? data.projects : [],
      phone: businessReg?.phone_number,
      email: businessReg?.email_address,
      images: Array.isArray(data.images) ? data.images : []
    };
  };

  const transformBusinessToPortfolio = (data: any) => {
    // Store business_registration_id for reviews
    if (data.id) {
      setBusinessRegistrationId(data.id);
    }
    
    // Get name: prioritize business_name, then contact_name
    const name = data.business_name || data.contact_name || 'Professional';
    
    // Get category: use business type name
    const category = data.business_types?.name || 'Professional';
    
    // Get location: prioritize cities_served, then service_area, then business_address
    const location = data.cities_served?.length > 0
      ? data.cities_served.join(', ')
      : data.service_area || data.business_address || 'Location not specified';
    
    // Get bio: clean about_services
    let bio = data.about_services || 'No description available';
    // Remove any garbled/nonsensical text (basic validation)
    if (bio && bio.length > 0 && /^[a-z]{20,}$/i.test(bio.replace(/\s/g, ''))) {
      bio = 'No description available';
    }
    
    return {
      id: data.id,
      name: name,
      category: category,
      profileImage: null,
      logo_url: null,
      banner_url: null,
      location: location,
      experience: data.years_in_business || 0,
      rating: 4.5,
      reviewCount: 0,
      bio: bio,
      skills: [],
      certifications: [],
      projects: [],
      phone: data.phone_number,
      email: data.email_address,
      images: []
    };
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-24 sm:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-lg">Loading portfolio...</div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!portfolioData) {
    return (
      <div className="min-h-screen bg-background pb-24 sm:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <div className="text-lg">Portfolio not found</div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getCategoryIcon = (category?: string) => {
    if (!category) return '📐';
    switch (category.toLowerCase()) {
      case 'residential': return '🏠';
      case 'commercial': return '🏢';
      case 'interior': return '🛋️';
      case 'public': return '🏛️';
      case 'hospitality': return '🏨';
      case 'renovation': return '🔨';
      default: return '📐';
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24 sm:pb-8">
      <Header />
      {/* Portfolio Header with Banner Background */}
      <div 
        className={`relative border-b ${portfolioData.banner_url 
          ? 'bg-cover bg-center bg-no-repeat' 
          : 'bg-gradient-to-r from-primary/10 to-secondary/10'
        }`}
        style={portfolioData.banner_url ? {
          backgroundImage: `url(${portfolioData.banner_url})`,
          minHeight: '300px'
        } : {}}
      >
        {/* Overlay for better text readability */}
        {portfolioData.banner_url && (
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/50" />
        )}
        <div className="container mx-auto px-4 sm:px-6 py-6 sm:py-8 relative z-10">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-4 sm:gap-6">
            <Avatar className="h-24 w-24 ring-4 ring-background shadow-lg">
              <AvatarImage src={portfolioData.logo_url || portfolioData.profileImage} alt={portfolioData.name} />
              <AvatarFallback className="text-2xl font-bold">
                {getInitials(portfolioData.name)}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <div className="flex flex-col md:flex-row md:items-center gap-4 mb-3">
                <h1 className={`text-3xl font-bold ${portfolioData.banner_url ? 'text-white' : 'text-foreground'}`}>
                  {portfolioData.name}
                </h1>
                <Badge variant="secondary" className="w-fit text-sm px-3 py-1">
                  {portfolioData.category}
                </Badge>
              </div>
              
              <div className={`flex flex-wrap items-center gap-4 mb-3 ${portfolioData.banner_url ? 'text-white/90' : 'text-muted-foreground'}`}>
                <div className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  <span>{portfolioData.location}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  <span>{portfolioData.experience} years experience</span>
                </div>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span>
                    {(() => {
                      const avgRating = reviews && reviews.length > 0
                        ? reviews.reduce((acc: number, r: any) => acc + (r.rating || 0), 0) / reviews.length
                        : 0;
                      return Number(avgRating.toFixed(1));
                    })()} ({reviews?.length || 0} reviews)
                  </span>
                </div>
              </div>
              
              <div className={`mb-4 max-w-2xl ${portfolioData.banner_url ? 'text-white/90' : 'text-muted-foreground'}`}>
                {(() => {
                  const charLimit = 200;
                  const bio = portfolioData.bio || '';
                  
                  if (bio.length <= charLimit) {
                    return <p>{bio}</p>;
                  }
                  
                  return (
                    <div>
                      <p className="inline">
                        {isBioExpanded ? bio : `${bio.substring(0, charLimit)}...`}
                      </p>
                      <button
                        onClick={() => setIsBioExpanded(!isBioExpanded)}
                        className={`ml-2 hover:underline font-medium inline ${portfolioData.banner_url ? 'text-white' : 'text-primary'}`}
                      >
                        {isBioExpanded ? 'Read less' : 'Read more'}
                      </button>
                    </div>
                  );
                })()}
              </div>
              
              <ProtectedContactInfo
                professionalId={professionalId || ''}
                professionalName={portfolioData.name}
                phone={portfolioData.phone}
                email={portfolioData.email}
                variant="buttons"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 py-4 sm:py-6 lg:py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-4 sm:space-y-6 lg:space-y-8">
            {/* Skills Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Skills & Specializations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {portfolioData.skills.map((skill, index) => (
                    <Badge key={index} variant="outline" className="px-3 py-1">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Projects Gallery */}
            <Card>
              <CardHeader>
                <CardTitle>Portfolio Projects</CardTitle>
              </CardHeader>
              <CardContent>
                {portfolioData.projects.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {portfolioData.projects.map((project) => (
                      <Card key={project.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedProject(project)}>
                        <div className="relative">
                          <img 
                            src={project.images?.[0] || "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=400&h=300&fit=crop"} 
                            alt={project.title}
                            className="w-full h-48 object-cover"
                          />
                          <div className="absolute top-2 left-2">
                            <Badge variant="secondary" className="text-xs">
                              {getCategoryIcon(project.category)} {project.category || 'Project'}
                            </Badge>
                          </div>
                        </div>
                        <CardContent className="p-4">
                          <h3 className="font-semibold mb-1">{project.title}</h3>
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                            {project.description}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground">
                              {new Date(project.date).toLocaleDateString()}
                            </span>
                            <Button size="sm" variant="ghost">
                              <Edit className="h-3 w-3" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No projects added yet.</p>
                    <p className="text-sm">Add your first project to showcase your work.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Reviews Section */}
            {businessRegistrationId && (
              <ShopReviews
                reviews={(() => {
                  const transformedReviews = (reviews || []).map((review: any) => ({
                    id: review.id,
                    userName: (review.profiles as any)?.full_name || 'Anonymous User',
                    rating: review.rating,
                    comment: review.comment || '',
                    date: review.created_at,
                    avatar: (review.profiles as any)?.profile_image_url || '',
                  }));
                  return transformedReviews;
                })()}
                shopRating={(() => {
                  const avgRating = reviews && reviews.length > 0
                    ? reviews.reduce((acc: number, r: any) => acc + (r.rating || 0), 0) / reviews.length
                    : 0;
                  return Number(avgRating.toFixed(1));
                })()}
                onWriteReview={() => setReviewDialogOpen(true)}
              />
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-4 sm:space-y-6">
            {/* Contact Info */}
            <Card>
              <CardHeader className="pb-3 sm:pb-4">
                <CardTitle className="text-base sm:text-lg">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0">
                <ProtectedContactInfo
                  professionalId={professionalId || ''}
                  professionalName={portfolioData.name}
                  phone={portfolioData.phone}
                  email={portfolioData.email}
                  variant="sidebar"
                />
              </CardContent>
            </Card>

            {/* Certifications */}
            <Card>
              <CardHeader className="pb-3 sm:pb-4">
                <CardTitle className="text-base sm:text-lg">Certifications</CardTitle>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0 space-y-2 sm:space-y-3">
                {portfolioData.certifications.length > 0 ? (
                  portfolioData.certifications.map((cert, index) => (
                    <div key={index} className="p-2.5 sm:p-3 border border-border rounded-lg">
                      <h4 className="font-medium text-xs sm:text-sm">{cert.title}</h4>
                      <p className="text-[10px] sm:text-xs text-muted-foreground">{cert.issuer} • {cert.year}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-xs sm:text-sm text-muted-foreground text-center py-2">No certifications listed</p>
                )}
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card>
              <CardHeader className="pb-3 sm:pb-4">
                <CardTitle className="text-base sm:text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="p-4 sm:p-6 pt-0 space-y-2 sm:space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs sm:text-sm text-muted-foreground">Projects Completed</span>
                  <span className="font-medium text-xs sm:text-sm">{portfolioData.projects.length}+</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs sm:text-sm text-muted-foreground">Years Experience</span>
                  <span className="font-medium text-xs sm:text-sm">{portfolioData.experience}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs sm:text-sm text-muted-foreground">Client Rating</span>
                  <span className="font-medium text-xs sm:text-sm flex items-center gap-1">
                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                    {(() => {
                      const avgRating = reviews && reviews.length > 0
                        ? reviews.reduce((acc: number, r: any) => acc + (r.rating || 0), 0) / reviews.length
                        : 0;
                      return Number(avgRating.toFixed(1));
                    })()}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Project Detail Modal */}
      {selectedProject && (
        <Dialog open={!!selectedProject} onOpenChange={() => setSelectedProject(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-2xl font-bold">{selectedProject.title}</h2>
                  <p className="text-muted-foreground">
                    {selectedProject.category} • {new Date(selectedProject.date).toLocaleDateString()}
                  </p>
                </div>
                <Badge variant="secondary">
                  {getCategoryIcon(selectedProject.category)} {selectedProject.category}
                </Badge>
              </div>
              
              <img 
                src={selectedProject.images[0]} 
                alt={selectedProject.title}
                className="w-full h-64 object-cover rounded-lg"
              />
              
              <p className="text-muted-foreground">{selectedProject.description}</p>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Review Form Dialog */}
      {businessRegistrationId && portfolioData && (
        <ReviewFormDialog
          open={reviewDialogOpen}
          onOpenChange={setReviewDialogOpen}
          businessRegistrationId={businessRegistrationId}
          businessName={portfolioData.name}
          onReviewSubmitted={refreshReviews}
        />
      )}
      <Footer />
    </div>
  );
}
