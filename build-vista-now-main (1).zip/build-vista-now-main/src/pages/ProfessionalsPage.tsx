import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Filter, MessageCircle, User, LogIn, Building, Hammer, Ruler, Cpu, Palette, Factory, ChevronLeft, ChevronRight, ShoppingBag } from 'lucide-react';
import { motion } from 'framer-motion';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProfessionalCard from '../components/ProfessionalCard';
import FilterSidebar from '../components/FilterSidebar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { CreditBalance } from '@/components/CreditBalance';
import { useProfessionals, type Professional, type ProfessionalFilters } from '@/hooks/useProfessionals';
import { useAuth } from '@/hooks/useAuth';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const ProfessionalsPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const typeFromUrl = searchParams.get('type') || 'all';
  const { user, loading: authLoading } = useAuth();
  
  // Use the updated useProfessionals hook with categoryCounts
  const { 
    professionals, 
    businessTypes, 
    loading, 
    error, 
    fetchProfessionals,
    categoryCounts,
    countsLoading 
  } = useProfessionals();
  
  const [filteredProfessionals, setFilteredProfessionals] = useState<Professional[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [filterSheetOpen, setFilterSheetOpen] = useState(false);
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [filters, setFilters] = useState<ProfessionalFilters>({
    city: '',
    experience: 'any',
    sortBy: 'rating',
    type: typeFromUrl,
    subType: 'all'
  });

  // Ref for scrollable container
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showLeftScroll, setShowLeftScroll] = useState(false);
  const [showRightScroll, setShowRightScroll] = useState(true);

  // Function to get icon for business type
  const getIconForBusinessType = (businessTypeName: string) => {
    const nameLower = businessTypeName.toLowerCase();
    if (nameLower.includes('architect')) return Ruler;
    if (nameLower.includes('design')) return Palette;
    if (nameLower.includes('engineer')) return Cpu;
    if (nameLower.includes('contractor') || nameLower.includes('construction')) return Hammer;
    if (nameLower.includes('vendor') || nameLower.includes('supplier') || nameLower.includes('material')) return Factory;
    if (nameLower.includes('manufactur')) return Factory;
    if (nameLower.includes('plumb')) return Building;
    if (nameLower.includes('electr')) return Cpu;
    if (nameLower.includes('paint')) return Palette;
    if (nameLower.includes('roof')) return Building;
    if (nameLower.includes('landscap')) return Building;
    // Default icon
    return Building;
  };

  // Dynamically generate professional categories from business types
  const professionalCategories = React.useMemo(() => {
    const categories = [
      { id: 'all', label: 'All', icon: Building, count: categoryCounts.all || 0 }
    ];

    // Add categories from business types
    businessTypes.forEach(businessType => {
      const count = categoryCounts[businessType.name] || 0;
      // Only show categories that have at least one professional
      if (count > 0 || businessType.name) {
        categories.push({
          id: businessType.name.toLowerCase().replace(/\s+/g, '-'),
          label: businessType.name,
          icon: getIconForBusinessType(businessType.name),
          count: count
        });
      }
    });

    return categories;
  }, [businessTypes, categoryCounts]);

  // Check scroll position
  const checkScrollPosition = () => {
    if (!scrollContainerRef.current) return;
    
    const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
    
    setShowLeftScroll(scrollLeft > 0);
    setShowRightScroll(scrollLeft < scrollWidth - clientWidth - 10);
  };

  // Scroll left/right functions
  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -200, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 200, behavior: 'smooth' });
    }
  };

  // Add scroll event listener
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', checkScrollPosition);
      // Initial check
      checkScrollPosition();
    }
    
    return () => {
      if (container) {
        container.removeEventListener('scroll', checkScrollPosition);
      }
    };
  }, []);

  // Count active filters
  const activeFilterCount = [
    filters.city !== '',
    filters.experience !== 'any',
    filters.type !== 'all',
    filters.subType !== 'all'
  ].filter(Boolean).length;

  const professionalsPerPage = 12;

  // Convert URL type parameter to business type name
  const getBusinessTypeFromUrl = (urlType: string) => {
    if (urlType === 'all') return 'all';
    
    // Check if it's a hyphenated categoryId
    const businessType = businessTypes.find(bt => 
      bt.name.toLowerCase().replace(/\s+/g, '-') === urlType.toLowerCase()
    );
    
    if (businessType) {
      return businessType.name;
    }
    
    // Fallback to original URL type (for legacy support)
    return urlType;
  };

  // Fetch professionals on initial load and when URL type changes
  useEffect(() => {
    // Wait for business types to load before converting URL type
    if (businessTypes.length === 0 && typeFromUrl !== 'all') {
      return;
    }
    
    // Convert URL type to business type name
    const businessTypeName = getBusinessTypeFromUrl(typeFromUrl);
    
    // Fetch professionals based on URL parameter or default to 'all'
    fetchProfessionals({
      type: businessTypeName === 'all' ? undefined : businessTypeName,
      experience: 'any',
      sortBy: 'rating'
    });
  }, [typeFromUrl, fetchProfessionals, businessTypes]); // Added businessTypes to dependencies

  // Update filters when URL parameter changes
  useEffect(() => {
    if (typeFromUrl && typeFromUrl !== filters.type) {
      const businessTypeName = getBusinessTypeFromUrl(typeFromUrl);
      setFilters(prev => ({ ...prev, type: businessTypeName }));
    }
  }, [typeFromUrl, businessTypes]);

  // Apply filters when professionals or filters change
  useEffect(() => {
    let filtered = [...professionals];

    // Filter by professional type (this is already done server-side, but keep for consistency)
    if (filters.type && filters.type !== 'all') {
      filtered = filtered.filter(prof => {
        if (!prof.business_type) return false;
        
        const businessTypeLower = prof.business_type.toLowerCase();
        const filterTypeLower = filters.type.toLowerCase();
        
        // First, try exact match or includes match for business type name
        if (businessTypeLower === filterTypeLower || businessTypeLower.includes(filterTypeLower)) {
          return true;
        }
        
        // Fallback: Map legacy filter types to keywords
        if (filterTypeLower === 'architects' && businessTypeLower.includes('architect')) return true;
        if (filterTypeLower === 'contractors' && businessTypeLower.includes('contractor')) return true;
        if (filterTypeLower === 'vendors' && businessTypeLower.includes('vendor')) return true;
        if (filterTypeLower === 'engineers' && businessTypeLower.includes('engineer')) return true;
        if (filterTypeLower === 'designers' && businessTypeLower.includes('designer')) return true;
        if (filterTypeLower === 'manufacturers' && businessTypeLower.includes('manufactur')) return true;
        
        return false;
      });
    }

    // Filter by sub business type
    if (filters.subType && filters.subType !== 'all') {
      const sub = filters.subType.toLowerCase();
      filtered = filtered.filter(prof =>
        prof.sub_business_type && prof.sub_business_type.toLowerCase().includes(sub)
      );
    }

    // Client-side filtering for city
    if (filters.city) {
      filtered = filtered.filter(prof => 
        prof.location.toLowerCase().includes(filters.city.toLowerCase()) ||
        prof.city_name?.toLowerCase().includes(filters.city.toLowerCase())
      );
    }

    setFilteredProfessionals(filtered);
  }, [professionals, filters.city, filters.type, filters.subType]);

  // Handle filter changes and fetch data
  const handleFiltersChange = (newFilters: ProfessionalFilters) => {
    setFilters(newFilters);
    setCurrentPage(1);
    
    // Fetch professionals with new filters
    fetchProfessionals({
      type: newFilters.type === 'all' ? undefined : newFilters.type,
      experience: newFilters.experience !== 'any' ? newFilters.experience : undefined,
      sortBy: newFilters.sortBy
    });
  };

  // Handle category button click
  const handleCategoryClick = (categoryId: string) => {
    // Convert categoryId back to business type name if it's not 'all'
    let filterType = categoryId;
    if (categoryId !== 'all') {
      // Find the business type that matches this categoryId
      const businessType = businessTypes.find(bt => 
        bt.name.toLowerCase().replace(/\s+/g, '-') === categoryId
      );
      if (businessType) {
        filterType = businessType.name;
      }
    }
    
    const newFilters = { ...filters, type: filterType };
    setFilters(newFilters);
    setCurrentPage(1);
    
    // Update URL
    navigate(`/professionals${categoryId !== 'all' ? `?type=${categoryId}` : ''}`);
    
    // Fetch professionals for this category
    fetchProfessionals({
      type: categoryId === 'all' ? undefined : filterType,
      experience: filters.experience !== 'any' ? filters.experience : undefined,
      sortBy: filters.sortBy
    });
  };

  // Handle contact professional button click
  const handleContactProfessional = (professionalId: string) => {
    if (!user) {
      // Redirect to auth page with return URL
      navigate(`/auth?redirect=${encodeURIComponent(window.location.pathname)}`);
      return;
    }
    // Contact logic is handled by ProfessionalCard's built-in ContactRequestModal
    // This function is kept for potential future custom handling
  };

  // Handle shop now button click
  const handleShopNow = (professionalId: string) => {
    if (!user) {
      // Redirect to auth page with return URL
      navigate(`/auth?redirect=${encodeURIComponent(window.location.pathname)}`);
      return;
    }
    // If user is logged in, proceed with shop logic
    console.log('Shop with professional:', professionalId);
    // Add your shop logic here
  };

  // Generic function to check authentication before any action
  const requireAuth = (action: () => void) => {
    if (!user) {
      navigate(`/auth?redirect=${encodeURIComponent(window.location.pathname)}`);
      return false;
    }
    action();
    return true;
  };

  // Handle login redirect
  const handleLoginRedirect = () => {
    setAuthDialogOpen(false);
    navigate(`/auth?redirect=${encodeURIComponent(window.location.pathname)}`);
  };

  // Handle register redirect
  const handleRegisterRedirect = () => {
    setAuthDialogOpen(false);
    navigate(`/auth?tab=register&redirect=${encodeURIComponent(window.location.pathname)}`);
  };

  // Pagination
  const totalPages = Math.ceil(filteredProfessionals.length / professionalsPerPage);
  const startIndex = (currentPage - 1) * professionalsPerPage;
  const currentProfessionals = filteredProfessionals.slice(startIndex, startIndex + professionalsPerPage);

  // Show skeleton loading for category counts
  const CategorySkeleton = () => (
    <div className="flex-shrink-0 flex items-center gap-2 px-3 sm:px-4 py-2 text-xs sm:text-sm border border-gray-300 rounded-md min-w-fit">
      <div className="h-3 w-3 sm:h-4 sm:w-4 bg-gray-200 rounded-full animate-pulse"></div>
      <div className="h-4 w-16 bg-gray-200 rounded animate-pulse"></div>
      <div className="ml-1 text-xs px-1.5 py-0 h-5 w-6 bg-gray-200 rounded animate-pulse"></div>
    </div>
  );

  return (
    <>
      <Helmet>
        <title>Connect All Professionals | BuildOnClicks</title>
        <meta name="description" content="Find verified contractors, vendors, and architects for your construction projects on BuildOnClicks. Browse professionals without login." />
      </Helmet>

      <Header />

      <div className="min-h-screen bg-gray-50 pb-24 sm:pb-8">
        {/* Header Section */}
        <div className="bg-white border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center"
            >
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-primary mb-4">
                Connect All Professionals
              </h1>
              <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-2xl mx-auto mb-2">
                Browse verified contractors, vendors, and architects in your area. No login required to explore.
              </p>
              {!user && !authLoading && (
                <p className="text-sm text-gray-500 max-w-2xl mx-auto">
                  Sign in to contact professionals, shop products, save favorites, and get personalized recommendations.
                </p>
              )}
            </motion.div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8 pb-32 sm:pb-24">
          {/* Professional Categories Filter Row */}
          <div className="mb-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
              <h2 className="text-lg font-semibold text-gray-800">Browse by Category</h2>
              <div className="text-sm text-gray-500">
                Showing <span className="font-semibold text-primary">{filteredProfessionals.length}</span> professionals
                {filters.type !== 'all' && ` in ${filters.type}`}
              </div>
            </div>
            
            {/* Scrollable categories container for mobile */}
            <div className="relative">
              {/* Left scroll button for mobile */}
              {showLeftScroll && (
                <button
                  onClick={scrollLeft}
                  className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 bg-white border border-gray-300 rounded-full shadow-md flex items-center justify-center hover:bg-gray-50 transition-colors sm:hidden"
                  aria-label="Scroll left"
                >
                  <ChevronLeft className="h-4 w-4 text-gray-600" />
                </button>
              )}
              
              {/* Right scroll button for mobile */}
              {showRightScroll && (
                <button
                  onClick={scrollRight}
                  className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 bg-white border border-gray-300 rounded-full shadow-md flex items-center justify-center hover:bg-gray-50 transition-colors sm:hidden"
                  aria-label="Scroll right"
                >
                  <ChevronRight className="h-4 w-4 text-gray-600" />
                </button>
              )}
              
              {/* Categories container */}
              <div 
                ref={scrollContainerRef}
                className="flex gap-2 sm:gap-3 overflow-x-auto pb-3 scrollbar-hide scroll-smooth"
                style={{
                  scrollbarWidth: 'none',
                  msOverflowStyle: 'none',
                  WebkitOverflowScrolling: 'touch'
                }}
              >
                {/* Add CSS to hide scrollbar */}
                <style>{`
                  .scrollbar-hide::-webkit-scrollbar {
                    display: none;
                  }
                  .scrollbar-hide {
                    -ms-overflow-style: none;
                    scrollbar-width: none;
                  }
                `}</style>
                
                {countsLoading || businessTypes.length === 0 ? (
                  // Show skeleton loading for categories
                  [...Array(Math.max(7, businessTypes.length + 1))].map((_, index) => (
                    <CategorySkeleton key={index} />
                  ))
                ) : (
                  professionalCategories.map((category) => {
                    const Icon = category.icon;
                    // Check if this category is active by comparing business type names
                    const isActive = category.id === 'all' 
                      ? filters.type === 'all'
                      : filters.type.toLowerCase() === category.label.toLowerCase();
                    
                    return (
                      <Button
                        key={category.id}
                        variant={isActive ? "orange" : "outline"}
                        onClick={() => handleCategoryClick(category.id)}
                        className={`
                          flex-shrink-0 flex items-center gap-2 px-3 sm:px-4 py-2 text-xs sm:text-sm
                          ${!isActive ? 'border-gray-300 hover:border-primary hover:text-primary' : ''}
                          min-w-fit
                        `}
                      >
                        <Icon className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                        <span className="whitespace-nowrap">{category.label}</span>
                        <Badge 
                          variant={isActive ? "secondary" : "outline"} 
                          className={`
                            ml-1 text-xs px-1.5 py-0 h-5 flex-shrink-0
                            ${isActive 
                              ? 'bg-white/20 text-white' 
                              : 'bg-gray-100 text-gray-600'
                            }
                          `}
                        >
                          {category.count}
                        </Badge>
                      </Button>
                    );
                  })
                )}
              </div>
              
              {/* Scroll indicators for mobile */}
              <div className="sm:hidden flex justify-center gap-1 mt-2">
                <div className={`h-1 w-8 rounded-full ${showLeftScroll ? 'bg-primary/30' : 'bg-gray-200'}`}></div>
                <div className={`h-1 w-8 rounded-full ${showRightScroll ? 'bg-primary/30' : 'bg-gray-200'}`}></div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="w-full">
              {/* Results Header */}
              <div className="flex flex-col sm:flex-row justify-between items-center gap-3 mb-6">
                <div className="text-center sm:text-left">
                  <p className="text-sm sm:text-base text-gray-600">
                    Showing {currentProfessionals.length} of {filteredProfessionals.length} professionals
                    {filters.type !== 'all' && ` in ${filters.type}`}
                  </p>
                  {!user && !authLoading && (
                    <p className="text-xs text-gray-500 mt-1">
                      Viewing as guest. <button 
                        onClick={() => navigate(`/auth?redirect=${encodeURIComponent(window.location.pathname)}`)} 
                        className="text-primary hover:underline font-medium"
                      >
                        Sign in for full access
                      </button>
                    </p>
                  )}
                </div>
                {user && (
                  <div>
                    <CreditBalance />
                  </div>
                )}
              </div>

              {/* Loading State */}
              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 lg:gap-6">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="bg-white rounded-lg shadow-sm p-6">
                        <div className="h-20 w-20 bg-primary/10 rounded-full mx-auto mb-4"></div>
                        <div className="h-4 bg-primary/20 rounded mb-2"></div>
                        <div className="h-3 bg-primary/10 rounded mb-4"></div>
                        <div className="flex space-x-2">
                          <div className="h-8 bg-primary/10 rounded flex-1"></div>
                          <div className="h-8 bg-primary/10 rounded flex-1"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <>
                  {/* Professionals Grid */}
                  {currentProfessionals.length > 0 ? (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.6 }}
                      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 lg:gap-6"
                    >
                      {currentProfessionals.map((professional, index) => (
                        <motion.div
                          key={professional.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.6, delay: index * 0.1 }}
                        >
                          <ProfessionalCard 
                            professional={professional} 
                            onShop={(id) => requireAuth(() => handleShopNow(id))}
                            isLoggedIn={!!user}
                          />
                        </motion.div>
                      ))}
                    </motion.div>
                  ) : (
                    <div className="text-center py-12 bg-white rounded-lg border border-primary/20 p-8">
                      <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                        <User className="h-8 w-8 text-primary" />
                      </div>
                      <p className="text-gray-600 text-lg mb-2">
                        {error || 'No professionals found matching your criteria.'}
                      </p>
                      <p className="text-sm text-gray-500 mb-4">
                        Try selecting a different category or adjusting your filters.
                      </p>
                      <div className="flex flex-col sm:flex-row gap-2 justify-center">
                        <Button
                          variant="outline"
                          onClick={() => handleCategoryClick('all')}
                          className="border-primary text-primary hover:bg-primary/10"
                        >
                          Show All Professionals
                        </Button>
                        <Button
                          variant="orange"
                          onClick={() => setFilterSheetOpen(true)}
                        >
                          <Filter className="h-4 w-4 mr-2" />
                          Advanced Filters
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Pagination */}
                  {totalPages > 1 && (
                    <div className="mt-12 flex justify-center">
                      <div className="flex items-center space-x-1 sm:space-x-2">
                        <Button
                          variant="outline"
                          onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                          disabled={currentPage === 1}
                          className="text-xs sm:text-sm border-gray-300 hover:border-primary hover:text-primary"
                        >
                          Previous
                        </Button>
                        
                        {/* Show simplified pagination on mobile */}
                        {totalPages <= 5 ? (
                          // Show all pages if 5 or less
                          [...Array(totalPages)].map((_, i) => (
                            <Button
                              key={i + 1}
                              variant={currentPage === i + 1 ? "orange" : "outline"}
                              onClick={() => setCurrentPage(i + 1)}
                              className={`w-8 h-8 sm:w-10 sm:h-10 text-xs sm:text-sm ${
                                currentPage === i + 1 
                                  ? '' 
                                  : 'border-gray-300 hover:border-primary hover:text-primary'
                              }`}
                            >
                              {i + 1}
                            </Button>
                          ))
                        ) : (
                          // Show smart pagination for more pages
                          <>
                            {/* First page */}
                            <Button
                              variant={currentPage === 1 ? "orange" : "outline"}
                              onClick={() => setCurrentPage(1)}
                              className={`w-8 h-8 sm:w-10 sm:h-10 text-xs sm:text-sm ${
                                currentPage === 1 
                                  ? '' 
                                  : 'border-gray-300 hover:border-primary hover:text-primary'
                              }`}
                            >
                              1
                            </Button>
                            
                            {/* Ellipsis if needed */}
                            {currentPage > 3 && (
                              <span className="px-2 text-gray-500">...</span>
                            )}
                            
                            {/* Current page and neighbors */}
                            {currentPage > 2 && currentPage < totalPages - 1 && (
                              <>
                                {currentPage > 3 && (
                                  <Button
                                    variant="outline"
                                    onClick={() => setCurrentPage(currentPage - 1)}
                                    className="w-8 h-8 sm:w-10 sm:h-10 text-xs sm:text-sm border-gray-300 hover:border-primary hover:text-primary"
                                  >
                                    {currentPage - 1}
                                  </Button>
                                )}
                                <Button
                                  variant="orange"
                                  className="w-8 h-8 sm:w-10 sm:h-10 text-xs sm:text-sm"
                                >
                                  {currentPage}
                                </Button>
                                {currentPage < totalPages - 2 && (
                                  <Button
                                    variant="outline"
                                    onClick={() => setCurrentPage(currentPage + 1)}
                                    className="w-8 h-8 sm:w-10 sm:h-10 text-xs sm:text-sm border-gray-300 hover:border-primary hover:text-primary"
                                  >
                                    {currentPage + 1}
                                  </Button>
                                )}
                              </>
                            )}
                            
                            {/* Show page 2 if current is 2 */}
                            {currentPage === 2 && (
                              <Button
                                variant="orange"
                                className="w-8 h-8 sm:w-10 sm:h-10 text-xs sm:text-sm"
                              >
                                2
                              </Button>
                            )}
                            
                            {/* Ellipsis if needed */}
                            {currentPage < totalPages - 2 && (
                              <span className="px-2 text-gray-500">...</span>
                            )}
                            
                            {/* Last page */}
                            <Button
                              variant={currentPage === totalPages ? "orange" : "outline"}
                              onClick={() => setCurrentPage(totalPages)}
                              className={`w-8 h-8 sm:w-10 sm:h-10 text-xs sm:text-sm ${
                                currentPage === totalPages 
                                  ? '' 
                                  : 'border-gray-300 hover:border-primary hover:text-primary'
                              }`}
                            >
                              {totalPages}
                            </Button>
                          </>
                        )}
                        
                        <Button
                          variant="outline"
                          onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                          disabled={currentPage === totalPages}
                          className="text-xs sm:text-sm border-gray-300 hover:border-primary hover:text-primary"
                        >
                          Next
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              )}
          </div>
        </div>

        {/* Sticky Filter Button */}
        <Sheet open={filterSheetOpen} onOpenChange={setFilterSheetOpen}>
          <SheetTrigger asChild>
            <Button
              variant="orange"
              className="fixed bottom-24 right-4 sm:right-6 z-50 shadow-lg h-12 sm:h-14 px-4 sm:px-6 rounded-full"
              size="lg"
            >
              <Filter className="h-4 w-4 sm:h-5 sm:w-5 sm:mr-2" />
              <span className="hidden sm:inline ml-2">Filters</span>
              {activeFilterCount > 0 && (
                <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 flex items-center justify-center rounded-full text-xs">
                  {activeFilterCount}
                </Badge>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-full sm:max-w-md overflow-y-auto">
            <SheetHeader>
              <SheetTitle>Filter Professionals</SheetTitle>
            </SheetHeader>
            <div className="mt-6">
              <FilterSidebar
                filters={filters}
                onFiltersChange={(newFilters) => {
                  handleFiltersChange(newFilters);
                  setFilterSheetOpen(false);
                }}
                resultCount={filteredProfessionals.length}
                businessTypes={businessTypes}
              />
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Guest Access Dialog */}
      <Dialog open={authDialogOpen} onOpenChange={setAuthDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl flex items-center gap-2">
              <User className="h-5 w-5 text-primary" />
              Sign In Required
            </DialogTitle>
            <DialogDescription>
              You need to be signed in to contact professionals, shop products, and access all features.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-blue-800 mb-2 flex items-center gap-2">
                  <ShoppingBag className="h-4 w-4" />
                  Benefits of signing in:
                </h4>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Contact professionals directly</li>
                  <li>• Shop products from vendors</li>
                  <li>• Save favorite professionals</li>
                  <li>• Get personalized recommendations</li>
                  <li>• Post your requirements</li>
                  <li>• Track your interactions</li>
                </ul>
              </div>

              <div className="space-y-3 pt-2">
                <Button
                  onClick={handleLoginRedirect}
                  variant="orange"
                  className="w-full"
                >
                  <LogIn className="h-4 w-4 mr-2" />
                  Sign In to Your Account
                </Button>
                
                <Button
                  onClick={handleRegisterRedirect}
                  variant="outline"
                  className="w-full border-primary text-primary hover:bg-primary/10"
                >
                  Create New Account
                </Button>
                
                <p className="text-xs text-gray-500 text-center mt-2">
                  By continuing, you agree to our Terms of Service and Privacy Policy
                </p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>


      

      <Footer />
    </>
  );
};

export default ProfessionalsPage;
