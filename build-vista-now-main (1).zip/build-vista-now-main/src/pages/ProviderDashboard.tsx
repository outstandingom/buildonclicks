import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useNavigate } from 'react-router-dom';
import { Building, FileText, CheckCircle, Clock, AlertCircle, Settings, Plus, User, Store, Briefcase, ExternalLink } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useAuth } from '@/hooks/useAuth';
import { useProviderDashboard } from '@/hooks/useProviderDashboard';
import { useShopPortfolio } from '@/hooks/useShopPortfolio';
import { RegistrationGuideModal } from '@/components/RegistrationGuideModal';
import { supabase } from '@/integrations/supabase/client';

const ProviderDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [showDocumentsModal, setShowDocumentsModal] = useState(false);
  const { 
    businessRegistration, 
    loading, 
    hasRegistration, 
    getProfileCompletionPercentage, 
    getStatusBadgeInfo 
  } = useProviderDashboard(user?.id);
  
  const { shop, portfolio, loading: shopPortfolioLoading } = useShopPortfolio(businessRegistration?.id);

  const handleBusinessRegistration = () => {
    navigate('/business-registration');
  };

  const handleShopPortfolioSetup = () => {
    navigate('/shop-portfolio-setup');
  };

  const handleShopManagement = () => {
    if (portfolio) {
      navigate('/portfolio-management');
    } else {
      navigate('/vendor-shop-management');
    }
  };

  const handleViewDocuments = () => {
    setShowDocumentsModal(true);
  };

  const openDocument = async (documentPath: string) => {
    if (!documentPath) return;
    try {
      // Attempt public URL first
      const { data: publicData } = supabase.storage
        .from('business-documents')
        .getPublicUrl(documentPath);
      
      if (publicData?.publicUrl) {
        window.open(publicData.publicUrl, '_blank');
        return;
      }

      // Fallback to signed URL
      const { data, error } = await supabase.storage
        .from('business-documents')
        .createSignedUrl(documentPath, 3600);

      if (error) {
        console.error('Error creating signed URL:', error);
        return;
      }

      if (data?.signedUrl) {
        window.open(data.signedUrl, '_blank');
      }
    } catch (err) {
      console.error('Error opening document:', err);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
        <Header />
        <div className="flex-1 bg-gradient-section flex items-center justify-center p-6">
          <div className="text-center">
            <div className="animate-spin rounded-full h-20 w-20 border-b-2 border-construction-primary mx-auto mb-3"></div>
            <p className="text-construction-neutral text-sm">Loading dashboard...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!user) {
    navigate('/auth');
    return null;
  }

  const statusInfo = getStatusBadgeInfo();
  const completionPercentage = getProfileCompletionPercentage();
  
  // Safe status checks
  const registrationStatus = businessRegistration?.status;
  const isApproved = registrationStatus === 'approved';
  const isPending = registrationStatus === 'pending';
  const isRejected = registrationStatus === 'rejected';

  return (
    <div className="min-h-screen flex flex-col pb-24 sm:pb-8 bg-white">
      <Header />

      <div className="flex-1 bg-gradient-section">
        <div className="container mx-auto px-3 sm:px-4 py-6 sm:py-8">
          {/* Header - stacked on mobile */}
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45 }}
            className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3 mb-6"
          >
            <div className="text-left">
              <h1 className="text-2xl sm:text-3xl font-bold text-construction-secondary leading-tight">Provider Dashboard</h1>
              <p className="text-xs sm:text-sm text-construction-neutral mt-1">
                {businessRegistration ? 
                  `Welcome back, ${businessRegistration.contact_name}` : 
                  'Manage your business profile and projects'
                }
              </p>
            </div>

            <div className="flex gap-2 items-center w-full sm:w-auto">
              <Button
                variant="outline"
                onClick={() => navigate('/profile')}
                className="flex items-center gap-2 w-full sm:w-auto text-xs sm:text-sm"
              >
                <User className="w-4 h-4" />
                Profile Settings
              </Button>
            </div>
          </motion.div>

          {/* Welcome / Status Card */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.06 }}
            className="mb-5"
          >
            <Card className="shadow-card border-l-4 border-l-construction-primary p-3 sm:p-4">
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-sm sm:text-base">
                      <Building className="w-4 h-4 text-construction-primary" />
                      {hasRegistration ? 
                        `Business Registration - ${businessRegistration?.business_name}` : 
                        'Welcome to BuildOnClicks!'
                      }
                    </CardTitle>
                    <CardDescription className="mt-1 text-xs sm:text-sm text-construction-neutral">
                      {hasRegistration ? (
                        isApproved ? 
                          'Your business is approved and ready to receive project leads!' :
                          isPending ?
                            'Your business registration is under review. We\'ll contact you within 48 hours.' :
                            'Your business registration was rejected. Please review and resubmit.'
                      ) : (
                        'Complete your business registration to start receiving project leads and connect with potential clients.'
                      )}
                    </CardDescription>
                  </div>

                  <div className="flex items-center justify-end">
                    <Badge variant={statusInfo.variant} className={`${statusInfo.color} text-xs sm:text-sm px-2 py-1`}>
                      <AlertCircle className="w-3 h-3 mr-1 inline" />
                      <span className="align-middle">{statusInfo.text}</span>
                    </Badge>
                  </div>
                </div>
              </CardHeader>

              {!hasRegistration && (
                <CardContent className="pt-3">
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Button 
                      onClick={handleBusinessRegistration}
                      className="bg-construction-primary hover:bg-construction-primary/90 text-white flex items-center gap-2 w-full sm:w-auto text-xs sm:text-sm"
                    >
                      <Plus className="w-4 h-4" />
                      Complete Business Registration
                    </Button>
                    <Button 
                      variant="outline"
                      className="flex items-center gap-2 w-full sm:w-auto text-xs sm:text-sm"
                      onClick={() => setShowGuideModal(true)}
                    >
                      <FileText className="w-4 h-4" />
                      View Registration Guide
                    </Button>
                  </div>
                </CardContent>
              )}
            </Card>
          </motion.div>

          {/* Shop / Portfolio - show only if approved */}
          {isApproved && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.1 }}
              className="mb-5"
            >
              <Card className="shadow-card border-l-4 border-l-green-500 p-3 sm:p-4">
                <CardHeader>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div>
                      <CardTitle className="flex items-center gap-2 text-sm sm:text-base">
                        {shop ? (
                          <Store className="w-4 h-4 text-green-600" />
                        ) : portfolio ? (
                          <Briefcase className="w-4 h-4 text-green-600" />
                        ) : (
                          <Plus className="w-4 h-4 text-construction-primary" />
                        )}
                        {shop ? `Shop: ${shop.shop_name}` : 
                         portfolio ? `Portfolio: ${portfolio.title}` : 
                         'Create Your Business Presence'}
                      </CardTitle>

                      <CardDescription className="mt-1 text-xs sm:text-sm text-construction-neutral">
                        {shop ? 'Your shop is live and ready to receive orders!' :
                         portfolio ? 'Your portfolio is showcasing your work to potential clients!' :
                         'Create a shop or portfolio to showcase your business to potential clients.'}
                      </CardDescription>
                    </div>

                    {(shop || portfolio) && (
                      <Badge variant="default" className="bg-green-100 text-green-700 text-xs sm:text-sm px-2 py-1">
                        <CheckCircle className="w-3 h-3 mr-1 inline" />
                        <span className="align-middle">Active</span>
                      </Badge>
                    )}
                  </div>
                </CardHeader>

                {!shop && !portfolio && (
                  <CardContent className="pt-3">
                    <Button 
                      onClick={handleShopPortfolioSetup}
                      className="bg-construction-primary hover:bg-construction-primary/90 text-white flex items-center gap-2 w-full sm:w-auto text-xs sm:text-sm"
                    >
                      <Plus className="w-4 h-4" />
                      Create Shop or Portfolio
                    </Button>
                  </CardContent>
                )}
              </Card>
            </motion.div>
          )}

          {/* Dashboard Cards - stack on mobile and compact sizes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {/* Profile Status */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.14 }}
            >
              <Card className="shadow-card hover:shadow-hover transition-shadow p-3 sm:p-4">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center justify-between text-sm sm:text-base">
                    <span className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-construction-primary" />
                      <span>Profile Status</span>
                    </span>
                    <Badge 
                      variant={completionPercentage === 100 ? "default" : "destructive"}
                      className={`${completionPercentage === 100 ? 'bg-green-100 text-green-700' : ''} text-xs sm:text-sm px-2 py-1`}
                    >
                      {completionPercentage === 100 ? (
                        <>
                          <CheckCircle className="w-3 h-3 mr-1 inline" />
                          <span className="align-middle">Complete</span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-3 h-3 mr-1 inline" />
                          <span className="align-middle">Incomplete</span>
                        </>
                      )}
                    </Badge>
                  </CardTitle>
                </CardHeader>

                <CardContent className="text-xs sm:text-sm">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Account Created</span>
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Business Registration</span>
                      {hasRegistration ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <Clock className="w-4 h-4 text-construction-neutral" />
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Document Verification</span>
                      {isApproved ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <Clock className="w-4 h-4 text-construction-neutral" />
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Admin Approval</span>
                      {isApproved ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <Clock className="w-4 h-4 text-construction-neutral" />
                      )}
                    </div>
                    {isApproved && (
                      <div className="flex items-center justify-between">
                        <span className="text-xs">Shop/Portfolio</span>
                        {shop || portfolio ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <Clock className="w-4 h-4 text-construction-neutral" />
                        )}
                      </div>
                    )}
                  </div>

                  <div className="mt-3 pt-3 border-t">
                    <div className="flex justify-between items-center text-xs sm:text-sm mb-2">
                      <span>Profile Completion</span>
                      <span className="font-semibold text-sm">{completionPercentage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1 sm:h-2">
                      <div 
                        className="bg-construction-primary h-1 sm:h-2 rounded-full transition-all duration-300" 
                        style={{ width: `${completionPercentage}%` }}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Projects */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.18 }}
            >
              <Card className="shadow-card hover:shadow-hover transition-shadow p-3 sm:p-4">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-sm sm:text-base">
                    <Building className="w-4 h-4 text-construction-primary" />
                    Projects
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-6">
                    <Building className="w-10 h-10 text-construction-neutral mx-auto mb-2 opacity-50" />
                    <p className="text-xs sm:text-sm text-construction-neutral">
                      {isApproved ? 
                        'No active projects yet. Projects will appear here once clients start contacting you.' :
                        'Complete your business registration to start receiving project opportunities'
                      }
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.22 }}
            >
              <Card className="shadow-card hover:shadow-hover transition-shadow p-3 sm:p-4">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2 text-sm sm:text-base">
                    <CheckCircle className="w-4 h-4 text-construction-primary" />
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {!hasRegistration ? (
                      <Button 
                        variant="outline" 
                        className="w-full justify-start text-xs sm:text-sm"
                        onClick={handleBusinessRegistration}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Business Registration
                      </Button>
                    ) : isRejected ? (
                      <Button 
                        variant="outline" 
                        className="w-full justify-start text-xs sm:text-sm"
                        onClick={handleBusinessRegistration}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Resubmit Registration
                      </Button>
                    ) : null}
                    
                    {isApproved && !shop && !portfolio && (
                      <Button 
                        variant="outline" 
                        className="w-full justify-start text-xs sm:text-sm"
                        onClick={handleShopPortfolioSetup}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Create Shop/Portfolio
                      </Button>
                    )}
                    
                    {isApproved && (shop || portfolio) && (
                      <Button 
                        variant="outline" 
                        className="w-full justify-start text-xs sm:text-sm"
                        onClick={handleShopManagement}
                      >
                        {portfolio ? (
                          <Briefcase className="w-4 h-4 mr-2" />
                        ) : (
                          <Store className="w-4 h-4 mr-2" />
                        )}
                        {portfolio ? 'Manage Portfolio' : 'Manage Shop'}
                      </Button>
                    )}
                    
                    <Button 
                      variant="outline" 
                      className="w-full justify-start text-xs sm:text-sm"
                      disabled={!hasRegistration}
                      onClick={handleViewDocuments}
                    >
                      <FileText className="w-4 h-4 mr-2" />
                      View Documents
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start text-xs sm:text-sm"
                      onClick={() => navigate('/profile')}
                    >
                      <Settings className="w-4 h-4 mr-2" />
                      Profile Settings
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Next Steps */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.26 }}
            className="mb-6"
          >
            <Card className="shadow-card p-3 sm:p-4">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-sm sm:text-base">
                  <CheckCircle className="w-4 h-4 text-construction-primary" />
                  {isApproved && (shop || portfolio) ? 'You\'re All Set!' : 'Next Steps to Get Started'}
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  {isApproved && (shop || portfolio) ? 
                    'Your business is fully set up and ready to receive project leads' :
                    'Follow these steps to complete your profile and start receiving projects'
                  }
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-3">
                {isApproved && (shop || portfolio) ? (
                  <div className="text-center py-6">
                    <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-2" />
                    <h3 className="text-base sm:text-lg font-semibold text-construction-secondary mb-1">Congratulations!</h3>
                    <p className="text-xs sm:text-sm text-construction-neutral">
                      Your business is fully set up with {shop ? 'a shop' : 'a portfolio'}. You'll start receiving project leads and customer inquiries based on your expertise and service area.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className={`flex flex-col sm:flex-row items-start sm:items-center gap-3 p-3 border rounded-lg ${hasRegistration ? 'opacity-70' : 'bg-construction-primary/5 border-construction-primary'}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${hasRegistration ? 'bg-green-500 text-white' : 'bg-construction-primary text-white'}`}>
                        {hasRegistration ? '✓' : '1'}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-construction-secondary text-xs sm:text-sm">Complete Business Registration</h4>
                        <p className="text-xs sm:text-sm text-construction-neutral">Provide your business details, upload required documents, and submit for verification</p>
                      </div>
                      <div className="self-end sm:self-auto">
                        {!hasRegistration ? (
                          <Button onClick={handleBusinessRegistration} size="sm" className="text-xs sm:text-sm">Start Now</Button>
                        ) : (
                          <Badge variant="default" className="text-xs sm:text-sm px-2 py-1">Completed</Badge>
                        )}
                      </div>
                    </div>

                    <div className={`flex flex-col sm:flex-row items-start sm:items-center gap-3 p-3 border rounded-lg ${isPending ? 'bg-yellow-50 border-yellow-200' : 'opacity-70'}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${isApproved ? 'bg-green-500 text-white' : isPending ? 'bg-yellow-500 text-white' : 'bg-gray-300 text-gray-600'}`}>
                        {isApproved ? '✓' : '2'}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-construction-secondary text-xs sm:text-sm">Admin Review</h4>
                        <p className="text-xs sm:text-sm text-construction-neutral">Our team will verify your documents and approve your profile within 48 hours</p>
                      </div>
                      <div className="self-end sm:self-auto">
                        {isPending && <Badge variant="secondary" className="text-xs sm:text-sm px-2 py-1">In Progress</Badge>}
                        {isApproved && <Badge variant="default" className="text-xs sm:text-sm px-2 py-1">Completed</Badge>}
                        {!hasRegistration && <Badge variant="outline" className="text-xs sm:text-sm px-2 py-1">Pending Step 1</Badge>}
                      </div>
                    </div>

                    <div className={`flex flex-col sm:flex-row items-start sm:items-center gap-3 p-3 border rounded-lg ${isApproved && (shop || portfolio) ? 'bg-green-50 border-green-200' : isApproved ? 'bg-construction-primary/5 border-construction-primary' : 'opacity-70'}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${isApproved && (shop || portfolio) ? 'bg-green-500 text-white' : isApproved ? 'bg-construction-primary text-white' : 'bg-gray-300 text-gray-600'}`}>
                        {isApproved && (shop || portfolio) ? '✓' : '3'}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-construction-secondary text-xs sm:text-sm">Create Shop or Portfolio</h4>
                        <p className="text-xs sm:text-sm text-construction-neutral">Set up your business presence to showcase your work and attract clients</p>
                      </div>
                      <div className="self-end sm:self-auto">
                        {isApproved && !shop && !portfolio && <Button onClick={handleShopPortfolioSetup} size="sm" className="text-xs sm:text-sm">Create Now</Button>}
                        {isApproved && (shop || portfolio) && <Badge variant="default" className="text-xs sm:text-sm px-2 py-1">Completed</Badge>}
                        {!isApproved && <Badge variant="outline" className="text-xs sm:text-sm px-2 py-1">Pending Approval</Badge>}
                      </div>
                    </div>

                    <div className={`flex flex-col sm:flex-row items-start sm:items-center gap-3 p-3 border rounded-lg ${isApproved && (shop || portfolio) ? 'bg-green-50 border-green-200' : 'opacity-70'}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${isApproved && (shop || portfolio) ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-600'}`}>
                        {isApproved && (shop || portfolio) ? '✓' : '4'}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-construction-secondary text-xs sm:text-sm">Start Receiving Projects</h4>
                        <p className="text-xs sm:text-sm text-construction-neutral">Once fully set up, you'll start receiving project leads based on your expertise</p>
                      </div>
                      <div className="self-end sm:self-auto">
                        {isApproved && (shop || portfolio) ? <Badge variant="default" className="text-xs sm:text-sm px-2 py-1">Active</Badge> : <Badge variant="outline" className="text-xs sm:text-sm px-2 py-1">Pending Setup</Badge>}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      <Footer />
      
      {/* Registration Guide Modal */}
      <RegistrationGuideModal 
        open={showGuideModal}
        onOpenChange={setShowGuideModal}
        onStartRegistration={handleBusinessRegistration}
      />

      {/* Documents Modal */}
      <Dialog open={showDocumentsModal} onOpenChange={setShowDocumentsModal}>
        <DialogContent className="max-w-[95%] sm:max-w-2xl w-full overflow-y-auto p-3 sm:p-4">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-sm sm:text-base">
              <FileText className="w-4 h-4 text-construction-primary" />
              Business Documents
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-3 sm:space-y-4">
            {businessRegistration ? (
              <>
                {businessRegistration.business_license_url && (
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-start sm:items-center gap-3">
                      <FileText className="w-5 h-5 text-construction-primary" />
                      <div>
                        <h4 className="font-medium text-sm">Business License</h4>
                        <p className="text-xs sm:text-sm text-construction-neutral">Business license document</p>
                      </div>
                    </div>
                    <div className="mt-3 sm:mt-0">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openDocument(businessRegistration.business_license_url)}
                        className="flex items-center gap-2 text-xs sm:text-sm"
                      >
                        <ExternalLink className="w-4 h-4" />
                        View
                      </Button>
                    </div>
                  </div>
                )}

                {businessRegistration.government_id_url && (
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-start sm:items-center gap-3">
                      <FileText className="w-5 h-5 text-construction-primary" />
                      <div>
                        <h4 className="font-medium text-sm">Government ID</h4>
                        <p className="text-xs sm:text-sm text-construction-neutral">Government identification document</p>
                      </div>
                    </div>
                    <div className="mt-3 sm:mt-0">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openDocument(businessRegistration.government_id_url)}
                        className="flex items-center gap-2 text-xs sm:text-sm"
                      >
                        <ExternalLink className="w-4 h-4" />
                        View
                      </Button>
                    </div>
                  </div>
                )}

                {businessRegistration.business_certificate_url && (
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-start sm:items-center gap-3">
                      <FileText className="w-5 h-5 text-construction-primary" />
                      <div>
                        <h4 className="font-medium text-sm">Business Certificate</h4>
                        <p className="text-xs sm:text-sm text-construction-neutral">Business registration certificate</p>
                      </div>
                    </div>
                    <div className="mt-3 sm:mt-0">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openDocument(businessRegistration.business_certificate_url)}
                        className="flex items-center gap-2 text-xs sm:text-sm"
                      >
                        <ExternalLink className="w-4 h-4" />
                        View
                      </Button>
                    </div>
                  </div>
                )}

                {businessRegistration.insurance_certificate_url && (
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-start sm:items-center gap-3">
                      <FileText className="w-5 h-5 text-construction-primary" />
                      <div>
                        <h4 className="font-medium text-sm">Insurance Certificate</h4>
                        <p className="text-xs sm:text-sm text-construction-neutral">Insurance certificate document</p>
                      </div>
                    </div>
                    <div className="mt-3 sm:mt-0">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openDocument(businessRegistration.insurance_certificate_url)}
                        className="flex items-center gap-2 text-xs sm:text-sm"
                      >
                        <ExternalLink className="w-4 h-4" />
                        View
                      </Button>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-6">
                <FileText className="w-10 h-10 text-construction-neutral mx-auto mb-3 opacity-50" />
                <p className="text-xs sm:text-sm text-construction-neutral">No documents available. Complete your business registration to upload documents.</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProviderDashboard;
