import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Phone, Mail, MessageCircle, MapPin, Calendar, User, Filter } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useMatchingRequirements, Requirement } from '@/hooks/useRequirements';
import { supabase } from '@/integrations/supabase/client';
import { showSuccessToast, showErrorToast, showLoadingToast } from '@/lib/loading-toast';
import { LeadPaywall } from '@/components/LeadPaywall';
import { useLeadCredits } from '@/hooks/useLeadCredits';
import { RequirementSkeleton } from '@/components/RequirementSkeleton';

const serviceTypes = [
  'All Services',
  'Contractor',
  'Architect',
  'Material Supplier',
  'Vendors',
  'Interior Designer'
];

const ProviderRequirements = () => {
  const navigate = useNavigate();
  const { requirements, loading, error } = useMatchingRequirements();
  const { hasAccessedLeads, consumeCredits } = useLeadCredits();
  const [selectedServiceType, setSelectedServiceType] = useState('All Services');
  const [accessMap, setAccessMap] = useState<Map<string, boolean>>(new Map());
  const [checkingAccess, setCheckingAccess] = useState(true);

  // Batch check access for all requirements
  React.useEffect(() => {
    const checkBatchAccess = async () => {
      if (requirements.length === 0) {
        setCheckingAccess(false);
        return;
      }

      if (!hasAccessedLeads) {
        setCheckingAccess(false);
        return;
      }

      try {
        setCheckingAccess(true);
        const requirementIds = requirements.map(req => req.id);
        const accessedSet = await hasAccessedLeads(requirementIds, 'contact', 'requirement');
        
        const newAccessMap = new Map<string, boolean>();
        requirements.forEach(req => {
          newAccessMap.set(req.id, accessedSet.has(req.id));
        });
        setAccessMap(newAccessMap);
      } catch (error) {
        console.error('Error batch checking access:', error);
        showErrorToast({
          title: 'Access Check Failed',
          description: 'Could not verify lead access. Please refresh the page.'
        });
      } finally {
        setCheckingAccess(false);
      }
    };

    checkBatchAccess();
  }, [requirements.length]); // Fixed: use requirements.length instead of full object

  const filteredRequirements = requirements.filter(req => {
    const matchesService = selectedServiceType === 'All Services' || req.service_type === selectedServiceType;
    return matchesService;
  });

  // Handler for unlocking contact with credits (separate from actual contact action)
  const handleUnlockContact = useCallback(async (requirementId: string) => {
    const success = await consumeCredits(requirementId, 1, 'contact', 'requirement');
    if (success) {
      setAccessMap(prev => new Map(prev).set(requirementId, true));
      showSuccessToast({
        title: 'Contact Unlocked',
        description: 'You can now contact this client anytime.'
      });
    }
    return success;
  }, [consumeCredits]);

  // Handler for initiating contact (no credit consumption, just opens WhatsApp/email/phone)
  const handleContact = useCallback((requirement: Requirement) => {
    console.log('handleContact called with:', requirement);
    console.log('Contact info:', requirement.contact_info);
    console.log('Contact preference:', requirement.contact_preference);
    
    const contactInfo = requirement.contact_info;
    const preference = requirement.contact_preference?.toLowerCase();
    
    if (!contactInfo) {
      showErrorToast({ 
        title: 'Contact Info Unavailable', 
        description: 'Contact information is not available for this requirement. Please contact admin for assistance.' 
      });
      return;
    }

    try {
      if (preference === 'whatsapp') {
        // Remove any non-numeric characters and ensure it starts with country code
        const cleanNumber = contactInfo.replace(/\D/g, '');
        const whatsappNumber = cleanNumber.startsWith('91') ? cleanNumber : `91${cleanNumber}`;
        const whatsappUrl = `https://wa.me/${whatsappNumber}`;
        console.log('Opening WhatsApp URL:', whatsappUrl);
        
        // Use a more robust method to open WhatsApp
        const link = document.createElement('a');
        link.href = whatsappUrl;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
      } else if (preference === 'email') {
        const emailUrl = `mailto:${contactInfo}`;
        console.log('Opening email URL:', emailUrl);
        
        // Use a more robust method to open email
        const link = document.createElement('a');
        link.href = emailUrl;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
      } else if (preference === 'phone') {
        const phoneUrl = `tel:${contactInfo}`;
        console.log('Opening phone URL:', phoneUrl);
        
        // Use a more robust method to open phone dialer
        const link = document.createElement('a');
        link.href = phoneUrl;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
      
      showSuccessToast({ 
        title: 'Contact Initiated', 
        description: `Opening ${requirement.contact_preference} to contact the client.` 
      });
    } catch (error) {
      console.error('Contact error:', error);
      showErrorToast({ 
        title: 'Contact Failed', 
        description: 'Unable to initiate contact. Please try again.' 
      });
    }
  }, []);

  const handleViewAttachments = useCallback(async (requirement: Requirement) => {
    console.log('handleViewAttachments called with:', requirement);
    console.log('Attachments:', requirement.attachments);
    
    if (!requirement.attachments || requirement.attachments.length === 0) {
      showErrorToast({ 
        title: 'No Attachments', 
        description: 'This requirement has no attachments to view.' 
      });
      return;
    }

    try {
      // For each attachment, create a signed URL and open it
      for (const attachment of requirement.attachments) {
        console.log('Processing attachment:', attachment);
        
        const { data, error } = await supabase.storage
          .from('requirement-attachments')
          .createSignedUrl(attachment.path, 3600); // 1 hour expiry

        if (error) {
          console.error('Error creating signed URL:', error);
          showErrorToast({ 
            title: 'Error', 
            description: `Could not open ${attachment.name}` 
          });
          continue;
        }

        if (data?.signedUrl) {
          // Construct full URL if it's a relative path
          let fullUrl = data.signedUrl;
          if (data.signedUrl.startsWith('/')) {
            fullUrl = `https://xfeubykrdtzjhblvzote.supabase.co/storage/v1${data.signedUrl}`;
          }
          console.log('Opening signed URL:', fullUrl);
          
          // Use a more robust method to open the file
          const link = document.createElement('a');
          link.href = fullUrl;
          link.target = '_blank';
          link.rel = 'noopener noreferrer';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
      }
      
      showSuccessToast({ 
        title: 'Attachments Opened', 
        description: `Opened ${requirement.attachments.length} attachment(s) in new tabs.` 
      });
    } catch (error) {
      console.error('Error viewing attachments:', error);
      showErrorToast({ 
        title: 'Error', 
        description: 'Failed to open attachments. Please try again.' 
      });
    }
  }, []);

  const getContactPreferenceIcon = (preference: string) => {
    switch (preference.toLowerCase()) {
      case 'email':
        return <Mail className="w-4 h-4" />;
      case 'phone':
        return <Phone className="w-4 h-4" />;
      case 'whatsapp':
        return <MessageCircle className="w-4 h-4" />;
      default:
        return <Phone className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'closed':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'completed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (loading || checkingAccess) {
    return (
      <div className="min-h-screen bg-background pb-24 sm:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-6xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-foreground mb-2">Client Requirements</h1>
              <p className="text-muted-foreground">
                {loading ? 'Loading requirements...' : 'Checking access...'}
              </p>
            </div>
            <div className="grid gap-6">
              <RequirementSkeleton />
              <RequirementSkeleton />
              <RequirementSkeleton />
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background pb-24 sm:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-destructive">Unable to Load Requirements</CardTitle>
              <CardDescription className="mt-2">{error}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  To view client requirements, please ensure:
                </p>
                <ul className="text-sm text-muted-foreground space-y-1 ml-4">
                  <li>• Your business registration is completed and approved</li>
                  <li>• Your provider profile is set up</li>
                  <li>• You have specified your service cities</li>
                </ul>
                <div className="flex flex-col md:flex-row gap-3 pt-4">
  <Button onClick={() => navigate('/business-registration')}>
    Complete Registration
  </Button>
  <Button variant="outline" onClick={() => navigate('/provider-dashboard')}>
    Go to Dashboard
  </Button>
</div>
              </div>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24 sm:pb-8">
      <Header />
      
      <div className="container mx-auto px-3 sm:px-4 py-6 sm:py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-3 sm:mb-2">Client Requirements</h1>
            <p className="text-muted-foreground text-sm sm:text-base">
              Browse and respond to client requirements in your service area
            </p>
          </div>

          {/* Filters */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-1.5 sm:gap-2 text-base sm:text-lg">
                <Filter className="w-4 h-4 sm:w-5 sm:h-5" />
                Filter Requirements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <label className="text-sm font-medium">Service Type</label>
                <Select value={selectedServiceType} onValueChange={setSelectedServiceType}>
                  <SelectTrigger className="text-sm sm:text-base">
                    <SelectValue placeholder="Select service type" />
                  </SelectTrigger>
                  <SelectContent>
                    {serviceTypes.map((type) => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Requirements List */}
          {filteredRequirements.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <div className="text-muted-foreground">
                  <MessageCircle className="w-10 h-10 sm:w-12 sm:h-12 mx-auto mb-4 opacity-50" />
                  <h3 className="text-base sm:text-lg font-medium mb-2">No Requirements Found</h3>
                  <p className="text-sm sm:text-base">No active requirements match your filters at the moment.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 sm:gap-5 md:gap-6">
              {filteredRequirements.map((requirement) => (
                <Card key={requirement.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="text-lg sm:text-xl mb-2 line-clamp-2 sm:line-clamp-none">{requirement.title}</CardTitle>
                        <div className="flex flex-wrap items-center gap-2 sm:gap-3 md:gap-4 text-xs sm:text-sm text-muted-foreground mb-2">
                          <div className="flex items-center gap-1">
                            <User className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                            Client
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                            {requirement.city}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                            {new Date(requirement.created_at).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-1.5 sm:gap-2 mb-3">
                          <Badge variant="secondary" className="text-xs sm:text-sm">{requirement.service_type}</Badge>
                          <Badge className={`${getStatusColor(requirement.status)} text-xs sm:text-sm`}>
                            {requirement.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 sm:space-y-4">
                      <div>
                        <h4 className="text-sm sm:text-base font-medium mb-2">Description</h4>
                        <p className="text-sm sm:text-base text-muted-foreground line-clamp-3 sm:line-clamp-none">{requirement.description}</p>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                        <div>
                          <h4 className="text-xs sm:text-sm font-medium mb-1">Timeline</h4>
                          <p className="text-xs sm:text-sm text-muted-foreground">{requirement.timeline}</p>
                        </div>
                        <div>
                          <h4 className="text-xs sm:text-sm font-medium mb-1">Preferred Contact</h4>
                          <div className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm text-muted-foreground">
                            {getContactPreferenceIcon(requirement.contact_preference)}
                            {requirement.contact_preference}
                          </div>
                        </div>
                      </div>

                      {/* Attachments - FREE to view, outside paywall */}
                      {requirement.attachments && requirement.attachments.length > 0 && (
                        <div>
                          <h4 className="text-sm sm:text-base font-medium mb-2">Attachments ({requirement.attachments.length})</h4>
                          <Button
                            variant="outline"
                            onClick={() => handleViewAttachments(requirement)}
                            className="w-full text-sm sm:text-base"
                          >
                            <span className="sm:hidden">View</span>
                            <span className="hidden sm:inline">View Attachments</span>
                          </Button>
                        </div>
                      )}

                      {/* Contact Info Paywall */}
                      <LeadPaywall 
                        title="Contact Client" 
                        description="Use 1 lead credit to access contact information"
                        requirementId={requirement.id}
                        accessType="contact"
                        hasAccess={accessMap.get(requirement.id) || false}
                        onUnlock={() => handleUnlockContact(requirement.id)}
                      >
                        <div className="space-y-3">
                          {/* Show contact info only when unlocked */}
                          <div className="p-3 sm:p-4 bg-muted/50 rounded-lg">
                            <h4 className="text-sm sm:text-base font-medium mb-2">Contact Information</h4>
                            <div className="flex items-center gap-2 text-xs sm:text-sm">
                              {getContactPreferenceIcon(requirement.contact_preference)}
                              <span className="font-medium break-all">
                                {requirement.contact_info || 'Not provided'}
                              </span>
                            </div>
                          </div>
                          
                          <Button
                            onClick={() => handleContact(requirement)}
                            className="w-full flex items-center justify-center gap-1.5 sm:gap-2 text-sm sm:text-base"
                            disabled={!requirement.contact_info}
                          >
                            {getContactPreferenceIcon(requirement.contact_preference)}
                            <span className="truncate">Contact Client via {requirement.contact_preference}</span>
                          </Button>
                        </div>
                      </LeadPaywall>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default ProviderRequirements;
