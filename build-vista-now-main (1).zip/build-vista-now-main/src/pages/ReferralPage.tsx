import React from 'react';
import { useAuth } from '@/hooks/useAuth';
import { ReferralDashboard } from '@/components/ReferralDashboard';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Navigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';

const ReferralPage = () => {
  const { user, loading } = useAuth();
  const { t } = useLanguage();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-background pb-24 sm:pb-8">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              {t('pages.referral.title')}
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {t('pages.referral.description')}
            </p>
          </div>
          <ReferralDashboard />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ReferralPage;
