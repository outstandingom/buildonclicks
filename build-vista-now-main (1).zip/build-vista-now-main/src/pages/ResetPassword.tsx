import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

const ResetPassword: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchParams] = useSearchParams();

  // Password fields
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Whether page opened via recovery link (supabase tokens)
  const [recoveryFromLink, setRecoveryFromLink] = useState(false);

  // OTP / email UI states
  const [email, setEmail] = useState<string>(user?.email || '');
  const [otp, setOtp] = useState<string>('');
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [otpVerified, setOtpVerified] = useState<boolean>(false);
  const [otpResendTimer, setOtpResendTimer] = useState<number>(0);
  const OTP_RESEND_SECONDS = 60;

  // NOTE: allowPasswordReset only if otpVerified OR recoveryFromLink
  const allowPasswordReset = otpVerified || recoveryFromLink;

  // When component mounts check if recovery tokens are present in URL.
  useEffect(() => {
    const checkResetSession = async () => {
      const accessToken = searchParams.get('access_token');
      const refreshToken = searchParams.get('refresh_token');
      const type = searchParams.get('type');

      // Supabase sometimes returns tokens in the hash instead of query params
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const hashAccessToken = hashParams.get('access_token');
      const hashRefreshToken = hashParams.get('refresh_token');
      const hashType = hashParams.get('type');

      const finalAccessToken = accessToken || hashAccessToken;
      const finalRefreshToken = refreshToken || hashRefreshToken;
      const finalType = type || hashType;

      console.log('Reset params check:', { finalAccessToken: !!finalAccessToken, finalRefreshToken: !!finalRefreshToken, finalType });

      if (finalAccessToken && finalRefreshToken && finalType === 'recovery') {
        try {
          // This sets the session from the recovery link — allow updating password afterwards without OTP
          const { data, error } = await supabase.auth.setSession({
            access_token: finalAccessToken,
            refresh_token: finalRefreshToken
          });

          if (error) {
            console.error('setSession error:', error);
            toast({
              title: "Invalid Reset Link",
              description: "This password reset link is invalid or expired. Request a new one.",
              variant: "destructive"
            });
            navigate('/auth');
            return;
          }

          console.log('Recovery link session set:', data);
          setRecoveryFromLink(true);
        } catch (err) {
          console.error('setSession catch:', err);
          toast({ title: "Error", description: "Error processing reset link.", variant: "destructive" });
        }
      } else {
        // No recovery link: do NOT trust current auth session for password reset.
        console.log('No recovery link present — OTP flow required.');
      }
    };

    checkResetSession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  // Listen for SUPABASE PASSWORD_RECOVERY event (keeps original behavior)
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY') {
        // If Supabase triggers PASSWORD_RECOVERY event (rare), treat as recoveryFromLink
        setRecoveryFromLink(true);
      }
    });
    return () => subscription.unsubscribe();
  }, []);

  // OTP resend countdown
  useEffect(() => {
    if (otpResendTimer > 0) {
      const id = setTimeout(() => setOtpResendTimer(prev => Math.max(0, prev - 1)), 1000);
      return () => clearTimeout(id);
    }
  }, [otpResendTimer]);

  // --- Send OTP using Supabase (recovery) ---
  const sendOtp = async () => {
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      toast({ title: "Invalid email", description: "Please enter a valid email.", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    try {
      // signInWithOtp for recovery - this will NOT create a new user
      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: { shouldCreateUser: false }
      });

      if (error) {
        console.error('signInWithOtp error:', error);
        toast({ title: "Failed to send OTP", description: error.message || "Could not send OTP", variant: "destructive" });
        setIsLoading(false);
        return;
      }

      toast({ title: "OTP Sent", description: "Check your email for the 6-digit verification code." });
      console.log('signInWithOtp succeeded — check Supabase Auth logs if mail not received');
      setOtpSent(true);
      setOtp('');
      setOtpVerified(false);
      setOtpResendTimer(OTP_RESEND_SECONDS);
    } catch (err) {
      console.error('sendOtp catch:', err);
      toast({ title: "Error", description: "Something went wrong sending OTP.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const resendOtp = async () => {
    if (otpResendTimer > 0) {
      toast({ title: "Please wait", description: `You can resend in ${otpResendTimer}s`, variant: "destructive" });
      return;
    }
    await sendOtp();
  };

  // --- Verify OTP using Supabase (type: 'recovery') ---
  const verifyOtp = async () => {
    if (!otp || otp.length !== 6) {
      toast({ title: "Invalid OTP", description: "Enter the 6-digit code.", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email,
        token: otp,
        type: 'recovery'
      });

      if (error) {
        console.error('verifyOtp error:', error);
        toast({ title: "Verification failed", description: error.message || "Invalid code", variant: "destructive" });
        setOtp('');
        setIsLoading(false);
        return;
      }

      console.log('verifyOtp success:', data);
      toast({ title: "OTP verified", description: "You may now reset your password." });
      setOtpVerified(true);
      // note: do NOT auto-set recoveryFromLink here — verifyOtp sets a recovery session server-side in many setups,
      // but to be strict we mark otpVerified and rely on allowPasswordReset = otpVerified || recoveryFromLink.
    } catch (err) {
      console.error('verifyOtp catch:', err);
      toast({ title: "Error", description: "Could not verify OTP. Try again.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  // --- Update password (only allowed after otpVerified OR recoveryFromLink) ---
  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!otpVerified && !recoveryFromLink) {
      toast({ title: "OTP not verified", description: "Please verify the OTP sent to your email before updating password.", variant: "destructive" });
      return;
    }

    if (!newPassword || newPassword.length < 6) {
      toast({ title: "Invalid password", description: "Password must be at least 6 characters.", variant: "destructive" });
      return;
    }

    if (newPassword !== confirmPassword) {
      toast({ title: "Passwords do not match", description: "Please re-enter to confirm.", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) {
        console.error('updateUser error:', error);
        toast({ title: "Update failed", description: error.message || "Could not update password", variant: "destructive" });
        setIsLoading(false);
        return;
      }

      toast({ title: "Password updated", description: "Please sign in with your new password." });
      await supabase.auth.signOut();
      navigate('/auth');
    } catch (err) {
      console.error('handleUpdatePassword catch:', err);
      toast({ title: "Error", description: "Something went wrong. Try again.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  // UI always shows Email -> Send OTP -> Enter OTP -> Verify OTP (status)
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-primary">Reset Your Password</CardTitle>
          <CardDescription>Enter your new password below</CardDescription>
        </CardHeader>

        <CardContent>
          {/* Email */}
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <div className="flex gap-2">
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  // reset OTP UI when email changes
                  setOtpSent(false);
                  setOtpVerified(false);
                  setOtp('');
                }}
                required
              />
              <Button type="button" onClick={sendOtp} disabled={isLoading}>
                {isLoading ? 'Sending...' : 'Send OTP'}
              </Button>
            </div>
            <div className="text-sm text-muted-foreground">{email || ''}</div>
          </div>

          {/* OTP */}
          <div className="space-y-2 mt-4">
            <Label htmlFor="otp">Enter OTP</Label>
            <div className="flex gap-2">
              <Input
                id="otp"
                type="text"
                placeholder="6-digit code"
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/[^0-9]/g, '').slice(0, 6))}
              />
              <Button type="button" onClick={verifyOtp} disabled={isLoading || !otpSent}>
                {isLoading ? 'Verifying...' : 'Verify OTP'}
              </Button>
            </div>

            {otpVerified ? (
              <p className="text-sm text-success">OTP verified ✓</p>
            ) : otpSent ? (
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  {otpResendTimer > 0 ? `Resend in ${otpResendTimer}s` : 'Code sent — check your email'}
                </p>
                <Button variant="link" onClick={resendOtp} disabled={otpResendTimer > 0 || isLoading}>
                  Resend
                </Button>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No code sent yet.</p>
            )}
          </div>

          {/* Password fields shown only after OTP verified or recovery link */}
          {(otpVerified || recoveryFromLink) && (
            <form onSubmit={handleUpdatePassword} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="new-password">New Password</Label>
                <Input
                  id="new-password"
                  type="password"
                  placeholder="Enter a new password (min 6 characters)"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  minLength={6}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirm New Password</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  placeholder="Re-enter new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  minLength={6}
                  required
                />
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? 'Updating Password...' : 'Update Password'}
              </Button>

              <div className="text-center">
                <Button type="button" variant="ghost" onClick={() => navigate('/auth')} className="text-sm">
                  Back to Sign In
                </Button>
              </div>
            </form>
          )}

          {/* hint when password fields hidden */}
          {!(otpVerified || recoveryFromLink) && (
            <div className="text-sm text-muted-foreground mt-4">
              After verifying OTP, the password fields will appear below.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ResetPassword;
