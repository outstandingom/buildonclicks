import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Search, Filter, User, Package, MessageCircle, ShoppingBag, Star } from 'lucide-react';
import { motion } from 'framer-motion';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProfessionalCard from '../components/ProfessionalCard';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useSearch, type SearchResult } from '@/hooks/useSearch';
import { useAuth } from '@/hooks/useAuth';
import { useLeadCredits } from '@/hooks/useLeadCredits';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { CreditBalance } from '@/components/CreditBalance';

const SearchResults = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get('q') || '';
  const { user, loading: authLoading } = useAuth();
  const { credits, loading: creditsLoading, consumeCredits, hasAccessedLead } = useLeadCredits();
  
  const [showFilters, setShowFilters] = useState(false);
  const [filter, setFilter] = useState<'all' | 'professional' | 'product'>('all');
  const [contactDialogOpen, setContactDialogOpen] = useState(false);
  const [selectedProfessionalId, setSelectedProfessionalId] = useState<string | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  
  const { results, loading, search } = useSearch();

  useEffect(() => {
    if (query) {
      search(query);
    }
  }, [query, search]);

  const filteredResults = results.filter(result => {
    if (filter === 'all') return true;
    return result.type === filter;
  });

  const professionalsCount = results.filter(r => r.type === 'professional').length;
  const productsCount = results.filter(r => r.type === 'product').length;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(price);
  };

  // Function to format rating - show "No reviews yet" for 0 rating
  const formatRating = (rating: number, reviewCount: number) => {
    if (rating === 0 || reviewCount === 0) {
      return (
        <div className="flex items-center gap-1 text-gray-500 text-sm">
          <Star className="h-4 w-4 text-gray-300" />
          <span>No reviews yet</span>
        </div>
      );
    }
    
    return (
      <div className="flex items-center gap-1">
        <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
        <span className="font-medium">{rating.toFixed(1)}</span>
        <span className="text-gray-500 text-sm">({reviewCount})</span>
      </div>
    );
  };

  // Handle contact button click for professionals
  const handleContactProfessional = async (professionalId: string) => {
    if (!user) {
      // Redirect to auth page with return URL
      navigate(`/auth?redirect=${encodeURIComponent(window.location.pathname + window.location.search)}`);
      return;
    }

    setSelectedProfessionalId(professionalId);
    
    // Check if user has already accessed this professional
    const hasAccessed = await hasAccessedLead(professionalId, 'contact', 'professional');
    
    if (hasAccessed) {
      // User already has access, proceed with contact
      setContactDialogOpen(true);
    } else {
      // Check if user has enough credits
      if (credits && credits.available_credits > 0) {
        setContactDialogOpen(true);
      } else {
        // Show insufficient credits dialog
        setContactDialogOpen(true);
      }
    }
  };

  // Handle shop now button click for products
  const handleShopNow = async (productId: string) => {
    if (!user) {
      // Redirect to auth page with return URL
      navigate(`/auth?redirect=${encodeURIComponent(window.location.pathname + window.location.search)}`);
      return;
    }

    setSelectedProductId(productId);
    
    // Check if user has already accessed this product
    const hasAccessed = await hasAccessedLead(productId, 'contact', 'requirement');
    
    if (hasAccessed) {
      // User already has access, proceed with shop
      window.open(`/product/${productId}`, '_blank');
    } else {
      // Check if user has enough credits
      if (credits && credits.available_credits > 0) {
        // Consume credit and proceed
        const success = await consumeCredits(productId, 1, 'contact', 'requirement');
        if (success) {
          window.open(`/product/${productId}`, '_blank');
        }
      } else {
        // Show insufficient credits dialog
        setContactDialogOpen(true);
      }
    }
  };

  // Confirm contact and consume credits
  const confirmContact = async () => {
    if (!selectedProfessionalId && !selectedProductId) return;
    
    if (selectedProfessionalId) {
      const success = await consumeCredits(selectedProfessionalId, 1, 'contact', 'professional');
      if (success) {
        // Here you would implement the actual contact logic
        console.log('Contacting professional:', selectedProfessionalId);
        // For now, show success message
        alert('Contact request sent successfully!');
      }
    }
    
    setContactDialogOpen(false);
    setSelectedProfessionalId(null);
    setSelectedProductId(null);
  };

  return (
    <>
      <Helmet>
        <title>Search Results: {query} | BuildConnect</title>
        <meta name="description" content={`Search results for "${query}" - Find professionals and products on BuildConnect`} />
      </Helmet>

      <Header />

      <div className="min-h-screen bg-gray-50 pb-24 sm:pb-8">
        {/* Header Section */}
        <div className="bg-white border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center"
            >
              <div className="flex items-center justify-center space-x-2 mb-4">
                <Search className="h-8 w-8 text-primary" />
                <h1 className="text-4xl font-bold text-gray-900">
                  Search Results
                </h1>
              </div>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Showing results for "{query}"
              </p>
              {!user && !authLoading && (
                <p className="text-sm text-gray-500 max-w-2xl mx-auto mt-2">
                  Sign in to contact professionals, shop products, and access all features.
                </p>
              )}
            </motion.div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* User Credit Balance */}
          {user && (
            <div className="mb-6 flex justify-end">
              <CreditBalance />
            </div>
          )}

          {/* Filters */}
          <div className="mb-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  variant={filter === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilter('all')}
                >
                  All ({results.length})
                </Button>
                <Button
                  variant={filter === 'professional' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilter('professional')}
                  className="space-x-1"
                >
                  <User className="h-4 w-4" />
                  <span>Professionals ({professionalsCount})</span>
                </Button>
                <Button
                  variant={filter === 'product' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilter('product')}
                  className="space-x-1"
                >
                  <Package className="h-4 w-4" />
                  <span>Products ({productsCount})</span>
                </Button>
              </div>

              <div className="text-sm text-gray-600">
                Found {filteredResults.length} results
              </div>
            </div>
          </div>

          {/* Results */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <Card>
                    <CardContent className="p-6">
                      <div className="h-20 w-20 bg-gray-200 rounded-full mx-auto mb-4"></div>
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded mb-4"></div>
                      <div className="flex space-x-2">
                        <div className="h-8 bg-gray-200 rounded flex-1"></div>
                        <div className="h-8 bg-gray-200 rounded flex-1"></div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          ) : filteredResults.length > 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              className="space-y-6"
            >
              {/* Professionals */}
              {filter === 'all' && professionalsCount > 0 && (
                <div>
                  <h2 className="text-xl font-semibold mb-4">Professionals</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {results
                      .filter(result => result.type === 'professional')
                      .map((result, index) => {
                        // Use actual review count from your data if available
                        const reviewCount = 0; // Replace with actual data if available
                        
                        return (
                          <motion.div
                            key={result.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.6, delay: index * 0.1 }}
                          >
                            <Card className="group hover:shadow-lg transition-all duration-200 h-full">
                              <CardContent className="p-6 flex flex-col h-full">
                                {/* Professional Header */}
                                <div className="flex items-center gap-4 mb-4">
                                  {result.image && (
                                    <div className="w-16 h-16 rounded-full bg-gray-100 overflow-hidden flex-shrink-0">
                                      <img
                                        src={result.image}
                                        alt={result.title}
                                        className="w-full h-full object-cover"
                                      />
                                    </div>
                                  )}
                                  <div className="flex-1 min-w-0">
                                    <h3 className="font-semibold text-lg text-gray-900 truncate">
                                      {result.title}
                                    </h3>
                                    {result.businessName && (
                                      <p className="text-sm text-gray-600 truncate">
                                        {result.businessName}
                                      </p>
                                    )}
                                    {formatRating(result.rating || 0, reviewCount)}
                                  </div>
                                </div>

                                {/* Professional Details */}
                                <div className="space-y-3 mb-4">
                                  {result.location && (
                                    <p className="text-sm text-gray-600">
                                      📍 {result.location}
                                    </p>
                                  )}
                                  {result.description && (
                                    <p className="text-sm text-gray-600 line-clamp-2">
                                      {result.description}
                                    </p>
                                  )}
                                </div>

                                {/* Category Badge */}
                                {result.category && (
                                  <div className="mb-4">
                                    <Badge variant="secondary">
                                      {result.category}
                                    </Badge>
                                  </div>
                                )}

                                {/* Action Buttons */}
                                <div className="flex gap-2 mt-auto pt-4">
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    className="flex-1 flex items-center gap-2"
                                    onClick={() => handleContactProfessional(result.id)}
                                  >
                                    <MessageCircle className="h-4 w-4" />
                                    Contact
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    className="flex-1 flex items-center gap-2"
                                    onClick={() => window.open(`/professional/${result.id}`, '_blank')}
                                  >
                                    View Profile
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          </motion.div>
                        );
                      })}
                  </div>
                </div>
              )}

              {/* Products */}
              {(filter === 'all' || filter === 'product') && (
                <div>
                  {filter === 'all' && <h2 className="text-xl font-semibold mb-4">Products</h2>}
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {results
                      .filter(result => result.type === 'product')
                      .map((result, index) => (
                        <motion.div
                          key={result.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.6, delay: index * 0.1 }}
                        >
                          <Card className="group hover:shadow-lg hover:scale-[1.02] transition-all duration-200">
                            <CardContent className="p-6">
                              {result.image && (
                                <div className="aspect-square bg-gray-100 rounded-lg mb-4 overflow-hidden">
                                  <img
                                    src={result.image}
                                    alt={result.title}
                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                                  />
                                </div>
                              )}
                              <div className="space-y-3">
                                <div>
                                  <h3 className="font-semibold text-lg text-gray-900 group-hover:text-primary transition-colors">
                                    {result.title}
                                  </h3>
                                  <p className="text-sm text-gray-600 line-clamp-2">
                                    {result.description}
                                  </p>
                                </div>
                                
                                <div className="flex items-center justify-between">
                                  <Badge variant="secondary">
                                    {result.category}
                                  </Badge>
                                  {result.price && (
                                    <span className="text-lg font-bold text-primary">
                                      {formatPrice(result.price)}
                                    </span>
                                  )}
                                </div>
                                
                                {result.businessName && (
                                  <p className="text-xs text-gray-500">
                                    by {result.businessName}
                                  </p>
                                )}
                                
                                {/* Action Buttons */}
                                <div className="flex gap-2 pt-2">
                                  <Button 
                                    size="sm" 
                                    className="flex-1 flex items-center gap-2"
                                    onClick={() => handleShopNow(result.id)}
                                  >
                                    <ShoppingBag className="h-4 w-4" />
                                    Shop Now
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    variant="outline" 
                                    className="flex-1"
                                    onClick={() => window.open(`/product/${result.id}`, '_blank')}
                                  >
                                    View Details
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                  </div>
                </div>
              )}

              {/* Professionals only view */}
              {filter === 'professional' && (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredResults.map((result, index) => {
                    // Use actual review count from your data if available
                    const reviewCount = 0; // Replace with actual data if available
                    
                    return (
                      <motion.div
                        key={result.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6, delay: index * 0.1 }}
                      >
                        <Card className="group hover:shadow-lg transition-all duration-200 h-full">
                          <CardContent className="p-6 flex flex-col h-full">
                            {/* Professional Header */}
                            <div className="flex items-center gap-4 mb-4">
                              {result.image && (
                                <div className="w-16 h-16 rounded-full bg-gray-100 overflow-hidden flex-shrink-0">
                                  <img
                                    src={result.image}
                                    alt={result.title}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                              )}
                              <div className="flex-1 min-w-0">
                                <h3 className="font-semibold text-lg text-gray-900 truncate">
                                  {result.title}
                                </h3>
                                {result.businessName && (
                                  <p className="text-sm text-gray-600 truncate">
                                    {result.businessName}
                                  </p>
                                )}
                                {formatRating(result.rating || 0, reviewCount)}
                              </div>
                            </div>

                            {/* Professional Details */}
                            <div className="space-y-3 mb-4">
                              {result.location && (
                                <p className="text-sm text-gray-600">
                                  📍 {result.location}
                                </p>
                              )}
                              {result.description && (
                                <p className="text-sm text-gray-600 line-clamp-2">
                                  {result.description}
                                </p>
                              )}
                            </div>

                            {/* Category Badge */}
                            {result.category && (
                              <div className="mb-4">
                                <Badge variant="secondary">
                                  {result.category}
                                </Badge>
                              </div>
                            )}

                            {/* Action Buttons */}
                            <div className="flex gap-2 mt-auto pt-4">
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="flex-1 flex items-center gap-2"
                                onClick={() => handleContactProfessional(result.id)}
                              >
                                <MessageCircle className="h-4 w-4" />
                                Contact
                              </Button>
                              <Button 
                                size="sm" 
                                className="flex-1 flex items-center gap-2"
                                onClick={() => window.open(`/professional/${result.id}`, '_blank')}
                              >
                                View Profile
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </motion.div>
          ) : (
            <div className="text-center py-12">
              <Search className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 text-lg mb-2">No results found for "{query}"</p>
              <p className="text-gray-500 text-sm">
                Try adjusting your search terms or browse our professionals and products.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Contact Dialog */}
      <Dialog open={contactDialogOpen} onOpenChange={setContactDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedProductId ? (
                <>
                  <ShoppingBag className="h-5 w-5 text-primary" />
                  Shop Product
                </>
              ) : (
                <>
                  <MessageCircle className="h-5 w-5 text-primary" />
                  Contact Professional
                </>
              )}
            </DialogTitle>
            <DialogDescription>
              {credits && credits.available_credits > 0 ? (
                <div>
                  <p className="mb-2">
                    This will use 1 of your available {credits.available_credits} lead credits for{' '}
                    {selectedProductId ? 'product access' : 'contact information'}.
                  </p>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mt-2">
                    <p className="text-sm text-blue-700 font-medium">
                      Credit will be deducted for:
                    </p>
                    <ul className="text-sm text-blue-600 mt-1 space-y-1">
                      <li>• Access to {selectedProductId ? 'product details and seller contact' : 'professional contact information'}</li>
                      <li>• Direct communication with the {selectedProductId ? 'seller' : 'professional'}</li>
                      <li>• Consultation and quotation requests</li>
                    </ul>
                  </div>
                </div>
              ) : (
                <div>
                  <p className="mb-2 text-red-600 font-medium">
                    You don't have enough credits to access this {selectedProductId ? 'product' : 'professional'}.
                  </p>
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mt-2">
                    <p className="text-sm text-yellow-700">
                      Please purchase more credits to continue. New users get 15 free credits to start!
                    </p>
                  </div>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setContactDialogOpen(false);
                setSelectedProfessionalId(null);
                setSelectedProductId(null);
              }}
              className="w-full sm:w-auto"
            >
              Cancel
            </Button>
            
            {credits && credits.available_credits > 0 ? (
              <Button
                variant="orange"
                onClick={confirmContact}
                className="w-full sm:w-auto"
              >
                Use 1 Credit to {selectedProductId ? 'Shop Now' : 'Contact'}
              </Button>
            ) : (
              <Button
                variant="orange"
                onClick={() => navigate('/subscription')}
                className="w-full sm:w-auto"
              >
                Buy Credits
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Footer />
    </>
  );
};

export default SearchResults;
