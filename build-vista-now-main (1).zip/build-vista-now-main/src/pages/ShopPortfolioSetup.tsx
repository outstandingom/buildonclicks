
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Store, User, ArrowLeft, CheckCircle } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ShopCreationForm from '@/components/ShopCreationForm';
import PortfolioCreationForm from '@/components/PortfolioCreationForm';
import { useAuth } from '@/hooks/useAuth';
import { useProviderDashboard } from '@/hooks/useProviderDashboard';
import { useShopPortfolio } from '@/hooks/useShopPortfolio';

type SetupType = 'shop' | 'portfolio' | null;

const ShopPortfolioSetup: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { businessRegistration, hasRegistration } = useProviderDashboard(user?.id);
  const { shop, portfolio, createShop, createPortfolio, isSubmitting } = useShopPortfolio(businessRegistration?.id);
  const [setupType, setSetupType] = useState<SetupType>(null);

  // Check if user has approved business registration
  const isApproved = businessRegistration?.status === 'approved';
  const isVendor = businessRegistration?.business_type_id; // This would need to be checked against actual business type

  if (!user || !hasRegistration || !isApproved) {
    return (
      <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
        <Header />
        <div className="flex-1 bg-gradient-section flex items-center justify-center">
          <Card className="max-w-md mx-auto">
            <CardHeader>
              <CardTitle className="text-center">Access Restricted</CardTitle>
              <CardDescription className="text-center">
                You need an approved business registration to create a shop or portfolio.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                onClick={() => navigate('/provider-dashboard')}
                className="w-full"
              >
                Go to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  // If shop or portfolio already exists, show success message
  if (shop || portfolio) {
    return (
      <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
        <Header />
        <div className="flex-1 bg-gradient-section py-8">
          <div className="container mx-auto px-4">
            <Card className="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                  {shop ? 'Shop Created Successfully!' : 'Portfolio Created Successfully!'}
                </CardTitle>
                <CardDescription className="text-center">
                  Your {shop ? 'shop' : 'portfolio'} is now live and ready to attract customers.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <Badge variant="default" className="mb-4">
                    {shop ? shop.shop_name : portfolio?.title}
                  </Badge>
                  <p className="text-sm text-muted-foreground mb-4">
                    {shop ? shop.description : portfolio?.description}
                  </p>
                </div>
                <div className="flex gap-4 justify-center">
                  <Button 
                    onClick={() => navigate('/provider-dashboard')}
                    variant="outline"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Dashboard
                  </Button>
                  <Button 
                    onClick={() => {
                      if (shop) {
                        navigate(`/vendor-shop/${shop.id}`);
                      } else if (portfolio) {
                        navigate(`/portfolio/${portfolio.id}`);
                      }
                    }}
                    className="bg-construction-primary hover:bg-construction-primary/90"
                  >
                    View {shop ? 'Shop' : 'Portfolio'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
      <Header />
      <div className="flex-1 bg-gradient-section py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            {/* Back Button */}
            <Button 
              onClick={() => navigate('/provider-dashboard')}
              variant="outline"
              className="mb-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>

            {!setupType ? (
              // Setup Type Selection
              <div className="space-y-8">
                <div className="text-center">
                  <h1 className="text-3xl font-bold text-construction-secondary mb-4">
                    Create Your Business Presence
                  </h1>
                  <p className="text-construction-neutral text-lg max-w-2xl mx-auto">
                    Choose how you want to showcase your business to potential clients.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                  {/* Shop Option */}
                  <Card className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-construction-primary">
                    <CardHeader className="text-center">
                      <div className="w-16 h-16 bg-construction-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Store className="w-8 h-8 text-construction-primary" />
                      </div>
                      <CardTitle>Create a Shop</CardTitle>
                      <CardDescription>
                        Perfect for vendors who sell products or materials. Set up an online storefront with product categories, delivery options, and working hours.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-sm text-construction-neutral mb-6">
                        <li>• Product catalog management</li>
                        <li>• Order management system</li>
                        <li>• Delivery options setup</li>
                        <li>• Customer reviews & ratings</li>
                        <li>• Inventory tracking</li>
                      </ul>
                      <Button 
                        onClick={() => setSetupType('shop')}
                        className="w-full bg-construction-primary hover:bg-construction-primary/90"
                      >
                        Create Shop
                      </Button>
                    </CardContent>
                  </Card>

                  {/* Portfolio Option */}
                  <Card className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-construction-primary">
                    <CardHeader className="text-center">
                      <div className="w-16 h-16 bg-construction-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <User className="w-8 h-8 text-construction-primary" />
                      </div>
                      <CardTitle>Create a Portfolio</CardTitle>
                      <CardDescription>
                        Ideal for service providers like contractors, architects, designers. Showcase your work, skills, and experience to attract clients.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-sm text-construction-neutral mb-6">
                        <li>• Project showcase gallery</li>
                        <li>• Skills & certifications display</li>
                        <li>• Client testimonials</li>
                        <li>• Service descriptions</li>
                        <li>• Experience timeline</li>
                      </ul>
                      <Button 
                        onClick={() => setSetupType('portfolio')}
                        className="w-full bg-construction-primary hover:bg-construction-primary/90"
                      >
                        Create Portfolio
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            ) : (
              // Show selected form
              <div className="space-y-6">
                <Button 
                  onClick={() => setSetupType(null)}
                  variant="outline"
                  className="mb-4"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Options
                </Button>

                {setupType === 'shop' ? (
                  <ShopCreationForm 
                    onSubmit={createShop}
                    isSubmitting={isSubmitting}
                  />
                ) : (
                  <PortfolioCreationForm 
                    onSubmit={createPortfolio}
                    isSubmitting={isSubmitting}
                  />
                )}
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ShopPortfolioSetup;
