import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Heart, Bookmark, Camera, Loader2, Home, Users, MessageCircle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ShareMenu } from "@/components/ShareMenu";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { useNavigate } from "react-router-dom";

interface SocialPost {
  id: string;
  content: string;
  media_url?: string | null;
  media_type?: string | null;
  likes_count: number;
  comments_count: number;
  created_at: string;
  user_id: string;
  provider_profile_id?: string | null;
  updated_at: string;
  profiles?: {
    full_name?: string;
    profile_image_url?: string;
  } | null;
  provider_profiles?: {
    display_name?: string;
    role: string;
  } | null;
  business_registrations?: {
    business_name?: string;
    logo_url?: string;
  } | null;
  user_liked?: boolean;
  user_saved?: boolean;
}

const POSTS_PER_PAGE = 10;
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

const SocialFeed = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [posts, setPosts] = useState<SocialPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(0);
  const [newPostContent, setNewPostContent] = useState("");
  const [selectedMedia, setSelectedMedia] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async (pageNum: number = 0, append: boolean = false) => {
    try {
      if (append) {
        setLoadingMore(true);
      } else {
        setLoading(true);
      }

      const from = pageNum * POSTS_PER_PAGE;
      const to = from + POSTS_PER_PAGE - 1;

      const { data: postsData, error: postsError } = await supabase
        .from('social_posts')
        .select('*')
        .order('created_at', { ascending: false })
        .range(from, to);

      if (postsError) throw postsError;

      setHasMore(postsData?.length === POSTS_PER_PAGE);

      if (postsData && postsData.length > 0) {
        const postIds = postsData.map(p => p.id);
        const userIds = [...new Set(postsData.map(p => p.user_id))];

        const { data: profilesData } = await supabase
          .from('profiles')
          .select('id, full_name, profile_image_url')
          .in('id', userIds);

        const { data: providerProfilesData } = await supabase
          .from('provider_profiles')
          .select('user_id, display_name, role')
          .in('user_id', userIds);

        const { data: businessRegistrationsData } = await supabase
          .from('business_registrations')
          .select('user_id, business_name, id')
          .in('user_id', userIds)
          .eq('status', 'approved');

        const businessRegIds = businessRegistrationsData?.map(b => b.id) || [];
        let shopsData = null;
        let portfoliosData = null;

        if (businessRegIds.length > 0) {
          const { data: shops } = await supabase
            .from('provider_shops')
            .select('business_registration_id, logo_url')
            .in('business_registration_id', businessRegIds);
          shopsData = shops;

          const { data: portfolios } = await supabase
            .from('provider_portfolios')
            .select('business_registration_id, logo_url')
            .in('business_registration_id', businessRegIds);
          portfoliosData = portfolios;
        }

        const profilesMap = new Map(profilesData?.map(p => [p.id, p]));
        const providerProfilesMap = new Map(providerProfilesData?.map(p => [p.user_id, p]));
        const shopsMap = new Map(shopsData?.map(s => [s.business_registration_id, s.logo_url]));
        const portfoliosMap = new Map(portfoliosData?.map(p => [p.business_registration_id, p.logo_url]));
        
        const businessRegistrationsMap = new Map(businessRegistrationsData?.map(b => [
          b.user_id, 
          { 
            business_name: b.business_name, 
            logo_url: shopsMap.get(b.id) || portfoliosMap.get(b.id) || null,
            id: b.id
          }
        ]));
        
        let likesMap = new Map();
        let savesMap = new Map();

        if (user) {
          const { data: likesData } = await supabase
            .from('social_post_likes')
            .select('post_id')
            .eq('user_id', user.id)
            .in('post_id', postIds);
          
          likesData?.forEach(like => likesMap.set(like.post_id, true));

          const { data: savesData } = await supabase
            .from('saved_social_posts')
            .select('post_id')
            .eq('user_id', user.id)
            .in('post_id', postIds);
          
          savesData?.forEach(save => savesMap.set(save.post_id, true));
        }

        const postsWithStatus = postsData.map(post => ({
          ...post,
          likes_count: Math.max(0, post.likes_count || 0),  // Ensure likes_count is never negative
          comments_count: Math.max(0, post.comments_count || 0),  // Ensure comments_count is never negative
          profiles: profilesMap.get(post.user_id) || null,
          provider_profiles: providerProfilesMap.get(post.user_id) || null,
          business_registrations: businessRegistrationsMap.get(post.user_id) || null,
          user_liked: likesMap.get(post.id) || false,
          user_saved: savesMap.get(post.id) || false
        }));

        if (append) {
          setPosts(prev => [...prev, ...postsWithStatus as SocialPost[]]);
        } else {
          setPosts(postsWithStatus as SocialPost[]);
        }
      } else if (!append) {
        setPosts([]);
      }
    } catch (error) {
      console.error('Error fetching posts:', error);
      toast.error('Failed to load posts');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  const loadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchPosts(nextPage, true);
  };

  const handleMediaSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > MAX_FILE_SIZE) {
        toast.error('File size must be less than 10MB', { duration: 3000 });
        e.target.value = '';
        return;
      }

      if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
        toast.error('Only images and videos are allowed', { duration: 3000 });
        e.target.value = '';
        return;
      }

      setSelectedMedia(file);
      const reader = new FileReader();
      reader.onload = (e) => setMediaPreview(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const uploadMedia = async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user?.id}/${Date.now()}.${fileExt}`;
      const filePath = fileName;

      const { error: uploadError } = await supabase.storage
        .from('social-media')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('social-media')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('Error uploading media:', error);
      toast.error('Failed to upload media', { duration: 3000 });
      return null;
    }
  };

  const createPost = async () => {
    if (!user) {
      toast.error('Please sign in to create a post', {
        duration: 3000,
        action: {
          label: 'Sign In',
          onClick: () => navigate('/auth')
        }
      });
      return;
    }

    if (!newPostContent.trim() && !selectedMedia) {
      toast.error('Please add content or media to your post', { duration: 3000 });
      return;
    }

    setUploading(true);
    try {
      let mediaUrl = null;
      let mediaType = null;

      if (selectedMedia) {
        mediaUrl = await uploadMedia(selectedMedia);
        mediaType = selectedMedia.type.startsWith('video/') ? 'video' : 'image';
      }

      const { error } = await supabase
        .from('social_posts')
        .insert({
          user_id: user.id,
          content: newPostContent.trim(),
          media_url: mediaUrl,
          media_type: mediaType
        });

      if (error) throw error;

      toast.success('Post created successfully!', { duration: 3000 });
      setNewPostContent('');
      setSelectedMedia(null);
      setMediaPreview(null);
      setIsCreateDialogOpen(false);
      setPage(0);
      fetchPosts(0, false);
    } catch (error) {
      console.error('Error creating post:', error);
      toast.error('Failed to create post', { duration: 3000 });
    } finally {
      setUploading(false);
    }
  };

  const handleLike = async (postId: string, isLiked: boolean) => {
    if (!user) {
      toast.error('Please sign in to like posts', {
        duration: 3000,
        action: {
          label: 'Sign In',
          onClick: () => navigate('/auth')
        }
      });
      return;
    }

    try {
      if (isLiked) {
        const { error } = await supabase
          .from('social_post_likes')
          .delete()
          .eq('post_id', postId)
          .eq('user_id', user.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('social_post_likes')
          .insert({
            post_id: postId,
            user_id: user.id
          });

        if (error) throw error;
      }

      setPosts(posts.map(post => 
        post.id === postId
          ? {
              ...post,
              likes_count: isLiked 
                ? Math.max(0, post.likes_count - 1)  // Ensure count never goes below 0
                : post.likes_count + 1,
              user_liked: !isLiked
            }
          : post
      ));
    } catch (error) {
      console.error('Error toggling like:', error);
      toast.error('Failed to update like', { duration: 3000 });
    }
  };

  const handleSave = async (postId: string, isSaved: boolean) => {
    if (!user) {
      toast.error('Please sign in to save posts', {
        duration: 3000,
        action: {
          label: 'Sign In',
          onClick: () => navigate('/auth')
        }
      });
      return;
    }

    try {
      if (isSaved) {
        const { error } = await supabase
          .from('saved_social_posts')
          .delete()
          .eq('post_id', postId)
          .eq('user_id', user.id);

        if (error) throw error;
        toast.success('Post removed from saved', { duration: 3000 });
      } else {
        const { error } = await supabase
          .from('saved_social_posts')
          .insert({
            post_id: postId,
            user_id: user.id
          });

        if (error) throw error;
        toast.success('Post saved successfully', { duration: 3000 });
      }

      setPosts(posts.map(post => 
        post.id === postId
          ? {
              ...post,
              user_saved: !isSaved
            }
          : post
      ));
    } catch (error) {
      console.error('Error toggling save:', error);
      toast.error('Failed to save post', { duration: 3000 });
    }
  };

  const getDisplayName = (post: SocialPost) => {
    const userName = post.profiles?.full_name;
    const businessName = post.business_registrations?.business_name;
    
    if (userName && userName.trim()) {
      return userName;
    }
    if (businessName && businessName.trim()) {
      return businessName;
    }
    return 'User';
  };

  const getUserRole = (post: SocialPost) => {
    if (post.provider_profiles?.role) {
      const roleMap: Record<string, string> = {
        'vendor': 'Vendor',
        'contractor': 'Contractor',
        'architect': 'Architect',
        'designer': 'Designer',
        'engineer': 'Engineer',
        'manufacturer': 'Manufacturer'
      };
      const roleLabel = roleMap[post.provider_profiles.role.toLowerCase()] || post.provider_profiles.role;
      return `Service Provider - ${roleLabel}`;
    }
    return 'User';
  };

  const getProfileImage = (post: SocialPost) => {
    const profileUrl = post.profiles?.profile_image_url;
    const logoUrl = post.business_registrations?.logo_url;
    
    if (profileUrl && profileUrl.trim()) {
      return profileUrl;
    }
    if (logoUrl && logoUrl.trim()) {
      return logoUrl;
    }
    return '';
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const PostSkeleton = () => (
    <Card>
      <CardHeader className="pb-2 sm:pb-3">
        <div className="flex items-center space-x-2 sm:space-x-3">
          <Skeleton className="h-8 w-8 sm:h-10 sm:w-10 rounded-full" />
          <div className="flex-1 space-y-1.5 sm:space-y-2">
            <Skeleton className="h-3 w-24 sm:h-4 sm:w-32" />
            <Skeleton className="h-2.5 w-16 sm:h-3 sm:w-24" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-2 sm:space-y-3 lg:space-y-4">
        <Skeleton className="h-16 sm:h-20 w-full" />
        <Skeleton className="h-48 sm:h-64 w-full rounded-lg" />
        <div className="flex items-center space-x-2 sm:space-x-4">
          <Skeleton className="h-8 w-16 sm:w-20" />
          <Skeleton className="h-8 w-16 sm:w-20" />
          <Skeleton className="h-8 w-12 sm:w-16 ml-auto" />
        </div>
      </CardContent>
    </Card>
  );

  const handleCreatePostClick = () => {
    if (!user) {
      toast.error('Please sign in to create posts', {
        duration: 3000,
        action: {
          label: 'Sign In',
          onClick: () => navigate('/auth')
        }
      });
    } else {
      setIsCreateDialogOpen(true);
    }
  };

  const handleShareClick = (post: SocialPost) => {
    // Allow non-logged in users to share posts
    const shareUrl = `${window.location.origin}/social#post-${post.id}`;
    const shareText = `Check out this post by ${getDisplayName(post)} on BuildConnect: ${post.content?.substring(0, 100)}${post.content && post.content.length > 100 ? '...' : ''}`;
    
    if (navigator.share) {
      navigator.share({
        title: `Post by ${getDisplayName(post)}`,
        text: shareText,
        url: shareUrl,
      }).catch((error) => {
        console.log('Share cancelled:', error);
      });
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(`${shareText}\n\n${shareUrl}`)
        .then(() => {
          toast.success('Link copied to clipboard!', { duration: 3000 });
        })
        .catch((error) => {
          console.error('Failed to copy:', error);
          toast.error('Failed to share post', { duration: 3000 });
        });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 pb-24 sm:pb-8">
      <Header />
      <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-6 lg:py-8 max-w-2xl pb-24 sm:pb-8">
        <div className="text-center mb-4 sm:mb-6 lg:mb-8">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold bg-gradient-to-r from-[#C45A2A] to-[#C45A2A]/60 bg-clip-text text-transparent mb-2">
            {t('social.title')}
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">
            {t('social.description')}
          </p>
          {!user && (
            <p className="text-xs sm:text-sm text-muted-foreground mt-2">
              {t('social.loginPrompt')} <button onClick={() => navigate('/auth')} className="text-[#C45A2A] hover:underline">{t('auth.signIn')}</button>
            </p>
          )}
        </div>

        {loading && (
          <div className="space-y-6">
            {[...Array(3)].map((_, i) => (
              <PostSkeleton key={i} />
            ))}
          </div>
        )}

        <div 
          className="mb-4 sm:mb-6 cursor-pointer hover:shadow-md transition-shadow"
          onClick={handleCreatePostClick}
        >
          <Card>
            <CardContent className="p-3 sm:p-4">
              <div className="flex items-center space-x-2 sm:space-x-3">
                <Avatar className="h-8 w-8 sm:h-10 sm:w-10">
                  <AvatarFallback>
                    {user ? getInitials(user.email || 'U') : '?'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 text-muted-foreground text-sm sm:text-base">
                  {user ? t('social.createPost.placeholder') : "Sign in to create a post"}
                </div>
                <Button 
                  size="sm" 
                  className="text-xs sm:text-sm bg-[#C45A2A] hover:bg-[#C45A2A]/90"
                >
                  <Camera className="h-3 w-3 sm:h-4 sm:w-4 sm:mr-2" />
                  <span className="hidden sm:inline">{t('social.createPost.button') || 'Create Post'}</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-md">
            <div className="space-y-3 sm:space-y-4">
              <h3 className="text-base sm:text-lg font-semibold">Create Post</h3>
              
              <Textarea
                placeholder="What's on your mind?"
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                rows={4}
                className="text-sm sm:text-base"
              />

              <div>
                <Label htmlFor="media" className="text-sm sm:text-base">Add Photo/Video</Label>
                <Input
                  id="media"
                  type="file"
                  accept="image/*,video/*"
                  onChange={handleMediaSelect}
                  className="mt-1 text-sm"
                />
              </div>

              {mediaPreview && (
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  {selectedMedia?.type.startsWith('video/') ? (
                    <video src={mediaPreview} controls className="w-full h-full object-cover" />
                  ) : (
                    <img src={mediaPreview} alt="Preview" className="w-full h-full object-cover" />
                  )}
                </div>
              )}

              <div className="flex gap-2">
                <Button
                  onClick={createPost}
                  disabled={uploading || (!newPostContent.trim() && !selectedMedia)}
                  className="flex-1 text-xs sm:text-sm bg-[#C45A2A] hover:bg-[#C45A2A]/90"
                >
                  {uploading ? 'Posting...' : 'Post'}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setIsCreateDialogOpen(false)} 
                  className="text-xs sm:text-sm border-[#C45A2A] text-[#C45A2A] hover:bg-[#C45A2A]/10"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <div className="space-y-4 sm:space-y-6">
          {posts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card>
                <CardHeader className="pb-2 sm:pb-3">
                  <div className="flex items-center space-x-2 sm:space-x-3">
                    <Avatar className="h-8 w-8 sm:h-10 sm:w-10 bg-white border border-gray-200">
                      <AvatarImage 
                        src={getProfileImage(post)} 
                        className={post.business_registrations?.logo_url ? "object-contain p-0.5" : "object-cover"}
                      />
                      <AvatarFallback className="bg-[#C45A2A]/10 text-[#C45A2A] font-semibold">
                        {getInitials(getDisplayName(post))}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm sm:text-base">{getDisplayName(post)}</h4>
                      <div className="flex items-center space-x-1.5 sm:space-x-2 text-xs sm:text-sm text-muted-foreground">
                        <Badge 
                          variant={post.provider_profiles?.role ? "default" : "secondary"} 
                          className="text-[10px] sm:text-xs px-1.5 sm:px-2.5 py-0 sm:py-0.5 bg-[#C45A2A] hover:bg-[#C45A2A]/90"
                        >
                          {getUserRole(post)}
                        </Badge>
                        <span>•</span>
                        <span>{formatDistanceToNow(new Date(post.created_at))} ago</span>
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-2 sm:space-y-3 lg:space-y-4">
                  {post.content && (
                    <p className="text-foreground whitespace-pre-wrap text-sm sm:text-base">{post.content}</p>
                  )}

                  {post.media_url && (
                    <div className="aspect-video bg-muted rounded-lg overflow-hidden">
                      {post.media_type === 'video' ? (
                        <video 
                          src={post.media_url} 
                          controls 
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            console.error('Video failed to load:', post.media_url);
                            e.currentTarget.style.display = 'none';
                          }}
                        />
                      ) : (
                        <img 
                          src={post.media_url} 
                          alt="Post media" 
                          className="w-full h-full object-cover"
                          loading="lazy"
                          onError={(e) => {
                            console.error('Image failed to load:', post.media_url);
                            e.currentTarget.src = '/placeholder.svg';
                          }}
                        />
                      )}
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-2 sm:pt-3 border-t gap-1">
                    <div className="flex items-center space-x-2 sm:space-x-4">
                      <button
                        onClick={() => handleLike(post.id, post.user_liked || false)}
                        className={`flex items-center space-x-1 sm:space-x-2 px-2 sm:px-3 py-1.5 sm:py-2 rounded-md transition-colors ${
                          post.user_liked 
                            ? 'text-red-500 hover:bg-red-50' 
                            : 'text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        <Heart 
                          className={`h-4 w-4 sm:h-5 sm:w-5 ${
                            post.user_liked ? 'fill-current' : ''
                          }`} 
                        />
                        <span className="text-xs sm:text-sm">{Math.max(0, post.likes_count)}</span>
                      </button>

                      <button
                        onClick={() => handleSave(post.id, post.user_saved || false)}
                        className={`flex items-center space-x-1 sm:space-x-2 px-2 sm:px-3 py-1.5 sm:py-2 rounded-md transition-colors ${
                          post.user_saved 
                            ? 'text-blue-500 hover:bg-blue-50' 
                            : 'text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        <Bookmark 
                          className={`h-4 w-4 sm:h-5 sm:w-5 ${
                            post.user_saved ? 'fill-current' : ''
                          }`} 
                        />
                        <span className="hidden sm:inline text-xs sm:text-sm">{t('social.actions.save') || 'Save'}</span>
                      </button>
                    </div>

                    <button
                      onClick={() => handleShareClick(post)}
                      className="flex items-center space-x-1 sm:space-x-2 px-2 sm:px-3 py-1.5 sm:py-2 rounded-md text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors"
                    >
                      <span className="text-xs sm:text-sm">Share</span>
                    </button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}

          {!loading && posts.length > 0 && hasMore && (
            <div className="text-center mt-4 sm:mt-6 lg:mt-8">
              <Button 
                onClick={loadMore} 
                disabled={loadingMore}
                variant="outline"
                className="min-w-[160px] sm:min-w-[200px] h-10 sm:h-12 text-sm sm:text-base border-[#C45A2A] text-[#C45A2A] hover:bg-[#C45A2A]/10"
              >
                {loadingMore ? (
                  <>
                    <Loader2 className="mr-2 h-3 w-3 sm:h-4 sm:w-4 animate-spin" />
                    <span className="text-xs sm:text-sm">Loading...</span>
                  </>
                ) : (
                  'Load More Posts'
                )}
              </Button>
            </div>
          )}

          {!loading && posts.length === 0 && (
            <div className="text-center py-8 sm:py-12">
              <p className="text-muted-foreground text-base sm:text-lg">{t('social.noPosts') || 'No posts yet'}</p>
              <p className="text-xs sm:text-sm text-muted-foreground mt-2">Be the first to share something!</p>
            </div>
          )}
        </div>
      </div>

      <nav className="sm:hidden fixed bottom-0 left-0 w-full bg-gray-800 text-white border-t border-gray-700 flex justify-around items-center py-2 z-50">
        <Link
          to="/"
          className="flex flex-col items-center text-xs hover:text-[#C45A2A] transition-colors"
        >
          <Home className="h-6 w-6 mb-1" />
          Home
        </Link>
        <Link
          to="/professionals"
          className="flex flex-col items-center text-xs hover:text-[#C45A2A] transition-colors"
        >
          <Users className="h-6 w-6 mb-1" />
          Professionals
        </Link>
        <Link
          to="/social"
          className="flex flex-col items-center text-xs text-[#C45A2A]"
        >
          <MessageCircle className="h-6 w-6 mb-1" />
          Social
        </Link>
      </nav>
      <Footer />
    </div>
  );
};

export default SocialFeed;
