import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import { 
  CreditCard, 
  Check, 
  Star, 
  TrendingUp, 
  Shield, 
  Clock, 
  Download,
  HelpCircle,
  Users,
  Target,
  Gift,
  Zap,
  Loader2
} from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { useLeadCredits } from '@/hooks/useLeadCredits';
import { SubscriptionHistory } from '@/components/SubscriptionHistory';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

const Subscription = () => {
  const { credits, plans, loading, refreshCredits } = useLeadCredits();
  const [purchasingPlanId, setPurchasingPlanId] = useState<string | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handlePurchase = async (planId: string) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to purchase credits",
        variant: "destructive",
      });
      return;
    }

    setPurchasingPlanId(planId);

    try {
      // Find the selected plan
      const selectedPlan = plans.find(plan => plan.id === planId);
      if (!selectedPlan) {
        throw new Error('Plan not found');
      }

      // Create Razorpay order
      const { data: orderData, error: orderError } = await supabase.functions.invoke('create-razorpay-order', {
        body: { planId }
      });

      if (orderError || !orderData) {
        console.error('Error creating order:', orderError);
        toast({
          title: "Error",
          description: orderError?.message || 'Failed to create payment order. Please try again.',
          variant: "destructive",
        });
        setPurchasingPlanId(null);
        return;
      }

      // Initialize Razorpay payment
      const options = {
        key: orderData.keyId,
        amount: orderData.amount,
        currency: orderData.currency,
        name: "BuildOnClicks",
        description: `${orderData.planName} - ${orderData.credits} Credits`,
        order_id: orderData.orderId,
        handler: async function (response: any) {
          try {
            // Verify payment on backend
            const { data: verificationData, error: verificationError } = await supabase.functions.invoke('verify-razorpay-payment', {
              body: {
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
                subscription_id: orderData.subscriptionId
              }
            });

            if (verificationError || !verificationData?.success) {
              console.error('Payment verification failed:', verificationError);
              toast({
                title: "Payment Verification Failed",
                description: "Please contact support if amount was deducted.",
                variant: "destructive",
              });
              setPurchasingPlanId(null);
              return;
            }

            // Refresh credits and show success
            await refreshCredits();
            toast({
              title: "Payment Successful!",
              description: `${selectedPlan.lead_credits} credits added to your account`,
            });
            setPurchasingPlanId(null);
          } catch (error) {
            console.error('Payment verification error:', error);
            toast({
              title: "Error",
              description: "Payment verification failed. Please contact support.",
              variant: "destructive",
            });
            setPurchasingPlanId(null);
          }
        },
        modal: {
          ondismiss: function() {
            setPurchasingPlanId(null);
          }
        },
        theme: {
          color: "#F97316"
        }
      };

      // Check if Razorpay is loaded
      if (typeof (window as any).Razorpay === 'undefined') {
        // Load Razorpay script dynamically
        const script = document.createElement('script');
        script.src = 'https://checkout.razorpay.com/v1/checkout.js';
        script.onload = () => {
          const rzp = new (window as any).Razorpay(options);
          rzp.open();
        };
        script.onerror = () => {
          toast({
            title: "Error",
            description: "Failed to load payment gateway. Please try again.",
            variant: "destructive",
          });
          setPurchasingPlanId(null);
        };
        document.body.appendChild(script);
      } else {
        const rzp = new (window as any).Razorpay(options);
        rzp.open();
      }

    } catch (error) {
      console.error('Purchase error:', error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
      setPurchasingPlanId(null);
    }
  };

  const getCostPerLead = (price: number, credits: number) => {
    return (price / credits).toFixed(2);
  };

  const getPopularPlan = () => {
    if (plans.length === 0) return null;
    return plans.find(plan => plan.lead_credits >= 50) || plans[1] || plans[0];
  };

  const faqData = [
    {
      question: "How do lead credits work?",
      answer: "Each lead credit allows you to access one potential customer's contact information. When you view a requirement that matches your services, you use credits to get the customer's details."
    },
    {
      question: "Do credits expire?",
      answer: "No, your purchased credits never expire. You can use them whenever you find relevant leads."
    },
    {
      question: "Can I upgrade my plan anytime?",
      answer: "Yes, you can purchase additional credits anytime. Your credits will be added to your existing balance."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept all major credit cards, debit cards, net banking, UPI, and digital wallets through Razorpay."
    },
    {
      question: "How will I know when I get new leads?",
      answer: "You'll receive instant notifications via email and SMS when new requirements matching your services are posted."
    },
    {
      question: "Is there a refund policy?",
      answer: "We offer refunds within 7 days of purchase if you haven't used any credits. Please contact support for refund requests."
    }
  ];

  const features = [
    {
      icon: Target,
      title: "Quality Leads",
      description: "Get verified requirements from genuine customers"
    },
    {
      icon: Zap,
      title: "Instant Notifications",
      description: "Be the first to respond to new opportunities"
    },
    {
      icon: Shield,
      title: "Secure Payments",
      description: "100% secure transactions with Razorpay"
    },
    {
      icon: Users,
      title: "Direct Contact",
      description: "Connect directly with potential customers"
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-section flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading subscription plans...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Subscription Plans | BuildOnClicks</title>
        <meta name="description" content="Choose the perfect subscription plan to grow your business. Get quality leads and connect with potential customers." />
        <meta name="keywords" content="subscription, plans, leads, business growth, contractors, vendors" />
      </Helmet>

      <Header />

      <div className="min-h-screen bg-gradient-section pb-24 sm:pb-8">
        {/* Hero Section */}
        <section className="pt-20 pb-12">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center max-w-4xl mx-auto"
            >
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
                Choose Your 
                <span className="text-primary"> Growth Plan</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                Get quality leads and grow your business with our flexible subscription plans
              </p>
              
              {/* Current Credit Status */}
              {credits && (
                <div className="bg-card rounded-lg p-6 max-w-md mx-auto mb-8 border shadow-sm">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm font-medium text-muted-foreground">Current Credits</span>
                    <Badge variant="secondary" className="text-primary">
                      {credits.available_credits} available
                    </Badge>
                  </div>
                  <Progress 
                    value={(credits.available_credits / (credits.total_credits || 1)) * 100} 
                    className="h-2" 
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    {credits.used_credits} used of {credits.total_credits} total credits
                  </p>
                </div>
              )}
            </motion.div>
          </div>
        </section>

        <div className="container mx-auto px-4 pb-20">
          <Tabs defaultValue="plans" className="max-w-6xl mx-auto">
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="plans" className="flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                Plans
              </TabsTrigger>
              <TabsTrigger value="history" className="flex items-center gap-2">
                <Download className="w-4 h-4" />
                History
              </TabsTrigger>
              <TabsTrigger value="features" className="flex items-center gap-2">
                <Star className="w-4 h-4" />
                Features
              </TabsTrigger>
              <TabsTrigger value="faq" className="flex items-center gap-2">
                <HelpCircle className="w-4 h-4" />
                FAQ
              </TabsTrigger>
            </TabsList>

            {/* Pricing Plans */}
            <TabsContent value="plans" className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {plans.map((plan, index) => {
                  const isPopular = plan.id === getPopularPlan()?.id;
                  const costPerLead = getCostPerLead(plan.price_inr, plan.lead_credits);
                  
                  return (
                    <motion.div
                      key={plan.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6, delay: index * 0.1 }}
                      className="relative"
                    >
                      {isPopular && (
                        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                          <Badge className="bg-primary text-primary-foreground px-3 py-1">
                            <Star className="w-3 h-3 mr-1" />
                            Most Popular
                          </Badge>
                        </div>
                      )}
                      
                      <Card className={`h-full transition-all duration-300 hover:shadow-lg ${
                        isPopular ? 'border-primary shadow-md scale-105' : ''
                      }`}>
                        <CardHeader className="text-center pb-4">
                          <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                          <div className="space-y-2">
                            <div className="text-3xl font-bold text-primary">
                              ₹{plan.price_inr.toLocaleString('en-IN')}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              ₹{costPerLead} per lead
                            </div>
                          </div>
                        </CardHeader>
                        
                        <CardContent className="space-y-4">
                          <div className="text-center">
                            <div className="text-4xl font-bold text-foreground mb-1">
                              {plan.lead_credits}
                            </div>
                            <div className="text-sm text-muted-foreground">Lead Credits</div>
                          </div>
                          
                          {plan.description && (
                            <p className="text-sm text-muted-foreground text-center">
                              {plan.description}
                            </p>
                          )}
                          
                          <div className="space-y-3">
                            <div className="flex items-center gap-2 text-sm">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Access to verified leads</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>Direct customer contact</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>No expiry on credits</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <Check className="w-4 h-4 text-green-500" />
                              <span>24/7 customer support</span>
                            </div>
                            {plan.lead_credits >= 50 && (
                              <div className="flex items-center gap-2 text-sm">
                                <Check className="w-4 h-4 text-green-500" />
                                <span className="font-medium text-primary">Priority listing</span>
                              </div>
                            )}
                          </div>
                          
                          <Button
                            onClick={() => handlePurchase(plan.id)}
                            variant={isPopular ? "default" : "default"}
                            size="lg"
                            className="w-full mt-6"
                          >
                            <CreditCard className="w-4 h-4 mr-2" />
                            Buy Credits
                          </Button>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>

              {/* Benefits Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="bg-card rounded-lg p-8 border"
              >
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-foreground mb-2">Why Choose Our Plans?</h3>
                  <p className="text-muted-foreground">Everything you need to grow your business</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {features.map((feature, index) => (
                    <div key={index} className="text-center">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                        <feature.icon className="w-6 h-6 text-primary" />
                      </div>
                      <h4 className="font-semibold text-foreground mb-2">{feature.title}</h4>
                      <p className="text-sm text-muted-foreground">{feature.description}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            </TabsContent>

            {/* Subscription History Tab */}
            <TabsContent value="history">
              <SubscriptionHistory />
            </TabsContent>

            {/* Features Tab */}
            <TabsContent value="features" className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="grid grid-cols-1 lg:grid-cols-2 gap-8"
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-primary" />
                      Business Growth
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Quality Lead Generation</h4>
                        <p className="text-sm text-muted-foreground">
                          Connect with genuine customers actively looking for your services
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Real-time Notifications</h4>
                        <p className="text-sm text-muted-foreground">
                          Get instant alerts when new leads match your expertise
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Direct Customer Contact</h4>
                        <p className="text-sm text-muted-foreground">
                          Skip middlemen and communicate directly with potential clients
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="w-5 h-5 text-primary" />
                      Trust & Security
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Verified Requirements</h4>
                        <p className="text-sm text-muted-foreground">
                          All customer requirements are manually verified for authenticity
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Secure Payments</h4>
                        <p className="text-sm text-muted-foreground">
                          Bank-grade security with Razorpay payment gateway
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Data Protection</h4>
                        <p className="text-sm text-muted-foreground">
                          Your business data is encrypted and securely stored
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Usage Analytics Preview */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-primary" />
                    Track Your Success
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary mb-2">Real-time</div>
                      <p className="text-sm text-muted-foreground">Lead tracking and notifications</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary mb-2">Analytics</div>
                      <p className="text-sm text-muted-foreground">Detailed usage reports and insights</p>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary mb-2">Support</div>
                      <p className="text-sm text-muted-foreground">24/7 customer support assistance</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* FAQ Tab */}
            <TabsContent value="faq" className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-foreground mb-2">Frequently Asked Questions</h3>
                  <p className="text-muted-foreground">Find answers to common questions about our subscription plans</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {faqData.map((faq, index) => (
                    <Card key={index}>
                      <CardHeader>
                        <CardTitle className="text-lg">{faq.question}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">{faq.answer}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Contact Support */}
                <Card className="bg-primary/5 border-primary/20">
                  <CardContent className="p-6 text-center">
                    <HelpCircle className="w-12 h-12 text-primary mx-auto mb-4" />
                    <h4 className="text-xl font-semibold text-foreground mb-2">Still have questions?</h4>
                    <p className="text-muted-foreground mb-4">
                      Our support team is here to help you choose the right plan and answer any questions.
                    </p>
                    <Button 
                      variant="outline" 
                      className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                      onClick={() => navigate('/contact')}
                    >
                      Contact Support
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <Footer />
    </>
  );
};

export default Subscription;