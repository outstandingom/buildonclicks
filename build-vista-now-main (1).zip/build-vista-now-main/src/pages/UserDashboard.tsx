
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { Plus, FolderOpen, Bell, MessageSquare, Star, Calendar, MapPin, DollarSign } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useAuth } from '@/hooks/useAuth';
import { useProjects } from '@/hooks/useProjects';
import { useProjectBids } from '@/hooks/useProjectBids';
import { useNotifications } from '@/hooks/useNotifications';
import { useNotificationTriggers } from '@/hooks/useNotificationTriggers';

const UserDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { projects, loading: projectsLoading } = useProjects(user?.id);
  const { bids, loading: bidsLoading } = useProjectBids(undefined, user?.id);
  const { notifications, unreadCount } = useNotifications(user?.id);
  const notificationTriggers = useNotificationTriggers();

  if (authLoading || projectsLoading || bidsLoading) {
    return (
      <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
        <Header />
        <div className="flex-1 bg-gradient-section flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-construction-primary mx-auto mb-4"></div>
            <p className="text-construction-neutral">Loading dashboard...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!user) {
    navigate('/auth');
    return null;
  }

  const activeProjects = projects.filter(p => p.status === 'active');
  const recentBids = bids.slice(0, 3);
  const recentNotifications = notifications.slice(0, 3);

  return (
    <div className="min-h-screen flex flex-col pb-24 sm:pb-8">
      <Header />
      <div className="flex-1 bg-gradient-section">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex justify-between items-center mb-8"
          >
            <div>
              <h1 className="text-3xl font-bold text-construction-secondary">Dashboard</h1>
              <p className="text-construction-neutral mt-2">Welcome back! Manage your projects and connect with professionals.</p>
            </div>
            <div className="flex gap-4">
              <Button
                variant="outline"
                onClick={() => navigate('/professionals')}
                className="flex items-center gap-2"
              >
                <Star className="w-4 h-4" />
                Find Professionals
              </Button>
              <Button
                onClick={() => navigate('/create-project')}
                className="bg-construction-primary hover:bg-construction-primary/90 text-white flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Post Project
              </Button>
            </div>
          </motion.div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="shadow-card hover:shadow-hover transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Active Projects</CardTitle>
                    <FolderOpen className="w-5 h-5 text-construction-primary" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-construction-secondary">{activeProjects.length}</div>
                  <p className="text-sm text-construction-neutral">Currently active</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="shadow-card hover:shadow-hover transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Total Bids</CardTitle>
                    <MessageSquare className="w-5 h-5 text-construction-primary" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-construction-secondary">{bids.length}</div>
                  <p className="text-sm text-construction-neutral">Received from professionals</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card className="shadow-card hover:shadow-hover transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Pending Bids</CardTitle>
                    <Calendar className="w-5 h-5 text-construction-primary" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-construction-secondary">
                    {bids.filter(b => b.status === 'pending').length}
                  </div>
                  <p className="text-sm text-construction-neutral">Awaiting your review</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Card className="shadow-card hover:shadow-hover transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Notifications</CardTitle>
                    <Bell className="w-5 h-5 text-construction-primary" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-construction-secondary">{unreadCount}</div>
                  <p className="text-sm text-construction-neutral">Unread messages</p>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Recent Projects */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <Card className="shadow-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <FolderOpen className="w-5 h-5 text-construction-primary" />
                      Recent Projects
                    </CardTitle>
                    <Button variant="outline" size="sm" onClick={() => navigate('/projects')}>
                      View All
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {activeProjects.length > 0 ? (
                    <div className="space-y-4">
                      {activeProjects.slice(0, 3).map((project) => (
                        <div key={project.id} className="border-l-4 border-l-construction-primary pl-4 py-2">
                          <h4 className="font-semibold text-construction-secondary">{project.title}</h4>
                          <p className="text-sm text-construction-neutral line-clamp-2">{project.description}</p>
                          <div className="flex items-center gap-4 mt-2 text-xs text-construction-neutral">
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              {project.location}
                            </span>
                            <span className="flex items-center gap-1">
                              <DollarSign className="w-3 h-3" />
                              {project.budget_range}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <FolderOpen className="w-12 h-12 text-construction-neutral mx-auto mb-4 opacity-50" />
                      <p className="text-construction-neutral">No active projects yet.</p>
                      <Button 
                        onClick={() => navigate('/create-project')} 
                        className="mt-4 bg-construction-primary hover:bg-construction-primary/90"
                      >
                        Create Your First Project
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Recent Bids */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              <Card className="shadow-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <MessageSquare className="w-5 h-5 text-construction-primary" />
                      Recent Bids
                    </CardTitle>
                    <Button variant="outline" size="sm" onClick={() => navigate('/bids')}>
                      View All
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {recentBids.length > 0 ? (
                    <div className="space-y-4">
                      {recentBids.map((bid) => (
                        <div key={bid.id} className="border rounded-lg p-3">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold text-construction-secondary">
                              {bid.professional?.name || 'Professional'}
                            </h4>
                            <Badge variant={bid.status === 'pending' ? 'secondary' : 'default'}>
                              {bid.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-construction-neutral mb-2">
                            Project: {bid.project?.title}
                          </p>
                          {bid.bid_amount && (
                            <p className="text-sm font-medium text-construction-primary">
                              Bid Amount: ${bid.bid_amount.toLocaleString()}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <MessageSquare className="w-12 h-12 text-construction-neutral mx-auto mb-4 opacity-50" />
                      <p className="text-construction-neutral">No bids received yet.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Notifications Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="mt-8"
          >
            <Card className="shadow-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="w-5 h-5 text-construction-primary" />
                    Recent Notifications
                    {unreadCount > 0 && (
                      <Badge variant="destructive" className="ml-2">
                        {unreadCount}
                      </Badge>
                    )}
                  </CardTitle>
                  <Button variant="outline" size="sm" onClick={() => navigate('/notifications')}>
                    View All
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {recentNotifications.length > 0 ? (
                  <div className="space-y-3">
                    {recentNotifications.map((notification) => (
                      <div key={notification.id} className={`p-3 rounded-lg border ${!notification.read ? 'bg-construction-primary/5 border-construction-primary/20' : ''}`}>
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h5 className="font-medium text-construction-secondary">{notification.title}</h5>
                            <p className="text-sm text-construction-neutral mt-1">{notification.message}</p>
                          </div>
                          {!notification.read && (
                            <div className="w-2 h-2 bg-construction-primary rounded-full ml-2 mt-2"></div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Bell className="w-12 h-12 text-construction-neutral mx-auto mb-4 opacity-50" />
                    <p className="text-construction-neutral">No notifications yet.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default UserDashboard;
