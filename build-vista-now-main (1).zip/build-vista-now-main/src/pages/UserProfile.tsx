
import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet-async';
import { Camera, Edit3, Save, X, MapPin, Phone, Mail, User, Heart, Settings,Bookmark, LogOut, Shield, Loader2, Crosshair, Coins, TrendingUp, ShoppingBag } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { useAuth } from '@/hooks/useAuth';
import { useProfile } from '@/hooks/useProfile';
import { useSavedProfessionals } from '@/hooks/useSavedProfessionals';
import { useSavedPosts } from '@/hooks/useSavedPosts';
import { useGoogleLocation } from '@/hooks/useGoogleLocation';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useLeadCredits } from '@/hooks/useLeadCredits';

const UserProfile: React.FC = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading, signOut } = useAuth();
  const { profile, cities, loading: profileLoading, updateProfile } = useProfile(user?.id);
  const { savedProfessionals, loading: savedLoading, removeSavedProfessional } = useSavedProfessionals(user?.id);
  const { savedPosts, loading: postsLoading, removeSavedPost } = useSavedPosts(user?.id);
  const { getCurrentLocation, loading: locationLoading, isGoogleMapsLoaded, searchLocations } = useGoogleLocation();
  const { credits, loading: creditsLoading } = useLeadCredits();
  const [addressSuggestions, setAddressSuggestions] = useState<any[]>([]);
  const [isSearchingAddress, setIsSearchingAddress] = useState(false);
  const { toast } = useToast();
  
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showLogoutDialog, setShowLogoutDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '',
    city_id: '',
    address: '',
    profile_image_url: ''
  });
  const [fetchedCityName, setFetchedCityName] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  // Update form data when profile loads
  useEffect(() => {
    if (profile) {
      setFormData({
        full_name: profile.full_name || '',
        city_id: profile.city_id || '',
        address: profile.address || '',
        profile_image_url: profile.profile_image_url || ''
      });
      setFetchedCityName(profile.city?.name || '');
    } else if (!profileLoading && user) {
      // If profile is null but loading is done, initialize with empty values
      setFormData({
        full_name: '',
        city_id: '',
        address: '',
        profile_image_url: ''
      });
    }
  }, [profile, profileLoading, user]);

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen bg-gradient-section flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-construction-primary mx-auto mb-4"></div>
          <p className="text-construction-neutral">Loading your profile...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect in useEffect
  }

  const handleSave = async () => {
    if (!formData.full_name.trim()) {
      toast({
        title: "Error",
        description: "Please enter your full name",
        variant: "destructive"
      });
      return;
    }

    setIsSaving(true);
    
    // Convert empty strings to null for UUID fields and image URL
    const dataToUpdate = {
      ...formData,
      city_id: formData.city_id || null,
      address: formData.address || null,
      profile_image_url: formData.profile_image_url || null,
    };
    
    const { error } = await updateProfile(dataToUpdate);
    setIsSaving(false);
    
    if (!error) {
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    if (profile) {
      setFormData({
        full_name: profile.full_name || '',
        city_id: profile.city_id || '',
        address: profile.address || '',
        profile_image_url: profile.profile_image_url || ''
      });
      setFetchedCityName(profile.city?.name || '');
    }
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Error",
        description: "Image size must be less than 5MB",
        variant: "destructive"
      });
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "Please upload an image file",
        variant: "destructive"
      });
      return;
    }

    setIsSaving(true);
    
    try {
      console.log('Starting image upload...');
      
      const { supabase } = await import('@/integrations/supabase/client');
      
      // Create unique filename
      const fileExt = file.name.split('.').pop();
      const fileName = `${user?.id}/${Date.now()}.${fileExt}`;

      console.log('Uploading to storage:', fileName);

      // Upload to Supabase Storage
      const { data, error } = await supabase.storage
        .from('profile-images')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: true
        });

      if (error) {
        console.error('Storage upload error:', error);
        throw error;
      }

      console.log('Upload successful, getting public URL');

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('profile-images')
        .getPublicUrl(fileName);

      console.log('Public URL:', publicUrl);

      // Automatically save to database
      const { error: updateError } = await updateProfile({ profile_image_url: publicUrl });
      
      if (updateError) {
        console.error('Profile update error:', updateError);
        toast({
          title: "Upload Failed",
          description: "Image uploaded but failed to save to profile",
          variant: "destructive"
        });
        setIsSaving(false);
        return;
      }

      console.log('Profile updated successfully');

      toast({
        title: "Success",
        description: "Profile picture uploaded successfully",
      });
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error: any) {
      console.error('Error uploading image:', error);
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload profile picture",
        variant: "destructive"
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  const confirmLogout = () => {
    setShowLogoutDialog(false);
    handleLogout();
  };

  const handleDeleteAccount = async () => {
    if (!user) return;
    setIsDeleting(true);
    try {
      const { supabase } = await import('@/integrations/supabase/client');

      // Call the edge function to delete the account
      let responseData: any = null;
      let responseError: any = null;
      
      try {
        const response = await supabase.functions.invoke('delete-user-account', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
        });
        
        responseData = response.data;
        responseError = response.error;
      } catch (invokeError: any) {
        console.error('Function invoke exception:', invokeError);
        // Try to extract error from the exception
        if (invokeError?.response) {
          try {
            const errorBody = await invokeError.response.json();
            responseData = errorBody;
          } catch (e) {
            console.error('Could not parse error response:', e);
          }
        }
        responseError = invokeError;
      }

      if (responseError) {
        console.error('Edge function error:', responseError);
        console.error('Error details:', JSON.stringify(responseError, null, 2));
        
        // Try to extract error message from response
        let errorMessage = 'Unable to delete account';
        
        // Check if we have error data in response
        if (responseData?.error) {
          errorMessage = responseData.error;
          if (responseData.details) {
            errorMessage += ': ' + responseData.details;
          }
          if (responseData.hint) {
            errorMessage += ' (Hint: ' + responseData.hint + ')';
          }
        } else if (responseError.message) {
          errorMessage = responseError.message;
        }
        
        // Check if it's a network error
        if (errorMessage.includes('Failed to fetch') || errorMessage.includes('network')) {
          throw new Error('Unable to connect to server. Please check your internet connection and ensure the edge function is deployed.');
        }
        
        // Check if function not found
        if (errorMessage.includes('404 Not Found')) {
          throw new Error('Delete account function not found. Please ensure it is deployed correctly.');
        }
        
        // For 500 errors, provide helpful message
        if (errorMessage.includes('500') || errorMessage.includes('non-2xx') || responseError.status === 500) {
          if (!responseData?.error) {
            errorMessage = 'Server error occurred. Please check Supabase Edge Function logs for details.';
          }
          throw new Error(errorMessage);
        }
        
        throw new Error(errorMessage);
      }

      if (responseData?.error) {
        const errorDetails = responseData.details ? `: ${responseData.details}` : '';
        const errorHint = responseData.hint ? ` (${responseData.hint})` : '';
        throw new Error(responseData.error + errorDetails + errorHint);
      }

      if (!responseData?.success) {
        throw new Error(responseData?.message || 'Failed to delete account');
      }

      toast({
        title: "Account deleted",
        description: "Your account and all associated data have been permanently deleted.",
      });

      setShowDeleteDialog(false);
      
      // Sign out and redirect
      await signOut();
      navigate('/');
    } catch (err) {
      console.error('Error deleting account', err);
      let errorMessage = 'Unable to delete account. Please try again.';
      
      if (err instanceof Error) {
        errorMessage = err.message;
      } else if (typeof err === 'string') {
        errorMessage = err;
      }
      
      // Provide helpful messages for common errors
      if (errorMessage.includes('Unable to connect to server') || errorMessage.includes('Delete account function not found')) {
        errorMessage += ' Please deploy the "delete-user-account" edge function using `supabase functions deploy delete-user-account`.';
      }
      
      toast({
        title: "Deletion failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const handleFetchCity = async () => {
    if (!isEditing) return;
    if (!isGoogleMapsLoaded) {
      toast({
        title: "Loading Google Maps",
        description: "Please wait for Google Maps to load...",
      });
      return;
    }

    try {
      const locationData = await getCurrentLocation();
      const cityName = locationData.city || '';
      setFetchedCityName(cityName);

      // Find matching city in cities array (case-insensitive)
      if (cityName && cities.length > 0) {
        const matchedCity = cities.find(
          city => city.name.toLowerCase() === cityName.toLowerCase()
        );
        
        if (matchedCity) {
          setFormData(prev => ({
            ...prev,
            city_id: matchedCity.id
          }));
          toast({
            title: "City fetched",
            description: `City set to ${cityName}`,
          });
        } else {
          toast({
            title: "City fetched",
            description: `${cityName} detected, but not found in our database. Please select from the list.`,
            variant: "default",
          });
        }
      } else {
        toast({
          title: "City fetched",
          description: cityName || "City detected",
        });
      }
    } catch (error: any) {
      console.error('City fetch failed', error);
      toast({
        title: "Error",
        description: "Failed to fetch city location",
        variant: "destructive",
      });
    }
  };

  const handleFetchAddress = async () => {
    if (!isEditing) return;
    if (!isGoogleMapsLoaded) {
      toast({
        title: "Loading Google Maps",
        description: "Please wait for Google Maps to load...",
      });
      return;
    }

    try {
      const locationData = await getCurrentLocation();
      setFormData((prev) => ({
        ...prev,
        address: locationData.fullAddress || prev.address,
      }));

      toast({
        title: "Address updated",
        description: `Set to ${locationData.fullAddress || locationData.city}`,
      });
    } catch (error: any) {
      console.error('Address fetch failed', error);
    }
  };

  const handleAddressSearch = async (query: string) => {
    if (!query || query.length < 2) {
      setAddressSuggestions([]);
      return;
    }

    setIsSearchingAddress(true);
    try {
      const results = await searchLocations(query);
      setAddressSuggestions(results);
    } catch (error) {
      console.error('Address search error:', error);
      setAddressSuggestions([]);
    } finally {
      setIsSearchingAddress(false);
    }
  };

  const handleSelectAddress = async (locationData: any) => {
    setFormData((prev) => ({
      ...prev,
      address: locationData.fullAddress,
    }));
    setAddressSuggestions([]);
    toast({
      title: "Address set",
      description: `Set to ${locationData.city}`,
    });
  };

  const getTypeLabel = (type: string) => {
    const labels = {
      contractor: 'Contractor',
      vendor: 'Vendor',
      architect: 'Architect'
    };
    return labels[type as keyof typeof labels] || type;
  };

  const calculateProfileCompletion = () => {
    if (!profile) return 0;
    let completed = 0;
    const total = 5;
    
    if (profile.full_name) completed++;
    if (user.email) completed++;
    if (profile.mobile_number) completed++;
    if (profile.city_id) completed++;
    if (profile.address) completed++;
    
    return Math.round((completed / total) * 100);
  };

  const profileCompletion = calculateProfileCompletion();

  return (
    <>
      <Helmet>
        <title>My Profile | BuildOnClicks</title>
        <meta name="description" content="Manage your BuildOnClicks profile, saved professionals, and account settings." />
      </Helmet>

      <Header />

      <div className="min-h-screen bg-gradient-section pb-24 sm:pb-8">
        <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-8 max-w-7xl">
          {/* Profile Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <Card className="shadow-card">
              <CardContent className="p-4 sm:p-6">
                <div className="flex flex-col md:flex-row items-start md:items-center gap-4 sm:gap-6">
                  {/* Profile Picture */}
                  <div className="relative">
                    <Avatar className="w-20 h-20 sm:w-24 sm:h-24">
                      <AvatarImage src={formData.profile_image_url || undefined} />
                      <AvatarFallback className="bg-construction-primary text-white text-xl sm:text-2xl">
                        {formData.full_name ? formData.full_name.split(' ').map(n => n[0]).join('') : 'U'}
                      </AvatarFallback>
                    </Avatar>
                    {isEditing && (
                      <Button
                        size="icon"
                        variant="outline"
                        className="absolute -bottom-2 -right-2 w-7 h-7 sm:w-8 sm:h-8 rounded-full"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={isSaving}
                      >
                        {isSaving ? (
                          <Loader2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 animate-spin" />
                        ) : (
                          <Camera className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                        )}
                      </Button>
                    )}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </div>

                  {/* Profile Info */}
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div>
                        <h1 className="text-xl sm:text-2xl font-bold text-construction-secondary">
                          {formData.full_name || 'User'}
                        </h1>
                        <p className="text-xs sm:text-sm text-construction-neutral mt-1">
                          Member since {new Date(profile?.created_at || Date.now()).toLocaleDateString('en-IN', { 
                            month: 'long', 
                            year: 'numeric' 
                          })}
                        </p>
                      </div>
                      <div className="flex gap-2 w-full sm:w-auto">
                        {!isEditing ? (
                          <Button
                            onClick={() => setIsEditing(true)}
                            className="bg-construction-primary hover:bg-construction-primary/90 w-full sm:w-auto"
                          >
                            <Edit3 className="w-4 h-4 mr-2" />
                            Edit Profile
                          </Button>
                        ) : (
                          <div className="flex flex-col sm:flex-row gap-2 w-full">
                            <Button
                              onClick={handleSave}
                              disabled={isSaving}
                              className="bg-green-600 hover:bg-green-700 w-full sm:w-auto"
                            >
                              {isSaving ? (
                                <>
                                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                  Saving...
                                </>
                              ) : (
                                <>
                                  <Save className="w-4 h-4 mr-2" />
                                  Save
                                </>
                              )}
                            </Button>
                            <Button
                              onClick={handleCancel}
                              variant="outline"
                              disabled={isSaving}
                              className="w-full sm:w-auto"
                            >
                              <X className="w-4 h-4 mr-2" />
                              Cancel
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Profile Completion */}
                    <div className="mt-4">
                      <div className="flex justify-between text-xs sm:text-sm mb-2">
                        <span className="text-construction-neutral">Profile Completion</span>
                        <span className="font-semibold text-construction-primary">{profileCompletion}%</span>
                      </div>
                      <Progress value={profileCompletion} className="h-2" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Main Content Tabs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Tabs defaultValue="overview" className="space-y-4 sm:space-y-6">
              <TabsList className="grid w-full grid-cols-3 lg:w-auto">
                <TabsTrigger value="overview" className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4">
                  <User className="w-4 h-4" />
                  <span className="hidden sm:inline">Overview</span>
                </TabsTrigger>
                <TabsTrigger value="saved" className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4">
                  <Bookmark className="w-4 h-4" />
                  <span className="hidden sm:inline">Saved</span>
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4">
                  <Settings className="w-4 h-4" />
                  <span className="hidden sm:inline">Settings</span>
                </TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-4 sm:space-y-6">
                <Card className="shadow-card">
                  <CardHeader className="p-4 sm:p-6">
                    <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                      <User className="w-4 h-4 sm:w-5 sm:h-5 text-construction-primary" />
                      Personal Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                      <div>
                        <label className="block text-xs sm:text-sm font-medium text-construction-secondary mb-2">
                          Full Name
                        </label>
                        {isEditing ? (
                          <Input
                            value={formData.full_name}
                            onChange={(e) => setFormData(prev => ({ ...prev, full_name: e.target.value }))}
                            placeholder="Enter your full name"
                          />
                        ) : (
                          <p className="text-construction-neutral">{formData.full_name || 'Not provided'}</p>
                        )}
                      </div>

                      <div>
                        <label className="block text-xs sm:text-sm font-medium text-construction-secondary mb-2">
                          Email Address
                        </label>
                        <p className="text-sm sm:text-base text-construction-neutral flex items-center gap-2">
                          <Mail className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                          {user.email}
                          <Badge variant="outline" className="text-[10px] sm:text-xs text-green-600 border-green-600">
                            Verified
                          </Badge>
                        </p>
                      </div>

                      <div>
                        <label className="block text-xs sm:text-sm font-medium text-construction-secondary mb-2">
                          Mobile Number
                        </label>
                        <p className="text-sm sm:text-base text-construction-neutral flex items-center gap-2">
                          <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                          {profile?.mobile_number || 'Not provided'}
                          {profile?.mobile_number && (
                            <Badge variant="outline" className="text-[10px] sm:text-xs text-green-600 border-green-600">
                              Verified
                            </Badge>
                          )}
                        </p>
                      </div>

                      <div className="hidden">
                        <label className="block text-xs sm:text-sm font-medium text-construction-secondary mb-2">
                          City
                        </label>
                        {isEditing ? (
                          <div className="space-y-2">
                            <p className="text-sm sm:text-base text-construction-neutral flex items-center gap-2">
                              <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                              {fetchedCityName || profile?.city?.name || 'Not set yet'}
                            </p>
                            <Button
                              variant="outline"
                              size="sm"
                              className="flex items-center gap-2"
                              onClick={handleFetchCity}
                              disabled={locationLoading || !isGoogleMapsLoaded}
                            >
                              {locationLoading ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <Crosshair className="w-4 h-4" />
                              )}
                              Use my location
                            </Button>
                          </div>
                        ) : (
                          <p className="text-sm sm:text-base text-construction-neutral flex items-center gap-2">
                            <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                            {profile?.city?.name || 'Not selected'}
                          </p>
                        )}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs sm:text-sm font-medium text-construction-secondary mb-2">
                        Address (Optional)
                      </label>
                      {isEditing ? (
                        <div className="space-y-2">
                          <div className="relative">
                            <Input
                              value={formData.address}
                              onChange={(e) => {
                                setFormData(prev => ({ ...prev, address: e.target.value }));
                                handleAddressSearch(e.target.value);
                              }}
                              placeholder="Type your address or use location button"
                              className="pr-10"
                              disabled={!isGoogleMapsLoaded}
                            />
                            {isSearchingAddress && (
                              <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                                <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                              </div>
                            )}
                            {addressSuggestions.length > 0 && (
                              <div className="absolute z-10 w-full mt-1 bg-white border rounded-md shadow-lg max-h-60 overflow-y-auto">
                                {addressSuggestions.map((suggestion, index) => (
                                  <div
                                    key={index}
                                    onClick={() => handleSelectAddress(suggestion)}
                                    className="p-3 hover:bg-accent cursor-pointer border-b last:border-b-0"
                                  >
                                    <div className="font-medium text-sm">{suggestion.city}</div>
                                    <div className="text-xs text-muted-foreground truncate">
                                      {suggestion.fullAddress}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex items-center gap-2"
                            onClick={handleFetchAddress}
                            disabled={locationLoading || !isGoogleMapsLoaded}
                          >
                            {locationLoading ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <Crosshair className="w-4 h-4" />
                            )}
                            Fetch address from my location
                          </Button>
                        </div>
                      ) : (
                        <p className="text-construction-neutral">
                          {formData.address || 'No address provided'}
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Lead Credits Section */}
                <Card className="shadow-card">
                  <CardHeader className="p-4 sm:p-6">
                    <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                      <Coins className="w-4 h-4 sm:w-5 sm:h-5 text-construction-primary" />
                      Lead Credits
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6">
                    {creditsLoading ? (
                      <div className="flex items-center justify-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-construction-primary"></div>
                      </div>
                    ) : credits ? (
                      <div className="space-y-4">
                        {/* Credit Balance Display */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                          <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
                            <div className="flex items-center gap-2 mb-2">
                              <Coins className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                              <span className="text-xs sm:text-sm font-medium text-blue-700 dark:text-blue-300">
                                Available Credits
                              </span>
                            </div>
                            <div className="text-2xl sm:text-3xl font-bold text-blue-900 dark:text-blue-100">
                              {credits.available_credits}
                            </div>
                            <div className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                              Ready to use
                            </div>
                          </div>

                          <div className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
                            <div className="flex items-center gap-2 mb-2">
                              <TrendingUp className="w-5 h-5 text-green-600 dark:text-green-400" />
                              <span className="text-xs sm:text-sm font-medium text-green-700 dark:text-green-300">
                                Total Credits
                              </span>
                            </div>
                            <div className="text-2xl sm:text-3xl font-bold text-green-900 dark:text-green-100">
                              {credits.total_credits}
                            </div>
                            <div className="text-xs text-green-600 dark:text-green-400 mt-1">
                              All time earned
                            </div>
                          </div>

                          <div className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 rounded-lg p-4 border border-orange-200 dark:border-orange-800">
                            <div className="flex items-center gap-2 mb-2">
                              <ShoppingBag className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                              <span className="text-xs sm:text-sm font-medium text-orange-700 dark:text-orange-300">
                                Used Credits
                              </span>
                            </div>
                            <div className="text-2xl sm:text-3xl font-bold text-orange-900 dark:text-orange-100">
                              {credits.used_credits}
                            </div>
                            <div className="text-xs text-orange-600 dark:text-orange-400 mt-1">
                              Leads accessed
                            </div>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs sm:text-sm">
                            <span className="text-construction-neutral">Credit Usage</span>
                            <span className="font-semibold text-construction-primary">
                              {credits.total_credits > 0 
                                ? Math.round((credits.used_credits / credits.total_credits) * 100)
                                : 0}%
                            </span>
                          </div>
                          <Progress 
                            value={credits.total_credits > 0 
                              ? (credits.used_credits / credits.total_credits) * 100 
                              : 0} 
                            className="h-2" 
                          />
                        </div>

                        {/* Action Buttons */}
                        <div className="flex flex-col sm:flex-row gap-2 pt-2">
                          <Button
                            onClick={() => navigate('/subscription')}
                            className="bg-construction-primary hover:bg-construction-primary/90 flex-1"
                          >
                            <Coins className="w-4 h-4 mr-2" />
                            Buy More Credits
                          </Button>
                          {credits.available_credits <= 3 && (
                            <div className="text-xs text-orange-600 dark:text-orange-400 flex items-center gap-1 sm:mt-0 mt-2 sm:justify-center">
                              <span>⚠️</span>
                              <span>Low credits! Consider purchasing more.</span>
                            </div>
                          )}
                        </div>

                        {/* Info Text */}
                        <div className="text-xs text-construction-neutral bg-accent/50 rounded-lg p-3">
                          <p className="font-medium mb-1">💡 How Lead Credits Work:</p>
                          <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                            <li>Use credits to access contact information of potential customers</li>
                            <li>Each lead access consumes 1 credit</li>
                            <li>Credits never expire - use them whenever you need</li>
                            {credits.free_credits_given && (
                              <li>You received {credits.total_credits >= 20 ? '20' : '15'} free credits as a new user!</li>
                            )}
                          </ul>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-construction-neutral">
                        <Coins className="w-12 h-12 mx-auto mb-3 opacity-50" />
                        <p className="text-sm">Unable to load credit information</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Saved Tab */}
              <TabsContent value="saved" className="space-y-4 sm:space-y-6">
                {/* Saved Posts */}
                <Card className="shadow-card">
                  <CardHeader className="p-4 sm:p-6">
                    <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                      <Bookmark className="w-4 h-4 sm:w-5 sm:h-5 text-construction-primary" />
                      Saved Posts ({savedPosts.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6">
                    {postsLoading ? (
                      <div className="text-center py-6 sm:py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-construction-primary mx-auto mb-4"></div>
                        <p className="text-sm sm:text-base text-construction-neutral">Loading saved posts...</p>
                      </div>
                    ) : savedPosts.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                        {savedPosts.map((saved) => (
                          <Card key={saved.id} className="shadow-sm hover:shadow-hover transition-shadow flex flex-col">
                            <CardContent className="p-3 sm:p-4 lg:p-4 flex flex-col flex-1">
                              <div className="flex items-start gap-2 sm:gap-3 mb-2 sm:mb-3">
                                <Avatar className="w-8 h-8 sm:w-9 sm:h-9 lg:w-10 lg:h-10 flex-shrink-0">
                                  <AvatarImage src={saved.post.profiles?.profile_image_url || ''} />
                                  <AvatarFallback className="bg-construction-primary/10 text-construction-primary text-xs">
                                    {(saved.post.profiles?.full_name || saved.post.business_registrations?.business_name || 'U').charAt(0)}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1 min-w-0">
                                  <p className="font-medium text-xs sm:text-sm lg:text-sm truncate">
                                    {saved.post.profiles?.full_name || saved.post.business_registrations?.business_name || 'User'}
                                  </p>
                                  <p className="text-[10px] sm:text-xs text-construction-neutral">
                                    {new Date(saved.post.created_at).toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                              <p className="text-xs sm:text-sm mb-2 sm:mb-3 line-clamp-2 lg:line-clamp-3 flex-1">{saved.post.content}</p>
                              {saved.post.media_url && (
                                <img 
                                  src={saved.post.media_url} 
                                  alt="Post media" 
                                  className="rounded-lg w-full mb-2 sm:mb-3 max-h-32 sm:max-h-40 lg:max-h-48 object-cover"
                                />
                              )}
                              <div className="flex items-center justify-between text-[10px] sm:text-xs text-construction-neutral mb-2 sm:mb-3">
                                <div className="flex gap-2 sm:gap-3">
                                  <span>❤️ {Math.max(0, saved.post.likes_count || 0)}</span>
                                  <span>💬 {Math.max(0, saved.post.comments_count || 0)}</span>
                                </div>
                              </div>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => removeSavedPost(saved.id)}
                                className="w-full text-red-600 hover:text-red-700 hover:bg-red-50 text-[10px] sm:text-xs h-7 sm:h-8"
                              >
                                <X className="h-3 w-3 mr-1" />
                                Remove
                              </Button>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-6 sm:py-8">
                        <Heart className="w-12 h-12 sm:w-16 sm:h-16 text-construction-neutral mx-auto mb-3 sm:mb-4 opacity-50" />
                        <h3 className="text-base sm:text-lg font-semibold text-construction-secondary mb-2">
                          No Saved Posts
                        </h3>
                        <p className="text-sm sm:text-base text-construction-neutral">
                          Start exploring the social feed and save posts you like.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Saved Professionals */}
                <Card className="shadow-card">
                  <CardHeader className="p-4 sm:p-6">
                    <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                      <Bookmark className="w-4 h-4 sm:w-5 sm:h-5 text-construction-primary" />
                      Saved Professionals ({savedProfessionals.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 sm:p-6">
                    {savedLoading ? (
                      <div className="text-center py-6 sm:py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-construction-primary mx-auto mb-4"></div>
                        <p className="text-sm sm:text-base text-construction-neutral">Loading saved professionals...</p>
                      </div>
                    ) : savedProfessionals.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                        {savedProfessionals.map((saved) => (
                          <Card key={saved.id} className="shadow-sm hover:shadow-hover transition-shadow">
                            <CardContent className="p-3 sm:p-4">
                              <div className="flex items-start gap-2 sm:gap-3">
                                <Avatar className="w-10 h-10 sm:w-12 sm:h-12">
                                  <AvatarImage src={saved.professional.profile_image_url || undefined} />
                                  <AvatarFallback className="bg-construction-primary/10 text-construction-primary text-xs sm:text-sm">
                                    {saved.professional.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                                  </AvatarFallback>
                                </Avatar>
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-semibold text-sm sm:text-base text-construction-secondary truncate">
                                    {saved.professional.business_name || saved.professional.name}
                                  </h4>
                                  <p className="text-xs sm:text-sm text-construction-neutral">
                                    {getTypeLabel(saved.professional.type)} • {saved.professional.city?.name}
                                  </p>
                                  <div className="flex items-center gap-1 mt-1 sm:mt-2">
                                    {saved.professional.rating > 0 ? (
                                      <>
                                        <span className="text-xs sm:text-sm font-medium">⭐ {saved.professional.rating}</span>
                                        <span className="text-[10px] sm:text-xs text-construction-neutral">
                                          ({saved.professional.review_count} reviews)
                                        </span>
                                      </>
                                    ) : (
                                      <span className="text-[10px] sm:text-xs text-construction-neutral">
                                        No reviews yet
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <div className="flex gap-1.5 sm:gap-2 mt-3 sm:mt-4">
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="flex-1 text-xs sm:text-sm"
                                  onClick={() => {
                                    // Navigate to portfolio or shop based on type
                                    if (saved.professional.type === 'vendor' || saved.professional.type === 'manufacturer') {
                                      // Try to find shop_id
                                      navigate(`/shop/${saved.professional_id}`);
                                    } else {
                                      navigate(`/portfolio/${saved.professional_id}`);
                                    }
                                  }}
                                >
                                  View Profile
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => removeSavedProfessional(saved.id)}
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50 text-xs sm:text-sm"
                                >
                                  Remove
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-6 sm:py-8">
                        <Bookmark className="w-12 h-12 sm:w-16 sm:h-16 text-construction-neutral mx-auto mb-3 sm:mb-4 opacity-50" />
                        <h3 className="text-base sm:text-lg font-semibold text-construction-secondary mb-2">
                          No Saved Professionals
                        </h3>
                        <p className="text-sm sm:text-base text-construction-neutral">
                          Start exploring professionals and save your favorites for easy access.
                        </p>
                        <Button 
                          className="mt-4 bg-construction-primary hover:bg-construction-primary/90 w-full sm:w-auto"
                          onClick={() => navigate('/professionals')}
                        >
                          Browse Professionals
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Settings Tab */}
              <TabsContent value="settings" className="space-y-4 sm:space-y-6">
                <Card className="shadow-card">
                  <CardHeader className="p-4 sm:p-6">
                    <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                      <Settings className="w-4 h-4 sm:w-5 sm:h-5 text-construction-primary" />
                      Account Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 sm:space-y-4 p-4 sm:p-6">
                    <div className="space-y-3 sm:space-y-4">
                      <Button 
                        variant="outline" 
                        className="w-full justify-start text-sm sm:text-base hover:bg-accent"
                        onClick={() => navigate('/reset-password')}
                      >
                        <Shield className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2" />
                        Change Password
                      </Button>
                      
                      <Button
                        variant="outline"
                        className="w-full justify-start text-sm sm:text-base text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                        onClick={() => setShowLogoutDialog(true)}
                      >
                        <LogOut className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2" />
                        Logout
                      </Button>

                      <div className="pt-3 sm:pt-4 border-t border-border">
                        <h4 className="text-xs sm:text-sm font-semibold text-destructive mb-3">
                          Danger Zone
                        </h4>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-sm sm:text-base text-red-600 hover:text-red-700 hover:bg-red-50 border-red-300 hover:border-red-400"
                          onClick={() => setShowDeleteDialog(true)}
                        >
                          <X className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2" />
                          Delete Account
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
      </div>

      <Footer />

      {/* Logout Confirmation Dialog */}
      <AlertDialog open={showLogoutDialog} onOpenChange={setShowLogoutDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Logout Confirmation</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to logout? You'll need to sign in again to access your account.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmLogout}
              className="bg-red-600 hover:bg-red-700"
            >
              Logout
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Account Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Account</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete your account and remove all your data from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteAccount}
              disabled={isDeleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {isDeleting ? 'Deleting...' : 'Delete Account'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default UserProfile;

