// src/pages/VendorShop.tsx

import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ShopHeader from '@/components/vendor-shop/ShopHeader';
import ShopProducts from '@/components/vendor-shop/ShopProducts';
import ShopReviews from '@/components/vendor-shop/ShopReviews';
import ReviewFormDialog from '@/components/ReviewFormDialog';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import { useReviews } from '@/hooks/useReviews';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Phone } from 'lucide-react';

// Safe import for ContactRequestModal (handles default or named export)
import * as ContactRequestModalModule from '@/components/ContactRequestModal';
const ContactRequestModal =
  (ContactRequestModalModule as any).default ||
  (ContactRequestModalModule as any).ContactRequestModal ||
  (ContactRequestModalModule as any).contactRequestModal ||
  null;

interface Shop {
  id: string;
  shop_name: string;
  description?: string;
  categories?: string[];
  working_hours?: string;
  delivery_options?: string[];
  min_order_value?: number;
  featured?: boolean;
  images?: string[];
  logo_url?: string | null;
  created_at?: string;
  business_registration_id?: string;
  business_registrations?: any;
  phone?: string | null;
  address?: string | null;
  location?: string | null;
  business_address?: string | null;
  email?: string | null;
}

interface Product {
  id: string;
  shop_id: string;
  name: string;
  description?: string;
  price?: number;
  unit?: string;
  category?: string;
  image_url?: string;
  in_stock?: boolean;
  min_order_quantity?: number;
  created_at?: string;
}

const VendorShop: React.FC = () => {
  const { shopId } = useParams<{ shopId: string }>();
  const route = useLocation();
  const passedProfessional = (route.state as any)?.professional;

  const [shop, setShop] = useState<Shop | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);

  const businessRegistrationId = shop?.business_registration_id || '';

  const { reviews, refreshReviews } = useReviews(
    undefined,
    undefined,
    businessRegistrationId
  );

  useEffect(() => {
    if (shopId) {
      fetchShopData();
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shopId]);

  const fetchShopData = async () => {
    try {
      setLoading(true);

      // 1) Try to get shop by ID first (provider_shops.id)
      let { data: shopData, error: shopError } = await supabase
        .from('provider_shops')
        .select(`
          *,
          business_registrations (
            phone_number,
            business_address,
            contact_name
          )
        `)
        .eq('id', shopId)
        .maybeSingle();

      // 2) If not found by id, try by business_registration_id
      //    (This handles when search passes business_registration.id)
      if (!shopData && !shopError) {
        const { data: shopByBizRegId, error: bizRegError } = await supabase
          .from('provider_shops')
          .select(`
            *,
            business_registrations (
              phone_number,
              business_address,
              contact_name
            )
          `)
          .eq('business_registration_id', shopId)
          .maybeSingle();
        
        if (!bizRegError && shopByBizRegId) {
          shopData = shopByBizRegId;
          shopError = null;
        }
      }

      if (shopError || !shopData) {
        setShop(null);
        setProducts([]);
        setLoading(false);
        return;
      }

      // 2) Normalize nested relation if present
      let br: any = null;
      if (shopData && shopData.business_registrations) {
        br = Array.isArray(shopData.business_registrations)
          ? (shopData.business_registrations.length > 0 ? shopData.business_registrations[0] : null)
          : shopData.business_registrations;
      }

      // 3) If nested relation missing, try fetching by business_registration_id from multiple plausible tables
      if (!br && shopData && shopData.business_registration_id) {
        const id = shopData.business_registration_id;

        const tryFetch = async (table: 'business_registrations' | 'professionals' | 'profiles') => {
          try {
            const { data, error } = await supabase
              .from(table)
              .select('*')
              .eq('id', id)
              .maybeSingle();
            if (error) return null;
            return data || null;
          } catch {
            return null;
          }
        };

        const candidates: ('business_registrations' | 'professionals' | 'profiles')[] = ['business_registrations', 'professionals', 'profiles'];

        for (const t of candidates) {
          const result = await tryFetch(t);
          if (result) {
            br = result;
            break;
          }
        }
      }

      // 4) Resolve candidate location & phone
      const routeProfessionalLocation =
        passedProfessional?.location || passedProfessional?.city_name || passedProfessional?.address || '';

      // try localStorage fallback (saved by ProfessionalCard on click)
      let storedProfessionalLocation = '';
      try {
        const key =
          shopData?.id
            ? `professional_shop_${shopData.id}`
            : shopData?.business_registration_id
            ? `professional_${shopData.business_registration_id}`
            : null;
        if (key) {
          const raw = localStorage.getItem(key);
          if (raw) {
            const parsed = JSON.parse(raw);
            storedProfessionalLocation = parsed?.location || parsed?.city_name || parsed?.address || '';
          }
        }
      } catch {
        // ignore storage errors
      }

      const dbLocationCandidates = [
        br?.business_address,
        br?.location,
        br?.address,
        br?.city_name,
        br?.city,
        br?.locality,
        br?.area,
      ];

      const candidateLocation =
        (routeProfessionalLocation && routeProfessionalLocation.toString().trim()) ||
        (storedProfessionalLocation && storedProfessionalLocation.toString().trim()) ||
        dbLocationCandidates.find((v) => v && typeof v === 'string' && v.toString().trim()) ||
        '';

      const phoneCandidates = [br?.phone_number, br?.phone];
      const candidatePhone = (phoneCandidates.find((v) => v && v.toString && v.toString().trim()) as string) || undefined;

      // 5) Build normalized shop object for UI
      const normalizedShop = {
        ...shopData,
        business_registrations: br,
        location: candidateLocation || '',
        address: candidateLocation || undefined,
        business_address: br?.business_address || undefined,
        phone: candidatePhone || undefined,
        contact_phone: candidatePhone || undefined,
        profile_image_url: shopData?.logo_url || (shopData?.images && shopData.images[0]) || undefined,
        logo_url: shopData?.logo_url || (shopData?.images && shopData.images[0]) || undefined,
      };

      setShop(normalizedShop as Shop);

      // 6) fetch products using actual shop ID (not URL param which might be business_registration_id)
      const actualShopId = shopData.id;
      const { data: productsData, error: productsError } = await supabase
        .from('shop_products')
        .select('*')
        .eq('shop_id', actualShopId);

      if (productsError) {
        setProducts([]);
      } else {
        setProducts(productsData || []);
      }
    } catch {
      setShop(null);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

  const averageRating =
    reviews && reviews.length > 0
      ? reviews.reduce((acc: number, r: any) => acc + (r.rating || 0), 0) / reviews.length
      : 0;

  const transformedReviews = (reviews || []).map((review: any) => ({
    id: review.id,
    userName: (review.profiles as any)?.full_name || 'Anonymous User',
    rating: review.rating,
    comment: review.comment || '',
    date: review.created_at,
    avatar: (review.profiles as any)?.profile_image_url || '',
  }));

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 pb-24 sm:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-6 max-w-6xl">
          <div className="space-y-4">
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-8 w-1/2" />
            <Skeleton className="h-4 w-3/4" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-64 w-full" />
              ))}
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!shop) {
    return (
      <div className="min-h-screen bg-gray-50 pb-24 sm:pb-8">
        <Header />
        <div className="container mx-auto px-4 py-6 max-w-6xl">
          <Card className="max-w-2xl mx-auto mt-12">
            <CardContent className="pt-6">
              <div className="text-center py-8">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">Shop Not Available</h1>
                <p className="text-gray-600 mb-4">This provider has not created their shop yet or the shop is currently unavailable.</p>
              </div>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  // final resolved values (use what's present in normalized shop)
  const resolvedLocation = (shop as any).location || '';
  const resolvedPhone = (shop as any).phone || undefined;

  // shopForHeader uses the resolved values and also adds multiple aliases so ShopHeader can read any key
  const shopForHeader = {
    id: shop.id,
    shop_name: shop.shop_name || '',
    description: shop.description || '',
    location: resolvedLocation || 'Location not available',
    phone: resolvedPhone || '',
    rating: Number(averageRating.toFixed(1)),
    reviewCount: reviews ? reviews.length : 0,
    isOpen: true,
    working_hours: shop.working_hours || '',
    coverImage: (shop as any).images && (shop as any).images.length > 0 ? (shop as any).images[0] : 'https://images.unsplash.com/photo-1449157291145-7efd050a4d0e?w=1200',
    logoUrl: (shop as any).logo_url || 'https://images.unsplash.com/photo-1482938289607-d4a9ddbe4151?w=100',
    categories: shop.categories || [],
    min_order_value: (shop as any).min_order_value || 0,
  };

  const productsForDisplay = (products || []).map((p) => ({
    id: p.id,
    name: p.name,
    image: p.image_url || 'https://images.unsplash.com/photo-1482938289607-d4a9ddbe4151?w=300',
    price: Number(p.price || 0),
    unit: p.unit,
    category: p.category,
    inStock: !!p.in_stock,
  }));

  return (
    <div className="min-h-screen bg-gray-50 pb-24 sm:pb-8">
      <Header />

      <div className="container mx-auto px-4 py-6 max-w-6xl">
        <ShopHeader shop={shopForHeader} />

        <div className="space-y-8 mt-8">
          <Card>
            <CardHeader>
              <CardTitle>Contact Shop Owner</CardTitle>
            </CardHeader>

            <CardContent>
              <div className="space-y-3">
                <button
                  onClick={() => setShowContactModal(true)}
                  className="w-full flex items-center gap-2 px-4 py-3 rounded-md bg-orange-200 text-orange-900 hover:bg-orange-300 transition"
                >
                  <Phone className="h-3 w-3 sm:h-4 sm:w-4 mr-1" />
                  <span className="font-medium">Contact</span>
                  {resolvedPhone && (
                    <span className="ml-auto text-sm text-gray-700">{resolvedPhone}</span>
                  )}
                </button>
              </div>
            </CardContent>
          </Card>

          <ShopProducts products={productsForDisplay} shopId={(shop as any).id} />

          <ShopReviews
            reviews={transformedReviews}
            shopRating={Number(averageRating.toFixed(1))}
            onWriteReview={() => setReviewDialogOpen(true)}
          />
        </div>
      </div>

      <Footer />

      {ContactRequestModal && (
        <ContactRequestModal
          isOpen={showContactModal}
          onClose={() => setShowContactModal(false)}
          professionalId={(shop as any).business_registration_id}
          professionalName={(shop as any).shop_name || (shop as any).business_name}
        />
      )}

      {shop && (
        <ReviewFormDialog
          open={reviewDialogOpen}
          onOpenChange={setReviewDialogOpen}
          businessRegistrationId={(shop as any).business_registration_id}
          businessName={(shop as any).shop_name}
          onReviewSubmitted={refreshReviews}
        />
      )}
    </div>
  );
};

export default VendorShop;
