import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Edit, Trash2, Store, Package, Settings, Eye, Upload, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import ShopCreationForm from '@/components/ShopCreationForm';
import { ProductManagement } from '@/components/ProductManagement';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

interface Shop {
  id: string;
  shop_name: string;
  description: string;
  categories: string[];
  working_hours: string;
  delivery_options: string[];
  min_order_value: number;
  featured: boolean;
  images: string[];
  logo_url: string | null;
  created_at: string;
  business_registration_id: string;
}

interface Product {
  id: string;
  shop_id: string;
  name: string;
  description: string;
  price: number;
  unit: string;
  category: string;
  image_url: string;
  in_stock: boolean;
  min_order_quantity: number;
  created_at: string;
}

export default function VendorShopManagement() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [shops, setShops] = useState<Shop[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showShopForm, setShowShopForm] = useState(false);
  const [isSubmittingShop, setIsSubmittingShop] = useState(false);
  const [selectedShop, setSelectedShop] = useState<Shop | null>(null);
  const [activeTab, setActiveTab] = useState('shops');
  const [uploadingBanner, setUploadingBanner] = useState<string | null>(null);
  const [uploadingLogo, setUploadingLogo] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchUserShops();
  }, []);

  const fetchUserShops = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/auth');
        return;
      }

      // Fetch shops owned by this user
      const { data: shopsData, error: shopsError } = await supabase
        .from('provider_shops')
        .select(`
          *,
          business_registrations!inner(user_id)
        `)
        .eq('business_registrations.user_id', user.id)
        .order('created_at', { ascending: false });

      if (shopsError) {
        console.error('Error fetching shops:', shopsError);
        toast({
          title: "Error",
          description: "Failed to load your shops.",
          variant: "destructive",
        });
      } else {
        setShops(shopsData || []);
        
        // If shops exist, fetch products for all shops
        if (shopsData && shopsData.length > 0) {
          const shopIds = shopsData.map(shop => shop.id);
          await fetchShopProducts(shopIds);
        }
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchShopProducts = async (shopIds: string[]) => {
    try {
      const { data: productsData, error: productsError } = await supabase
        .from('shop_products')
        .select('*')
        .in('shop_id', shopIds)
        .order('created_at', { ascending: false });

      if (productsError) {
        console.error('Error fetching products:', productsError);
      } else {
        setProducts(productsData || []);
      }
    } catch (error) {
      console.error('Unexpected error fetching products:', error);
    }
  };

  const handleShopCreated = async (shopData: any): Promise<boolean> => {
    setIsSubmittingShop(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return false;

      // Get user's business registration
      const { data: businessReg, error: businessError } = await supabase
        .from('business_registrations')
        .select('id')
        .eq('user_id', user.id)
        .eq('status', 'approved')
        .single();

      if (businessError || !businessReg) {
        toast({
          title: "Error",
          description: "You need an approved business registration to create a shop.",
          variant: "destructive",
        });
        return false;
      }

      // Convert the form data to match database schema
      const shopDataForDB = {
        shop_name: shopData.shopName,
        description: shopData.description,
        categories: shopData.categories,
        working_hours: shopData.workingHours,
        delivery_options: shopData.deliveryOptions,
        min_order_value: shopData.minOrderValue || 1000,
        featured: shopData.featured,
        images: shopData.images,
        business_registration_id: businessReg.id
      };

      const { error } = await supabase
        .from('provider_shops')
        .insert([shopDataForDB]);

      if (error) {
        console.error('Error creating shop:', error);
        const errorMessage = error.message.includes('unique_shop_per_business') 
          ? "You can only create one shop per business registration."
          : "Failed to create shop.";
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
        return false;
      } else {
        toast({
          title: "Success",
          description: "Shop created successfully!",
        });
        setShowShopForm(false);
        fetchUserShops();
        return true;
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      return false;
    } finally {
      setIsSubmittingShop(false);
    }
  };

  const handleDeleteShop = async (shopId: string) => {
    if (!confirm('Are you sure you want to delete this shop? This will also delete all products.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('provider_shops')
        .delete()
        .eq('id', shopId);

      if (error) {
        console.error('Error deleting shop:', error);
        toast({
          title: "Error",
          description: "Failed to delete shop.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Success",
          description: "Shop deleted successfully.",
        });
        fetchUserShops();
      }
    } catch (error) {
      console.error('Unexpected error:', error);
    }
  };

  const handleBannerUpload = async (shopId: string, file: File) => {
    if (!file || !file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "Please select a valid image file.",
        variant: "destructive",
      });
      return;
    }

    setUploadingBanner(shopId);
    try {
      // Create unique filename with proper folder structure
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `shop-banners/${shopId}/${fileName}`;

      // Upload file to Supabase Storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('business-documents')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw new Error(`Upload failed: ${uploadError.message}`);
      }

      // Get public URL
      const { data } = supabase.storage
        .from('business-documents')
        .getPublicUrl(filePath);

      if (!data.publicUrl) {
        throw new Error('Failed to get public URL');
      }

      // Update shop with new banner image
      const currentShop = shops.find(s => s.id === shopId);
      if (!currentShop) {
        throw new Error('Shop not found');
      }

      const updatedImages = [data.publicUrl, ...(currentShop.images || []).slice(1)];

      const { error: updateError } = await supabase
        .from('provider_shops')
        .update({ images: updatedImages })
        .eq('id', shopId);

      if (updateError) {
        console.error('Database update error:', updateError);
        throw new Error(`Database update failed: ${updateError.message}`);
      }

      toast({
        title: "Success",
        description: "Shop banner uploaded successfully!",
      });

      // Refresh shops data
      fetchUserShops();
    } catch (error: any) {
      console.error('Error uploading banner:', error);
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload banner. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingBanner(null);
    }
  };

  const handleLogoUpload = async (shopId: string, file: File) => {
    if (!file || !file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "Please select a valid image file.",
        variant: "destructive",
      });
      return;
    }

    setUploadingLogo(shopId);
    try {
      // Create unique filename with proper folder structure
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `shop-logos/${shopId}/${fileName}`;

      // Upload file to Supabase Storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('business-documents')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw new Error(`Upload failed: ${uploadError.message}`);
      }

      // Get public URL
      const { data } = supabase.storage
        .from('business-documents')
        .getPublicUrl(filePath);

      if (!data.publicUrl) {
        throw new Error('Failed to get public URL');
      }

      // Update shop with new logo
      const { error: updateError } = await supabase
        .from('provider_shops')
        .update({ logo_url: data.publicUrl })
        .eq('id', shopId);

      if (updateError) {
        console.error('Database update error:', updateError);
        throw new Error(`Database update failed: ${updateError.message}`);
      }

      toast({
        title: "Success",
        description: "Shop logo uploaded successfully!",
      });

      // Refresh shops data
      fetchUserShops();
    } catch (error: any) {
      console.error('Error uploading logo:', error);
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload logo. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingLogo(null);
    }
  };

  const triggerFileUpload = (shopId: string) => {
    if (fileInputRef.current) {
      fileInputRef.current.dataset.shopId = shopId;
      fileInputRef.current.click();
    }
  };

  const triggerLogoUpload = (shopId: string) => {
    if (logoInputRef.current) {
      logoInputRef.current.dataset.shopId = shopId;
      logoInputRef.current.click();
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    const shopId = event.target.dataset.shopId;
    
    if (file && shopId) {
      handleBannerUpload(shopId, file);
    }
    
    // Reset the input
    event.target.value = '';
  };

  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    const shopId = event.target.dataset.shopId;
    
    if (file && shopId) {
      handleLogoUpload(shopId, file);
    }
    
    // Reset the input
    event.target.value = '';
  };

  const getShopProducts = (shopId: string) => {
    return products.filter(product => product.shop_id === shopId);
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
            <p className="mt-4 text-muted-foreground">Loading your shops...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24 sm:pb-8">
      <Header />
      <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Shop Management</h1>
          <p className="text-muted-foreground">Manage your vendor shop and products</p>
        </div>
        {shops.length === 0 && (
          <Button 
            onClick={() => setShowShopForm(true)}
            className="flex items-center gap-2 mt-4 md:mt-0"
          >
            <Plus className="h-4 w-4" />
            Create Your Shop
          </Button>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="shops" className="flex items-center gap-2">
            <Store className="h-4 w-4" />
            My Shop {shops.length > 0 && `(${shops.length})`}
          </TabsTrigger>
          <TabsTrigger value="products" className="flex items-center gap-2">
            <Package className="h-4 w-4" />
            All Products ({products.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="shops" className="space-y-6">
          {shops.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Store className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No shop yet</h3>
                <p className="text-muted-foreground text-center mb-4">
                  Create your shop to start selling construction materials and services.
                </p>
                <Button onClick={() => setShowShopForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Your Shop
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Single shop display */}
              {shops.map((shop) => {
                const shopProducts = getShopProducts(shop.id);
                return (
                  <Card key={shop.id} className="overflow-hidden">
                    <div className="relative group">
                      {shop.images && shop.images.length > 0 ? (
                        <>
                          <img 
                            src={shop.images[0]} 
                            alt={shop.shop_name}
                            className="w-full h-48 object-cover"
                          />
                          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <Button
                              size="sm"
                              variant="secondary"
                              onClick={() => triggerFileUpload(shop.id)}
                              disabled={uploadingBanner === shop.id}
                              className="gap-2"
                            >
                              {uploadingBanner === shop.id ? (
                                <>
                                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current"></div>
                                  Uploading...
                                </>
                              ) : (
                                <>
                                  <Camera className="h-4 w-4" />
                                  Change Banner
                                </>
                              )}
                            </Button>
                          </div>
                        </>
                      ) : (
                        <div className="w-full h-48 bg-muted flex items-center justify-center relative group cursor-pointer" onClick={() => triggerFileUpload(shop.id)}>
                          {uploadingBanner === shop.id ? (
                            <div className="text-center">
                              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-current mx-auto mb-2"></div>
                              <p className="text-sm text-muted-foreground">Uploading...</p>
                            </div>
                          ) : (
                            <div className="text-center">
                              <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                              <p className="text-sm text-muted-foreground">Click to upload banner</p>
                            </div>
                          )}
                        </div>
                      )}
                      {shop.featured && (
                        <Badge className="absolute top-2 right-2">Featured</Badge>
                      )}
                    </div>
                    
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {/* Shop Logo */}
                          <div className="relative group">
                            {shop.logo_url ? (
                              <>
                                <img 
                                  src={shop.logo_url} 
                                  alt={`${shop.shop_name} logo`}
                                  className="w-12 h-12 rounded-full object-cover border-2 border-background shadow-sm"
                                />
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-full flex items-center justify-center">
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => triggerLogoUpload(shop.id)}
                                    disabled={uploadingLogo === shop.id}
                                    className="p-1 h-auto text-white hover:text-white"
                                  >
                                    {uploadingLogo === shop.id ? (
                                      <div className="animate-spin rounded-full h-3 w-3 border border-white border-t-transparent"></div>
                                    ) : (
                                      <Camera className="h-3 w-3" />
                                    )}
                                  </Button>
                                </div>
                              </>
                            ) : (
                              <div 
                                className="w-12 h-12 rounded-full bg-muted flex items-center justify-center cursor-pointer hover:bg-muted/80 transition-colors border-2 border-dashed border-muted-foreground/30"
                                onClick={() => triggerLogoUpload(shop.id)}
                              >
                                {uploadingLogo === shop.id ? (
                                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-current border-t-transparent"></div>
                                ) : (
                                  <Upload className="h-4 w-4 text-muted-foreground" />
                                )}
                              </div>
                            )}
                          </div>
                          <span className="truncate">{shop.shop_name}</span>
                        </div>
                      </CardTitle>
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {shop.description}
                      </p>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <div className="flex flex-wrap gap-2">
                        {shop.categories.slice(0, 3).map((category, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {category}
                          </Badge>
                        ))}
                        {shop.categories.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{shop.categories.length - 3} more
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>{shopProducts.length} products</span>
                        <span>Min order: ₹{shop.min_order_value}</span>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="flex-1"
                          onClick={() => navigate(`/vendor-shop/${shop.id}`)}
                        >
                          <Eye className="h-3 w-3 mr-1" />
                          View Shop
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            setSelectedShop(shop);
                            setActiveTab('products');
                          }}
                        >
                          <Settings className="h-3 w-3 mr-1" />
                          Manage Products
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleDeleteShop(shop.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="products" className="space-y-6">
          <ProductManagement 
            shops={shops}
            selectedShop={selectedShop}
            onShopChange={setSelectedShop}
            onProductsUpdate={fetchUserShops}
          />
        </TabsContent>
      </Tabs>

      {/* Shop Creation Form */}
      {showShopForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-background rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <ShopCreationForm 
              onSubmit={handleShopCreated}
              isSubmitting={isSubmittingShop}
              onClose={() => setShowShopForm(false)}
            />
          </div>
        </div>
      )}

      {/* Hidden file inputs for uploads */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />
      <input
        ref={logoInputRef}
        type="file"
        accept="image/*"
        onChange={handleLogoChange}
        className="hidden"
      />
      </div>
      <Footer />
    </div>
  );
}
