import { supabase } from "@/integrations/supabase/client";

export async function saveChatMessage({
  role,
  content,
  session_id,
  user_id,
}: {
  role: string;
  content: string;
  session_id: string;
  user_id: string;
}) {
  const { data, error } = await supabase
    .from("chat_memory")
    .insert([{ role, content, session_id, user_id }]);

  return { data, error };
}
