export interface Customer {
  id: string;
  name: string;
  mobile_number: string;
  notes: string;
  registered: boolean;
  business_category: string;
  follow_up_date: string | null;
  created_at: string;
  updated_at: string;
  status: CustomerStatus;
  last_contact_date: string | null;
  call_count: number;
  whatsapp_sent: boolean;
  admin_id?: string;
  source?: string;
}

export type CustomerStatus = 
  | 'new'
  | 'contacted'
  | 'interested'
  | 'not_interested'
  | 'registered'
  | 'follow_up'
  | 'wrong_number'
  | 'busy'
  | 'call_later';

export type BusinessCategory = 
  | 'plumber'
  | 'contractor'
  | 'engineer'
  | 'architect'
  | 'manufacturer'
  | 'vendor'
  | 'other';

export interface CustomerStats {
  total: number;
  registered: number;
  interested: number;
  followUp: number;
  todayContacts: number;
}

export interface CustomerFilters {
  search: string;
  status: string;
  category: string;
  dateFrom: string | null;
  dateTo: string | null;
}
