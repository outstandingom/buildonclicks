export interface SeoProps {
  title?: string;
  description?: string;
  keywords?: string;
  canonical?: string;
  ogImage?: string;
  twitterCard?: 'summary' | 'summary_large_image' | 'app' | 'player';
  noindex?: boolean;
  structuredData?: object;
}

export interface StructuredDataProps {
  data: object;
}

export interface BreadcrumbItem {
  name: string;
  url: string;
}

export interface SeoConfig {
  site: {
    name: string;
    url: string;
    logo?: string;
    twitterHandle?: string;
  };
  defaults: {
    title: string;
    description: string;
    keywords: string;
    ogImage: string;
    twitterCard: string;
  };
}
