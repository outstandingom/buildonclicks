export function getChatSessionID() {
  let id = sessionStorage.getItem("chatSessionID");

  if (!id) {
    id = crypto.randomUUID();
    sessionStorage.setItem("chatSessionID", id);
  }

  return id;
}
