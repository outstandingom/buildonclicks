export const importCustomersFromCSV = (csvText: string): Partial<Customer>[] => {
  const lines = csvText.split('\n');
  const headers = lines[0].split(',').map(h => h.trim());
  
  return lines.slice(1).map(line => {
    const values = line.split(',');
    const customer: any = {};
    
    headers.forEach((header, index) => {
      customer[header] = values[index]?.trim() || '';
    });
    
    // Map your CSV columns to database columns
    return {
      name: customer['custmer name'] || customer['name'] || '',
      mobile_number: customer['number'] || customer['mobile'] || '',
      notes: customer['note'] || customer['notes'] || '',
      registered: customer['register']?.toLowerCase() === 'yes',
      business_category: 'other', // You can extract this from notes
      status: determineStatus(customer['note']),
      created_at: customer['date'] || new Date().toISOString()
    };
  });
};

const determineStatus = (note: string): CustomerStatus => {
  const noteLower = note?.toLowerCase() || '';
  
  if (noteLower.includes('registered')) return 'registered';
  if (noteLower.includes('intrested') || noteLower.includes('interested')) return 'interested';
  if (noteLower.includes('busy')) return 'busy';
  if (noteLower.includes('call')) return 'call_later';
  if (noteLower.includes('wrong')) return 'wrong_number';
  if (noteLower.includes('not intrested')) return 'not_interested';
  
  return 'new';
};
