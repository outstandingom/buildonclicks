export const generateSrcSet = (basePath: string, sizes: number[]): string => {
  return sizes.map(size => `${basePath}?w=${size} ${size}w`).join(', ');
};

export const getOptimizedImageUrl = (url: string, width?: number, quality = 85): string => {
  if (!url) return '';
  
  // For external URLs or already optimized images
  if (url.startsWith('http')) return url;
  
  // Add optimization parameters
  const separator = url.includes('?') ? '&' : '?';
  const params = [];
  
  if (width) params.push(`w=${width}`);
  params.push(`q=${quality}`);
  
  return params.length > 0 ? `${url}${separator}${params.join('&')}` : url;
};

export const imageSizes = {
  thumbnail: 150,
  small: 320,
  medium: 640,
  large: 1024,
  xlarge: 1280,
  hero: 1920,
};
