import { supabase } from '@/integrations/supabase/client';

export interface CreateNotificationParams {
  userId: string;
  title: string;
  message: string;
  type?: 'info' | 'success' | 'warning' | 'error';
}

export const createNotification = async (params: CreateNotificationParams) => {
  try {
    const { data, error } = await supabase.rpc('create_notification', {
      p_user_id: params.userId,
      p_title: params.title,
      p_message: params.message,
      p_type: params.type || 'info'
    });

    if (error) {
      console.error('Error creating notification:', error);
      return { success: false, error };
    }

    return { success: true, data };
  } catch (error) {
    console.error('Unexpected error creating notification:', error);
    return { success: false, error };
  }
};

// Helper functions for common notification scenarios
export const notificationTemplates = {
  // User notifications
  newBid: (projectTitle: string, professionalName: string) => ({
    title: 'New Bid Received',
    message: `${professionalName} has submitted a bid for your project "${projectTitle}". Review it now!`,
    type: 'info' as const
  }),

  bidAccepted: (projectTitle: string) => ({
    title: 'Bid Accepted!',
    message: `Congratulations! Your bid for "${projectTitle}" has been accepted. The client will contact you soon.`,
    type: 'success' as const
  }),

  bidRejected: (projectTitle: string) => ({
    title: 'Bid Update',
    message: `Your bid for "${projectTitle}" was not selected this time. Keep applying to more projects!`,
    type: 'info' as const
  }),

  projectUpdated: (projectTitle: string) => ({
    title: 'Project Updated',
    message: `The project "${projectTitle}" has been updated. Check the latest details.`,
    type: 'info' as const
  }),

  // Service provider notifications
  newRequirement: (serviceType: string, location: string) => ({
    title: 'New Requirement Posted',
    message: `A new ${serviceType} requirement has been posted in ${location}. Check it out!`,
    type: 'info' as const
  }),

  businessApproved: () => ({
    title: 'Business Registration Approved!',
    message: 'Congratulations! Your business registration has been approved. You can now start receiving client requirements.',
    type: 'success' as const
  }),

  businessRejected: (reason?: string) => ({
    title: 'Business Registration Update',
    message: `Your business registration needs attention. ${reason ? `Reason: ${reason}` : 'Please check your application and resubmit.'}`,
    type: 'warning' as const
  }),

  profileIncomplete: () => ({
    title: 'Complete Your Profile',
    message: 'Complete your profile to start receiving more client requirements and build trust with potential clients.',
    type: 'warning' as const
  }),

  // General notifications
  welcomeUser: () => ({
    title: 'Welcome to BuildOnClicks!',
    message: 'Welcome to our platform! Start by posting your first requirement or browsing professionals in your area.',
    type: 'success' as const
  }),

  welcomeProvider: () => ({
    title: 'Welcome to BuildOnClicks!',
    message: 'Welcome! Complete your business registration to start receiving client requirements and grow your business.',
    type: 'success' as const
  }),

  systemMaintenance: (date: string) => ({
    title: 'Scheduled Maintenance',
    message: `System maintenance is scheduled for ${date}. Some features may be temporarily unavailable.`,
    type: 'warning' as const
  }),

  paymentSuccess: (amount: string, service: string) => ({
    title: 'Payment Successful',
    message: `Your payment of ₹${amount} for ${service} has been processed successfully.`,
    type: 'success' as const
  }),

  paymentFailed: (amount: string, service: string) => ({
    title: 'Payment Failed',
    message: `Your payment of ₹${amount} for ${service} could not be processed. Please try again.`,
    type: 'error' as const
  }),

  reviewReceived: (projectTitle: string, rating: number) => ({
    title: 'New Review Received',
    message: `You received a ${rating}-star review for "${projectTitle}". Great work!`,
    type: 'success' as const
  }),

  messageReceived: (senderName: string) => ({
    title: 'New Message',
    message: `You have a new message from ${senderName}. Click to view.`,
    type: 'info' as const
  })
};

// Batch notification creation for multiple users
export const createBulkNotifications = async (notifications: CreateNotificationParams[]) => {
  try {
    const promises = notifications.map(notification => createNotification(notification));
    const results = await Promise.allSettled(promises);
    
    const successful = results.filter(result => result.status === 'fulfilled').length;
    const failed = results.filter(result => result.status === 'rejected').length;
    
    return {
      success: failed === 0,
      successful,
      failed,
      results
    };
  } catch (error) {
    console.error('Error creating bulk notifications:', error);
    return { success: false, error };
  }
};

// Auto-notification triggers
export const triggerAutoNotifications = {
  onUserSignup: async (userId: string, userType: 'user' | 'provider') => {
    const template = userType === 'user' 
      ? notificationTemplates.welcomeUser()
      : notificationTemplates.welcomeProvider();
    
    return createNotification({
      userId,
      ...template
    });
  },

  onBusinessApproval: async (userId: string, approved: boolean, reason?: string) => {
    const template = approved 
      ? notificationTemplates.businessApproved()
      : notificationTemplates.businessRejected(reason);
    
    return createNotification({
      userId,
      ...template
    });
  },

  onNewBid: async (projectOwnerId: string, projectTitle: string, professionalName: string) => {
    const template = notificationTemplates.newBid(projectTitle, professionalName);
    
    return createNotification({
      userId: projectOwnerId,
      ...template
    });
  },

  onBidStatusUpdate: async (bidderId: string, projectTitle: string, accepted: boolean) => {
    const template = accepted 
      ? notificationTemplates.bidAccepted(projectTitle)
      : notificationTemplates.bidRejected(projectTitle);
    
    return createNotification({
      userId: bidderId,
      ...template
    });
  },

  onNewRequirement: async (providerIds: string[], serviceType: string, location: string) => {
    const template = notificationTemplates.newRequirement(serviceType, location);
    
    const notifications = providerIds.map(userId => ({
      userId,
      ...template
    }));
    
    return createBulkNotifications(notifications);
  }
};