import { SeoConfig } from '../types/seo';

export const SEO_CONFIG: SeoConfig = {
  site: {
    name: "BuildOnClicks",
    url: "https://buildonclicks.com",
    logo: "https://i.ibb.co/yFX8Z8zJ/buildonclicklogo-removebg-preview.png",
    twitterHandle: "@buildonclicks"
  },
  defaults: {
    title: "BuildOnClicks - India's #1 Construction Platform",
    description: "Connect with verified construction professionals, contractors, architects and quality building materials in Bhopal. Your trusted construction partner.",
    keywords: "construction services, contractors, architects, building materials, construction professionals Bhopal",
    ogImage: "/src/assets/hero-construction.jpg",
    twitterCard: "summary_large_image"
  }
};

