
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, cookie',
  'Access-Control-Allow-Credentials': 'true',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get client IP address for rate limiting
    const clientIP = req.headers.get('x-forwarded-for')?.split(',')[0] || 
                     req.headers.get('x-real-ip') || 
                     'unknown'

    const { action, email, password, sessionToken } = await req.json()

    // Input validation
    if (action === 'login') {
      if (!email || !password || typeof email !== 'string' || typeof password !== 'string') {
        return new Response(
          JSON.stringify({ error: 'Invalid input parameters' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        )
      }
      
      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(email) || email.length > 255) {
        return new Response(
          JSON.stringify({ error: 'Invalid email format' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        )
      }
      
      // Validate password length
      if (password.length < 1 || password.length > 255) {
        return new Response(
          JSON.stringify({ error: 'Invalid password length' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        )
      }

      // Check rate limiting
      const { data: isBlocked } = await supabase
        .rpc('check_admin_rate_limit', { 
          p_email: email, 
          p_ip_address: clientIP 
        })

      if (isBlocked) {
        // Log failed attempt
        await supabase.rpc('log_admin_login_attempt', {
          p_email: email,
          p_ip_address: clientIP,
          p_success: false
        })
        
        return new Response(
          JSON.stringify({ error: 'Too many failed login attempts. Please try again in 15 minutes.' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 429 }
        )
      }
      
      // Verify admin credentials
      const { data: adminData, error: verifyError } = await supabase
        .rpc('verify_admin_credentials', { 
          p_email: email, 
          p_password: password 
        })

      if (verifyError || !adminData || adminData.length === 0) {
        // Log failed attempt
        await supabase.rpc('log_admin_login_attempt', {
          p_email: email,
          p_ip_address: clientIP,
          p_success: false
        })
        
        return new Response(
          JSON.stringify({ error: 'Authentication failed' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 401 }
        )
      }

      const admin = adminData[0]

      // Log successful attempt
      await supabase.rpc('log_admin_login_attempt', {
        p_email: email,
        p_ip_address: clientIP,
        p_success: true
      })

      // Create session
      const { data: sessionToken, error: sessionError } = await supabase
        .rpc('create_admin_session', { p_admin_id: admin.admin_id })

      if (sessionError) {
        return new Response(
          JSON.stringify({ error: 'Failed to create session' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
        )
      }

      // Set HTTP-only cookie with secure flags
      const isProduction = Deno.env.get('DENO_DEPLOYMENT_ID') !== undefined
      const cookieOptions = [
        `admin_session=${sessionToken}`,
        'Path=/',
        'HttpOnly',
        'SameSite=Lax',
        `Max-Age=${24 * 60 * 60}`,
        isProduction ? 'Secure' : ''
      ].filter(Boolean).join('; ')

      return new Response(
        JSON.stringify({ 
          success: true,
          session_token: sessionToken,
          admin: {
            id: admin.admin_id,
            email: admin.admin_email,
            name: admin.admin_name,
            role: admin.admin_role
          }
        }),
        { 
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'Set-Cookie': cookieOptions
          } 
        }
      )

    } else if (action === 'verify') {
      // Extract session token from cookie
      const cookieHeader = req.headers.get('Cookie') || ''
      const cookies = Object.fromEntries(
        cookieHeader.split('; ').map(c => {
          const [key, ...v] = c.split('=')
          return [key, v.join('=')]
        })
      )
      const cookieSessionToken = cookies['admin_session']

      // Also accept from body for backwards compatibility during migration
      const tokenToVerify = cookieSessionToken || sessionToken

      if (!tokenToVerify || typeof tokenToVerify !== 'string') {
        return new Response(
          JSON.stringify({ error: 'Invalid session token' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        )
      }
      
      // Verify session
      const { data: adminData, error: verifyError } = await supabase
        .rpc('verify_admin_session', { p_session_token: tokenToVerify })

      if (verifyError || !adminData || adminData.length === 0) {
        return new Response(
          JSON.stringify({ error: 'Invalid or expired session' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 401 }
        )
      }

      const admin = adminData[0]

      return new Response(
        JSON.stringify({ 
          success: true,
          admin: {
            id: admin.admin_id,
            email: admin.admin_email,
            name: admin.admin_name,
            role: admin.admin_role
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )

    } else if (action === 'logout') {
      // Extract session token from cookie
      const cookieHeader = req.headers.get('Cookie') || ''
      const cookies = Object.fromEntries(
        cookieHeader.split('; ').map(c => {
          const [key, ...v] = c.split('=')
          return [key, v.join('=')]
        })
      )
      const cookieSessionToken = cookies['admin_session']

      // Also accept from body for backwards compatibility
      const tokenToDelete = cookieSessionToken || sessionToken

      if (!tokenToDelete || typeof tokenToDelete !== 'string') {
        return new Response(
          JSON.stringify({ error: 'Invalid session token' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        )
      }
      
      // Delete session
      await supabase
        .from('admin_sessions')
        .delete()
        .eq('session_token', tokenToDelete)

      // Clear cookie
      const clearCookie = 'admin_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'

      return new Response(
        JSON.stringify({ success: true }),
        { 
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'Set-Cookie': clearCookie
          } 
        }
      )
    }

    return new Response(
      JSON.stringify({ error: 'Invalid action' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    )

  } catch (error) {
    console.error('Admin auth error:', error)
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    )
  }
})
