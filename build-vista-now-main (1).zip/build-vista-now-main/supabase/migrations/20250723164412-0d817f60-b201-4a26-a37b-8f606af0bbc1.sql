
-- Create cities table for dropdown selection
CREATE TABLE public.cities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  state TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Insert some sample cities
INSERT INTO public.cities (name, state) VALUES
  ('Mumbai', 'Maharashtra'),
  ('Delhi', 'Delhi'),
  ('Bangalore', 'Karnataka'),
  ('Pune', 'Maharashtra'),
  ('Chennai', 'Tamil Nadu'),
  ('Hyderabad', 'Telangana'),
  ('Kolkata', 'West Bengal'),
  ('Ahmedabad', 'Gujarat'),
  ('Surat', 'Gujarat'),
  ('Jaipur', 'Rajasthan');

-- Create profiles table to extend auth.users
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  mobile_number TEXT,
  city_id UUID REFERENCES public.cities(id),
  address TEXT,
  profile_image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create professionals table
CREATE TABLE public.professionals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  business_name TEXT,
  type TEXT NOT NULL CHECK (type IN ('contractor', 'vendor', 'architect')),
  city_id UUID REFERENCES public.cities(id),
  rating DECIMAL(2,1) DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  review_count INTEGER DEFAULT 0,
  profile_image_url TEXT,
  experience INTEGER DEFAULT 0,
  is_verified BOOLEAN DEFAULT false,
  phone TEXT,
  email TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create saved_professionals table for user bookmarks
CREATE TABLE public.saved_professionals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  professional_id UUID REFERENCES public.professionals(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(user_id, professional_id)
);

-- Enable RLS on all tables
ALTER TABLE public.cities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.professionals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_professionals ENABLE ROW LEVEL SECURITY;

-- RLS Policies for cities (public read access)
CREATE POLICY "Cities are publicly readable" ON public.cities
  FOR SELECT USING (true);

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- RLS Policies for professionals (public read access)
CREATE POLICY "Professionals are publicly readable" ON public.professionals
  FOR SELECT USING (true);

-- RLS Policies for saved_professionals
CREATE POLICY "Users can view their own saved professionals" ON public.saved_professionals
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own saved professionals" ON public.saved_professionals
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own saved professionals" ON public.saved_professionals
  FOR DELETE USING (auth.uid() = user_id);

-- Insert sample professionals data
INSERT INTO public.professionals (name, business_name, type, city_id, rating, review_count, experience, is_verified, phone, email, description) VALUES
  ('Rajesh Kumar', 'Kumar Construction', 'contractor', (SELECT id FROM public.cities WHERE name = 'Mumbai'), 4.5, 23, 8, true, '+91-9876543210', 'rajesh@kumarconstruction.com', 'Specializing in residential and commercial construction with over 8 years of experience.'),
  ('Priya Sharma', 'Elite Architects', 'architect', (SELECT id FROM public.cities WHERE name = 'Delhi'), 4.8, 35, 12, true, '+91-9876543211', 'priya@elitearchitects.com', 'Award-winning architect with expertise in modern sustainable design.'),
  ('Amit Patel', 'Patel Building Materials', 'vendor', (SELECT id FROM public.cities WHERE name = 'Bangalore'), 4.2, 18, 5, false, '+91-9876543212', 'amit@patelmaterials.com', 'Supplier of high-quality building materials and construction equipment.'),
  ('Sunita Reddy', 'Metro Constructions', 'contractor', (SELECT id FROM public.cities WHERE name = 'Hyderabad'), 4.6, 41, 15, true, '+91-9876543213', 'sunita@metroconstructions.com', 'Leading contractor specializing in large-scale infrastructure projects.'),
  ('Vikram Singh', 'Singh Interiors', 'vendor', (SELECT id FROM public.cities WHERE name = 'Pune'), 4.3, 27, 7, true, '+91-9876543214', 'vikram@singhinteriors.com', 'Premium interior design solutions and home furnishing vendor.');

-- Create trigger to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_profiles_updated_at 
  BEFORE UPDATE ON public.profiles 
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

CREATE TRIGGER update_professionals_updated_at 
  BEFORE UPDATE ON public.professionals 
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- Function to handle new user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, NEW.raw_user_meta_data->>'full_name');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create profile when user signs up
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();
