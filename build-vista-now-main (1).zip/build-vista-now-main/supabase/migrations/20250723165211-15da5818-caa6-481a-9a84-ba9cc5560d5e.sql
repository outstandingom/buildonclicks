
-- Create business_types table for dropdown selection
CREATE TABLE public.business_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Insert business types
INSERT INTO public.business_types (name) VALUES
  ('Contractor'),
  ('Architect'),
  ('Material Supplier'),
  ('Interior Designer'),
  ('Structural Engineer'),
  ('Electrical Contractor'),
  ('Plumbing Contractor'),
  ('Landscaping'),
  ('Other');

-- Create business_registrations table
CREATE TABLE public.business_registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  
  -- Business Information
  business_name TEXT NOT NULL,
  business_type_id UUID REFERENCES public.business_types(id),
  registration_number TEXT NOT NULL,
  vat_gst_number TEXT,
  website TEXT,
  business_license_url TEXT,
  business_address TEXT NOT NULL,
  cities_served TEXT[] NOT NULL,
  service_area TEXT NOT NULL,
  years_in_business INTEGER NOT NULL DEFAULT 0,
  about_services TEXT NOT NULL,
  
  -- Contact Information
  contact_name TEXT NOT NULL,
  phone_number TEXT NOT NULL,
  email_address TEXT NOT NULL,
  alternate_contact TEXT,
  preferred_communication TEXT NOT NULL,
  
  -- Social Media
  linkedin_profile TEXT,
  facebook_page TEXT,
  instagram_handle TEXT,
  other_links TEXT[],
  
  -- Documents
  government_id_url TEXT NOT NULL,
  business_certificate_url TEXT NOT NULL,
  insurance_certificate_url TEXT,
  
  -- Banking
  bank_name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  account_type TEXT NOT NULL,
  ifsc_code TEXT,
  
  -- Status and timestamps
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  admin_notes TEXT,
  submitted_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on business_types and business_registrations
ALTER TABLE public.business_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_registrations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for business_types (public read access)
CREATE POLICY "Business types are publicly readable" ON public.business_types
  FOR SELECT USING (true);

-- RLS Policies for business_registrations
CREATE POLICY "Users can view their own business registrations" ON public.business_registrations
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own business registrations" ON public.business_registrations
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own business registrations" ON public.business_registrations
  FOR UPDATE USING (auth.uid() = user_id);

-- Admin policies (for future admin functionality)
CREATE POLICY "Admins can view all business registrations" ON public.business_registrations
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.profiles 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Create trigger to update updated_at timestamp
CREATE TRIGGER update_business_registrations_updated_at 
  BEFORE UPDATE ON public.business_registrations 
  FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- Add role column to profiles table for admin functionality
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin', 'business'));
