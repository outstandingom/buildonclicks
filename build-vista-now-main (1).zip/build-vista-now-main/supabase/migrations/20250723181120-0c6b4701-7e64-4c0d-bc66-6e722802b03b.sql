
-- Create business_types table
CREATE TABLE IF NOT EXISTS public.business_types (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create business_registrations table
CREATE TABLE IF NOT EXISTS public.business_registrations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  business_name TEXT NOT NULL,
  business_type_id UUID REFERENCES public.business_types(id) NOT NULL,
  registration_number TEXT NOT NULL,
  vat_gst_number TEXT,
  website TEXT,
  business_license_url TEXT NOT NULL,
  business_address TEXT NOT NULL,
  cities_served TEXT[] NOT NULL,
  service_area TEXT NOT NULL,
  years_in_business INTEGER NOT NULL,
  about_services TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  phone_number TEXT NOT NULL,
  email_address TEXT NOT NULL,
  alternate_contact TEXT,
  preferred_communication TEXT NOT NULL,
  linkedin_profile TEXT,
  facebook_page TEXT,
  instagram_handle TEXT,
  other_links TEXT[],
  government_id_url TEXT NOT NULL,
  business_certificate_url TEXT NOT NULL,
  insurance_certificate_url TEXT,
  bank_name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  account_type TEXT NOT NULL,
  ifsc_code TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Insert some default business types
INSERT INTO public.business_types (name) VALUES 
  ('Construction Company'),
  ('Electrical Contractor'),
  ('Plumbing Services'),
  ('Painting Services'),
  ('Roofing Contractor'),
  ('Landscaping Services'),
  ('Interior Design'),
  ('Architecture Firm'),
  ('Engineering Services'),
  ('General Contractor')
ON CONFLICT (name) DO NOTHING;

-- Enable RLS on business_registrations
ALTER TABLE public.business_registrations ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for business_registrations
CREATE POLICY "Users can view their own registrations" 
  ON public.business_registrations 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own registrations" 
  ON public.business_registrations 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own registrations" 
  ON public.business_registrations 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Enable RLS on business_types (read-only for all users)
ALTER TABLE public.business_types ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Business types are publicly readable" 
  ON public.business_types 
  FOR SELECT 
  USING (true);

-- Create RPC function to get business types
CREATE OR REPLACE FUNCTION public.get_business_types()
RETURNS TABLE(id UUID, name TEXT)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT bt.id, bt.name
  FROM public.business_types bt
  ORDER BY bt.name;
END;
$$;

-- Create RPC function to get business type ID by name
CREATE OR REPLACE FUNCTION public.get_business_type_id(type_name TEXT)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  type_id UUID;
BEGIN
  SELECT id INTO type_id
  FROM public.business_types
  WHERE name = type_name;
  
  RETURN type_id;
END;
$$;

-- Create RPC function to insert business registration
CREATE OR REPLACE FUNCTION public.insert_business_registration(registration_data JSONB)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.business_registrations (
    user_id, business_name, business_type_id, registration_number,
    vat_gst_number, website, business_license_url, business_address,
    cities_served, service_area, years_in_business, about_services,
    contact_name, phone_number, email_address, alternate_contact,
    preferred_communication, linkedin_profile, facebook_page,
    instagram_handle, other_links, government_id_url,
    business_certificate_url, insurance_certificate_url,
    bank_name, account_number, account_type, ifsc_code
  ) VALUES (
    (registration_data->>'user_id')::UUID,
    registration_data->>'business_name',
    (registration_data->>'business_type_id')::UUID,
    registration_data->>'registration_number',
    registration_data->>'vat_gst_number',
    registration_data->>'website',
    registration_data->>'business_license_url',
    registration_data->>'business_address',
    ARRAY(SELECT jsonb_array_elements_text(registration_data->'cities_served')),
    registration_data->>'service_area',
    (registration_data->>'years_in_business')::INTEGER,
    registration_data->>'about_services',
    registration_data->>'contact_name',
    registration_data->>'phone_number',
    registration_data->>'email_address',
    registration_data->>'alternate_contact',
    registration_data->>'preferred_communication',
    registration_data->>'linkedin_profile',
    registration_data->>'facebook_page',
    registration_data->>'instagram_handle',
    CASE 
      WHEN registration_data->'other_links' IS NOT NULL 
      THEN ARRAY(SELECT jsonb_array_elements_text(registration_data->'other_links'))
      ELSE NULL 
    END,
    registration_data->>'government_id_url',
    registration_data->>'business_certificate_url',
    registration_data->>'insurance_certificate_url',
    registration_data->>'bank_name',
    registration_data->>'account_number',
    registration_data->>'account_type',
    registration_data->>'ifsc_code'
  );
END;
$$;

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE TRIGGER update_business_registrations_updated_at
  BEFORE UPDATE ON public.business_registrations
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
