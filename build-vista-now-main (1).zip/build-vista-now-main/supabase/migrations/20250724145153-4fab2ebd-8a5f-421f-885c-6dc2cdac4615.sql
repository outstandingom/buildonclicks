
-- Create admin_users table for admin authentication
CREATE TABLE public.admin_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_login TIMESTAMP WITH TIME ZONE
);

-- Enable RLS on admin_users table
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

-- Create policy for admin users to view their own data
CREATE POLICY "Admins can view their own data" 
  ON public.admin_users 
  FOR SELECT 
  USING (auth.uid()::text = id::text);

-- Create policy for admin users to update their own data
CREATE POLICY "Admins can update their own data" 
  ON public.admin_users 
  FOR UPDATE 
  USING (auth.uid()::text = id::text);

-- Create admin_sessions table for session management
CREATE TABLE public.admin_sessions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  admin_id UUID NOT NULL REFERENCES public.admin_users(id) ON DELETE CASCADE,
  session_token TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on admin_sessions table
ALTER TABLE public.admin_sessions ENABLE ROW LEVEL SECURITY;

-- Create policy for admin sessions
CREATE POLICY "Admins can view their own sessions" 
  ON public.admin_sessions 
  FOR SELECT 
  USING (admin_id::text = auth.uid()::text);

-- Create function to verify admin credentials
CREATE OR REPLACE FUNCTION public.verify_admin_credentials(p_email TEXT, p_password TEXT)
RETURNS TABLE(admin_id UUID, admin_email TEXT, admin_name TEXT, admin_role TEXT)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  stored_hash TEXT;
  admin_record RECORD;
BEGIN
  -- Get admin user record
  SELECT id, email, password_hash, full_name, role, is_active
  INTO admin_record
  FROM public.admin_users
  WHERE email = p_email AND is_active = true;
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Verify password (simplified - in production use proper hashing)
  IF admin_record.password_hash = crypt(p_password, admin_record.password_hash) THEN
    -- Update last login
    UPDATE public.admin_users 
    SET last_login = now() 
    WHERE id = admin_record.id;
    
    -- Return admin info
    RETURN QUERY SELECT 
      admin_record.id,
      admin_record.email,
      admin_record.full_name,
      admin_record.role;
  END IF;
END;
$$;

-- Create function to create admin session
CREATE OR REPLACE FUNCTION public.create_admin_session(p_admin_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  session_token TEXT;
BEGIN
  -- Generate session token
  session_token := encode(gen_random_bytes(32), 'base64');
  
  -- Insert session
  INSERT INTO public.admin_sessions (admin_id, session_token, expires_at)
  VALUES (p_admin_id, session_token, now() + interval '24 hours');
  
  RETURN session_token;
END;
$$;

-- Create function to verify admin session
CREATE OR REPLACE FUNCTION public.verify_admin_session(p_session_token TEXT)
RETURNS TABLE(admin_id UUID, admin_email TEXT, admin_name TEXT, admin_role TEXT)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  session_record RECORD;
  admin_record RECORD;
BEGIN
  -- Get session record
  SELECT admin_id, expires_at
  INTO session_record
  FROM public.admin_sessions
  WHERE session_token = p_session_token AND expires_at > now();
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Get admin record
  SELECT id, email, full_name, role
  INTO admin_record
  FROM public.admin_users
  WHERE id = session_record.admin_id AND is_active = true;
  
  IF FOUND THEN
    RETURN QUERY SELECT 
      admin_record.id,
      admin_record.email,
      admin_record.full_name,
      admin_record.role;
  END IF;
END;
$$;

-- Insert a default admin user (password: admin123)
-- In production, use proper password hashing
INSERT INTO public.admin_users (email, password_hash, full_name, role)
VALUES ('admin@buildonclick.com', crypt('admin123', gen_salt('bf')), 'System Administrator', 'admin');
