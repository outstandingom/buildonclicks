
-- Create admin dashboard functions to get real statistics and data

-- Function to get dashboard statistics
CREATE OR REPLACE FUNCTION public.get_admin_dashboard_stats()
RETURNS TABLE(
  total_users BIGINT,
  approved_vendors BIGINT,
  pending_requests BIGINT,
  total_posts BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    (SELECT COUNT(*) FROM public.profiles) as total_users,
    (SELECT COUNT(*) FROM public.business_registrations WHERE status = 'approved') as approved_vendors,
    (SELECT COUNT(*) FROM public.business_registrations WHERE status = 'pending') as pending_requests,
    (SELECT COUNT(*) FROM public.projects) as total_posts;
END;
$$;

-- Function to get recent activity for admin dashboard
CREATE OR REPLACE FUNCTION public.get_admin_recent_activity()
RETURNS TABLE(
  activity_type TEXT,
  user_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  description TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  WITH recent_activities AS (
    -- Recent business registrations
    SELECT 
      'vendor_registration' as activity_type,
      br.business_name as user_name,
      br.created_at,
      'New vendor registration' as description
    FROM public.business_registrations br
    WHERE br.created_at > now() - interval '7 days'
    
    UNION ALL
    
    -- Recent user registrations
    SELECT 
      'user_registration' as activity_type,
      COALESCE(p.full_name, 'Unknown User') as user_name,
      p.created_at,
      'New user account created' as description
    FROM public.profiles p
    WHERE p.created_at > now() - interval '7 days'
    
    UNION ALL
    
    -- Recent projects
    SELECT 
      'project_posted' as activity_type,
      pr.title as user_name,
      pr.created_at,
      'New project posted' as description
    FROM public.projects pr
    WHERE pr.created_at > now() - interval '7 days'
  )
  SELECT ra.activity_type, ra.user_name, ra.created_at, ra.description
  FROM recent_activities ra
  ORDER BY ra.created_at DESC
  LIMIT 10;
END;
$$;

-- Function to get pending business registrations for admin approval
CREATE OR REPLACE FUNCTION public.get_pending_business_registrations()
RETURNS TABLE(
  id UUID,
  business_name TEXT,
  business_type TEXT,
  contact_name TEXT,
  email_address TEXT,
  phone_number TEXT,
  cities_served TEXT[],
  created_at TIMESTAMP WITH TIME ZONE,
  status TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    br.id,
    br.business_name,
    bt.name as business_type,
    br.contact_name,
    br.email_address,
    br.phone_number,
    br.cities_served,
    br.created_at,
    br.status
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.status = 'pending'
  ORDER BY br.created_at DESC;
END;
$$;

-- Function to update business registration status
CREATE OR REPLACE FUNCTION public.update_business_registration_status(
  registration_id UUID,
  new_status TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.business_registrations 
  SET status = new_status, updated_at = now()
  WHERE id = registration_id;
  
  RETURN FOUND;
END;
$$;

-- Function to get user management data
CREATE OR REPLACE FUNCTION public.get_users_for_admin()
RETURNS TABLE(
  id UUID,
  full_name TEXT,
  user_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  city_name TEXT,
  is_active BOOLEAN
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    COALESCE(p.full_name, 'Unknown User') as full_name,
    COALESCE(p.user_type, 'user') as user_type,
    p.created_at,
    c.name as city_name,
    true as is_active -- We don't have an is_active field in profiles, defaulting to true
  FROM public.profiles p
  LEFT JOIN public.cities c ON p.city_id = c.id
  ORDER BY p.created_at DESC;
END;
$$;

-- Function to get projects for post moderation
CREATE OR REPLACE FUNCTION public.get_projects_for_moderation()
RETURNS TABLE(
  id UUID,
  title TEXT,
  description TEXT,
  user_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  status TEXT,
  project_type TEXT,
  budget_range TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pr.id,
    pr.title,
    pr.description,
    COALESCE(p.full_name, 'Unknown User') as user_name,
    pr.created_at,
    pr.status,
    pr.project_type,
    pr.budget_range
  FROM public.projects pr
  LEFT JOIN public.profiles p ON pr.user_id = p.id
  ORDER BY pr.created_at DESC;
END;
$$;
