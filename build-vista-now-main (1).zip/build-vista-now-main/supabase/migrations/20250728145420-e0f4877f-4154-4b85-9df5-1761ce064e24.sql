
-- Create provider_shops table
CREATE TABLE public.provider_shops (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  business_registration_id UUID NOT NULL,
  shop_name TEXT NOT NULL,
  description TEXT NOT NULL,
  categories TEXT[] NOT NULL DEFAULT '{}',
  working_hours TEXT NOT NULL,
  delivery_options TEXT[] NOT NULL DEFAULT '{}',
  min_order_value NUMERIC,
  images TEXT[] NOT NULL DEFAULT '{}',
  featured BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT fk_provider_shops_business_registration 
    FOREIGN KEY (business_registration_id) 
    REFERENCES public.business_registrations(id) 
    ON DELETE CASCADE
);

-- Create provider_portfolios table
CREATE TABLE public.provider_portfolios (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  business_registration_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  services TEXT[] NOT NULL DEFAULT '{}',
  skills TEXT[] NOT NULL DEFAULT '{}',
  experience TEXT NOT NULL,
  projects JSONB NOT NULL DEFAULT '[]',
  certifications TEXT[] NOT NULL DEFAULT '{}',
  images TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT fk_provider_portfolios_business_registration 
    FOREIGN KEY (business_registration_id) 
    REFERENCES public.business_registrations(id) 
    ON DELETE CASCADE
);

-- Add RLS policies for provider_shops
ALTER TABLE public.provider_shops ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Shops are publicly readable" 
  ON public.provider_shops 
  FOR SELECT 
  USING (true);

CREATE POLICY "Business owners can manage their shops" 
  ON public.provider_shops 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM public.business_registrations br 
      WHERE br.id = provider_shops.business_registration_id 
      AND br.user_id = auth.uid()
    )
  );

-- Add RLS policies for provider_portfolios
ALTER TABLE public.provider_portfolios ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Portfolios are publicly readable" 
  ON public.provider_portfolios 
  FOR SELECT 
  USING (true);

CREATE POLICY "Business owners can manage their portfolios" 
  ON public.provider_portfolios 
  FOR ALL 
  USING (
    EXISTS (
      SELECT 1 FROM public.business_registrations br 
      WHERE br.id = provider_portfolios.business_registration_id 
      AND br.user_id = auth.uid()
    )
  );

-- Add triggers for updated_at
CREATE TRIGGER update_provider_shops_updated_at
  BEFORE UPDATE ON public.provider_shops
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_provider_portfolios_updated_at
  BEFORE UPDATE ON public.provider_portfolios
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
