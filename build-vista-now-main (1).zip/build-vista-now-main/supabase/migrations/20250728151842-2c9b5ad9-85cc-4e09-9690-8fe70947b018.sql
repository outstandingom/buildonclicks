-- Create products table for vendor shops
CREATE TABLE public.shop_products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  shop_id UUID NOT NULL REFERENCES public.provider_shops(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10,2) NOT NULL,
  unit TEXT NOT NULL DEFAULT 'piece', -- kg, ton, piece, etc.
  category TEXT NOT NULL,
  image_url TEXT,
  in_stock BOOLEAN NOT NULL DEFAULT true,
  min_order_quantity INTEGER DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.shop_products ENABLE ROW LEVEL SECURITY;

-- Create policies for shop products
CREATE POLICY "Shop products are publicly readable" 
ON public.shop_products 
FOR SELECT 
USING (true);

CREATE POLICY "Shop owners can manage their products" 
ON public.shop_products 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 
    FROM public.provider_shops ps
    JOIN public.business_registrations br ON ps.business_registration_id = br.id
    WHERE ps.id = shop_products.shop_id 
    AND br.user_id = auth.uid()
  )
);

-- Create trigger for automatic timestamp updates on products
CREATE TRIGGER update_shop_products_updated_at
BEFORE UPDATE ON public.shop_products
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add indexes for better performance
CREATE INDEX idx_shop_products_shop_id ON public.shop_products(shop_id);
CREATE INDEX idx_shop_products_category ON public.shop_products(category);
CREATE INDEX idx_shop_products_in_stock ON public.shop_products(in_stock);

-- Create some sample product categories for construction materials
INSERT INTO public.shop_products (shop_id, name, description, price, unit, category, in_stock, min_order_quantity)
SELECT 
  ps.id,
  product_data.name,
  product_data.description,
  product_data.price,
  product_data.unit,
  product_data.category,
  true,
  product_data.min_qty
FROM public.provider_shops ps
CROSS JOIN (
  VALUES 
    ('Red Bricks', 'High quality red clay bricks for construction', 8.50, 'piece', 'Bricks', 100),
    ('Portland Cement', 'Grade 53 OPC cement, 50kg bags', 450.00, 'bag', 'Cement', 10),
    ('TMT Steel Bars', '12mm Fe500 grade TMT bars', 65.00, 'kg', 'Steel', 100),
    ('River Sand', 'Clean washed river sand for construction', 1200.00, 'truck', 'Sand', 1),
    ('Concrete Blocks', 'AAC concrete blocks 600x200x100mm', 35.00, 'piece', 'Blocks', 50)
) AS product_data(name, description, price, unit, category, min_qty)
LIMIT 5; -- Only add to first shop for demo