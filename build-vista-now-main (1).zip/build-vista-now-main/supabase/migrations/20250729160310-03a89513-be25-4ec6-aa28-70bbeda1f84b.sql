-- Create provider_profiles table for role-based access control
CREATE TYPE public.provider_role AS ENUM ('vendor', 'contractor', 'architect');

CREATE TABLE public.provider_profiles (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  business_registration_id uuid REFERENCES public.business_registrations(id) ON DELETE CASCADE,
  role provider_role NOT NULL,
  approved boolean NOT NULL DEFAULT false,
  slug text UNIQUE,
  display_name text,
  bio text,
  phone text,
  whatsapp text,
  address_street text,
  address_city text,
  address_pincode text,
  working_hours jsonb,
  is_live boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE public.provider_profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own profile"
ON public.provider_profiles
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile" 
ON public.provider_profiles
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
ON public.provider_profiles
FOR UPDATE  
USING (auth.uid() = user_id);

CREATE POLICY "Approved profiles are publicly readable"
ON public.provider_profiles
FOR SELECT
USING (approved = true AND is_live = true);

-- Update trigger for timestamps
CREATE TRIGGER update_provider_profiles_updated_at
BEFORE UPDATE ON public.provider_profiles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Function to get current user role
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS provider_role
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT role FROM public.provider_profiles WHERE user_id = auth.uid();
$$;

-- Function to check if current user is approved
CREATE OR REPLACE FUNCTION public.is_current_user_approved()  
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT approved FROM public.provider_profiles WHERE user_id = auth.uid();
$$;