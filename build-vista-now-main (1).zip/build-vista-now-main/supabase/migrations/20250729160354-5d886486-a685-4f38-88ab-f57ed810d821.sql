-- Fix search path security issues for new functions
DROP FUNCTION IF EXISTS public.get_current_user_role();
DROP FUNCTION IF EXISTS public.is_current_user_approved();

-- Function to get current user role with proper search path
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS provider_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.provider_profiles WHERE user_id = auth.uid();
$$;

-- Function to check if current user is approved with proper search path
CREATE OR REPLACE FUNCTION public.is_current_user_approved()  
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT approved FROM public.provider_profiles WHERE user_id = auth.uid();
$$;