-- Add unique constraint to ensure one shop per business registration
ALTER TABLE public.provider_shops 
ADD CONSTRAINT unique_shop_per_business 
UNIQUE (business_registration_id);

-- Add comment to explain the constraint
COMMENT ON CONSTRAINT unique_shop_per_business ON public.provider_shops 
IS 'Ensures each business registration can only have one shop';