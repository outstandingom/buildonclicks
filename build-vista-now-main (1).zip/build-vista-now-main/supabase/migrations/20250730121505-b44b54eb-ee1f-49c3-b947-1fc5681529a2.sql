-- Insert some sample data into professionals table for testing
INSERT INTO public.professionals (
  name, business_name, type, city_id, rating, review_count, 
  experience, is_verified, email, phone, description
) VALUES 
  ('Rahul Steel Works', 'Rahul Steel Works Pvt Ltd', 'contractor', 
   (SELECT id FROM cities WHERE name = 'Mumbai' LIMIT 1), 
   4.8, 127, 8, true, 'contact@rahulsteel.com', '+91-9876543210', 
   'Specializing in steel construction and fabrication'),
   
  ('Premium Constructions', 'Premium Constructions Ltd', 'contractor', 
   (SELECT id FROM cities WHERE name = 'Delhi' LIMIT 1), 
   4.5, 89, 12, true, 'info@premiumconstructions.com', '+91-9876543211', 
   'High-quality residential and commercial construction'),
   
  ('Modern Architects Co.', 'Modern Architects Co.', 'architect', 
   (SELECT id FROM cities WHERE name = 'Bangalore' LIMIT 1), 
   4.9, 203, 15, true, 'design@modernarchitects.com', '+91-9876543212', 
   'Innovative architectural design and planning'),
   
  ('Quality Materials Ltd', 'Quality Materials Ltd', 'vendor', 
   (SELECT id FROM cities WHERE name = 'Pune' LIMIT 1), 
   4.7, 98, 6, true, 'sales@qualitymaterials.com', '+91-9876543213', 
   'Supplier of premium construction materials'),
   
  ('BuildMart Supplies', 'BuildMart Supplies', 'vendor', 
   (SELECT id FROM cities WHERE name = 'Chennai' LIMIT 1), 
   4.6, 134, 8, true, 'orders@buildmart.com', '+91-9876543214', 
   'One-stop shop for all construction supplies');

-- Add some cities if they don't exist
INSERT INTO public.cities (name, state) VALUES 
  ('Mumbai', 'Maharashtra'),
  ('Delhi', 'Delhi'),
  ('Bangalore', 'Karnataka'),
  ('Pune', 'Maharashtra'),
  ('Chennai', 'Tamil Nadu')
ON CONFLICT (name) DO NOTHING;