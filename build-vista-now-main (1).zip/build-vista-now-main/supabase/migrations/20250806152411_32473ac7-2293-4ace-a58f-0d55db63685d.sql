-- Create requirements table for construction marketplace
CREATE TABLE public.requirements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  service_type TEXT NOT NULL CHECK (service_type IN ('Contractor', 'Architect', 'Material Supplier', 'Interior Designer', 'Other')),
  city TEXT NOT NULL,
  description TEXT NOT NULL,
  timeline TEXT NOT NULL, -- 'ASAP' or specific date
  contact_preference TEXT NOT NULL CHECK (contact_preference IN ('Email', 'Phone', 'WhatsApp')),
  attachments JSONB DEFAULT '[]'::jsonb, -- Array of file URLs/info
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'closed', 'completed')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.requirements ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own requirements" 
ON public.requirements 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own requirements" 
ON public.requirements 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own requirements" 
ON public.requirements 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own requirements" 
ON public.requirements 
FOR DELETE 
USING (auth.uid() = user_id);

-- Service providers can view requirements that match their city and service type
CREATE POLICY "Providers can view matching requirements" 
ON public.requirements 
FOR SELECT 
USING (
  status = 'active' AND
  EXISTS (
    SELECT 1 FROM public.business_registrations br 
    WHERE br.user_id = auth.uid() 
    AND br.status = 'approved'
    AND requirements.city = ANY(br.cities_served)
  )
);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_requirements_updated_at
BEFORE UPDATE ON public.requirements
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create storage bucket for requirement attachments
INSERT INTO storage.buckets (id, name, public) VALUES ('requirement-attachments', 'requirement-attachments', false);

-- Create storage policies for requirement attachments
CREATE POLICY "Users can upload their own requirement attachments" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'requirement-attachments' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their own requirement attachments" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'requirement-attachments' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their own requirement attachments" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'requirement-attachments' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own requirement attachments" 
ON storage.objects 
FOR DELETE 
USING (bucket_id = 'requirement-attachments' AND auth.uid()::text = (storage.foldername(name))[1]);