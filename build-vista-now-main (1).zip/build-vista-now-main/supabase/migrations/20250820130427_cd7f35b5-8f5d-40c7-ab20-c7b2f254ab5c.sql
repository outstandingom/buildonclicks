-- Drop the existing check constraint
ALTER TABLE requirements DROP CONSTRAINT requirements_service_type_check;

-- Add the updated check constraint that includes 'Vendors'
ALTER TABLE requirements ADD CONSTRAINT requirements_service_type_check 
CHECK (service_type = ANY (ARRAY['Contractor'::text, 'Architect'::text, 'Material Supplier'::text, 'Vendors'::text, 'Interior Designer'::text, 'Other'::text]));