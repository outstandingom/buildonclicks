-- Add contact_info column to requirements table
ALTER TABLE requirements 
ADD COLUMN contact_info text;