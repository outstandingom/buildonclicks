-- Drop the existing restrictive policy
DROP POLICY IF EXISTS "Providers can view matching requirements" ON public.requirements;

-- Create a new policy that allows approved providers to see all active requirements
CREATE POLICY "Approved providers can view all active requirements" 
ON public.requirements 
FOR SELECT 
USING (
  status = 'active' AND 
  EXISTS (
    SELECT 1 
    FROM public.business_registrations br 
    WHERE br.user_id = auth.uid() 
    AND br.status = 'approved'
  )
);