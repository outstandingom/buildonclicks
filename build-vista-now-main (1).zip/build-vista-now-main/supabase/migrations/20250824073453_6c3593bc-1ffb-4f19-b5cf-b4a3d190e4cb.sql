-- Add sub_business_types column to business_registrations table
ALTER TABLE public.business_registrations 
ADD COLUMN sub_business_types TEXT[] DEFAULT '{}';

-- Insert predefined business types
INSERT INTO public.business_types (name) VALUES 
('Architects'),
('Designers'),
('Engineers'),
('Contractors'),
('Vendors')
ON CONFLICT (name) DO NOTHING;

-- Update business_registrations table comment
COMMENT ON COLUMN public.business_registrations.sub_business_types IS 'Array of selected sub-business types/specializations';