-- Create function to check for existing users during signup
CREATE OR REPLACE FUNCTION public.check_user_exists(
  p_email text,
  p_mobile text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  email_exists boolean := false;
  mobile_exists boolean := false;
  result jsonb;
BEGIN
  -- Check if mobile number exists in profiles
  SELECT EXISTS(
    SELECT 1 FROM public.profiles 
    WHERE mobile_number = p_mobile
  ) INTO mobile_exists;
  
  -- We can't directly check auth.users from here, but we can check profiles
  -- which should have all registered users due to the trigger
  -- For additional email check, we'll rely on the signup process to catch duplicates
  
  -- Build result object
  result := jsonb_build_object(
    'mobile_exists', mobile_exists,
    'email_exists', false  -- Will be checked during actual signup
  );
  
  RETURN result;
END;
$$;