-- Create function to get detailed business registration information
CREATE OR REPLACE FUNCTION public.get_business_registration_details(registration_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  registration_data jsonb;
BEGIN
  SELECT jsonb_build_object(
    'id', br.id,
    'business_name', br.business_name,
    'business_type', bt.name,
    'registration_number', br.registration_number,
    'vat_gst_number', br.vat_gst_number,
    'website', br.website,
    'business_license_url', br.business_license_url,
    'business_address', br.business_address,
    'cities_served', br.cities_served,
    'service_area', br.service_area,
    'years_in_business', br.years_in_business,
    'about_services', br.about_services,
    'contact_name', br.contact_name,
    'phone_number', br.phone_number,
    'email_address', br.email_address,
    'alternate_contact', br.alternate_contact,
    'preferred_communication', br.preferred_communication,
    'linkedin_profile', br.linkedin_profile,
    'facebook_page', br.facebook_page,
    'instagram_handle', br.instagram_handle,
    'other_links', br.other_links,
    'government_id_url', br.government_id_url,
    'business_certificate_url', br.business_certificate_url,
    'insurance_certificate_url', br.insurance_certificate_url,
    'bank_name', br.bank_name,
    'account_number', br.account_number,
    'account_type', br.account_type,
    'ifsc_code', br.ifsc_code,
    'sub_business_types', br.sub_business_types,
    'status', br.status,
    'created_at', br.created_at,
    'updated_at', br.updated_at
  )
  INTO registration_data
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.id = registration_id;
  
  RETURN registration_data;
END;
$$;