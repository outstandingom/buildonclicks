-- Ensure business-documents bucket exists and is public for shop banners
UPDATE storage.buckets 
SET public = true 
WHERE id = 'business-documents';

-- Create RLS policies for shop banner uploads
CREATE POLICY "Shop owners can upload banners" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'business-documents' 
  AND (storage.foldername(name))[1] = 'shop-banners'
  AND EXISTS (
    SELECT 1 FROM provider_shops ps
    JOIN business_registrations br ON ps.business_registration_id = br.id
    WHERE br.user_id = auth.uid()
    AND ps.id::text = (storage.foldername(name))[2]
  )
);

CREATE POLICY "Anyone can view shop banners" 
ON storage.objects 
FOR SELECT 
USING (
  bucket_id = 'business-documents' 
  AND (storage.foldername(name))[1] = 'shop-banners'
);

CREATE POLICY "Shop owners can update their banners" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'business-documents' 
  AND (storage.foldername(name))[1] = 'shop-banners'
  AND EXISTS (
    SELECT 1 FROM provider_shops ps
    JOIN business_registrations br ON ps.business_registration_id = br.id
    WHERE br.user_id = auth.uid()
    AND ps.id::text = (storage.foldername(name))[2]
  )
);

CREATE POLICY "Shop owners can delete their banners" 
ON storage.objects 
FOR DELETE 
USING (
  bucket_id = 'business-documents' 
  AND (storage.foldername(name))[1] = 'shop-banners'
  AND EXISTS (
    SELECT 1 FROM provider_shops ps
    JOIN business_registrations br ON ps.business_registration_id = br.id
    WHERE br.user_id = auth.uid()
    AND ps.id::text = (storage.foldername(name))[2]
  )
);