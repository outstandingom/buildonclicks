-- Add logo field to provider_shops table
ALTER TABLE public.provider_shops 
ADD COLUMN logo_url TEXT;