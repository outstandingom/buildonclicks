-- Create RLS policies for shop logo uploads
CREATE POLICY "Shop owners can upload logos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'business-documents' 
  AND (storage.foldername(name))[1] = 'shop-logos'
  AND EXISTS (
    SELECT 1 FROM provider_shops ps
    JOIN business_registrations br ON ps.business_registration_id = br.id
    WHERE br.user_id = auth.uid()
    AND ps.id::text = (storage.foldername(name))[2]
  )
);

CREATE POLICY "Anyone can view shop logos" 
ON storage.objects 
FOR SELECT 
USING (
  bucket_id = 'business-documents' 
  AND (storage.foldername(name))[1] = 'shop-logos'
);

CREATE POLICY "Shop owners can update their logos" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'business-documents' 
  AND (storage.foldername(name))[1] = 'shop-logos'
  AND EXISTS (
    SELECT 1 FROM provider_shops ps
    JOIN business_registrations br ON ps.business_registration_id = br.id
    WHERE br.user_id = auth.uid()
    AND ps.id::text = (storage.foldername(name))[2]
  )
);

CREATE POLICY "Shop owners can delete their logos" 
ON storage.objects 
FOR DELETE 
USING (
  bucket_id = 'business-documents' 
  AND (storage.foldername(name))[1] = 'shop-logos'
  AND EXISTS (
    SELECT 1 FROM provider_shops ps
    JOIN business_registrations br ON ps.business_registration_id = br.id
    WHERE br.user_id = auth.uid()
    AND ps.id::text = (storage.foldername(name))[2]
  )
);