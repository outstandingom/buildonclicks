-- Add rejection_reason column to business_registrations table
ALTER TABLE public.business_registrations 
ADD COLUMN IF NOT EXISTS rejection_reason TEXT;

-- Drop and recreate the function to handle rejection reasons
DROP FUNCTION IF EXISTS public.update_business_registration_status(uuid, text);

CREATE OR REPLACE FUNCTION public.update_business_registration_status(
  registration_id uuid, 
  new_status text,
  rejection_reason_param text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Update the registration status and rejection reason if provided
  UPDATE public.business_registrations 
  SET 
    status = new_status, 
    rejection_reason = CASE 
      WHEN new_status = 'rejected' AND rejection_reason_param IS NOT NULL 
      THEN rejection_reason_param 
      ELSE rejection_reason 
    END,
    updated_at = now()
  WHERE id = registration_id;
  
  RETURN FOUND;
END;
$$;

-- Drop and recreate the pending registrations function to include rejection_reason
DROP FUNCTION IF EXISTS public.get_pending_business_registrations();

CREATE OR REPLACE FUNCTION public.get_pending_business_registrations()
RETURNS TABLE(
  id uuid, 
  business_name text, 
  business_type text, 
  contact_name text, 
  email_address text, 
  phone_number text, 
  cities_served text[], 
  created_at timestamp with time zone, 
  status text,
  rejection_reason text
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    br.id,
    br.business_name,
    bt.name as business_type,
    br.contact_name,
    br.email_address,
    br.phone_number,
    br.cities_served,
    br.created_at,
    br.status,
    br.rejection_reason
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.status = 'pending'
  ORDER BY br.created_at DESC;
END;
$$;