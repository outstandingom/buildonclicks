-- Update the user_has_business_registration function to handle multiple registrations properly
CREATE OR REPLACE FUNCTION public.user_has_business_registration(user_uuid uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.business_registrations 
    WHERE user_id = user_uuid
    ORDER BY created_at DESC
    LIMIT 1
  );
END;
$$;

-- Clean up duplicate registrations by keeping only the most recent one per user
-- This is a one-time cleanup operation
DO $$
DECLARE
    rec RECORD;
BEGIN
    -- For each user with multiple registrations, keep only the most recent one
    FOR rec IN 
        SELECT user_id, COUNT(*) as count_registrations
        FROM public.business_registrations 
        GROUP BY user_id 
        HAVING COUNT(*) > 1
    LOOP
        -- Delete all but the most recent registration for this user
        DELETE FROM public.business_registrations 
        WHERE user_id = rec.user_id 
        AND id NOT IN (
            SELECT id 
            FROM public.business_registrations 
            WHERE user_id = rec.user_id 
            ORDER BY created_at DESC 
            LIMIT 1
        );
    END LOOP;
END $$;