-- Add policy to allow public read access to approved business registrations
CREATE POLICY "Approved business registrations are publicly readable" 
ON public.business_registrations 
FOR SELECT 
USING (status = 'approved');