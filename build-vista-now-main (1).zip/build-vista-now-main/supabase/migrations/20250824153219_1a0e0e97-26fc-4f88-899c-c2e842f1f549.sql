-- Create a function to check if an email exists in auth.users
CREATE OR REPLACE FUNCTION public.email_exists_in_auth(p_email text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Check if email exists in auth.users by trying to query the profiles table
  -- which is created for all auth users
  RETURN EXISTS (
    SELECT 1 FROM auth.users 
    WHERE email = p_email
  );
END;
$$;