-- Insert some sample notifications for testing
INSERT INTO public.notifications (user_id, title, message, type, read) VALUES
('2396b466-7cc4-4b2d-a17d-3b8eb32e3a5f', 'Welcome to the Platform!', 'Thank you for joining our platform. Start exploring to find the best professionals for your needs.', 'success', false),
('2396b466-7cc4-4b2d-a17d-3b8eb32e3a5f', 'Profile Update Required', 'Please complete your profile to get better recommendations and connect with professionals.', 'warning', false),
('2396b466-7cc4-4b2d-a17d-3b8eb32e3a5f', 'New Feature Available', 'Check out our new project bidding feature to get competitive quotes from multiple professionals.', 'info', true),
('2396b466-7cc4-4b2d-a17d-3b8eb32e3a5f', 'System Maintenance', 'Scheduled maintenance will occur tonight from 2 AM to 4 AM. Some features may be temporarily unavailable.', 'warning', true);

-- Update RLS policy to allow the create_notification function to insert
DROP POLICY IF EXISTS "Service role can insert notifications" ON public.notifications;
CREATE POLICY "Service role can insert notifications" 
ON public.notifications 
FOR INSERT 
TO service_role 
WITH CHECK (true);