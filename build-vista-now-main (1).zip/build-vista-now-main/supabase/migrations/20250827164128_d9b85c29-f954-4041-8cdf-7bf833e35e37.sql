-- Add sample notifications for the current logged-in user
INSERT INTO public.notifications (user_id, title, message, type, read) VALUES
('0f0862f0-d2d5-4a0f-8b45-6063ad1f980d', 'Business Registration Rejected', 'Your business registration has been rejected. Reason: Your document is not verified. Kindly resubmit the application. You can reapply after addressing the issues.', 'error', false),
('0f0862f0-d2d5-4a0f-8b45-6063ad1f980d', 'Welcome to BuildOnClick!', 'Thank you for joining our platform. Start exploring to find the best professionals for your needs.', 'success', false),
('0f0862f0-d2d5-4a0f-8b45-6063ad1f980d', 'Profile Update Required', 'Please complete your profile to get better recommendations and connect with professionals.', 'warning', true);