-- Add banner and logo fields to provider_portfolios table
ALTER TABLE public.provider_portfolios 
ADD COLUMN banner_url TEXT,
ADD COLUMN logo_url TEXT;