-- Create storage policies for portfolio banners and logos
-- Allow authenticated users to upload to portfolio folders
CREATE POLICY "Allow authenticated users to upload portfolio banners" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'business-documents' 
  AND auth.uid() IS NOT NULL 
  AND (storage.foldername(name))[1] = 'portfolio-banners'
);

CREATE POLICY "Allow authenticated users to upload portfolio logos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'business-documents' 
  AND auth.uid() IS NOT NULL 
  AND (storage.foldername(name))[1] = 'portfolio-logos'
);

-- Allow users to update their own portfolio images
CREATE POLICY "Allow users to update portfolio banners" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'business-documents' 
  AND auth.uid() IS NOT NULL 
  AND (storage.foldername(name))[1] = 'portfolio-banners'
);

CREATE POLICY "Allow users to update portfolio logos" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'business-documents' 
  AND auth.uid() IS NOT NULL 
  AND (storage.foldername(name))[1] = 'portfolio-logos'
);

-- Allow public access to view portfolio images
CREATE POLICY "Public access to portfolio banners" 
ON storage.objects 
FOR SELECT 
USING (
  bucket_id = 'business-documents' 
  AND (storage.foldername(name))[1] = 'portfolio-banners'
);

CREATE POLICY "Public access to portfolio logos" 
ON storage.objects 
FOR SELECT 
USING (
  bucket_id = 'business-documents' 
  AND (storage.foldername(name))[1] = 'portfolio-logos'
);