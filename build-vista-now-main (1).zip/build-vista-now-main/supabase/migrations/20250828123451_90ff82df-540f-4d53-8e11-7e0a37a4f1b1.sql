-- Add Manufacturer business type
INSERT INTO public.business_types (name) VALUES ('Manufacturer');

-- Update provider_role enum to include manufacturer
ALTER TYPE provider_role ADD VALUE IF NOT EXISTS 'manufacturer';