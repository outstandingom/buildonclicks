-- Fix critical security vulnerability in business_registrations table
-- Remove overly permissive public read access and create secure access patterns

-- First, drop the problematic policy that allows public access to ALL fields
DROP POLICY IF EXISTS "Approved business registrations are publicly readable" ON public.business_registrations;

-- Create a secure view that only exposes safe, non-sensitive business information publicly
CREATE OR REPLACE VIEW public.public_business_listings AS
SELECT 
  br.id,
  br.business_name,
  br.about_services,
  br.cities_served,
  br.service_area,
  br.years_in_business,
  br.website,
  br.sub_business_types,
  br.created_at,
  bt.name as business_type
FROM public.business_registrations br
LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
WHERE br.status = 'approved';

-- Enable RLS on the view
ALTER VIEW public.public_business_listings SET (security_barrier = true);

-- Create RLS policy for the view (publicly readable)
CREATE POLICY "Public business listings are readable by everyone" 
ON public.business_registrations 
FOR SELECT 
USING (false); -- This ensures the original table is not directly accessible

-- Create a new restricted policy for approved businesses that only allows specific safe fields
-- We'll handle this through the view instead of direct table access

-- Create a function to get safe business data for approved registrations
CREATE OR REPLACE FUNCTION public.get_approved_business_listing(business_id uuid)
RETURNS TABLE(
  id uuid,
  business_name text,
  about_services text,
  cities_served text[],
  service_area text,
  years_in_business integer,
  website text,
  sub_business_types text[],
  business_type text,
  created_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    br.id,
    br.business_name,
    br.about_services,
    br.cities_served,
    br.service_area,
    br.years_in_business,
    br.website,
    br.sub_business_types,
    bt.name as business_type,
    br.created_at
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.id = business_id AND br.status = 'approved';
END;
$$;

-- Create a function to get all approved business listings safely
CREATE OR REPLACE FUNCTION public.get_approved_business_listings()
RETURNS TABLE(
  id uuid,
  business_name text,
  about_services text,
  cities_served text[],
  service_area text,
  years_in_business integer,
  website text,
  sub_business_types text[],
  business_type text,
  created_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    br.id,
    br.business_name,
    br.about_services,
    br.cities_served,
    br.service_area,
    br.years_in_business,
    br.website,
    br.sub_business_types,
    bt.name as business_type,
    br.created_at
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.status = 'approved'
  ORDER BY br.created_at DESC;
END;
$$;

-- Grant execute permissions on the functions
GRANT EXECUTE ON FUNCTION public.get_approved_business_listing(uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_approved_business_listings() TO anon, authenticated;

-- Update the existing functions that might be using the old direct access pattern
-- Update get_pending_business_registrations to ensure it's admin-only
CREATE OR REPLACE FUNCTION public.get_pending_business_registrations()
RETURNS TABLE(
  id uuid,
  business_name text,
  business_type text,
  contact_name text,
  email_address text,
  phone_number text,
  cities_served text[],
  created_at timestamp with time zone,
  status text,
  rejection_reason text
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Ensure this function is only accessible by admin users
  -- You may need to implement admin role checking here
  RETURN QUERY
  SELECT 
    br.id,
    br.business_name,
    bt.name as business_type,
    br.contact_name,
    br.email_address,
    br.phone_number,
    br.cities_served,
    br.created_at,
    br.status,
    br.rejection_reason
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.status = 'pending'
  ORDER BY br.created_at DESC;
END;
$$;