-- Fix security linter issues introduced by the previous migration

-- Remove the problematic security definer view and replace with proper security patterns
DROP VIEW IF EXISTS public.public_business_listings;

-- Update functions to include proper search_path settings for security
CREATE OR REPLACE FUNCTION public.get_approved_business_listing(business_id uuid)
RETURNS TABLE(
  id uuid,
  business_name text,
  about_services text,
  cities_served text[],
  service_area text,
  years_in_business integer,
  website text,
  sub_business_types text[],
  business_type text,
  created_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    br.id,
    br.business_name,
    br.about_services,
    br.cities_served,
    br.service_area,
    br.years_in_business,
    br.website,
    br.sub_business_types,
    bt.name as business_type,
    br.created_at
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.id = business_id AND br.status = 'approved';
END;
$$;

-- Update the get_approved_business_listings function with proper search_path
CREATE OR REPLACE FUNCTION public.get_approved_business_listings()
RETURNS TABLE(
  id uuid,
  business_name text,
  about_services text,
  cities_served text[],
  service_area text,
  years_in_business integer,
  website text,
  sub_business_types text[],
  business_type text,
  created_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    br.id,
    br.business_name,
    br.about_services,
    br.cities_served,
    br.service_area,
    br.years_in_business,
    br.website,
    br.sub_business_types,
    bt.name as business_type,
    br.created_at
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.status = 'approved'
  ORDER BY br.created_at DESC;
END;
$$;

-- Update other existing functions to include proper search_path
CREATE OR REPLACE FUNCTION public.get_pending_business_registrations()
RETURNS TABLE(
  id uuid,
  business_name text,
  business_type text,
  contact_name text,
  email_address text,
  phone_number text,
  cities_served text[],
  created_at timestamp with time zone,
  status text,
  rejection_reason text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    br.id,
    br.business_name,
    bt.name as business_type,
    br.contact_name,
    br.email_address,
    br.phone_number,
    br.cities_served,
    br.created_at,
    br.status,
    br.rejection_reason
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.status = 'pending'
  ORDER BY br.created_at DESC;
END;
$$;

-- Update other existing functions with proper search_path
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_post_likes_count()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.social_posts 
    SET likes_count = likes_count + 1
    WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.social_posts 
    SET likes_count = likes_count - 1
    WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_post_comments_count()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.social_posts 
    SET comments_count = comments_count + 1
    WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.social_posts 
    SET comments_count = comments_count - 1
    WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_professional_rating()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  UPDATE public.professionals 
  SET 
    rating = (
      SELECT COALESCE(AVG(rating), 0) 
      FROM public.reviews 
      WHERE professional_id = NEW.professional_id
    ),
    review_count = (
      SELECT COUNT(*) 
      FROM public.reviews 
      WHERE professional_id = NEW.professional_id
    )
  WHERE id = NEW.professional_id;
  
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.create_notification(p_user_id uuid, p_title text, p_message text, p_type text DEFAULT 'info'::text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  notification_id UUID;
BEGIN
  INSERT INTO public.notifications (user_id, title, message, type)
  VALUES (p_user_id, p_title, p_message, p_type)
  RETURNING id INTO notification_id;
  
  RETURN notification_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_business_types()
RETURNS TABLE(id uuid, name text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT bt.id, bt.name
  FROM public.business_types bt
  ORDER BY bt.name;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_business_type_id(type_name text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  type_id UUID;
BEGIN
  SELECT id INTO type_id
  FROM public.business_types
  WHERE name = type_name;
  
  RETURN type_id;
END;
$$;