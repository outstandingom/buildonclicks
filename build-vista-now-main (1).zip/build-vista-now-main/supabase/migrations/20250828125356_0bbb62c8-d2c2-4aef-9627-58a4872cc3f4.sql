-- Fix remaining functions without proper search_path settings

CREATE OR REPLACE FUNCTION public.insert_business_registration(registration_data jsonb)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.business_registrations (
    user_id, business_name, business_type_id, registration_number,
    vat_gst_number, website, business_license_url, business_address,
    cities_served, service_area, years_in_business, about_services,
    contact_name, phone_number, email_address, alternate_contact,
    preferred_communication, linkedin_profile, facebook_page,
    instagram_handle, other_links, government_id_url,
    business_certificate_url, insurance_certificate_url,
    bank_name, account_number, account_type, ifsc_code
  ) VALUES (
    (registration_data->>'user_id')::UUID,
    registration_data->>'business_name',
    (registration_data->>'business_type_id')::UUID,
    registration_data->>'registration_number',
    registration_data->>'vat_gst_number',
    registration_data->>'website',
    registration_data->>'business_license_url',
    registration_data->>'business_address',
    ARRAY(SELECT jsonb_array_elements_text(registration_data->'cities_served')),
    registration_data->>'service_area',
    (registration_data->>'years_in_business')::INTEGER,
    registration_data->>'about_services',
    registration_data->>'contact_name',
    registration_data->>'phone_number',
    registration_data->>'email_address',
    registration_data->>'alternate_contact',
    registration_data->>'preferred_communication',
    registration_data->>'linkedin_profile',
    registration_data->>'facebook_page',
    registration_data->>'instagram_handle',
    CASE 
      WHEN registration_data->'other_links' IS NOT NULL 
      THEN ARRAY(SELECT jsonb_array_elements_text(registration_data->'other_links'))
      ELSE NULL 
    END,
    registration_data->>'government_id_url',
    registration_data->>'business_certificate_url',
    registration_data->>'insurance_certificate_url',
    registration_data->>'bank_name',
    registration_data->>'account_number',
    registration_data->>'account_type',
    registration_data->>'ifsc_code'
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, mobile_number, user_type)
  VALUES (
    NEW.id, 
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'mobile_number',
    COALESCE(NEW.raw_user_meta_data->>'user_type', 'user')
  );
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.verify_admin_credentials(p_email text, p_password text)
RETURNS TABLE(admin_id uuid, admin_email text, admin_name text, admin_role text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  stored_hash TEXT;
  admin_record RECORD;
BEGIN
  -- Get admin user record
  SELECT id, email, password_hash, full_name, role, is_active
  INTO admin_record
  FROM public.admin_users
  WHERE email = p_email AND is_active = true;
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Verify password (simplified - in production use proper hashing)
  IF admin_record.password_hash = crypt(p_password, admin_record.password_hash) THEN
    -- Update last login
    UPDATE public.admin_users 
    SET last_login = now() 
    WHERE id = admin_record.id;
    
    -- Return admin info
    RETURN QUERY SELECT 
      admin_record.id,
      admin_record.email,
      admin_record.full_name,
      admin_record.role;
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.create_admin_session(p_admin_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  session_token TEXT;
BEGIN
  -- Generate session token
  session_token := encode(gen_random_bytes(32), 'base64');
  
  -- Insert session
  INSERT INTO public.admin_sessions (admin_id, session_token, expires_at)
  VALUES (p_admin_id, session_token, now() + interval '24 hours');
  
  RETURN session_token;
END;
$$;

CREATE OR REPLACE FUNCTION public.verify_admin_session(p_session_token text)
RETURNS TABLE(admin_id uuid, admin_email text, admin_name text, admin_role text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  session_record RECORD;
  admin_record RECORD;
BEGIN
  -- Get session record
  SELECT admin_id, expires_at
  INTO session_record
  FROM public.admin_sessions
  WHERE session_token = p_session_token AND expires_at > now();
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Get admin record
  SELECT id, email, full_name, role
  INTO admin_record
  FROM public.admin_users
  WHERE id = session_record.admin_id AND is_active = true;
  
  IF FOUND THEN
    RETURN QUERY SELECT 
      admin_record.id,
      admin_record.email,
      admin_record.full_name,
      admin_record.role;
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.check_user_exists(p_email text, p_mobile text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  email_exists boolean := false;
  mobile_exists boolean := false;
  result jsonb;
BEGIN
  -- Check if mobile number exists in profiles
  SELECT EXISTS(
    SELECT 1 FROM public.profiles 
    WHERE mobile_number = p_mobile
  ) INTO mobile_exists;
  
  -- Build result object
  result := jsonb_build_object(
    'mobile_exists', mobile_exists,
    'email_exists', false  -- Will be checked during actual signup
  );
  
  RETURN result;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_business_registration_status(registration_id uuid, new_status text, rejection_reason_param text DEFAULT NULL::text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update the registration status and rejection reason if provided
  UPDATE public.business_registrations 
  SET 
    status = new_status, 
    rejection_reason = CASE 
      WHEN new_status = 'rejected' AND rejection_reason_param IS NOT NULL 
      THEN rejection_reason_param 
      ELSE rejection_reason 
    END,
    updated_at = now()
  WHERE id = registration_id;
  
  RETURN FOUND;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_admin_dashboard_stats()
RETURNS TABLE(total_users bigint, approved_vendors bigint, pending_requests bigint, total_posts bigint)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    (SELECT COUNT(*) FROM public.profiles) as total_users,
    (SELECT COUNT(*) FROM public.business_registrations WHERE status = 'approved') as approved_vendors,
    (SELECT COUNT(*) FROM public.business_registrations WHERE status = 'pending') as pending_requests,
    (SELECT COUNT(*) FROM public.projects) as total_posts;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_admin_recent_activity()
RETURNS TABLE(activity_type text, user_name text, created_at timestamp with time zone, description text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  WITH recent_activities AS (
    -- Recent business registrations
    SELECT 
      'vendor_registration' as activity_type,
      br.business_name as user_name,
      br.created_at,
      'New vendor registration' as description
    FROM public.business_registrations br
    WHERE br.created_at > now() - interval '7 days'
    
    UNION ALL
    
    -- Recent user registrations
    SELECT 
      'user_registration' as activity_type,
      COALESCE(p.full_name, 'Unknown User') as user_name,
      p.created_at,
      'New user account created' as description
    FROM public.profiles p
    WHERE p.created_at > now() - interval '7 days'
    
    UNION ALL
    
    -- Recent projects
    SELECT 
      'project_posted' as activity_type,
      pr.title as user_name,
      pr.created_at,
      'New project posted' as description
    FROM public.projects pr
    WHERE pr.created_at > now() - interval '7 days'
  )
  SELECT ra.activity_type, ra.user_name, ra.created_at, ra.description
  FROM recent_activities ra
  ORDER BY ra.created_at DESC
  LIMIT 10;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_users_for_admin()
RETURNS TABLE(id uuid, full_name text, user_type text, created_at timestamp with time zone, city_name text, is_active boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    COALESCE(p.full_name, 'Unknown User') as full_name,
    COALESCE(p.user_type, 'user') as user_type,
    p.created_at,
    c.name as city_name,
    true as is_active
  FROM public.profiles p
  LEFT JOIN public.cities c ON p.city_id = c.id
  ORDER BY p.created_at DESC;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_projects_for_moderation()
RETURNS TABLE(id uuid, title text, description text, user_name text, created_at timestamp with time zone, status text, project_type text, budget_range text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pr.id,
    pr.title,
    pr.description,
    COALESCE(p.full_name, 'Unknown User') as user_name,
    pr.created_at,
    pr.status,
    pr.project_type,
    pr.budget_range
  FROM public.projects pr
  LEFT JOIN public.profiles p ON pr.user_id = p.id
  ORDER BY pr.created_at DESC;
END;
$$;

CREATE OR REPLACE FUNCTION public.user_has_business_registration(user_uuid uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.business_registrations 
    WHERE user_id = user_uuid
    ORDER BY created_at DESC
    LIMIT 1
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.get_business_registration_details(registration_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  registration_data jsonb;
BEGIN
  SELECT jsonb_build_object(
    'id', br.id,
    'business_name', br.business_name,
    'business_type', bt.name,
    'registration_number', br.registration_number,
    'vat_gst_number', br.vat_gst_number,
    'website', br.website,
    'business_license_url', br.business_license_url,
    'business_address', br.business_address,
    'cities_served', br.cities_served,
    'service_area', br.service_area,
    'years_in_business', br.years_in_business,
    'about_services', br.about_services,
    'contact_name', br.contact_name,
    'phone_number', br.phone_number,
    'email_address', br.email_address,
    'alternate_contact', br.alternate_contact,
    'preferred_communication', br.preferred_communication,
    'linkedin_profile', br.linkedin_profile,
    'facebook_page', br.facebook_page,
    'instagram_handle', br.instagram_handle,
    'other_links', br.other_links,
    'government_id_url', br.government_id_url,
    'business_certificate_url', br.business_certificate_url,
    'insurance_certificate_url', br.insurance_certificate_url,
    'bank_name', br.bank_name,
    'account_number', br.account_number,
    'account_type', br.account_type,
    'ifsc_code', br.ifsc_code,
    'sub_business_types', br.sub_business_types,
    'status', br.status,
    'created_at', br.created_at,
    'updated_at', br.updated_at
  )
  INTO registration_data
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.id = registration_id;
  
  RETURN registration_data;
END;
$$;

CREATE OR REPLACE FUNCTION public.email_exists_in_auth(p_email text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Check if email exists in auth.users by trying to query the profiles table
  -- which is created for all auth users
  RETURN EXISTS (
    SELECT 1 FROM auth.users 
    WHERE email = p_email
  );
END;
$$;