-- Fix critical security vulnerability in professionals table
-- Remove public access to contact information and create secure access patterns

-- First, drop the overly permissive public read policy
DROP POLICY IF EXISTS "Professionals are publicly readable" ON public.professionals;

-- Create a new restricted policy that blocks direct table access
CREATE POLICY "Professionals table access restricted" 
ON public.professionals 
FOR SELECT 
USING (false); -- This blocks all direct table access

-- Create a secure function that only exposes safe professional data (no contact info)
CREATE OR REPLACE FUNCTION public.get_professionals_safe_data()
RETURNS TABLE(
  id uuid,
  name text,
  business_name text,
  type text,
  rating numeric,
  review_count integer,
  experience integer,
  is_verified boolean,
  created_at timestamp with time zone,
  updated_at timestamp with time zone,
  profile_image_url text,
  description text,
  city_id uuid
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.name,
    p.business_name,
    p.type,
    p.rating,
    p.review_count,
    p.experience,
    p.is_verified,
    p.created_at,
    p.updated_at,
    p.profile_image_url,
    p.description,
    p.city_id
  FROM public.professionals p
  ORDER BY p.created_at DESC;
END;
$$;

-- Create a function to get a single professional's safe data
CREATE OR REPLACE FUNCTION public.get_professional_safe_data(professional_id uuid)
RETURNS TABLE(
  id uuid,
  name text,
  business_name text,
  type text,
  rating numeric,
  review_count integer,
  experience integer,
  is_verified boolean,
  created_at timestamp with time zone,
  updated_at timestamp with time zone,
  profile_image_url text,
  description text,
  city_id uuid
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.name,
    p.business_name,
    p.type,
    p.rating,
    p.review_count,
    p.experience,
    p.is_verified,
    p.created_at,
    p.updated_at,
    p.profile_image_url,
    p.description,
    p.city_id
  FROM public.professionals p
  WHERE p.id = professional_id;
END;
$$;

-- Create a secure function for authenticated users to request contact information
-- This implements a contact request system instead of exposing data publicly
CREATE OR REPLACE FUNCTION public.request_professional_contact(
  professional_id uuid,
  requester_message text DEFAULT 'I would like to discuss a project with you.'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  professional_data RECORD;
  notification_id uuid;
  result jsonb;
BEGIN
  -- Check if user is authenticated
  IF auth.uid() IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Authentication required to request contact information'
    );
  END IF;
  
  -- Get professional data
  SELECT email, phone, name INTO professional_data
  FROM public.professionals 
  WHERE id = professional_id;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Professional not found'
    );
  END IF;
  
  -- Create a notification for the professional about the contact request
  -- In a real system, you might want to store contact requests in a separate table
  SELECT public.create_notification(
    professional_id,
    'New Contact Request',
    'Someone wants to contact you about a project: ' || requester_message,
    'contact_request'
  ) INTO notification_id;
  
  -- For now, return limited contact info to authenticated users only
  -- In production, you might want to implement a more sophisticated contact system
  result := jsonb_build_object(
    'success', true,
    'message', 'Contact request sent successfully',
    'professional_name', professional_data.name,
    'notification_id', notification_id
  );
  
  -- Only return actual contact info for authenticated users
  -- You could add additional checks here (e.g., premium users, verified users, etc.)
  IF auth.uid() IS NOT NULL THEN
    result := result || jsonb_build_object(
      'email', professional_data.email,
      'phone', professional_data.phone
    );
  END IF;
  
  RETURN result;
END;
$$;

-- Create a function for professionals to manage their own contact visibility
CREATE OR REPLACE FUNCTION public.update_professional_contact_visibility(
  professional_id uuid,
  email_visible boolean DEFAULT false,
  phone_visible boolean DEFAULT false
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Check if the authenticated user owns this professional profile
  IF NOT EXISTS (
    SELECT 1 FROM public.professionals 
    WHERE id = professional_id 
    AND id = auth.uid() -- Assuming professional id matches user id
  ) THEN
    RETURN false;
  END IF;
  
  -- For now, this is a placeholder for contact visibility settings
  -- In a full implementation, you'd add visibility columns to the professionals table
  -- UPDATE public.professionals 
  -- SET email_visible = email_visible, phone_visible = phone_visible
  -- WHERE id = professional_id;
  
  RETURN true;
END;
$$;

-- Grant execute permissions on the safe functions
GRANT EXECUTE ON FUNCTION public.get_professionals_safe_data() TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_professional_safe_data(uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.request_professional_contact(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_professional_contact_visibility(uuid, boolean, boolean) TO authenticated;

-- Create a secure view for professionals that can be used in joins (without contact info)
CREATE OR REPLACE VIEW public.professionals_safe_view AS
SELECT 
  id,
  name,
  business_name,
  type,
  rating,
  review_count,
  experience,
  is_verified,
  created_at,
  updated_at,
  profile_image_url,
  description,
  city_id
FROM public.professionals;

-- Set up RLS on the view to be publicly readable
ALTER VIEW public.professionals_safe_view SET (security_barrier = true);

-- Create policy to allow reading the safe view
CREATE POLICY "Safe professional data is publicly readable" 
ON public.professionals 
FOR SELECT 
USING (false); -- Still block direct table access