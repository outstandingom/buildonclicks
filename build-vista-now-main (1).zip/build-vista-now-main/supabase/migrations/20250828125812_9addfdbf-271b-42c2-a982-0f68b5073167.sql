-- Fix the security definer view issue

-- Drop the problematic security definer view
DROP VIEW IF EXISTS public.professionals_safe_view;

-- Remove the last policy that was referencing the view issue
DROP POLICY IF EXISTS "Safe professional data is publicly readable" ON public.professionals;

-- Instead of a view, we'll rely entirely on the secure functions
-- which are already properly configured with search_path settings

-- Ensure the table remains locked down
CREATE POLICY "Professionals table completely restricted" 
ON public.professionals 
FOR ALL
USING (false);