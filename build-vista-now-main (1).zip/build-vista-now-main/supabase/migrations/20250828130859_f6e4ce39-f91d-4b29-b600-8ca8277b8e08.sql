-- Update social media RLS policies to require authentication
-- Drop existing permissive policies
DROP POLICY IF EXISTS "Posts are publicly readable" ON public.social_posts;
DROP POLICY IF EXISTS "Likes are publicly readable" ON public.social_post_likes;
DROP POLICY IF EXISTS "Comments are publicly readable" ON public.social_post_comments;

-- Create new policies that require authentication for viewing social content
CREATE POLICY "Authenticated users can view posts" 
ON public.social_posts 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can view likes" 
ON public.social_post_likes 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can view comments" 
ON public.social_post_comments 
FOR SELECT 
USING (auth.uid() IS NOT NULL);