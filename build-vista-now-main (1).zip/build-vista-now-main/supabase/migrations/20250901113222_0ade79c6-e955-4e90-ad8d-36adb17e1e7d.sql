-- Enable the pgcrypto extension for password hashing functions
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Create or update the verify_admin_credentials function with proper password verification
CREATE OR REPLACE FUNCTION public.verify_admin_credentials(p_email text, p_password text)
RETURNS TABLE(admin_id uuid, admin_email text, admin_name text, admin_role text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  admin_record RECORD;
BEGIN
  -- Get admin user record
  SELECT id, email, password_hash, full_name, role, is_active
  INTO admin_record
  FROM public.admin_users
  WHERE email = p_email AND is_active = true;
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Verify password using crypt function (now available with pgcrypto extension)
  IF admin_record.password_hash = crypt(p_password, admin_record.password_hash) THEN
    -- Update last login
    UPDATE public.admin_users 
    SET last_login = now() 
    WHERE id = admin_record.id;
    
    -- Return admin info
    RETURN QUERY SELECT 
      admin_record.id,
      admin_record.email,
      admin_record.full_name,
      admin_record.role;
  END IF;
END;
$function$;