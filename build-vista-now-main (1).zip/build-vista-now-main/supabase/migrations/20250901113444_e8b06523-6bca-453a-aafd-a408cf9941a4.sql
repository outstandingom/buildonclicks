-- Update the existing admin user with properly hashed password
UPDATE public.admin_users 
SET password_hash = crypt('admin@123', gen_salt('bf'))
WHERE email = 'info.buildonclick@gmail.com';

-- If the user doesn't exist, insert it
INSERT INTO public.admin_users (email, password_hash, full_name, role, is_active)
SELECT 'info.buildonclick@gmail.com', crypt('admin@123', gen_salt('bf')), 'BuildOnClick Admin', 'admin', true
WHERE NOT EXISTS (
  SELECT 1 FROM public.admin_users WHERE email = 'info.buildonclick@gmail.com'
);