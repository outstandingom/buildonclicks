-- Temporarily reset password to simple hash for testing
UPDATE public.admin_users 
SET password_hash = 'admin@123'
WHERE email = 'info.buildonclick@gmail.com';

-- Create a simple verification function for testing
CREATE OR REPLACE FUNCTION public.verify_admin_credentials(p_email text, p_password text)
RETURNS TABLE(admin_id uuid, admin_email text, admin_name text, admin_role text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  admin_record RECORD;
BEGIN
  -- Get admin user record
  SELECT id, email, password_hash, full_name, role, is_active
  INTO admin_record
  FROM public.admin_users
  WHERE email = p_email AND is_active = true;
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Simple password verification for testing (NOT for production!)
  IF admin_record.password_hash = p_password THEN
    -- Update last login
    UPDATE public.admin_users 
    SET last_login = now() 
    WHERE id = admin_record.id;
    
    -- Return admin info
    RETURN QUERY SELECT 
      admin_record.id,
      admin_record.email,
      admin_record.full_name,
      admin_record.role;
  END IF;
END;
$function$;