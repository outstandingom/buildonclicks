-- Fix the create_admin_session function to use a different method for generating tokens
CREATE OR REPLACE FUNCTION public.create_admin_session(p_admin_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  session_token TEXT;
BEGIN
  -- Generate session token using random() and current timestamp
  session_token := encode(
    (random()::text || extract(epoch from now())::text || p_admin_id::text)::bytea, 
    'base64'
  );
  
  -- Insert session
  INSERT INTO public.admin_sessions (admin_id, session_token, expires_at)
  VALUES (p_admin_id, session_token, now() + interval '24 hours');
  
  RETURN session_token;
END;
$function$;