-- Create subscription plans table
CREATE TABLE public.subscription_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price_inr DECIMAL(10,2) NOT NULL,
  lead_credits INTEGER NOT NULL,
  duration_days INTEGER NOT NULL DEFAULT 30,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create user lead credits table
CREATE TABLE public.user_lead_credits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  total_credits INTEGER NOT NULL DEFAULT 0,
  used_credits INTEGER NOT NULL DEFAULT 0,
  free_credits_given BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Create user subscriptions table
CREATE TABLE public.user_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_id UUID NOT NULL REFERENCES public.subscription_plans(id),
  stripe_subscription_id TEXT,
  stripe_customer_id TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  credits_added INTEGER NOT NULL,
  starts_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create lead access logs table
CREATE TABLE public.lead_access_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  requirement_id UUID NOT NULL REFERENCES public.requirements(id),
  credits_consumed INTEGER NOT NULL DEFAULT 1,
  access_type TEXT NOT NULL DEFAULT 'view', -- 'view' or 'contact'
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_lead_credits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_access_logs ENABLE ROW LEVEL SECURITY;

-- RLS policies for subscription_plans (publicly readable)
CREATE POLICY "subscription_plans_select" ON public.subscription_plans
  FOR SELECT USING (is_active = true);

-- RLS policies for user_lead_credits
CREATE POLICY "user_lead_credits_select" ON public.user_lead_credits
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "user_lead_credits_insert" ON public.user_lead_credits
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "user_lead_credits_update" ON public.user_lead_credits
  FOR UPDATE USING (auth.uid() = user_id);

-- RLS policies for user_subscriptions
CREATE POLICY "user_subscriptions_select" ON public.user_subscriptions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "user_subscriptions_insert" ON public.user_subscriptions
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "user_subscriptions_update" ON public.user_subscriptions
  FOR UPDATE USING (auth.uid() = user_id);

-- RLS policies for lead_access_logs
CREATE POLICY "lead_access_logs_select" ON public.lead_access_logs
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "lead_access_logs_insert" ON public.lead_access_logs
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Insert default subscription plans
INSERT INTO public.subscription_plans (name, description, price_inr, lead_credits, duration_days) VALUES
('Basic Lead Package', '15 leads for ₹600', 600.00, 15, 30),
('Standard Lead Package', '30 leads for ₹1000', 1000.00, 30, 30),
('Premium Lead Package', '60 leads for ₹1800', 1800.00, 60, 30);

-- Function to check if user has sufficient credits
CREATE OR REPLACE FUNCTION public.check_user_lead_credits(p_user_id UUID, p_credits_needed INTEGER DEFAULT 1)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  available_credits INTEGER;
BEGIN
  SELECT (total_credits - used_credits) 
  INTO available_credits
  FROM public.user_lead_credits 
  WHERE user_id = p_user_id;
  
  IF available_credits IS NULL THEN
    RETURN FALSE;
  END IF;
  
  RETURN available_credits >= p_credits_needed;
END;
$function$;

-- Function to consume lead credits
CREATE OR REPLACE FUNCTION public.consume_lead_credits(p_user_id UUID, p_requirement_id UUID, p_credits INTEGER DEFAULT 1, p_access_type TEXT DEFAULT 'view')
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  available_credits INTEGER;
  access_exists BOOLEAN;
BEGIN
  -- Check if user already accessed this requirement
  SELECT EXISTS(
    SELECT 1 FROM public.lead_access_logs 
    WHERE user_id = p_user_id AND requirement_id = p_requirement_id AND access_type = p_access_type
  ) INTO access_exists;
  
  -- If already accessed, don't charge again
  IF access_exists THEN
    RETURN TRUE;
  END IF;
  
  -- Check available credits
  SELECT (total_credits - used_credits) 
  INTO available_credits
  FROM public.user_lead_credits 
  WHERE user_id = p_user_id;
  
  IF available_credits IS NULL OR available_credits < p_credits THEN
    RETURN FALSE;
  END IF;
  
  -- Update used credits
  UPDATE public.user_lead_credits 
  SET used_credits = used_credits + p_credits,
      updated_at = now()
  WHERE user_id = p_user_id;
  
  -- Log the access
  INSERT INTO public.lead_access_logs (user_id, requirement_id, credits_consumed, access_type)
  VALUES (p_user_id, p_requirement_id, p_credits, p_access_type);
  
  RETURN TRUE;
END;
$function$;

-- Function to add credits to user (for subscriptions)
CREATE OR REPLACE FUNCTION public.add_user_credits(p_user_id UUID, p_credits INTEGER, p_subscription_id UUID DEFAULT NULL)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.user_lead_credits (user_id, total_credits, used_credits)
  VALUES (p_user_id, p_credits, 0)
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    total_credits = user_lead_credits.total_credits + p_credits,
    updated_at = now();
  
  RETURN TRUE;
END;
$function$;

-- Function to give free credits to new users
CREATE OR REPLACE FUNCTION public.give_free_credits(p_user_id UUID, p_free_credits INTEGER DEFAULT 15)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.user_lead_credits (user_id, total_credits, used_credits, free_credits_given)
  VALUES (p_user_id, p_free_credits, 0, true)
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    total_credits = CASE 
      WHEN user_lead_credits.free_credits_given = false THEN user_lead_credits.total_credits + p_free_credits
      ELSE user_lead_credits.total_credits
    END,
    free_credits_given = true,
    updated_at = now()
  WHERE user_lead_credits.free_credits_given = false;
  
  RETURN TRUE;
END;
$function$;

-- Trigger to give free credits to new users
CREATE OR REPLACE FUNCTION public.handle_new_user_credits()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Give free credits to new users (15 for regular users, 20 for service providers)
  IF NEW.user_type = 'provider' THEN
    PERFORM public.give_free_credits(NEW.id, 20);
  ELSE
    PERFORM public.give_free_credits(NEW.id, 15);
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create trigger for new user credits
CREATE TRIGGER on_profile_created_give_credits
  AFTER INSERT ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_credits();