-- Admin functions for lead subscription system management

-- Get detailed user credit history
CREATE OR REPLACE FUNCTION public.get_user_credit_history(p_user_id uuid)
RETURNS TABLE(
  user_name text,
  total_credits integer,
  used_credits integer,
  available_credits integer,
  free_credits_given boolean,
  subscription_count bigint,
  last_access timestamp with time zone,
  access_logs jsonb
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    COALESCE(p.full_name, 'Unknown User') as user_name,
    COALESCE(ulc.total_credits, 0) as total_credits,
    COALESCE(ulc.used_credits, 0) as used_credits,
    COALESCE(ulc.total_credits - ulc.used_credits, 0) as available_credits,
    COALESCE(ulc.free_credits_given, false) as free_credits_given,
    COALESCE(
      (SELECT COUNT(*) FROM public.user_subscriptions WHERE user_id = p_user_id), 
      0
    ) as subscription_count,
    (SELECT MAX(created_at) FROM public.lead_access_logs WHERE user_id = p_user_id) as last_access,
    COALESCE(
      (SELECT jsonb_agg(
        jsonb_build_object(
          'requirement_id', requirement_id,
          'credits_consumed', credits_consumed,
          'access_type', access_type,
          'created_at', created_at
        ) ORDER BY created_at DESC
      ) FROM public.lead_access_logs WHERE user_id = p_user_id LIMIT 10),
      '[]'::jsonb
    ) as access_logs
  FROM public.profiles p
  LEFT JOIN public.user_lead_credits ulc ON p.id = ulc.user_id
  WHERE p.id = p_user_id;
END;
$function$

-- Get subscription analytics
CREATE OR REPLACE FUNCTION public.get_subscription_analytics()
RETURNS TABLE(
  total_active_subscriptions bigint,
  total_revenue numeric,
  monthly_revenue numeric,
  popular_plan_name text,
  popular_plan_count bigint,
  avg_credits_per_user numeric,
  total_credits_distributed bigint,
  total_credits_used bigint
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    (SELECT COUNT(*) FROM public.user_subscriptions WHERE status = 'active' AND expires_at > now()) as total_active_subscriptions,
    COALESCE(
      (SELECT SUM(sp.price_inr) 
       FROM public.user_subscriptions us 
       JOIN public.subscription_plans sp ON us.plan_id = sp.id 
       WHERE us.status = 'active'), 
      0
    ) as total_revenue,
    COALESCE(
      (SELECT SUM(sp.price_inr) 
       FROM public.user_subscriptions us 
       JOIN public.subscription_plans sp ON us.plan_id = sp.id 
       WHERE us.status = 'active' AND us.created_at >= date_trunc('month', now())), 
      0
    ) as monthly_revenue,
    COALESCE(
      (SELECT sp.name 
       FROM public.subscription_plans sp 
       JOIN public.user_subscriptions us ON sp.id = us.plan_id 
       WHERE us.status = 'active' 
       GROUP BY sp.name 
       ORDER BY COUNT(*) DESC 
       LIMIT 1), 
      'None'
    ) as popular_plan_name,
    COALESCE(
      (SELECT COUNT(*) 
       FROM public.user_subscriptions us 
       JOIN public.subscription_plans sp ON us.plan_id = sp.id 
       WHERE us.status = 'active' 
       GROUP BY sp.name 
       ORDER BY COUNT(*) DESC 
       LIMIT 1), 
      0
    ) as popular_plan_count,
    COALESCE(
      (SELECT AVG(total_credits) FROM public.user_lead_credits), 
      0
    ) as avg_credits_per_user,
    COALESCE(
      (SELECT SUM(total_credits) FROM public.user_lead_credits), 
      0
    ) as total_credits_distributed,
    COALESCE(
      (SELECT SUM(used_credits) FROM public.user_lead_credits), 
      0
    ) as total_credits_used;
END;
$function$

-- Get lead access analytics
CREATE OR REPLACE FUNCTION public.get_lead_access_analytics()
RETURNS TABLE(
  requirement_id uuid,
  requirement_title text,
  total_views bigint,
  total_contacts bigint,
  unique_viewers bigint,
  credits_consumed_total integer,
  created_at timestamp with time zone,
  last_accessed timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    r.id as requirement_id,
    r.title as requirement_title,
    COALESCE(
      (SELECT COUNT(*) FROM public.lead_access_logs WHERE requirement_id = r.id AND access_type = 'view'), 
      0
    ) as total_views,
    COALESCE(
      (SELECT COUNT(*) FROM public.lead_access_logs WHERE requirement_id = r.id AND access_type = 'contact'), 
      0
    ) as total_contacts,
    COALESCE(
      (SELECT COUNT(DISTINCT user_id) FROM public.lead_access_logs WHERE requirement_id = r.id), 
      0
    ) as unique_viewers,
    COALESCE(
      (SELECT SUM(credits_consumed) FROM public.lead_access_logs WHERE requirement_id = r.id), 
      0
    ) as credits_consumed_total,
    r.created_at,
    (SELECT MAX(created_at) FROM public.lead_access_logs WHERE requirement_id = r.id) as last_accessed
  FROM public.requirements r
  WHERE r.status = 'active'
  ORDER BY total_views DESC, total_contacts DESC;
END;
$function$

-- Admin function to add credits to user
CREATE OR REPLACE FUNCTION public.admin_add_credits(p_user_id uuid, p_credits integer, p_reason text DEFAULT 'Admin allocation')
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.user_lead_credits (user_id, total_credits, used_credits)
  VALUES (p_user_id, p_credits, 0)
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    total_credits = user_lead_credits.total_credits + p_credits,
    updated_at = now();
  
  -- Create notification for user
  PERFORM public.create_notification(
    p_user_id,
    'Credits Added',
    format('Admin has added %s credits to your account. Reason: %s', p_credits, p_reason),
    'credit_update'
  );
  
  RETURN TRUE;
END;
$function$

-- Get all users with credit summary for admin
CREATE OR REPLACE FUNCTION public.get_users_credit_summary()
RETURNS TABLE(
  user_id uuid,
  user_name text,
  user_type text,
  total_credits integer,
  used_credits integer,
  available_credits integer,
  last_activity timestamp with time zone,
  subscription_status text,
  created_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as user_id,
    COALESCE(p.full_name, 'Unknown User') as user_name,
    COALESCE(p.user_type, 'user') as user_type,
    COALESCE(ulc.total_credits, 0) as total_credits,
    COALESCE(ulc.used_credits, 0) as used_credits,
    COALESCE(ulc.total_credits - ulc.used_credits, 0) as available_credits,
    (SELECT MAX(created_at) FROM public.lead_access_logs WHERE user_id = p.id) as last_activity,
    CASE 
      WHEN EXISTS(
        SELECT 1 FROM public.user_subscriptions 
        WHERE user_id = p.id AND status = 'active' AND expires_at > now()
      ) THEN 'active'
      ELSE 'inactive'
    END as subscription_status,
    p.created_at
  FROM public.profiles p
  LEFT JOIN public.user_lead_credits ulc ON p.id = ulc.user_id
  ORDER BY p.created_at DESC;
END;
$function$