-- Get detailed user credit history
CREATE OR REPLACE FUNCTION public.get_user_credit_history(p_user_id uuid)
RETURNS TABLE(
  user_name text,
  total_credits integer,
  used_credits integer,
  available_credits integer,
  free_credits_given boolean,
  subscription_count bigint,
  last_access timestamp with time zone,
  access_logs jsonb
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    COALESCE(p.full_name, 'Unknown User') as user_name,
    COALESCE(ulc.total_credits, 0) as total_credits,
    COALESCE(ulc.used_credits, 0) as used_credits,
    COALESCE(ulc.total_credits - ulc.used_credits, 0) as available_credits,
    COALESCE(ulc.free_credits_given, false) as free_credits_given,
    COALESCE(
      (SELECT COUNT(*) FROM public.user_subscriptions WHERE user_id = p_user_id), 
      0
    ) as subscription_count,
    (SELECT MAX(created_at) FROM public.lead_access_logs WHERE user_id = p_user_id) as last_access,
    COALESCE(
      (SELECT jsonb_agg(
        jsonb_build_object(
          'requirement_id', requirement_id,
          'credits_consumed', credits_consumed,
          'access_type', access_type,
          'created_at', created_at
        ) ORDER BY created_at DESC
      ) FROM public.lead_access_logs WHERE user_id = p_user_id LIMIT 10),
      '[]'::jsonb
    ) as access_logs
  FROM public.profiles p
  LEFT JOIN public.user_lead_credits ulc ON p.id = ulc.user_id
  WHERE p.id = p_user_id;
END;
$function$;