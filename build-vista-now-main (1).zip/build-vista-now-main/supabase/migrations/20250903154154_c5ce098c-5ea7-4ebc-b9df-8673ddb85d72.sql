-- Get subscription analytics
CREATE OR REPLACE FUNCTION public.get_subscription_analytics()
RETURNS TABLE(
  total_active_subscriptions bigint,
  total_revenue numeric,
  monthly_revenue numeric,
  popular_plan_name text,
  popular_plan_count bigint,
  avg_credits_per_user numeric,
  total_credits_distributed bigint,
  total_credits_used bigint
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    (SELECT COUNT(*) FROM public.user_subscriptions WHERE status = 'active' AND expires_at > now()) as total_active_subscriptions,
    COALESCE(
      (SELECT SUM(sp.price_inr) 
       FROM public.user_subscriptions us 
       JOIN public.subscription_plans sp ON us.plan_id = sp.id 
       WHERE us.status = 'active'), 
      0
    ) as total_revenue,
    COALESCE(
      (SELECT SUM(sp.price_inr) 
       FROM public.user_subscriptions us 
       JOIN public.subscription_plans sp ON us.plan_id = sp.id 
       WHERE us.status = 'active' AND us.created_at >= date_trunc('month', now())), 
      0
    ) as monthly_revenue,
    COALESCE(
      (SELECT sp.name 
       FROM public.subscription_plans sp 
       JOIN public.user_subscriptions us ON sp.id = us.plan_id 
       WHERE us.status = 'active' 
       GROUP BY sp.name 
       ORDER BY COUNT(*) DESC 
       LIMIT 1), 
      'None'
    ) as popular_plan_name,
    COALESCE(
      (SELECT COUNT(*) 
       FROM public.user_subscriptions us 
       JOIN public.subscription_plans sp ON us.plan_id = sp.id 
       WHERE us.status = 'active' 
       GROUP BY sp.name 
       ORDER BY COUNT(*) DESC 
       LIMIT 1), 
      0
    ) as popular_plan_count,
    COALESCE(
      (SELECT AVG(total_credits) FROM public.user_lead_credits), 
      0
    ) as avg_credits_per_user,
    COALESCE(
      (SELECT SUM(total_credits) FROM public.user_lead_credits), 
      0
    ) as total_credits_distributed,
    COALESCE(
      (SELECT SUM(used_credits) FROM public.user_lead_credits), 
      0
    ) as total_credits_used;
END;
$function$;