CREATE OR REPLACE FUNCTION public.get_lead_access_analytics()
RETURNS TABLE(
  requirement_id uuid,
  requirement_title text,
  total_views bigint,
  total_contacts bigint,
  unique_viewers bigint,
  credits_consumed_total integer,
  requirement_created_at timestamptz,   -- renamed from created_at
  last_accessed timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    r.id AS requirement_id,
    r.title AS requirement_title,
    COALESCE((SELECT COUNT(*) FROM public.lead_access_logs lal WHERE lal.requirement_id = r.id AND lal.access_type = 'view'), 0) AS total_views,
    COALESCE((SELECT COUNT(*) FROM public.lead_access_logs lal WHERE lal.requirement_id = r.id AND lal.access_type = 'contact'), 0) AS total_contacts,
    COALESCE((SELECT COUNT(DISTINCT lal.user_id) FROM public.lead_access_logs lal WHERE lal.requirement_id = r.id), 0) AS unique_viewers,
    COALESCE((SELECT SUM(lal.credits_consumed) FROM public.lead_access_logs lal WHERE lal.requirement_id = r.id), 0) AS credits_consumed_total,
    r.created_at AS requirement_created_at,
    (SELECT MAX(lal.created_at) FROM public.lead_access_logs lal WHERE lal.requirement_id = r.id) AS last_accessed
  FROM public.requirements r
  WHERE r.status = 'active'
  ORDER BY total_views DESC, total_contacts DESC;
END;
$function$;
