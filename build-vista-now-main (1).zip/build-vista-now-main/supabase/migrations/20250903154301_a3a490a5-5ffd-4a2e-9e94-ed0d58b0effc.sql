CREATE OR REPLACE FUNCTION public.get_users_credit_summary()
RETURNS TABLE(
  user_id uuid,
  user_name text,
  user_type text,
  total_credits integer,
  used_credits integer,
  available_credits integer,
  last_activity timestamptz,
  subscription_status text,
  profile_created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    p.id AS user_id,
    COALESCE(p.full_name, 'Unknown User') AS user_name,
    COALESCE(p.user_type, 'user') AS user_type,
    COALESCE(ulc.total_credits, 0) AS total_credits,
    COALESCE(ulc.used_credits, 0) AS used_credits,
    COALESCE(ulc.total_credits - ulc.used_credits, 0) AS available_credits,
    lal.last_activity,
    CASE 
      WHEN EXISTS(
        SELECT 1 
        FROM public.user_subscriptions us 
        WHERE us.user_id = p.id 
          AND us.status = 'active' 
          AND us.expires_at > now()
      ) THEN 'active'
      ELSE 'inactive'
    END AS subscription_status,
    p.created_at AS profile_created_at
  FROM public.profiles p
  LEFT JOIN public.user_lead_credits ulc 
    ON p.id = ulc.user_id
  LEFT JOIN LATERAL (
    SELECT MAX(created_at) AS last_activity
    FROM public.lead_access_logs
    WHERE user_id = p.id
  ) lal ON TRUE
  ORDER BY profile_created_at DESC;
END;
$function$;
