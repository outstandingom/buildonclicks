-- Create referral system tables

-- Referral rewards configuration
CREATE TABLE public.referral_rewards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  reward_type TEXT NOT NULL CHECK (reward_type IN ('signup', 'first_purchase', 'business_verification')),
  referrer_credits INTEGER NOT NULL DEFAULT 0,
  referee_credits INTEGER NOT NULL DEFAULT 0,
  user_type TEXT NOT NULL DEFAULT 'all' CHECK (user_type IN ('all', 'user', 'provider')),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Referral codes for each user
CREATE TABLE public.referral_codes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  code TEXT NOT NULL UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  usage_count INTEGER NOT NULL DEFAULT 0,
  max_usage INTEGER,
  expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Track referral relationships
CREATE TABLE public.referrals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  referrer_id UUID NOT NULL,
  referee_id UUID NOT NULL,
  referral_code_id UUID NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'expired')),
  reward_type TEXT NOT NULL,
  referrer_reward_given BOOLEAN NOT NULL DEFAULT false,
  referee_reward_given BOOLEAN NOT NULL DEFAULT false,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  CONSTRAINT referrals_referrer_id_fkey FOREIGN KEY (referrer_id) REFERENCES public.profiles(id),
  CONSTRAINT referrals_referee_id_fkey FOREIGN KEY (referee_id) REFERENCES public.profiles(id),
  CONSTRAINT referrals_referral_code_id_fkey FOREIGN KEY (referral_code_id) REFERENCES public.referral_codes(id),
  CONSTRAINT referrals_unique_referee UNIQUE (referee_id)
);

-- Track referral-based credit transactions
CREATE TABLE public.referral_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  referral_id UUID NOT NULL,
  user_id UUID NOT NULL,
  credits_amount INTEGER NOT NULL,
  transaction_type TEXT NOT NULL CHECK (transaction_type IN ('referrer_reward', 'referee_reward')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  CONSTRAINT referral_transactions_referral_id_fkey FOREIGN KEY (referral_id) REFERENCES public.referrals(id),
  CONSTRAINT referral_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id)
);

-- Enable RLS on all tables
ALTER TABLE public.referral_rewards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_transactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for referral_rewards (read-only for users)
CREATE POLICY "referral_rewards_select" ON public.referral_rewards
FOR SELECT USING (is_active = true);

-- RLS Policies for referral_codes
CREATE POLICY "referral_codes_select" ON public.referral_codes
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "referral_codes_insert" ON public.referral_codes
FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "referral_codes_update" ON public.referral_codes
FOR UPDATE USING (auth.uid() = user_id);

-- RLS Policies for referrals
CREATE POLICY "referrals_select" ON public.referrals
FOR SELECT USING (auth.uid() = referrer_id OR auth.uid() = referee_id);

CREATE POLICY "referrals_insert" ON public.referrals
FOR INSERT WITH CHECK (auth.uid() = referee_id);

-- RLS Policies for referral_transactions
CREATE POLICY "referral_transactions_select" ON public.referral_transactions
FOR SELECT USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX idx_referral_codes_user_id ON public.referral_codes(user_id);
CREATE INDEX idx_referral_codes_code ON public.referral_codes(code);
CREATE INDEX idx_referrals_referrer_id ON public.referrals(referrer_id);
CREATE INDEX idx_referrals_referee_id ON public.referrals(referee_id);
CREATE INDEX idx_referrals_status ON public.referrals(status);
CREATE INDEX idx_referral_transactions_user_id ON public.referral_transactions(user_id);
CREATE INDEX idx_referral_transactions_referral_id ON public.referral_transactions(referral_id);

-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code(p_user_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  base_code TEXT;
  final_code TEXT;
  counter INTEGER := 0;
BEGIN
  -- Get user's name to create base code
  SELECT UPPER(LEFT(COALESCE(full_name, 'USER'), 3))
  INTO base_code
  FROM public.profiles
  WHERE id = p_user_id;
  
  -- If no name found, use 'REF'
  IF base_code IS NULL OR LENGTH(base_code) < 3 THEN
    base_code := 'REF';
  END IF;
  
  -- Add random numbers and ensure uniqueness
  LOOP
    final_code := base_code || LPAD((RANDOM() * 9999)::INTEGER::TEXT, 4, '0');
    
    -- Check if code already exists
    IF NOT EXISTS (SELECT 1 FROM public.referral_codes WHERE code = final_code) THEN
      EXIT;
    END IF;
    
    counter := counter + 1;
    -- Prevent infinite loop
    IF counter > 100 THEN
      final_code := 'REF' || LPAD((RANDOM() * 99999999)::INTEGER::TEXT, 8, '0');
      EXIT;
    END IF;
  END LOOP;
  
  RETURN final_code;
END;
$$;

-- Function to create referral code for new users
CREATE OR REPLACE FUNCTION public.create_user_referral_code()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_code TEXT;
BEGIN
  -- Generate referral code
  new_code := public.generate_referral_code(NEW.id);
  
  -- Insert referral code
  INSERT INTO public.referral_codes (user_id, code)
  VALUES (NEW.id, new_code);
  
  RETURN NEW;
END;
$$;

-- Trigger to create referral code when profile is created
CREATE TRIGGER create_referral_code_trigger
AFTER INSERT ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.create_user_referral_code();

-- Function to process referral signup
CREATE OR REPLACE FUNCTION public.process_referral_signup(p_referee_id UUID, p_referral_code TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  referral_code_record RECORD;
  reward_config RECORD;
  referral_id UUID;
BEGIN
  -- Get referral code info
  SELECT rc.*, p.user_type as referee_type
  INTO referral_code_record
  FROM public.referral_codes rc
  JOIN public.profiles p ON p.id = p_referee_id
  WHERE rc.code = p_referral_code AND rc.is_active = true
  AND (rc.expires_at IS NULL OR rc.expires_at > now())
  AND (rc.max_usage IS NULL OR rc.usage_count < rc.max_usage)
  AND rc.user_id != p_referee_id; -- Can't refer yourself
  
  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;
  
  -- Check if user is already referred
  IF EXISTS (SELECT 1 FROM public.referrals WHERE referee_id = p_referee_id) THEN
    RETURN FALSE;
  END IF;
  
  -- Get reward configuration
  SELECT * INTO reward_config
  FROM public.referral_rewards
  WHERE reward_type = 'signup'
  AND is_active = true
  AND (user_type = 'all' OR user_type = referral_code_record.referee_type)
  ORDER BY created_at DESC
  LIMIT 1;
  
  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;
  
  -- Create referral record
  INSERT INTO public.referrals (
    referrer_id, referee_id, referral_code_id, 
    reward_type, status
  ) VALUES (
    referral_code_record.user_id, p_referee_id, referral_code_record.id,
    'signup', 'completed'
  ) RETURNING id INTO referral_id;
  
  -- Update referral code usage
  UPDATE public.referral_codes 
  SET usage_count = usage_count + 1, updated_at = now()
  WHERE id = referral_code_record.id;
  
  -- Give rewards to both users
  -- Referee reward
  IF reward_config.referee_credits > 0 THEN
    PERFORM public.add_user_credits(p_referee_id, reward_config.referee_credits);
    
    INSERT INTO public.referral_transactions (
      referral_id, user_id, credits_amount, transaction_type
    ) VALUES (
      referral_id, p_referee_id, reward_config.referee_credits, 'referee_reward'
    );
    
    -- Create notification
    PERFORM public.create_notification(
      p_referee_id,
      'Welcome Bonus!',
      format('You received %s credits for joining through a referral!', reward_config.referee_credits),
      'referral_reward'
    );
  END IF;
  
  -- Referrer reward
  IF reward_config.referrer_credits > 0 THEN
    PERFORM public.add_user_credits(referral_code_record.user_id, reward_config.referrer_credits);
    
    INSERT INTO public.referral_transactions (
      referral_id, user_id, credits_amount, transaction_type
    ) VALUES (
      referral_id, referral_code_record.user_id, reward_config.referrer_credits, 'referrer_reward'
    );
    
    -- Create notification
    PERFORM public.create_notification(
      referral_code_record.user_id,
      'Referral Reward!',
      format('You earned %s credits for referring a new user!', reward_config.referrer_credits),
      'referral_reward'
    );
  END IF;
  
  -- Mark rewards as given
  UPDATE public.referrals 
  SET 
    referrer_reward_given = true,
    referee_reward_given = true,
    completed_at = now(),
    updated_at = now()
  WHERE id = referral_id;
  
  RETURN TRUE;
END;
$$;

-- Function to get user referral stats
CREATE OR REPLACE FUNCTION public.get_user_referral_stats(p_user_id UUID)
RETURNS TABLE(
  referral_code TEXT,
  total_referrals BIGINT,
  total_credits_earned INTEGER,
  successful_referrals BIGINT,
  pending_referrals BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    rc.code as referral_code,
    COALESCE(COUNT(r.id), 0) as total_referrals,
    COALESCE(SUM(rt.credits_amount), 0)::INTEGER as total_credits_earned,
    COALESCE(COUNT(r.id) FILTER (WHERE r.status = 'completed'), 0) as successful_referrals,
    COALESCE(COUNT(r.id) FILTER (WHERE r.status = 'pending'), 0) as pending_referrals
  FROM public.referral_codes rc
  LEFT JOIN public.referrals r ON r.referrer_id = p_user_id AND r.referral_code_id = rc.id
  LEFT JOIN public.referral_transactions rt ON rt.referral_id = r.id AND rt.user_id = p_user_id
  WHERE rc.user_id = p_user_id AND rc.is_active = true
  GROUP BY rc.code;
END;
$$;

-- Insert default reward configurations
INSERT INTO public.referral_rewards (reward_type, referrer_credits, referee_credits, user_type) VALUES
('signup', 10, 5, 'user'),
('signup', 15, 10, 'provider'),
('business_verification', 25, 0, 'provider');

-- Update updated_at trigger for all tables
CREATE TRIGGER update_referral_rewards_updated_at
BEFORE UPDATE ON public.referral_rewards
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_referral_codes_updated_at
BEFORE UPDATE ON public.referral_codes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_referrals_updated_at
BEFORE UPDATE ON public.referrals
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();