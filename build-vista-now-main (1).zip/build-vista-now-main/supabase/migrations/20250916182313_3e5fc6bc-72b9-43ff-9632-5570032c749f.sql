-- First, let's create the trigger for automatic referral code generation if it doesn't exist
CREATE OR REPLACE FUNCTION public.create_user_referral_code()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  new_code TEXT;
BEGIN
  -- Generate referral code
  new_code := public.generate_referral_code(NEW.id);
  
  -- Insert referral code
  INSERT INTO public.referral_codes (user_id, code)
  VALUES (NEW.id, new_code);
  
  RETURN NEW;
END;
$function$;

-- Create trigger if it doesn't exist
DROP TRIGGER IF EXISTS trigger_create_referral_code ON public.profiles;
CREATE TRIGGER trigger_create_referral_code
  AFTER INSERT ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.create_user_referral_code();

-- Create referral codes for existing users who don't have them
DO $$
DECLARE
  user_record RECORD;
  new_code TEXT;
BEGIN
  FOR user_record IN 
    SELECT p.id 
    FROM public.profiles p 
    LEFT JOIN public.referral_codes rc ON p.id = rc.user_id 
    WHERE rc.user_id IS NULL
  LOOP
    new_code := public.generate_referral_code(user_record.id);
    
    INSERT INTO public.referral_codes (user_id, code)
    VALUES (user_record.id, new_code)
    ON CONFLICT (user_id) DO NOTHING;
  END LOOP;
END $$;