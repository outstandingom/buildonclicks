-- Add unique constraint to referral_codes table if it doesn't exist
ALTER TABLE public.referral_codes 
ADD CONSTRAINT unique_referral_codes_user_id UNIQUE (user_id);

-- Create referral codes for existing users who don't have them
DO $$
DECLARE
  user_record RECORD;
  new_code TEXT;
BEGIN
  FOR user_record IN 
    SELECT p.id 
    FROM public.profiles p 
    LEFT JOIN public.referral_codes rc ON p.id = rc.user_id 
    WHERE rc.user_id IS NULL
  LOOP
    new_code := public.generate_referral_code(user_record.id);
    
    INSERT INTO public.referral_codes (user_id, code)
    VALUES (user_record.id, new_code)
    ON CONFLICT (user_id) DO NOTHING;
  END LOOP;
END $$;