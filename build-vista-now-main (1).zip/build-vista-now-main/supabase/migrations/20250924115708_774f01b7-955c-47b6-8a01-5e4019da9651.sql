-- Add admin policies for banner management
CREATE POLICY "Service role can manage all banners" 
ON public.banners 
FOR ALL 
USING (true);

-- Create storage policies for admin banner management
CREATE POLICY "Service role can upload banners" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'banners');

CREATE POLICY "Service role can update banners" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'banners');

CREATE POLICY "Service role can delete banners" 
ON storage.objects 
FOR DELETE 
USING (bucket_id = 'banners');