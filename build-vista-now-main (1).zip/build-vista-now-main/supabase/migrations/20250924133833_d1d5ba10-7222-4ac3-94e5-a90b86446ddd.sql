-- Update user_subscriptions table to replace Stripe fields with Razorpay fields
ALTER TABLE public.user_subscriptions 
DROP COLUMN IF EXISTS stripe_customer_id,
DROP COLUMN IF EXISTS stripe_subscription_id,
ADD COLUMN razorpay_order_id TEXT,
ADD COLUMN razorpay_payment_id TEXT,
ADD COLUMN razorpay_signature TEXT;

-- Create database function to create Razorpay order
CREATE OR REPLACE FUNCTION public.create_razorpay_order(
  p_user_id UUID,
  p_plan_id UUID,
  p_amount NUMERIC,
  p_currency TEXT DEFAULT 'INR'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  order_data JSONB;
  subscription_id UUID;
BEGIN
  -- Create a pending subscription record
  INSERT INTO public.user_subscriptions (
    user_id, 
    plan_id, 
    credits_added, 
    starts_at, 
    expires_at,
    status
  )
  SELECT 
    p_user_id,
    p_plan_id,
    sp.lead_credits,
    now(),
    now() + interval '1 day' * sp.duration_days,
    'pending'
  FROM public.subscription_plans sp
  WHERE sp.id = p_plan_id
  RETURNING id INTO subscription_id;

  -- Return order data for Razorpay
  order_data := jsonb_build_object(
    'subscription_id', subscription_id,
    'amount', p_amount * 100, -- Razorpay expects amount in paise
    'currency', p_currency,
    'user_id', p_user_id,
    'plan_id', p_plan_id
  );

  RETURN order_data;
END;
$$;

-- Create database function to verify Razorpay payment
CREATE OR REPLACE FUNCTION public.verify_razorpay_payment(
  p_razorpay_order_id TEXT,
  p_razorpay_payment_id TEXT,
  p_razorpay_signature TEXT,
  p_subscription_id UUID
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  subscription_record RECORD;
BEGIN
  -- Get subscription record
  SELECT us.*, sp.lead_credits
  INTO subscription_record
  FROM public.user_subscriptions us
  JOIN public.subscription_plans sp ON us.plan_id = sp.id
  WHERE us.id = p_subscription_id AND us.status = 'pending';

  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;

  -- Update subscription with payment details
  UPDATE public.user_subscriptions 
  SET 
    razorpay_order_id = p_razorpay_order_id,
    razorpay_payment_id = p_razorpay_payment_id,
    razorpay_signature = p_razorpay_signature,
    status = 'active',
    updated_at = now()
  WHERE id = p_subscription_id;

  -- Add credits to user
  PERFORM public.add_user_credits(
    subscription_record.user_id, 
    subscription_record.lead_credits,
    p_subscription_id
  );

  RETURN TRUE;
END;
$$;