-- Update the request_professional_contact function to look in business_registrations table
DROP FUNCTION IF EXISTS public.request_professional_contact(uuid, text);

CREATE OR REPLACE FUNCTION public.request_professional_contact(
  professional_id uuid, 
  requester_message text DEFAULT 'I would like to discuss a project with you.'::text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  professional_data RECORD;
  user_credits RECORD;
  access_exists BOOLEAN;
  result jsonb;
BEGIN
  -- Check if user is authenticated
  IF auth.uid() IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Authentication required to request contact information'
    );
  END IF;
  
  -- Check if user already accessed this professional's contact info
  SELECT EXISTS(
    SELECT 1 FROM public.lead_access_logs 
    WHERE user_id = auth.uid() 
    AND requirement_id = professional_id 
    AND access_type = 'contact'
  ) INTO access_exists;
  
  -- If already accessed, get professional data without consuming credits
  IF access_exists THEN
    SELECT email_address, phone_number, contact_name INTO professional_data
    FROM public.business_registrations 
    WHERE id = professional_id AND status = 'approved';
    
    IF NOT FOUND THEN
      RETURN jsonb_build_object(
        'success', false,
        'error', 'Professional not found'
      );
    END IF;
    
    RETURN jsonb_build_object(
      'success', true,
      'message', 'Contact information already accessed',
      'professional_name', professional_data.contact_name,
      'email', professional_data.email_address,
      'phone', professional_data.phone_number
    );
  END IF;
  
  -- Check if user has enough credits
  SELECT (total_credits - used_credits) as available_credits
  INTO user_credits
  FROM public.user_lead_credits 
  WHERE user_id = auth.uid();
  
  -- If no credit record exists or insufficient credits
  IF user_credits IS NULL OR user_credits.available_credits < 1 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Insufficient credits to access contact information',
      'credits_required', 1,
      'available_credits', COALESCE(user_credits.available_credits, 0)
    );
  END IF;
  
  -- Get professional data
  SELECT email_address, phone_number, contact_name INTO professional_data
  FROM public.business_registrations 
  WHERE id = professional_id AND status = 'approved';
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Professional not found'
    );
  END IF;
  
  -- Consume 1 credit using existing function
  IF NOT public.consume_lead_credits(auth.uid(), professional_id, 1, 'contact') THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Failed to consume credits. Please try again.'
    );
  END IF;
  
  -- Create a notification for the professional about the contact request
  -- Note: professional_id here is actually business_registration_id, need to get user_id
  DECLARE
    business_user_id uuid;
  BEGIN
    SELECT user_id INTO business_user_id 
    FROM public.business_registrations 
    WHERE id = professional_id;
    
    IF business_user_id IS NOT NULL THEN
      PERFORM public.create_notification(
        business_user_id,
        'New Contact Request',
        'Someone wants to contact you about a project: ' || requester_message,
        'contact_request'
      );
    END IF;
  END;
  
  -- Return success with contact information
  RETURN jsonb_build_object(
    'success', true,
    'message', 'Contact information accessed successfully (1 credit consumed)',
    'professional_name', professional_data.contact_name,
    'email', professional_data.email_address,
    'phone', professional_data.phone_number,
    'credits_consumed', 1
  );
END;
$function$;