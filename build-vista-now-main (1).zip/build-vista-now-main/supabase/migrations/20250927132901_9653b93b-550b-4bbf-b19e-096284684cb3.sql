-- Fix the lead_access_logs table to handle both requirements and professional contact access
-- First, let's remove the foreign key constraint and make the table more flexible

ALTER TABLE public.lead_access_logs DROP CONSTRAINT IF EXISTS lead_access_logs_requirement_id_fkey;

-- Add a new column to specify what type of access this is
ALTER TABLE public.lead_access_logs ADD COLUMN IF NOT EXISTS access_entity_type TEXT DEFAULT 'requirement';

-- Update existing records to mark them as requirement access
UPDATE public.lead_access_logs SET access_entity_type = 'requirement' WHERE access_entity_type IS NULL;

-- Add a check constraint to ensure access_entity_type is valid
ALTER TABLE public.lead_access_logs DROP CONSTRAINT IF EXISTS lead_access_logs_access_entity_type_check;
ALTER TABLE public.lead_access_logs ADD CONSTRAINT lead_access_logs_access_entity_type_check 
CHECK (access_entity_type IN ('requirement', 'professional'));

-- Rename the requirement_id column to be more generic
ALTER TABLE public.lead_access_logs RENAME COLUMN requirement_id TO entity_id;