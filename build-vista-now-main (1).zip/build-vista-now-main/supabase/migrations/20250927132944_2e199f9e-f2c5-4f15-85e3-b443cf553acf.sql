-- Update the consume_lead_credits function to work with the new table structure
DROP FUNCTION IF EXISTS public.consume_lead_credits(uuid, uuid, integer, text);

CREATE OR REPLACE FUNCTION public.consume_lead_credits(
  p_user_id uuid, 
  p_entity_id uuid, 
  p_credits integer DEFAULT 1, 
  p_access_type text DEFAULT 'view'::text,
  p_entity_type text DEFAULT 'requirement'::text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  available_credits INTEGER;
  access_exists BOOLEAN;
BEGIN
  -- Check if user already accessed this entity
  SELECT EXISTS(
    SELECT 1 FROM public.lead_access_logs 
    WHERE user_id = p_user_id 
    AND entity_id = p_entity_id 
    AND access_type = p_access_type
    AND access_entity_type = p_entity_type
  ) INTO access_exists;
  
  -- If already accessed, don't charge again
  IF access_exists THEN
    RETURN TRUE;
  END IF;
  
  -- Check available credits
  SELECT (total_credits - used_credits) 
  INTO available_credits
  FROM public.user_lead_credits 
  WHERE user_id = p_user_id;
  
  IF available_credits IS NULL OR available_credits < p_credits THEN
    RETURN FALSE;
  END IF;
  
  -- Update used credits
  UPDATE public.user_lead_credits 
  SET used_credits = used_credits + p_credits,
      updated_at = now()
  WHERE user_id = p_user_id;
  
  -- Log the access
  INSERT INTO public.lead_access_logs (user_id, entity_id, credits_consumed, access_type, access_entity_type)
  VALUES (p_user_id, p_entity_id, p_credits, p_access_type, p_entity_type);
  
  RETURN TRUE;
END;
$function$;

-- Update the request_professional_contact function
DROP FUNCTION IF EXISTS public.request_professional_contact(uuid, text);

CREATE OR REPLACE FUNCTION public.request_professional_contact(
  professional_id uuid, 
  requester_message text DEFAULT 'I would like to discuss a project with you.'::text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  professional_data RECORD;
  user_credits RECORD;
  access_exists BOOLEAN;
  result jsonb;
BEGIN
  -- Check if user is authenticated
  IF auth.uid() IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Authentication required to request contact information'
    );
  END IF;
  
  -- Check if user already accessed this professional's contact info
  SELECT EXISTS(
    SELECT 1 FROM public.lead_access_logs 
    WHERE user_id = auth.uid() 
    AND entity_id = professional_id 
    AND access_type = 'contact'
    AND access_entity_type = 'professional'
  ) INTO access_exists;
  
  -- If already accessed, get professional data without consuming credits
  IF access_exists THEN
    SELECT email_address, phone_number, contact_name INTO professional_data
    FROM public.business_registrations 
    WHERE id = professional_id AND status = 'approved';
    
    IF NOT FOUND THEN
      RETURN jsonb_build_object(
        'success', false,
        'error', 'Professional not found'
      );
    END IF;
    
    RETURN jsonb_build_object(
      'success', true,
      'message', 'Contact information already accessed',
      'professional_name', professional_data.contact_name,
      'email', professional_data.email_address,
      'phone', professional_data.phone_number
    );
  END IF;
  
  -- Check if user has enough credits
  SELECT (total_credits - used_credits) as available_credits
  INTO user_credits
  FROM public.user_lead_credits 
  WHERE user_id = auth.uid();
  
  -- If no credit record exists or insufficient credits
  IF user_credits IS NULL OR user_credits.available_credits < 1 THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Insufficient credits to access contact information',
      'credits_required', 1,
      'available_credits', COALESCE(user_credits.available_credits, 0)
    );
  END IF;
  
  -- Get professional data
  SELECT email_address, phone_number, contact_name INTO professional_data
  FROM public.business_registrations 
  WHERE id = professional_id AND status = 'approved';
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Professional not found'
    );
  END IF;
  
  -- Consume 1 credit using updated function
  IF NOT public.consume_lead_credits(auth.uid(), professional_id, 1, 'contact', 'professional') THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'Failed to consume credits. Please try again.'
    );
  END IF;
  
  -- Create a notification for the professional about the contact request
  DECLARE
    business_user_id uuid;
  BEGIN
    SELECT user_id INTO business_user_id 
    FROM public.business_registrations 
    WHERE id = professional_id;
    
    IF business_user_id IS NOT NULL THEN
      PERFORM public.create_notification(
        business_user_id,
        'New Contact Request',
        'Someone wants to contact you about a project: ' || requester_message,
        'contact_request'
      );
    END IF;
  END;
  
  -- Return success with contact information
  RETURN jsonb_build_object(
    'success', true,
    'message', 'Contact information accessed successfully (1 credit consumed)',
    'professional_name', professional_data.contact_name,
    'email', professional_data.email_address,
    'phone', professional_data.phone_number,
    'credits_consumed', 1
  );
END;
$function$;