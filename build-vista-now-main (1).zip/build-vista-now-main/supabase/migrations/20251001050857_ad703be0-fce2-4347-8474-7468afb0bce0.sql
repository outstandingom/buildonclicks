-- Add storage bucket policies for social-media bucket

-- Create policy for uploading media (authenticated users only)
CREATE POLICY "Users can upload their own social media"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'social-media' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Create policy for deleting own media
CREATE POLICY "Users can delete their own social media"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'social-media' AND
  auth.uid()::text = (storage.foldername(name))[1]
);