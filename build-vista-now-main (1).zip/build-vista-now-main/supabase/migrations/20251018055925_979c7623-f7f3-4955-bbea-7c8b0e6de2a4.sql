-- Add business_registration_id to reviews table for shop/portfolio reviews
ALTER TABLE public.reviews 
ADD COLUMN business_registration_id uuid REFERENCES public.business_registrations(id) ON DELETE CASCADE;

-- Make professional_id nullable since we'll use either professional_id OR business_registration_id
ALTER TABLE public.reviews 
ALTER COLUMN professional_id DROP NOT NULL;

-- Add index for better query performance
CREATE INDEX idx_reviews_business_registration_id ON public.reviews(business_registration_id);

-- Add constraint to ensure at least one ID is provided
ALTER TABLE public.reviews 
ADD CONSTRAINT reviews_target_check 
CHECK (
  (professional_id IS NOT NULL AND business_registration_id IS NULL) OR
  (professional_id IS NULL AND business_registration_id IS NOT NULL)
);

-- Update RLS policy for reading reviews to include business reviews
DROP POLICY IF EXISTS "Everyone can read reviews" ON public.reviews;

CREATE POLICY "Everyone can read reviews" 
ON public.reviews 
FOR SELECT 
USING (true);

-- Policy for creating reviews (users can review businesses or professionals)
DROP POLICY IF EXISTS "Users can create reviews" ON public.reviews;

CREATE POLICY "Users can create reviews" 
ON public.reviews 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);