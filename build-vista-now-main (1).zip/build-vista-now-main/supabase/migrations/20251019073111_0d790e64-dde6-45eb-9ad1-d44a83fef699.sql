-- Create enum for report reasons
CREATE TYPE report_reason AS ENUM ('spam', 'harassment', 'inappropriate_content', 'fake_profile', 'scam', 'copyright', 'other');

-- Create enum for report status
CREATE TYPE report_status AS ENUM ('open', 'investigating', 'resolved', 'dismissed');

-- Create enum for report priority
CREATE TYPE report_priority AS ENUM ('low', 'medium', 'high');

-- Create enum for content types
CREATE TYPE content_type AS ENUM ('post', 'comment', 'profile', 'shop', 'portfolio');

-- Create enum for ban types
CREATE TYPE ban_type AS ENUM ('temporary', 'permanent');

-- Create enum for warning severity
CREATE TYPE warning_severity AS ENUM ('low', 'medium', 'high');

-- Create user_reports table
CREATE TABLE public.user_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reported_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  content_type content_type NOT NULL,
  content_id UUID NOT NULL,
  reason report_reason NOT NULL,
  description TEXT NOT NULL,
  status report_status NOT NULL DEFAULT 'open',
  priority report_priority NOT NULL DEFAULT 'medium',
  admin_notes TEXT,
  resolved_by UUID REFERENCES public.admin_users(id),
  resolved_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_warnings table
CREATE TABLE public.user_warnings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  admin_id UUID NOT NULL REFERENCES public.admin_users(id),
  report_id UUID REFERENCES public.user_reports(id) ON DELETE SET NULL,
  reason TEXT NOT NULL,
  severity warning_severity NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_bans table
CREATE TABLE public.user_bans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  admin_id UUID NOT NULL REFERENCES public.admin_users(id),
  report_id UUID REFERENCES public.user_reports(id) ON DELETE SET NULL,
  reason TEXT NOT NULL,
  ban_type ban_type NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- Create indexes for performance
CREATE INDEX idx_user_reports_status ON public.user_reports(status);
CREATE INDEX idx_user_reports_priority ON public.user_reports(priority);
CREATE INDEX idx_user_reports_reporter ON public.user_reports(reporter_id);
CREATE INDEX idx_user_reports_reported_user ON public.user_reports(reported_user_id);
CREATE INDEX idx_user_reports_content ON public.user_reports(content_type, content_id);
CREATE INDEX idx_user_reports_created_at ON public.user_reports(created_at DESC);

CREATE INDEX idx_user_warnings_user ON public.user_warnings(user_id);
CREATE INDEX idx_user_warnings_created_at ON public.user_warnings(created_at DESC);

CREATE INDEX idx_user_bans_active ON public.user_bans(user_id, is_active);
CREATE INDEX idx_user_bans_expires ON public.user_bans(expires_at) WHERE is_active = true;

-- Enable RLS
ALTER TABLE public.user_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_warnings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_bans ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_reports
CREATE POLICY "Users can view their own reports"
  ON public.user_reports FOR SELECT
  USING (auth.uid() = reporter_id);

CREATE POLICY "Users can create reports"
  ON public.user_reports FOR INSERT
  WITH CHECK (auth.uid() = reporter_id);

-- RLS Policies for user_warnings
CREATE POLICY "Users can view their own warnings"
  ON public.user_warnings FOR SELECT
  USING (auth.uid() = user_id);

-- RLS Policies for user_bans
CREATE POLICY "Users can view their own bans"
  ON public.user_bans FOR SELECT
  USING (auth.uid() = user_id);

-- Function to check if user is banned
CREATE OR REPLACE FUNCTION public.is_user_banned(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.user_bans
    WHERE user_id = p_user_id
    AND is_active = true
    AND (ban_type = 'permanent' OR expires_at > now())
  );
END;
$$;

-- Function to get user warning count
CREATE OR REPLACE FUNCTION public.get_user_warning_count(p_user_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  warning_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO warning_count
  FROM public.user_warnings
  WHERE user_id = p_user_id;
  
  RETURN warning_count;
END;
$$;

-- Function to auto-expire temporary bans
CREATE OR REPLACE FUNCTION public.expire_temporary_bans()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.user_bans
  SET is_active = false
  WHERE ban_type = 'temporary'
  AND is_active = true
  AND expires_at <= now();
END;
$$;

-- Function to get admin reports with user details
CREATE OR REPLACE FUNCTION public.get_admin_reports(p_status TEXT DEFAULT NULL, p_priority TEXT DEFAULT NULL)
RETURNS TABLE(
  id UUID,
  reporter_name TEXT,
  reported_user_name TEXT,
  content_type content_type,
  content_id UUID,
  reason report_reason,
  description TEXT,
  status report_status,
  priority report_priority,
  admin_notes TEXT,
  resolved_by_name TEXT,
  resolved_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE,
  reporter_id UUID,
  reported_user_id UUID
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ur.id,
    COALESCE(p1.full_name, 'Unknown User') as reporter_name,
    COALESCE(p2.full_name, 'Unknown User') as reported_user_name,
    ur.content_type,
    ur.content_id,
    ur.reason,
    ur.description,
    ur.status,
    ur.priority,
    ur.admin_notes,
    au.full_name as resolved_by_name,
    ur.resolved_at,
    ur.created_at,
    ur.reporter_id,
    ur.reported_user_id
  FROM public.user_reports ur
  LEFT JOIN public.profiles p1 ON ur.reporter_id = p1.id
  LEFT JOIN public.profiles p2 ON ur.reported_user_id = p2.id
  LEFT JOIN public.admin_users au ON ur.resolved_by = au.id
  WHERE 
    (p_status IS NULL OR ur.status::TEXT = p_status)
    AND (p_priority IS NULL OR ur.priority::TEXT = p_priority)
  ORDER BY 
    CASE ur.priority
      WHEN 'high' THEN 1
      WHEN 'medium' THEN 2
      WHEN 'low' THEN 3
    END,
    ur.created_at DESC;
END;
$$;

-- Trigger to update updated_at on user_reports
CREATE TRIGGER update_user_reports_updated_at
  BEFORE UPDATE ON public.user_reports
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();