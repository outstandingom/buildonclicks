-- Enable pgcrypto extension for password hashing
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Create login attempts tracking table for rate limiting
CREATE TABLE IF NOT EXISTS public.admin_login_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  ip_address text,
  attempted_at timestamp with time zone NOT NULL DEFAULT now(),
  success boolean NOT NULL DEFAULT false
);

-- Add index for efficient rate limiting queries
CREATE INDEX IF NOT EXISTS idx_admin_login_attempts_email_time 
ON public.admin_login_attempts(email, attempted_at DESC);

CREATE INDEX IF NOT EXISTS idx_admin_login_attempts_ip_time 
ON public.admin_login_attempts(ip_address, attempted_at DESC);

-- Hash existing plaintext password
UPDATE public.admin_users 
SET password_hash = crypt('admin@123', gen_salt('bf'))
WHERE email = 'info.buildonclick@gmail.com' AND password_hash = 'admin@123';

-- Replace password verification function with secure bcrypt comparison
CREATE OR REPLACE FUNCTION public.verify_admin_credentials(p_email text, p_password text)
RETURNS TABLE(admin_id uuid, admin_email text, admin_name text, admin_role text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  admin_record RECORD;
BEGIN
  -- Get admin user record
  SELECT id, email, password_hash, full_name, role, is_active
  INTO admin_record
  FROM public.admin_users
  WHERE email = p_email AND is_active = true;
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Secure password verification using bcrypt
  IF admin_record.password_hash = crypt(p_password, admin_record.password_hash) THEN
    -- Update last login
    UPDATE public.admin_users 
    SET last_login = now() 
    WHERE id = admin_record.id;
    
    -- Return admin info
    RETURN QUERY SELECT 
      admin_record.id,
      admin_record.email,
      admin_record.full_name,
      admin_record.role;
  END IF;
END;
$function$;

-- Function to check if login should be blocked due to rate limiting
CREATE OR REPLACE FUNCTION public.check_admin_rate_limit(p_email text, p_ip_address text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  email_attempts integer;
  ip_attempts integer;
BEGIN
  -- Check failed attempts from email in last 15 minutes
  SELECT COUNT(*)
  INTO email_attempts
  FROM public.admin_login_attempts
  WHERE email = p_email 
    AND success = false
    AND attempted_at > now() - interval '15 minutes';
  
  -- Check failed attempts from IP in last 15 minutes
  SELECT COUNT(*)
  INTO ip_attempts
  FROM public.admin_login_attempts
  WHERE ip_address = p_ip_address
    AND success = false
    AND attempted_at > now() - interval '15 minutes';
  
  -- Block if more than 5 failed attempts from email or IP
  RETURN (email_attempts >= 5 OR ip_attempts >= 5);
END;
$function$;

-- Function to log login attempt
CREATE OR REPLACE FUNCTION public.log_admin_login_attempt(
  p_email text, 
  p_ip_address text, 
  p_success boolean
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.admin_login_attempts (email, ip_address, success)
  VALUES (p_email, p_ip_address, p_success);
  
  -- Clean up old attempts (older than 24 hours)
  DELETE FROM public.admin_login_attempts
  WHERE attempted_at < now() - interval '24 hours';
END;
$function$;