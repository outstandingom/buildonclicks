-- Enable RLS on admin_login_attempts table
ALTER TABLE public.admin_login_attempts ENABLE ROW LEVEL SECURITY;

-- Create policy to allow service role to manage login attempts
CREATE POLICY "Service role can manage login attempts"
ON public.admin_login_attempts
FOR ALL
USING (true);