-- Enable RLS on admin_login_attempts table
ALTER TABLE public.admin_login_attempts ENABLE ROW LEVEL SECURITY;

-- No policies needed - this table should only be accessed by SECURITY DEFINER functions
-- Admin users don't need direct access to login attempts