-- Add composite index for faster batch access queries on lead_access_logs
-- This index optimizes the IN query used in hasAccessedLeads function
CREATE INDEX IF NOT EXISTS idx_lead_access_logs_batch_lookup 
ON lead_access_logs(user_id, access_type, access_entity_type, entity_id);

-- Add comment for documentation
COMMENT ON INDEX idx_lead_access_logs_batch_lookup IS 
'Composite index to optimize batch lead access queries. Used by hasAccessedLeads function to check multiple entity_ids at once.';