-- Insert admin user using bcrypt hash for password 'admin123'
-- In production, this should be changed immediately
INSERT INTO public.admin_users (email, password_hash, full_name, role, is_active)
VALUES (
  'info.buildonclkick@gmail.com',
  crypt('admin123', gen_salt('bf')),
  'Admin User',
  'admin',
  true
)
ON CONFLICT (email) DO UPDATE 
SET is_active = true,
    updated_at = now();

-- Add last_accessed_at column to admin_sessions if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public' 
    AND table_name = 'admin_sessions' 
    AND column_name = 'last_accessed_at'
  ) THEN
    ALTER TABLE public.admin_sessions ADD COLUMN last_accessed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
  END IF;
END $$;

-- Update verify_admin_session function to use last_accessed_at
CREATE OR REPLACE FUNCTION public.verify_admin_session(p_session_token TEXT)
RETURNS TABLE(admin_id UUID, admin_email TEXT, admin_name TEXT, admin_role TEXT)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  session_record RECORD;
  admin_record RECORD;
BEGIN
  -- Get session record
  SELECT admin_id, expires_at
  INTO session_record
  FROM public.admin_sessions
  WHERE session_token = p_session_token AND expires_at > now();
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Get admin record
  SELECT id, email, full_name, role
  INTO admin_record
  FROM public.admin_users
  WHERE id = session_record.admin_id AND is_active = true;
  
  IF FOUND THEN
    -- Update last accessed timestamp
    UPDATE public.admin_sessions
    SET last_accessed_at = now()
    WHERE session_token = p_session_token;
    
    RETURN QUERY SELECT 
      admin_record.id,
      admin_record.email,
      admin_record.full_name,
      admin_record.role;
  END IF;
END;
$$;