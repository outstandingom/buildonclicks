-- Clear ALL rate limiting attempts
TRUNCATE TABLE public.admin_login_attempts;

-- Reset password for existing admin user
UPDATE public.admin_users 
SET password_hash = crypt('admin123', gen_salt('bf')),
    is_active = true,
    updated_at = now()
WHERE email = 'info.buildonclick@gmail.com';