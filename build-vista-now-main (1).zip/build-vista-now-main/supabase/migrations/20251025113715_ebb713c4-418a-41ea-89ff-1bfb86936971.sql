-- Enable pgcrypto extension for password hashing
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Re-hash the admin password now that pgcrypto is enabled
UPDATE public.admin_users 
SET password_hash = crypt('admin123', gen_salt('bf')),
    updated_at = now()
WHERE email = 'info.buildonclick@gmail.com';

-- Clear rate limit attempts
TRUNCATE TABLE public.admin_login_attempts;