-- Drop and recreate the verify_admin_credentials function with pgcrypto enabled
DROP FUNCTION IF EXISTS public.verify_admin_credentials(text, text);

CREATE OR REPLACE FUNCTION public.verify_admin_credentials(
  p_email text,
  p_password text
)
RETURNS TABLE (
  admin_id uuid,
  admin_email text,
  admin_name text,
  admin_role text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    au.id,
    au.email,
    au.full_name,
    au.role
  FROM public.admin_users au
  WHERE au.email = p_email
    AND au.is_active = true
    AND au.password_hash = crypt(p_password, au.password_hash);
END;
$$;