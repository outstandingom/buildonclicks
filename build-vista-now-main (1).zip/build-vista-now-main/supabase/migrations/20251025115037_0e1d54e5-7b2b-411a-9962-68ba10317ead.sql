-- Clear rate limit attempts to allow login
TRUNCATE TABLE public.admin_login_attempts;