-- Clear rate limit records to allow login
DELETE FROM public.admin_login_attempts WHERE success = false;