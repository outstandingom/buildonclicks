-- Fix create_admin_session to remove newlines from base64 token
DROP FUNCTION IF EXISTS public.create_admin_session(uuid);

CREATE OR REPLACE FUNCTION public.create_admin_session(p_admin_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  session_token TEXT;
BEGIN
  -- Generate session token and remove newlines from base64 encoding
  session_token := replace(
    encode(
      (random()::text || extract(epoch from now())::text || p_admin_id::text)::bytea, 
      'base64'
    ),
    E'\n',
    ''
  );
  
  -- Insert session
  INSERT INTO public.admin_sessions (admin_id, session_token, expires_at)
  VALUES (p_admin_id, session_token, now() + interval '24 hours');
  
  RETURN session_token;
END;
$$;