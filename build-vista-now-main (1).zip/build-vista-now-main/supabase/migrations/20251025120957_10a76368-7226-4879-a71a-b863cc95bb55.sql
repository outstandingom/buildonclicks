-- Create function to create admin users with password hashing
CREATE OR REPLACE FUNCTION public.create_admin_user(
  p_email text,
  p_password text,
  p_full_name text,
  p_role text DEFAULT 'admin'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  -- Check if admin already exists
  IF EXISTS (SELECT 1 FROM public.admin_users WHERE email = p_email) THEN
    RAISE EXCEPTION 'Admin with this email already exists';
  END IF;
  
  -- Insert new admin with hashed password
  INSERT INTO public.admin_users (email, password_hash, full_name, role, is_active)
  VALUES (p_email, crypt(p_password, gen_salt('bf')), p_full_name, p_role, true);
  
  RETURN true;
END;
$$;