-- Create function to get all contact submissions for admins
CREATE OR REPLACE FUNCTION public.get_contact_submissions()
RETURNS TABLE(
  id uuid,
  first_name text,
  last_name text,
  email text,
  phone text,
  subject text,
  message text,
  status text,
  admin_notes text,
  created_at timestamp with time zone,
  updated_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    cs.id,
    cs.first_name,
    cs.last_name,
    cs.email,
    cs.phone,
    cs.subject,
    cs.message,
    cs.status,
    cs.admin_notes,
    cs.created_at,
    cs.updated_at
  FROM public.contact_submissions cs
  ORDER BY cs.created_at DESC;
END;
$$;

-- Create function to update contact submission status
CREATE OR REPLACE FUNCTION public.update_contact_submission(
  p_submission_id uuid,
  p_status text,
  p_admin_notes text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.contact_submissions
  SET 
    status = p_status,
    admin_notes = p_admin_notes,
    updated_at = now()
  WHERE id = p_submission_id;
  
  RETURN FOUND;
END;
$$;