-- Fix the verify_admin_session function to resolve column ambiguity
CREATE OR REPLACE FUNCTION public.verify_admin_session(p_session_token text)
RETURNS TABLE(admin_id uuid, admin_email text, admin_name text, admin_role text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_session_record RECORD;
  v_admin_record RECORD;
BEGIN
  -- Get session record
  SELECT s.admin_id, s.expires_at
  INTO v_session_record
  FROM public.admin_sessions s
  WHERE s.session_token = p_session_token AND s.expires_at > now();
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Get admin record
  SELECT a.id, a.email, a.full_name, a.role
  INTO v_admin_record
  FROM public.admin_users a
  WHERE a.id = v_session_record.admin_id AND a.is_active = true;
  
  IF FOUND THEN
    -- Update last accessed timestamp
    UPDATE public.admin_sessions
    SET last_accessed_at = now()
    WHERE session_token = p_session_token;
    
    RETURN QUERY SELECT 
      v_admin_record.id,
      v_admin_record.email,
      v_admin_record.full_name,
      v_admin_record.role;
  END IF;
END;
$$;