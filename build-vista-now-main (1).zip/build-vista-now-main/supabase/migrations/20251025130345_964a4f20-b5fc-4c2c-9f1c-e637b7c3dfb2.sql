-- Create function to get all admin users
CREATE OR REPLACE FUNCTION public.get_all_admin_users()
RETURNS TABLE(
  id uuid,
  email text,
  full_name text,
  role text,
  is_active boolean,
  created_at timestamp with time zone,
  last_login timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    au.id,
    au.email,
    au.full_name,
    au.role,
    au.is_active,
    au.created_at,
    au.last_login
  FROM public.admin_users au
  ORDER BY au.created_at DESC;
END;
$$;

-- Create function to update admin status (block/unblock)
CREATE OR REPLACE FUNCTION public.update_admin_status(
  p_admin_id uuid,
  p_is_active boolean
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.admin_users
  SET 
    is_active = p_is_active,
    updated_at = now()
  WHERE id = p_admin_id;
  
  RETURN FOUND;
END;
$$;

-- Create function to update admin role
CREATE OR REPLACE FUNCTION public.update_admin_role(
  p_admin_id uuid,
  p_role text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.admin_users
  SET 
    role = p_role,
    updated_at = now()
  WHERE id = p_admin_id;
  
  RETURN FOUND;
END;
$$;

-- Create function to delete admin user
CREATE OR REPLACE FUNCTION public.delete_admin_user(
  p_admin_id uuid
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Delete associated sessions first
  DELETE FROM public.admin_sessions WHERE admin_id = p_admin_id;
  
  -- Delete admin user
  DELETE FROM public.admin_users WHERE id = p_admin_id;
  
  RETURN FOUND;
END;
$$;