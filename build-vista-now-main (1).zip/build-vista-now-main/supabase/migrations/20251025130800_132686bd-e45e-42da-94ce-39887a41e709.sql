-- Create function to reset/change admin password
CREATE OR REPLACE FUNCTION public.reset_admin_password(
  p_admin_id uuid,
  p_new_password text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
BEGIN
  -- Validate password length
  IF LENGTH(p_new_password) < 8 THEN
    RAISE EXCEPTION 'Password must be at least 8 characters long';
  END IF;
  
  -- Update password with bcrypt hashing
  UPDATE public.admin_users
  SET 
    password_hash = crypt(p_new_password, gen_salt('bf')),
    updated_at = now()
  WHERE id = p_admin_id;
  
  -- Invalidate all existing sessions for this admin
  DELETE FROM public.admin_sessions 
  WHERE admin_id = p_admin_id;
  
  RETURN FOUND;
END;
$$;