-- Drop and recreate the function with fixed SQL
DROP FUNCTION IF EXISTS get_user_details_for_admin(UUID);

CREATE OR REPLACE FUNCTION get_user_details_for_admin(p_user_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result JSON;
BEGIN
  SELECT json_build_object(
    'profile', (
      SELECT json_build_object(
        'id', p.id,
        'full_name', p.full_name,
        'mobile_number', p.mobile_number,
        'user_type', p.user_type,
        'created_at', p.created_at,
        'profile_image_url', p.profile_image_url,
        'city_name', c.name,
        'is_active', true,
        'email', (SELECT email FROM auth.users WHERE id = p.id)
      )
      FROM profiles p
      LEFT JOIN cities c ON p.city_id = c.id
      WHERE p.id = p_user_id
    ),
    'credit_summary', (
      SELECT json_build_object(
        'total_credits', COALESCE(ulc.total_credits, 0),
        'used_credits', COALESCE(ulc.used_credits, 0),
        'available_credits', COALESCE(ulc.total_credits - ulc.used_credits, 0),
        'free_credits_given', COALESCE(ulc.free_credits_given, false),
        'access_logs', COALESCE(
          (SELECT json_agg(log_data)
          FROM (
            SELECT json_build_object(
              'access_type', lal.access_type,
              'credits_consumed', lal.credits_consumed,
              'created_at', lal.created_at
            ) as log_data
            FROM lead_access_logs lal
            WHERE lal.user_id = p_user_id
            ORDER BY lal.created_at DESC
            LIMIT 20
          ) as logs
          ), '[]'::json
        )
      )
      FROM user_lead_credits ulc
      WHERE ulc.user_id = p_user_id
    ),
    'subscriptions', COALESCE(
      (SELECT json_agg(sub_data)
      FROM (
        SELECT json_build_object(
          'id', us.id,
          'plan_name', sp.name,
          'plan_description', sp.description,
          'credits_added', us.credits_added,
          'amount', sp.price_inr,
          'status', us.status,
          'starts_at', us.starts_at,
          'expires_at', us.expires_at,
          'created_at', us.created_at,
          'razorpay_payment_id', us.razorpay_payment_id
        ) as sub_data
        FROM user_subscriptions us
        LEFT JOIN subscription_plans sp ON us.plan_id = sp.id
        WHERE us.user_id = p_user_id
        ORDER BY us.created_at DESC
      ) as subs
      ), '[]'::json
    ),
    'referral_stats', (
      SELECT json_build_object(
        'referral_code', COALESCE(MAX(rc.code), ''),
        'total_referrals', COUNT(DISTINCT r.id),
        'successful_referrals', COUNT(DISTINCT CASE WHEN r.status = 'completed' THEN r.id END),
        'pending_referrals', COUNT(DISTINCT CASE WHEN r.status = 'pending' THEN r.id END),
        'total_credits_earned', COALESCE(SUM(DISTINCT rt.credits_amount), 0)
      )
      FROM referral_codes rc
      LEFT JOIN referrals r ON rc.id = r.referral_code_id
      LEFT JOIN referral_transactions rt ON r.id = rt.referral_id AND rt.user_id = p_user_id
      WHERE rc.user_id = p_user_id
    ),
    'referral_transactions', COALESCE(
      (SELECT json_agg(trans_data)
      FROM (
        SELECT json_build_object(
          'id', rt.id,
          'credits_amount', rt.credits_amount,
          'transaction_type', rt.transaction_type,
          'created_at', rt.created_at,
          'referee_name', (SELECT full_name FROM profiles WHERE id = r.referee_id),
          'status', r.status
        ) as trans_data
        FROM referral_transactions rt
        LEFT JOIN referrals r ON rt.referral_id = r.id
        WHERE rt.user_id = p_user_id
        ORDER BY rt.created_at DESC
      ) as trans
      ), '[]'::json
    )
  ) INTO result;

  RETURN result;
END;
$$;