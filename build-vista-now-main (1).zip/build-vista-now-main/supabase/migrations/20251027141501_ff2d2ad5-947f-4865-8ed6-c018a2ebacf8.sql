-- Create storage bucket for business documents if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('business-documents', 'business-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Admins can view all business documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload their business documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their business documents" ON storage.objects;
DROP POLICY IF EXISTS "Service role can access all documents" ON storage.objects;

-- Allow service role (for admin access through service functions) to access all documents
CREATE POLICY "Service role can access all documents"
ON storage.objects
FOR SELECT
TO service_role
USING (bucket_id = 'business-documents');

-- Allow authenticated users to view documents (for when admin is logged in)
CREATE POLICY "Authenticated users can view business documents"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'business-documents');

-- Allow authenticated users to upload their own business documents
CREATE POLICY "Users can upload their business documents"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'business-documents');

-- Allow users to update their own documents
CREATE POLICY "Users can update their business documents"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'business-documents');