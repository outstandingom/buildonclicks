-- Remove duplicate business types (singular versions)
-- Keep "Designers" and "Engineers" (plural versions)

DELETE FROM business_types 
WHERE id IN (
  '6465925a-eb43-4daa-95d5-6f8e6bc5c410', -- Designer
  'eeb9c6dd-44c3-4e4c-bbb1-45c312596ab0'  -- Engineer
);