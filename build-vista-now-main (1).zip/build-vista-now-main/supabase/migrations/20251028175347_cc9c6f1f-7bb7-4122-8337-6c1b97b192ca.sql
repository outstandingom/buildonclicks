-- Make service_area nullable to allow removal from forms
ALTER TABLE business_registrations 
ALTER COLUMN service_area DROP NOT NULL;