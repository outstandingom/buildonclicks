-- Make business_license_url and business_certificate_url nullable in business_registrations table
ALTER TABLE business_registrations 
  ALTER COLUMN business_license_url DROP NOT NULL,
  ALTER COLUMN business_certificate_url DROP NOT NULL;