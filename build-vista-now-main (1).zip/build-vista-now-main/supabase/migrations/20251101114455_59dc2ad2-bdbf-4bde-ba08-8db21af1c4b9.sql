-- Create function to get user basic info for social posts
-- This helps when profiles table doesn't have complete data
CREATE OR REPLACE FUNCTION public.get_user_basic_info(user_ids UUID[])
RETURNS TABLE (
  id UUID,
  email TEXT,
  full_name TEXT,
  profile_image_url TEXT,
  created_at TIMESTAMPTZ
) 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    au.id,
    au.email,
    COALESCE(p.full_name, au.raw_user_meta_data->>'full_name', au.email) as full_name,
    p.profile_image_url,
    au.created_at
  FROM auth.users au
  LEFT JOIN public.profiles p ON p.id = au.id
  WHERE au.id = ANY(user_ids);
END;
$$;