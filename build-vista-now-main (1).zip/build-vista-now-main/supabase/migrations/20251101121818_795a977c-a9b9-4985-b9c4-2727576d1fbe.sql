-- Allow authenticated users to view basic profile info (name and image) for social features
-- This is needed so users can see who posted on social feed
CREATE POLICY "Users can view basic profile info of others"
ON public.profiles
FOR SELECT
TO authenticated
USING (true);

-- Update the RLS so basic info (full_name, profile_image_url) is visible to all authenticated users
-- But sensitive info like mobile_number, address is still protected by the existing "view own profile" policy