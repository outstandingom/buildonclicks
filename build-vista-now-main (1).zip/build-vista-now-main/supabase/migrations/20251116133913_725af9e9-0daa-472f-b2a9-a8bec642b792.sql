-- Create requirement-attachments storage bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('requirement-attachments', 'requirement-attachments', false)
ON CONFLICT (id) DO NOTHING;