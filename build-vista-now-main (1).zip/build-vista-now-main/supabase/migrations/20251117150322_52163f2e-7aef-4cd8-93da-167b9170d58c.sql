-- Create quick requirement submissions table
CREATE TABLE public.quick_requirement_submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  service TEXT NOT NULL,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  admin_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.quick_requirement_submissions ENABLE ROW LEVEL SECURITY;

-- Allow anyone to submit
CREATE POLICY "Anyone can submit quick requirements"
ON public.quick_requirement_submissions
FOR INSERT
TO public
WITH CHECK (true);

-- Service role can view all
CREATE POLICY "Service role can view all quick requirements"
ON public.quick_requirement_submissions
FOR SELECT
TO service_role
USING (true);

-- Service role can update
CREATE POLICY "Service role can update quick requirements"
ON public.quick_requirement_submissions
FOR UPDATE
TO service_role
USING (true);

-- Add updated_at trigger
CREATE TRIGGER update_quick_requirement_submissions_updated_at
BEFORE UPDATE ON public.quick_requirement_submissions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to get submissions
CREATE OR REPLACE FUNCTION public.get_quick_requirement_submissions()
RETURNS TABLE (
  id UUID,
  name TEXT,
  phone TEXT,
  service TEXT,
  message TEXT,
  status TEXT,
  admin_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    qrs.id,
    qrs.name,
    qrs.phone,
    qrs.service,
    qrs.message,
    qrs.status,
    qrs.admin_notes,
    qrs.created_at,
    qrs.updated_at
  FROM public.quick_requirement_submissions qrs
  ORDER BY qrs.created_at DESC;
END;
$$;

-- Create function to update submission
CREATE OR REPLACE FUNCTION public.update_quick_requirement_submission(
  p_submission_id UUID,
  p_status TEXT,
  p_admin_notes TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public
AS $$
BEGIN
  UPDATE public.quick_requirement_submissions
  SET 
    status = p_status,
    admin_notes = p_admin_notes,
    updated_at = now()
  WHERE id = p_submission_id;
  
  RETURN FOUND;
END;
$$;