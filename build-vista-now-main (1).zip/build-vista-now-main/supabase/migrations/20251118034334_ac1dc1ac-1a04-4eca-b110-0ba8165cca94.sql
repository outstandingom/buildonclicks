-- Add foreign key constraint for saved_social_posts to social_posts
ALTER TABLE public.saved_social_posts
ADD CONSTRAINT saved_social_posts_post_id_fkey 
FOREIGN KEY (post_id) 
REFERENCES public.social_posts(id) 
ON DELETE CASCADE;