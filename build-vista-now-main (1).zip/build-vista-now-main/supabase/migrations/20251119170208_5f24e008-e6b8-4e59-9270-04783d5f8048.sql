-- Fix saved_professionals foreign key to reference business_registrations instead of professionals
-- Drop the old foreign key constraint
ALTER TABLE public.saved_professionals
DROP CONSTRAINT IF EXISTS saved_professionals_professional_id_fkey;

-- Add new foreign key constraint pointing to business_registrations
ALTER TABLE public.saved_professionals
ADD CONSTRAINT saved_professionals_professional_id_fkey 
FOREIGN KEY (professional_id) 
REFERENCES public.business_registrations(id) 
ON DELETE CASCADE;

-- Create RLS policies for saved_professionals if they don't exist
ALTER TABLE public.saved_professionals ENABLE ROW LEVEL SECURITY;

-- Policy: Users can view their own saved professionals
DROP POLICY IF EXISTS "Users can view their own saved professionals" ON public.saved_professionals;
CREATE POLICY "Users can view their own saved professionals"
ON public.saved_professionals
FOR SELECT
USING (auth.uid() = user_id);

-- Policy: Users can save professionals
DROP POLICY IF EXISTS "Users can save professionals" ON public.saved_professionals;
CREATE POLICY "Users can save professionals"
ON public.saved_professionals
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Policy: Users can remove their saved professionals
DROP POLICY IF EXISTS "Users can remove their saved professionals" ON public.saved_professionals;
CREATE POLICY "Users can remove their saved professionals"
ON public.saved_professionals
FOR DELETE
USING (auth.uid() = user_id);