-- Create function to get provider documents for admin
CREATE OR REPLACE FUNCTION public.get_provider_documents_for_admin(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result jsonb;
BEGIN
  SELECT jsonb_build_object(
    'id', br.id,
    'business_name', br.business_name,
    'status', br.status,
    'government_id_url', br.government_id_url,
    'business_certificate_url', br.business_certificate_url,
    'insurance_certificate_url', br.insurance_certificate_url,
    'business_license_url', br.business_license_url
  )
  INTO result
  FROM public.business_registrations br
  WHERE br.user_id = p_user_id
  ORDER BY br.created_at DESC
  LIMIT 1;
  
  RETURN result;
END;
$$;

-- Create function to update provider document URL for admin
CREATE OR REPLACE FUNCTION public.admin_update_provider_document(
  p_registration_id uuid,
  p_document_key text,
  p_document_url text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  EXECUTE format(
    'UPDATE public.business_registrations SET %I = $1, updated_at = now() WHERE id = $2',
    p_document_key
  ) USING p_document_url, p_registration_id;
  
  RETURN FOUND;
END;
$$;