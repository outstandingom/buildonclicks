-- Create RPC function to suspend a user (admin action)
CREATE OR REPLACE FUNCTION public.admin_suspend_user(
  p_user_id UUID,
  p_admin_id UUID,
  p_reason TEXT DEFAULT 'Account suspended by admin',
  p_duration_days INTEGER DEFAULT 30
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Insert a temporary ban
  INSERT INTO public.user_bans (user_id, admin_id, reason, ban_type, expires_at, is_active)
  VALUES (
    p_user_id, 
    p_admin_id, 
    p_reason, 
    'temporary', 
    now() + (p_duration_days || ' days')::interval,
    true
  );
  
  -- Create notification for the user
  PERFORM public.create_notification(
    p_user_id,
    'Account Suspended',
    format('Your account has been suspended for %s days. Reason: %s', p_duration_days, p_reason),
    'warning'
  );
  
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    RETURN FALSE;
END;
$$;

-- Create RPC function to reset user access (remove bans)
CREATE OR REPLACE FUNCTION public.admin_reset_user_access(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Deactivate all active bans for the user
  UPDATE public.user_bans
  SET is_active = false
  WHERE user_id = p_user_id AND is_active = true;
  
  -- Create notification for the user
  PERFORM public.create_notification(
    p_user_id,
    'Access Restored',
    'Your account access has been restored by an administrator.',
    'info'
  );
  
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    RETURN FALSE;
END;
$$;

-- Create RPC function to activate a user
CREATE OR REPLACE FUNCTION public.admin_activate_user(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Remove any active bans
  UPDATE public.user_bans
  SET is_active = false
  WHERE user_id = p_user_id AND is_active = true;
  
  -- Create notification for the user
  PERFORM public.create_notification(
    p_user_id,
    'Account Activated',
    'Your account has been activated by an administrator.',
    'info'
  );
  
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    RETURN FALSE;
END;
$$;