-- Add status column for social posts to support moderation
ALTER TABLE public.social_posts
ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'flagged'));

-- Optional admin notes for moderation context
ALTER TABLE public.social_posts
ADD COLUMN IF NOT EXISTS admin_notes TEXT;

-- Function to fetch social posts for moderation (with author name)
CREATE OR REPLACE FUNCTION public.get_social_posts_for_moderation()
RETURNS TABLE(
  id UUID,
  content TEXT,
  media_url TEXT,
  media_type TEXT,
  user_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  status TEXT,
  likes_count INTEGER,
  comments_count INTEGER,
  admin_notes TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT
    sp.id,
    sp.content,
    sp.media_url,
    sp.media_type,
    COALESCE(p.full_name, 'Unknown User') AS user_name,
    sp.created_at,
    sp.status,
    sp.likes_count,
    sp.comments_count,
    sp.admin_notes
  FROM public.social_posts sp
  LEFT JOIN public.profiles p ON sp.user_id = p.id
  ORDER BY sp.created_at DESC;
END;
$$;

-- Function to update social post status (approve/reject/flag)
CREATE OR REPLACE FUNCTION public.update_social_post_status(
  p_post_id UUID,
  p_status TEXT,
  p_admin_notes TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF p_status NOT IN ('pending', 'approved', 'rejected', 'flagged') THEN
    RAISE EXCEPTION 'Invalid status value';
  END IF;

  UPDATE public.social_posts
  SET
    status = p_status,
    admin_notes = p_admin_notes,
    updated_at = now()
  WHERE id = p_post_id;

  RETURN FOUND;
END;
$$;

-- Function to delete a social post (and its likes/comments)
CREATE OR REPLACE FUNCTION public.delete_social_post(
  p_post_id UUID
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Delete comments first
  DELETE FROM public.social_post_comments WHERE post_id = p_post_id;
  -- Delete likes
  DELETE FROM public.social_post_likes WHERE post_id = p_post_id;
  -- Delete the post
  DELETE FROM public.social_posts WHERE id = p_post_id;

  RETURN FOUND;
END;
$$;

