-- Drop and recreate to fix email type mismatch (cast to text)
DROP FUNCTION IF EXISTS public.get_users_for_admin();

CREATE OR REPLACE FUNCTION public.get_users_for_admin()
RETURNS TABLE(
  id UUID,
  full_name TEXT,
  user_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  city_name TEXT,
  is_active BOOLEAN,
  email TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    COALESCE(p.full_name, 'Unknown User') AS full_name,
    COALESCE(p.user_type, 'user') AS user_type,
    p.created_at,
    c.name AS city_name,
    COALESCE(p.is_active, true) AS is_active,
    au.email::text
  FROM public.profiles p
  LEFT JOIN public.cities c ON p.city_id = c.id
  LEFT JOIN auth.users au ON au.id = p.id
  ORDER BY p.created_at DESC;
END;
$$;

