-- Allow public (anon) and authenticated access to business-documents bucket

-- Ensure bucket exists
INSERT INTO storage.buckets (id, name, public)
VALUES ('business-documents', 'business-documents', true)
ON CONFLICT (id) DO NOTHING;

-- Drop old policies that might block access
DROP POLICY IF EXISTS "Authenticated users can view business documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload their business documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their business documents" ON storage.objects;
DROP POLICY IF EXISTS "Service role can access all documents" ON storage.objects;

-- Public read (needed for viewing via public URL)
CREATE POLICY "Anyone can view business documents"
ON storage.objects
FOR SELECT
USING (bucket_id = 'business-documents');

-- Public upload/update/delete (to avoid RLS failures in admin UI; consider tightening later)
CREATE POLICY "Anyone can upload business documents"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'business-documents');

CREATE POLICY "Anyone can update business documents"
ON storage.objects
FOR UPDATE
USING (bucket_id = 'business-documents');

CREATE POLICY "Anyone can delete business documents"
ON storage.objects
FOR DELETE
USING (bucket_id = 'business-documents');

