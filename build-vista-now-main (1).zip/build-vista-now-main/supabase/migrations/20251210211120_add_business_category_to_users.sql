-- Drop and recreate get_users_for_admin to include business category
DROP FUNCTION IF EXISTS public.get_users_for_admin();

CREATE OR REPLACE FUNCTION public.get_users_for_admin()
RETURNS TABLE(
  id UUID,
  full_name TEXT,
  user_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  city_name TEXT,
  is_active BOOLEAN,
  email TEXT,
  is_verified BOOLEAN,
  registration_status TEXT,
  business_category TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    COALESCE(p.full_name, 'Unknown User') AS full_name,
    COALESCE(p.user_type, 'user') AS user_type,
    p.created_at,
    c.name AS city_name,
    COALESCE(p.is_active, true) AS is_active,
    au.email::text,
    (au.email_confirmed_at IS NOT NULL) AS is_verified,
    br.status AS registration_status,
    bt.name AS business_category
  FROM public.profiles p
  LEFT JOIN public.cities c ON p.city_id = c.id
  LEFT JOIN auth.users au ON au.id = p.id
  LEFT JOIN LATERAL (
    SELECT status, business_type_id
    FROM public.business_registrations br
    WHERE br.user_id = p.id
    ORDER BY br.created_at DESC
    LIMIT 1
  ) br ON true
  LEFT JOIN public.business_types bt ON bt.id = br.business_type_id
  ORDER BY p.created_at DESC;
END;
$$;
