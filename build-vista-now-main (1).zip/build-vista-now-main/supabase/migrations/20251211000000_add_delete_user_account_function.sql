-- Create function to delete user account and all related data
CREATE OR REPLACE FUNCTION public.delete_user_account(
  p_user_id UUID
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Delete in order to respect foreign key constraints
  
  -- Delete user's lead access logs (references user_lead_credits)
  DELETE FROM public.lead_access_logs WHERE user_id = p_user_id;
  
  -- Delete user's subscriptions
  DELETE FROM public.user_subscriptions WHERE user_id = p_user_id;
  
  -- Delete user's lead credits
  DELETE FROM public.user_lead_credits WHERE user_id = p_user_id;
  
  -- Delete user's social post comments (references social_posts)
  DELETE FROM public.social_post_comments WHERE user_id = p_user_id;
  
  -- Delete comments on user's posts
  DELETE FROM public.social_post_comments WHERE post_id IN (
    SELECT id FROM public.social_posts WHERE user_id = p_user_id
  );
  
  -- Delete user's social post likes
  DELETE FROM public.social_post_likes WHERE user_id = p_user_id;
  
  -- Delete likes on user's posts
  DELETE FROM public.social_post_likes WHERE post_id IN (
    SELECT id FROM public.social_posts WHERE user_id = p_user_id
  );
  
  -- Delete user's saved social posts
  DELETE FROM public.saved_social_posts WHERE user_id = p_user_id;
  
  -- Delete user's social posts
  DELETE FROM public.social_posts WHERE user_id = p_user_id;
  
  -- Delete user's saved professionals
  DELETE FROM public.saved_professionals WHERE user_id = p_user_id;
  
  -- Delete user's business registrations
  DELETE FROM public.business_registrations WHERE user_id = p_user_id;
  
  -- Delete user's provider profiles
  DELETE FROM public.provider_profiles WHERE user_id = p_user_id;
  
  -- Delete user's requirements
  DELETE FROM public.requirements WHERE user_id = p_user_id;
  
  -- Delete user's projects (if any)
  DELETE FROM public.projects WHERE user_id = p_user_id;
  
  -- Delete user's project bids
  DELETE FROM public.project_bids WHERE user_id = p_user_id;
  
  -- Delete user's reviews
  DELETE FROM public.reviews WHERE user_id = p_user_id;
  
  -- Delete user's notifications
  DELETE FROM public.notifications WHERE user_id = p_user_id;
  
  -- Delete user's reports (as reporter)
  DELETE FROM public.user_reports WHERE reporter_id = p_user_id;
  
  -- Delete user's warnings
  DELETE FROM public.user_warnings WHERE user_id = p_user_id;
  
  -- Delete user's bans
  DELETE FROM public.user_bans WHERE user_id = p_user_id;
  
  -- Note: We don't delete the profile here - it has ON DELETE CASCADE from auth.users
  -- The profile will be automatically deleted when we delete from auth.users
  -- This avoids foreign key constraint issues
  
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    -- Log the error and re-raise it
    RAISE EXCEPTION 'Error deleting user account: %', SQLERRM;
END;
$$;

-- Grant execute permission to authenticated users (they can only delete their own account)
GRANT EXECUTE ON FUNCTION public.delete_user_account(UUID) TO authenticated;

