-- Create drafts table for business registration progress
CREATE TABLE IF NOT EXISTS public.business_registration_drafts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL UNIQUE,
  data JSONB NOT NULL DEFAULT '{}'::jsonb,
  current_step INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.business_registration_drafts ENABLE ROW LEVEL SECURITY;

-- Policies: users can manage their own drafts (drop if already present to avoid conflicts)
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can select their drafts" ON public.business_registration_drafts;
  DROP POLICY IF EXISTS "Users can insert their drafts" ON public.business_registration_drafts;
  DROP POLICY IF EXISTS "Users can update their drafts" ON public.business_registration_drafts;
  DROP POLICY IF EXISTS "Users can delete their drafts" ON public.business_registration_drafts;
END $$;

CREATE POLICY "Users can select their drafts"
  ON public.business_registration_drafts
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their drafts"
  ON public.business_registration_drafts
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their drafts"
  ON public.business_registration_drafts
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their drafts"
  ON public.business_registration_drafts
  FOR DELETE
  USING (auth.uid() = user_id);

-- Update updated_at on change
CREATE OR REPLACE TRIGGER update_business_registration_drafts_updated_at
  BEFORE UPDATE ON public.business_registration_drafts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
