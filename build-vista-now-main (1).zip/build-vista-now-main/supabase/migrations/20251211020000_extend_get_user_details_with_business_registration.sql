-- Extend admin user details to include business registration and add update helper

DROP FUNCTION IF EXISTS get_user_details_for_admin(UUID);

CREATE OR REPLACE FUNCTION get_user_details_for_admin(p_user_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result JSON;
BEGIN
  SELECT json_build_object(
    'profile', (
      SELECT json_build_object(
        'id', p.id,
        'full_name', p.full_name,
        'mobile_number', p.mobile_number,
        'user_type', p.user_type,
        'created_at', p.created_at,
        'profile_image_url', p.profile_image_url,
        'city_name', c.name,
        'is_active', true,
        'email', (SELECT email FROM auth.users WHERE id = p.id)
      )
      FROM profiles p
      LEFT JOIN cities c ON p.city_id = c.id
      WHERE p.id = p_user_id
    ),
    'credit_summary', (
      SELECT json_build_object(
        'total_credits', COALESCE(ulc.total_credits, 0),
        'used_credits', COALESCE(ulc.used_credits, 0),
        'available_credits', COALESCE(ulc.total_credits - ulc.used_credits, 0),
        'free_credits_given', COALESCE(ulc.free_credits_given, false),
        'access_logs', COALESCE(
          (SELECT json_agg(log_data)
          FROM (
            SELECT json_build_object(
              'access_type', lal.access_type,
              'credits_consumed', lal.credits_consumed,
              'created_at', lal.created_at
            ) as log_data
            FROM lead_access_logs lal
            WHERE lal.user_id = p_user_id
            ORDER BY lal.created_at DESC
            LIMIT 20
          ) as logs
          ), '[]'::json
        )
      )
      FROM user_lead_credits ulc
      WHERE ulc.user_id = p_user_id
    ),
    'subscriptions', COALESCE(
      (SELECT json_agg(sub_data)
      FROM (
        SELECT json_build_object(
          'id', us.id,
          'plan_name', sp.name,
          'plan_description', sp.description,
          'credits_added', us.credits_added,
          'amount', sp.price_inr,
          'status', us.status,
          'starts_at', us.starts_at,
          'expires_at', us.expires_at,
          'created_at', us.created_at,
          'razorpay_payment_id', us.razorpay_payment_id
        ) as sub_data
        FROM user_subscriptions us
        LEFT JOIN subscription_plans sp ON us.plan_id = sp.id
        WHERE us.user_id = p_user_id
        ORDER BY us.created_at DESC
      ) as subs
      ), '[]'::json
    ),
    'referral_stats', (
      SELECT json_build_object(
        'referral_code', COALESCE(MAX(rc.code), ''),
        'total_referrals', COUNT(DISTINCT r.id),
        'successful_referrals', COUNT(DISTINCT CASE WHEN r.status = 'completed' THEN r.id END),
        'pending_referrals', COUNT(DISTINCT CASE WHEN r.status = 'pending' THEN r.id END),
        'total_credits_earned', COALESCE(SUM(DISTINCT rt.credits_amount), 0)
      )
      FROM referral_codes rc
      LEFT JOIN referrals r ON rc.id = r.referral_code_id
      LEFT JOIN referral_transactions rt ON r.id = rt.referral_id AND rt.user_id = p_user_id
      WHERE rc.user_id = p_user_id
    ),
    'referral_transactions', COALESCE(
      (SELECT json_agg(trans_data)
      FROM (
        SELECT json_build_object(
          'id', rt.id,
          'credits_amount', rt.credits_amount,
          'transaction_type', rt.transaction_type,
          'created_at', rt.created_at,
          'referee_name', (SELECT full_name FROM profiles WHERE id = r.referee_id),
          'status', r.status
        ) as trans_data
        FROM referral_transactions rt
        LEFT JOIN referrals r ON rt.referral_id = r.id
        WHERE rt.user_id = p_user_id
        ORDER BY rt.created_at DESC
      ) as trans
      ), '[]'::json
    ),
    'business_registration', (
      SELECT json_build_object(
        'id', br.id,
        'business_name', br.business_name,
        'business_type_name', bt.name,
        'registration_number', br.registration_number,
        'vat_gst_number', br.vat_gst_number,
        'website', br.website,
        'business_address', br.business_address,
        'cities_served', br.cities_served,
        'service_area', br.service_area,
        'years_in_business', br.years_in_business,
        'sub_business_types', br.sub_business_types,
        'about_services', br.about_services,
        'contact_name', br.contact_name,
        'phone_number', br.phone_number,
        'email_address', br.email_address,
        'alternate_contact', br.alternate_contact,
        'preferred_communication', br.preferred_communication,
        'linkedin_profile', br.linkedin_profile,
        'facebook_page', br.facebook_page,
        'instagram_handle', br.instagram_handle,
        'other_links', br.other_links,
        'business_license_url', br.business_license_url,
        'government_id_url', br.government_id_url,
        'business_certificate_url', br.business_certificate_url,
        'insurance_certificate_url', br.insurance_certificate_url,
        'bank_name', br.bank_name,
        'account_number', br.account_number,
        'account_type', br.account_type,
        'ifsc_code', br.ifsc_code,
        'status', br.status,
        'rejection_reason', br.rejection_reason,
        'created_at', br.created_at,
        'updated_at', br.updated_at
      )
      FROM business_registrations br
      LEFT JOIN business_types bt ON br.business_type_id = bt.id
      WHERE br.user_id = p_user_id
      ORDER BY br.created_at DESC
      LIMIT 1
    )
  ) INTO result;

  RETURN result;
END;
$$;

-- Admin helper to update a business registration with controlled fields
CREATE OR REPLACE FUNCTION admin_update_business_registration(
  p_registration_id UUID,
  p_data JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated_row business_registrations;
BEGIN
  UPDATE public.business_registrations
  SET
    business_name = COALESCE(p_data->>'business_name', business_name),
    registration_number = COALESCE(p_data->>'registration_number', registration_number),
    vat_gst_number = COALESCE(p_data->>'vat_gst_number', vat_gst_number),
    website = COALESCE(p_data->>'website', website),
    business_address = COALESCE(p_data->>'business_address', business_address),
    service_area = COALESCE(p_data->>'service_area', service_area),
    years_in_business = COALESCE((p_data->>'years_in_business')::INT, years_in_business),
    about_services = COALESCE(p_data->>'about_services', about_services),
    contact_name = COALESCE(p_data->>'contact_name', contact_name),
    phone_number = COALESCE(p_data->>'phone_number', phone_number),
    email_address = COALESCE(p_data->>'email_address', email_address),
    alternate_contact = COALESCE(p_data->>'alternate_contact', alternate_contact),
    status = COALESCE(p_data->>'status', status),
    rejection_reason = COALESCE(p_data->>'rejection_reason', rejection_reason),
    cities_served = COALESCE(
      (SELECT ARRAY(SELECT jsonb_array_elements_text(p_data->'cities_served'))),
      cities_served
    ),
    sub_business_types = COALESCE(
      (SELECT ARRAY(SELECT jsonb_array_elements_text(p_data->'sub_business_types'))),
      sub_business_types
    ),
    preferred_communication = COALESCE(p_data->>'preferred_communication', preferred_communication),
    linkedin_profile = COALESCE(p_data->>'linkedin_profile', linkedin_profile),
    facebook_page = COALESCE(p_data->>'facebook_page', facebook_page),
    instagram_handle = COALESCE(p_data->>'instagram_handle', instagram_handle),
    other_links = COALESCE(
      (SELECT ARRAY(SELECT jsonb_array_elements_text(p_data->'other_links'))),
      other_links
    ),
    bank_name = COALESCE(p_data->>'bank_name', bank_name),
    account_number = COALESCE(p_data->>'account_number', account_number),
    account_type = COALESCE(p_data->>'account_type', account_type),
    ifsc_code = COALESCE(p_data->>'ifsc_code', ifsc_code),
    updated_at = NOW()
  WHERE id = p_registration_id
  RETURNING * INTO updated_row;

  RETURN to_json(updated_row);
END;
$$;

-- Admin helper to create a business registration for a provider
CREATE OR REPLACE FUNCTION admin_create_business_registration(
  p_user_id UUID,
  p_data JSONB
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_business_type_id UUID;
  inserted_row business_registrations;
BEGIN
  -- Resolve business type by name if provided
  IF p_data ? 'business_type_name' THEN
    SELECT id INTO v_business_type_id
    FROM public.business_types
    WHERE name = p_data->>'business_type_name'
    LIMIT 1;
  END IF;

  -- Fallback to provided id
  IF v_business_type_id IS NULL AND p_data ? 'business_type_id' THEN
    v_business_type_id := (p_data->>'business_type_id')::UUID;
  END IF;

  IF v_business_type_id IS NULL THEN
    RAISE EXCEPTION 'business_type not found';
  END IF;

  INSERT INTO public.business_registrations (
    user_id,
    business_name,
    business_type_id,
    registration_number,
    vat_gst_number,
    website,
    business_address,
    service_area,
    years_in_business,
    about_services,
    contact_name,
    phone_number,
    email_address,
    alternate_contact,
    preferred_communication,
    linkedin_profile,
    facebook_page,
    instagram_handle,
    other_links,
    business_license_url,
    government_id_url,
    business_certificate_url,
    insurance_certificate_url,
    cities_served,
    sub_business_types,
    status,
    rejection_reason,
    bank_name,
    account_number,
    account_type,
    ifsc_code
  ) VALUES (
    p_user_id,
    p_data->>'business_name',
    v_business_type_id,
    p_data->>'registration_number',
    p_data->>'vat_gst_number',
    p_data->>'website',
    p_data->>'business_address',
    p_data->>'service_area',
    COALESCE((p_data->>'years_in_business')::INT, 0),
    p_data->>'about_services',
    p_data->>'contact_name',
    p_data->>'phone_number',
    p_data->>'email_address',
    p_data->>'alternate_contact',
    p_data->>'preferred_communication',
    p_data->>'linkedin_profile',
    p_data->>'facebook_page',
    p_data->>'instagram_handle',
    CASE WHEN p_data ? 'other_links' THEN (SELECT ARRAY(SELECT jsonb_array_elements_text(p_data->'other_links'))) ELSE NULL END,
    COALESCE(p_data->>'business_license_url', 'admin-upload-pending'),
    COALESCE(p_data->>'government_id_url', 'admin-upload-pending'),
    p_data->>'business_certificate_url',
    p_data->>'insurance_certificate_url',
    CASE WHEN p_data ? 'cities_served' THEN (SELECT ARRAY(SELECT jsonb_array_elements_text(p_data->'cities_served'))) ELSE ARRAY[]::text[] END,
    CASE WHEN p_data ? 'sub_business_types' THEN (SELECT ARRAY(SELECT jsonb_array_elements_text(p_data->'sub_business_types'))) ELSE ARRAY[]::text[] END,
    COALESCE(p_data->>'status', 'pending'),
    p_data->>'rejection_reason',
    p_data->>'bank_name',
    p_data->>'account_number',
    p_data->>'account_type',
    p_data->>'ifsc_code'
  )
  RETURNING * INTO inserted_row;

  RETURN to_json(inserted_row);
END;
$$;
