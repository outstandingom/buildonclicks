-- Drop first to avoid return type mismatch
DROP FUNCTION IF EXISTS public.get_approved_business_listings();

-- Extend get_approved_business_listings to include user_id so client can attach reports to providers
CREATE OR REPLACE FUNCTION public.get_approved_business_listings()
RETURNS TABLE(
  id uuid,
  user_id uuid,
  business_name text,
  about_services text,
  cities_served text[],
  service_area text,
  years_in_business integer,
  website text,
  sub_business_types text[],
  business_type text,
  created_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    br.id,
    br.user_id,
    br.business_name,
    br.about_services,
    br.cities_served,
    br.service_area,
    br.years_in_business,
    br.website,
    br.sub_business_types,
    bt.name as business_type,
    br.created_at
  FROM public.business_registrations br
  LEFT JOIN public.business_types bt ON br.business_type_id = bt.id
  WHERE br.status = 'approved'
  ORDER BY br.created_at DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_approved_business_listings() TO anon, authenticated;
